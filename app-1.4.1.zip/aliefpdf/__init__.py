"""ALIEF PDF EDITOR PRO - PDF viewer & editor for engineering documents.

PT. ALIEF ENERGY UTAMA - Naval Architect & Marine Engineer Consultant, Batam.
Rendering engine: MuPDF (via PyMuPDF), the same engine used by SumatraPDF.
"""

APP_NAME = "ALIEF PDF EDITOR PRO"
APP_CODE = "ALIEF_PDFEDITPRO"
VERSION = "1.4.1"
COMPANY = "PT. ALIEF ENERGY UTAMA"
COMPANY_CITY = "Batam"
