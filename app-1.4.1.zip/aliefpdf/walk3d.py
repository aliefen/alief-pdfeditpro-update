"""First-person Walk / Fly navigation for the 3D review.

Walk: the eye stays at a set height above the deck / floor under it, climbs stairs
and steps up to the step height, falls down openings, and stops (sliding along) at
walls. Fly: free movement in the viewing direction (no gravity).

Keyboard: W/S or Up/Down = forward/back, A/D = sideways, Left/Right = turn,
Q/E or PgDn/PgUp = down/up (Fly), Shift = run, Ctrl = slow.
Mouse: drag = look around, right-drag = forward/back, middle-drag = sideways/up,
wheel = step, double-click = stand on the floor / move to the point clicked."""

import math
import time

import numpy as np
from PySide6.QtCore import Qt, QTimer, QElapsedTimer

UNIT_M = {"mm": 0.001, "cm": 0.01, "m": 1.0, "in": 0.0254, "ft": 0.3048}
GRAVITY_M = 9.81


# ----------------------------------------------------------------- ray index
class WalkIndex:
    """Uniform grid (in the horizontal plane) over the triangles of the visible parts,
    for fast floor / wall ray casts while walking."""

    MAX_CELLS = 256
    BIG_CELLS = 4096

    def __init__(self, parts, up):
        self.up = np.asarray(up, float) / (np.linalg.norm(up) or 1.0)
        self.e1, self.e2 = horizontal_basis(self.up)
        tris = [np.asarray(p.tri, np.float64).reshape(-1, 3, 3) for p in parts
                if p.visible and p.tri is not None and len(p.tri)]
        if not tris:
            self.n = 0
            return
        T = np.concatenate(tris)
        T = T[np.isfinite(T).all(axis=(1, 2))]
        self.n = len(T)
        if not self.n:
            return
        self.v0 = T[:, 0].copy()
        self.e_1 = T[:, 1] - T[:, 0]
        self.e_2 = T[:, 2] - T[:, 0]
        nrm = np.cross(self.e_1, self.e_2)
        ln = np.linalg.norm(nrm, axis=1)
        ln[ln == 0] = 1.0
        self.nrm = nrm / ln[:, None]
        U = T @ self.e1
        V = T @ self.e2
        umin, umax = U.min(axis=1), U.max(axis=1)
        vmin, vmax = V.min(axis=1), V.max(axis=1)
        self.u0, self.v0g = float(umin.min()), float(vmin.min())
        span = max(float(umax.max() - self.u0), float(vmax.max() - self.v0g), 1e-9)
        g = int(min(self.MAX_CELLS, max(8, math.sqrt(self.n) * 1.5)))
        self.g = g
        self.cell = span / g * 1.000001
        i0 = np.clip(((umin - self.u0) / self.cell).astype(np.int64), 0, g - 1)
        i1 = np.clip(((umax - self.u0) / self.cell).astype(np.int64), 0, g - 1)
        j0 = np.clip(((vmin - self.v0g) / self.cell).astype(np.int64), 0, g - 1)
        j1 = np.clip(((vmax - self.v0g) / self.cell).astype(np.int64), 0, g - 1)
        w = i1 - i0 + 1
        h = j1 - j0 + 1
        cnt = w * h
        big = cnt > self.BIG_CELLS
        self.big = np.nonzero(big)[0]
        keep = np.nonzero(~big)[0]
        c = cnt[keep]
        tri_ids = np.repeat(keep, c)
        starts = np.repeat(np.cumsum(c) - c, c)
        off = np.arange(len(tri_ids)) - starts
        ww = np.repeat(w[keep], c)
        ci = np.repeat(i0[keep], c) + off % ww
        cj = np.repeat(j0[keep], c) + off // ww
        cells = ci * g + cj
        order = np.argsort(cells, kind="stable")
        self.ids = tri_ids[order].astype(np.int64)
        counts = np.bincount(cells, minlength=g * g)
        self.ptr = np.concatenate([[0], np.cumsum(counts)])

    def _cells_on_segment(self, a, b):
        ua, va = (a @ self.e1 - self.u0) / self.cell, (a @ self.e2 - self.v0g) / self.cell
        ub, vb = (b @ self.e1 - self.u0) / self.cell, (b @ self.e2 - self.v0g) / self.cell
        n = int(max(abs(ub - ua), abs(vb - va)) * 2) + 2
        n = min(n, 4 * self.g)
        s = np.linspace(0.0, 1.0, n)
        us = ua + (ub - ua) * s
        vs = va + (vb - va) * s
        out = set()
        for du in (-0.5, 0.5):
            for dv in (-0.5, 0.5):
                i = np.floor(us + du * 0.02).astype(np.int64)
                j = np.floor(vs + dv * 0.02).astype(np.int64)
                ok = (i >= 0) & (i < self.g) & (j >= 0) & (j < self.g)
                out.update((i[ok] * self.g + j[ok]).tolist())
        return out

    def candidates(self, a, b):
        cells = self._cells_on_segment(a, b)
        if not cells:
            return self.big
        parts = [self.ids[self.ptr[c]:self.ptr[c + 1]] for c in cells]
        parts.append(self.big)
        return np.unique(np.concatenate(parts)) if parts else self.big

    def ray(self, o, d, tmax):
        """Nearest hit within tmax: (t, normal) or None. d must be a unit vector."""
        if not self.n:
            return None
        o = np.asarray(o, float)
        d = np.asarray(d, float)
        idx = self.candidates(o, o + d * tmax)
        if not len(idx):
            return None
        v0 = self.v0[idx]
        e1 = self.e_1[idx]
        e2 = self.e_2[idx]
        pv = np.cross(d, e2)
        det = (e1 * pv).sum(axis=1)
        ok = np.abs(det) > 1e-18
        inv = np.where(ok, 1.0 / np.where(ok, det, 1.0), 0.0)
        tv = o - v0
        u = (tv * pv).sum(axis=1) * inv
        ok &= (u >= -1e-7) & (u <= 1 + 1e-7)
        qv = np.cross(tv, e1)
        v = (qv @ d) * inv
        ok &= (v >= -1e-7) & (u + v <= 1 + 1e-7)
        t = (e2 * qv).sum(axis=1) * inv
        ok &= (t > 1e-9) & (t <= tmax)
        if not ok.any():
            return None
        k = np.nonzero(ok)[0]
        k = k[np.argmin(t[k])]
        n = self.nrm[idx[k]]
        if np.dot(n, d) > 0:
            n = -n
        return float(t[k]), n


def horizontal_basis(up):
    up = np.asarray(up, float)
    up = up / (np.linalg.norm(up) or 1.0)
    if abs(up[2]) > 0.9:
        e1 = np.array([1.0, 0.0, 0.0])
    elif abs(up[1]) > 0.9:
        e1 = np.array([0.0, 0.0, 1.0])
    else:
        e1 = np.cross(up, [0.0, 0.0, 1.0])
    e1 = e1 - up * np.dot(e1, up)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(up, e1)
    return e1, e2


# ----------------------------------------------------------------- controller
class WalkController:
    def __init__(self, gl):
        self.gl = gl
        self.mode = None              # None / "walk" / "fly"
        self.eye = np.zeros(3)
        self.yaw = 0.0
        self.pitch = 0.0
        self.eye_height = 1.6         # model units (set by configure)
        self.speed = 1.4              # model units / s
        self.m_per_unit = 1.0
        self.gravity = True
        self.collide = True
        self.fog = True
        self.fov = 60.0
        self.grounded = False
        self.vz = 0.0
        self.keys = set()
        self._index = None
        self._index_sig = None
        self._saved = None
        self._timer = QTimer()
        self._timer.setInterval(15)
        self._timer.timeout.connect(self._tick)
        self._clock = QElapsedTimer()
        self.on_status = None

    # ---- configuration ---------------------------------------------------
    @property
    def active(self):
        return self.mode is not None

    def scene_size(self):
        lo, hi = self.gl.bounds(False)
        return float(np.linalg.norm(hi - lo)) or 1.0

    def default_scale(self, unit, unit_scale):
        """metres per model unit from the units of the 3D window, or a guess from the model size."""
        if unit in UNIT_M:
            return UNIT_M[unit] * (unit_scale or 1.0)
        D = self.scene_size()
        return 0.001 if D > 2000 else 1.0

    def configure(self, unit, unit_scale, eye_m=1.6, speed_m=1.4):
        self.m_per_unit = self.default_scale(unit, unit_scale)
        D = self.scene_size()
        eh = eye_m / self.m_per_unit
        self.eye_height = float(min(max(eh, D * 0.002), D * 0.3))
        self.speed = float(max(speed_m / self.m_per_unit, D * 0.004))

    @property
    def up(self):
        u = np.asarray(self.gl.up, float)
        return u / (np.linalg.norm(u) or 1.0)

    # ---- enter / leave ------------------------------------------------------
    def enter(self, mode):
        gl = self.gl
        if self.mode is None:
            self._saved = (gl.cam.fov, gl.cam.ortho)
        self.mode = mode
        gl.cam.ortho = False
        gl.cam.fov = self.fov
        self.sync_from_camera()
        self.grounded = False
        self.vz = 0.0
        if mode == "walk" and self.gravity and self._inside_box():
            self._land(snap=True)
        self._apply()
        if not self._inside_box():
            self._msg("You are outside the model: double-click a deck to stand on it (hide the roof / shell in the model "
                      "tree to reach the inside), or choose an inside view. W A S D = move, drag = look around.")
        elif mode == "walk" and not self.grounded:
            self._msg("Double-click a deck or floor to stand there. W A S D = walk, drag = look around, Shift = run.")

    def leave(self):
        if self.mode is None:
            return
        gl = self.gl
        self.mode = None
        self.keys.clear()
        self._timer.stop()
        fov, ortho = self._saved or (30.0, False)
        f = self.forward()
        hit = gl.pick(gl.width() / 2.0, gl.height() / 2.0) if gl.model is not None else None
        dist = float(hit["t"]) if hit is not None else self.scene_size() * 0.25
        dist = max(dist, self.eye_height)
        gl.cam.fov = fov
        gl.cam.ortho = ortho
        gl.cam.target = self.eye + f * dist
        gl.cam.dist = dist
        gl.cam.ortho_h = 2 * math.tan(math.radians(fov) / 2) * dist
        gl.camera_changed.emit()
        gl.update()

    def _inside_box(self):
        lo, hi = self.gl.bounds(False)
        pad = (hi - lo) * 0.02
        return bool(np.all(self.eye >= lo - pad) and np.all(self.eye <= hi + pad))

    # ---- camera <-> eye / yaw / pitch ------------------------------------------
    def sync_from_camera(self):
        cam = self.gl.cam
        self.eye = np.asarray(cam.eye, float).copy()
        f = -cam.R[:, 2]
        e1, e2 = horizontal_basis(self.up)
        self.pitch = math.degrees(math.asin(max(-1.0, min(1.0, float(np.dot(f, self.up))))))
        self.pitch = max(-85.0, min(85.0, self.pitch))
        self.yaw = math.degrees(math.atan2(float(np.dot(f, e2)), float(np.dot(f, e1))))

    def forward(self, horizontal=False):
        e1, e2 = horizontal_basis(self.up)
        y = math.radians(self.yaw)
        h = math.cos(y) * e1 + math.sin(y) * e2
        if horizontal:
            return h
        p = math.radians(self.pitch)
        return math.cos(p) * h + math.sin(p) * self.up

    def right(self):
        r = np.cross(self.forward(True), self.up)
        return r / (np.linalg.norm(r) or 1.0)

    def _apply(self):
        cam = self.gl.cam
        f = self.forward()
        r = np.cross(f, self.up)
        r /= np.linalg.norm(r) or 1.0
        u = np.cross(r, f)
        cam.R = np.column_stack([r, u, -f])
        d0 = max(self.eye_height * 0.5, 1e-6)
        cam.dist = d0
        cam.target = self.eye + f * d0
        cam.fov = self.fov
        cam.ortho = False
        self.gl.camera_changed.emit()
        self.gl.update()

    def near_far(self):
        D = self.scene_size()
        lo, hi = self.gl.bounds(False)
        c = (lo + hi) / 2
        far = float(np.linalg.norm(self.eye - c)) + D * 1.2
        near = max(self.eye_height * 0.01, D * 2e-6)
        return near, max(far, near * 10)

    def fog_density(self):
        if not (self.fog and self.active):
            return 0.0
        # fade over about 25 m (or half the model), whichever is shorter
        reach = min(25.0 / self.m_per_unit, self.scene_size() * 0.6)
        return 0.9 / max(reach, 1e-9)

    def light_attenuation(self):
        """1 / range of the head torch used by the Interior lighting (range about 7 m)."""
        reach = min(7.0 / self.m_per_unit, self.scene_size() * 0.25)
        return 1.0 / max(reach, 1e-9)

    # ---- index ---------------------------------------------------------------------
    def index(self):
        m = self.gl.model
        if m is None:
            return None
        sig = (id(m), tuple(bool(p.visible) for p in m.parts), tuple(self.up))
        if self._index is None or self._index_sig != sig:
            self._index = WalkIndex(m.parts, self.up)
            self._index_sig = sig
        return self._index

    # ---- input ----------------------------------------------------------------------
    MOVE_KEYS = {Qt.Key_W, Qt.Key_S, Qt.Key_A, Qt.Key_D, Qt.Key_Q, Qt.Key_E, Qt.Key_Up, Qt.Key_Down,
                 Qt.Key_Left, Qt.Key_Right, Qt.Key_PageUp, Qt.Key_PageDown, Qt.Key_Space}

    def key_press(self, e):
        k = e.key()
        if k in self.MOVE_KEYS:
            if not e.isAutoRepeat():
                self.keys.add(k)
                self._start()
            return True
        if k in (Qt.Key_Plus, Qt.Key_Equal):
            self.speed *= 1.25
            self._msg("Speed %s" % self.speed_text())
            return True
        if k == Qt.Key_Minus:
            self.speed /= 1.25
            self._msg("Speed %s" % self.speed_text())
            return True
        return False

    def key_release(self, e):
        if e.isAutoRepeat():
            return e.key() in self.MOVE_KEYS
        if e.key() in self.keys:
            self.keys.discard(e.key())
            return True
        return False

    def focus_lost(self):
        self.keys.clear()

    def look(self, dx, dy):
        self.yaw -= dx * 0.22
        self.pitch = max(-85.0, min(85.0, self.pitch - dy * 0.22))
        self._apply()

    def dolly(self, dy):
        step = -dy * self.speed * 0.01
        self._move(self.forward(self.mode == "walk") * step)
        self._apply()

    def strafe(self, dx, dy):
        k = self.speed * 0.01
        mv = self.right() * dx * k
        if self.mode == "fly" or not self.gravity:
            mv = mv - self.up * dy * k
        self._move(mv)
        self._apply()

    def wheel(self, steps):
        self._move(self.forward(self.mode == "walk") * steps * self.speed * 0.35)
        if self.mode == "walk" and self.gravity and self.grounded:
            self._land()
        self._apply()

    def stand_at(self, hit):
        """Double-click: stand on the floor clicked, or walk up to the wall / object clicked."""
        P = np.asarray(hit["point"], float)
        n = hit.get("normal")
        n = np.asarray(n, float) if n is not None else -self.forward()
        if np.dot(n, self.eye - P) < 0:
            n = -n
        up = self.up
        if self.mode == "walk" and float(np.dot(n, up)) > 0.6:
            self.eye = P + up * self.eye_height
            self.grounded = True
            self.vz = 0.0
            self._msg("Standing on %s. W A S D = walk, drag = look around." % (hit["part"].name if hit.get("part") else "the floor"))
        else:
            back = self.eye_height * 0.6
            target = P + n * back
            if self.mode == "walk":
                target = target - up * np.dot(target - self.eye, up)     # keep the eye height
            self.eye = target
            if self.mode == "walk" and self.gravity:
                self._land(snap=True)
        self._apply()

    # ---- motion ---------------------------------------------------------------------
    def _start(self):
        if not self._timer.isActive():
            self._clock.start()
            self._timer.start()

    def _tick(self):
        if not self.active:
            self._timer.stop()
            return
        dt = min(self._clock.restart() / 1000.0, 0.1)
        if dt <= 0:
            return
        from PySide6.QtWidgets import QApplication
        mods = QApplication.keyboardModifiers()
        sp = self.speed * (3.0 if mods & Qt.ShiftModifier else 1.0) * (0.25 if mods & Qt.ControlModifier else 1.0)
        K = self.keys
        fwd = (1 if (Qt.Key_W in K or Qt.Key_Up in K) else 0) - (1 if (Qt.Key_S in K or Qt.Key_Down in K) else 0)
        side = (1 if Qt.Key_D in K else 0) - (1 if Qt.Key_A in K else 0)
        turn = (1 if Qt.Key_Right in K else 0) - (1 if Qt.Key_Left in K else 0)
        vert = (1 if (Qt.Key_E in K or Qt.Key_PageUp in K or Qt.Key_Space in K) else 0) - \
               (1 if (Qt.Key_Q in K or Qt.Key_PageDown in K) else 0)
        if turn:
            self.yaw -= turn * 75.0 * dt
        walk = self.mode == "walk"
        mv = self.forward(walk) * fwd + self.right() * side
        ln = np.linalg.norm(mv)
        if ln > 1e-9:
            mv = mv / ln * sp * dt
        else:
            mv = np.zeros(3)
        if vert and (not walk or not self.gravity or not self.grounded):
            mv = mv + self.up * vert * sp * dt
            if walk:
                self.grounded = False
        moving = bool(fwd or side or turn or vert)
        if np.linalg.norm(mv) > 0:
            self._move(mv)
        falling = False
        if walk and self.gravity and self.grounded:
            falling = self._land(dt=dt)
        self._apply()
        if not moving and not falling:
            self._timer.stop()

    def _move(self, mv):
        if not self.collide:
            self.eye = self.eye + mv
            return
        idx = self.index()
        if idx is None or not idx.n:
            self.eye = self.eye + mv
            return
        radius = self.eye_height * 0.18
        up = self.up
        for _ in range(3):
            L = float(np.linalg.norm(mv))
            if L < 1e-12:
                return
            d = mv / L
            origins = [self.eye]
            if self.mode == "walk":
                step = self.eye_height * 0.28
                origins.append(self.eye - up * (self.eye_height - step))      # just above the step height
                origins.append(self.eye - up * (self.eye_height * 0.5))       # chest
            hit = None
            for o in origins:
                h = idx.ray(o, d, L + radius)
                if h is not None and (hit is None or h[0] < hit[0]):
                    hit = h
            if hit is None:
                self.eye = self.eye + mv
                return
            t, n = hit
            if self.mode == "walk":
                n = n - up * np.dot(n, up)
                nl = np.linalg.norm(n)
                if nl < 1e-6:
                    self.eye = self.eye + mv
                    return
                n = n / nl
            # move up to the wall, then slide along it
            allowed = max(0.0, t - radius)
            self.eye = self.eye + d * min(allowed, L)
            rest = mv - d * min(allowed, L)
            mv = rest - n * np.dot(rest, n)

    def _land(self, dt=None, snap=False):
        """Keep the eye at eye_height above the floor below; returns True while falling / climbing."""
        idx = self.index()
        if idx is None or not idx.n:
            return False
        up = self.up
        step = self.eye_height * 0.28
        probe = self.eye - up * (self.eye_height - step)
        h = idx.ray(probe, -up, self.scene_size() * 1.5)
        if h is None:
            if snap:
                return False
            lo, hi = self.gl.bounds(False)
            # nothing below: fall, but never far below the model
            if float(np.dot(self.eye, up)) < float(np.min([np.dot(lo, up), np.dot(hi, up)])) - self.eye_height * 2:
                return False
            target = None
        else:
            target = probe - up * h[0] + up * self.eye_height
        if snap:
            if target is not None:
                self.eye = target
                self.grounded = True
                self.vz = 0.0
            return False
        if target is None:
            g = GRAVITY_M / self.m_per_unit
            self.vz = min(self.vz + g * (dt or 0.016), g * 2.0)
            self.eye = self.eye - up * self.vz * (dt or 0.016)
            return True
        dz = float(np.dot(target - self.eye, up))
        if dz > 1e-9:                                           # step / stairs up
            self.vz = 0.0
            k = min(1.0, (dt or 0.016) * 14.0)
            self.eye = self.eye + up * dz * k
            return dz * (1 - k) > self.eye_height * 0.002
        if dz < -1e-9:                                          # floor lower: fall
            g = GRAVITY_M / self.m_per_unit
            self.vz = min(self.vz + g * (dt or 0.016), g * 2.0)
            fall = min(self.vz * (dt or 0.016), -dz)
            self.eye = self.eye - up * fall
            if fall >= -dz - 1e-12:
                self.vz = 0.0
                return False
            return True
        self.vz = 0.0
        return False

    # ---- text ------------------------------------------------------------------------
    def speed_text(self):
        return "%.2f m/s" % (self.speed * self.m_per_unit)

    def hud(self):
        if not self.active:
            return ""
        s = "%s  ·  %s  ·  eye %.2f m" % ("WALK" if self.mode == "walk" else "FLY", self.speed_text(),
                                          self.eye_height * self.m_per_unit)
        if self.mode == "walk" and self.gravity and not self.grounded:
            s += "  ·  double-click a floor to stand"
        return s

    def _msg(self, text):
        try:
            self.gl.status.emit(text)
        except Exception:
            pass
