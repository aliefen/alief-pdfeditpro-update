# -*- coding: utf-8 -*-
"""
OpenGL 3D review canvas (QOpenGLWidget, GLSL 1.20 so it runs on any
desktop OpenGL 2.1+ driver and on Qt's software renderer).

Features: orbit / pan / zoom with the mouse, fit, standard and PDF views,
perspective / orthographic projection, the PDF render modes (solid,
wireframe, transparent, illustration, outline, vertices, bounding box ...),
lighting schemes, section plane with filled caps and section outline,
selection highlight, picking with vertex / edge snapping for measurements,
and an overlay for measurements and 3D comment markers.
"""
from __future__ import annotations

import math

import numpy as np
from PySide6.QtCore import Qt, Signal, QPointF, QRectF, QTimer
from PySide6.QtGui import QMatrix4x4, QVector3D, QPainter, QPen, QColor, QFont, QBrush, QPainterPath, QFontMetricsF
from . import glsupport
glsupport.ensure()
from PySide6.QtOpenGL import QOpenGLShaderProgram, QOpenGLShader, QOpenGLBuffer
from PySide6.QtOpenGLWidgets import QOpenGLWidget

from .scene3d import Camera, look_camera

GL_TRIANGLES, GL_LINES, GL_POINTS = 0x0004, 0x0001, 0x0000
GL_DEPTH_TEST, GL_BLEND, GL_CULL_FACE = 0x0B71, 0x0BE2, 0x0B44
GL_POLYGON_OFFSET_FILL = 0x8037
GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA = 0x0302, 0x0303
GL_COLOR_BUFFER_BIT, GL_DEPTH_BUFFER_BIT = 0x4000, 0x0100
GL_FLOAT = 0x1406
GL_LEQUAL, GL_LESS = 0x0203, 0x0201
GL_PROGRAM_POINT_SIZE = 0x8642
GL_BACK = 0x0405
GL_MULTISAMPLE = 0x809D

VS_MESH = """
#version 120
attribute vec3 a_pos;
attribute vec3 a_nrm;
attribute vec4 a_col;
uniform mat4 u_mvp;
uniform mat4 u_view;
uniform vec4 u_color;
uniform float u_usevc;
varying vec3 v_n;
varying vec3 v_world;
varying vec3 v_eye;
varying vec4 v_col;
void main() {
    v_world = a_pos;
    v_n = (u_view * vec4(a_nrm, 0.0)).xyz;
    v_eye = (u_view * vec4(a_pos, 1.0)).xyz;
    v_col = mix(u_color, vec4(a_col.rgb, u_color.a), u_usevc);
    gl_Position = u_mvp * vec4(a_pos, 1.0);
}
"""

FS_MESH = """
#version 120
uniform vec4 u_plane;
uniform float u_clip;
uniform vec3 u_capcol;
uniform float u_lit;
uniform float u_alpha;
uniform vec3 u_ldir[4];
uniform vec3 u_lcol[4];
uniform float u_nl;
uniform vec3 u_amb;
uniform float u_hl;
uniform vec3 u_hlcol;
uniform float u_spec;
uniform float u_flat;
uniform float u_fog;
uniform vec3 u_fogcol;
uniform float u_att;
varying vec3 v_n;
varying vec3 v_world;
varying vec3 v_eye;
varying vec4 v_col;
void main() {
    if (u_clip > 0.5 && dot(u_plane.xyz, v_world) + u_plane.w > 0.0) discard;
    vec3 n = normalize(v_n);
    if (!gl_FrontFacing) {
        if (u_clip > 0.5) { gl_FragColor = vec4(mix(u_capcol, u_hlcol, u_hl * 0.6), 1.0); return; }
        n = -n;
    }
    vec3 base = v_col.rgb;
    vec3 c = base;
    if (u_lit > 0.5) {
        vec3 V = normalize(-v_eye);
        float ad = length(v_eye) * u_att;
        float att = 1.0 / (1.0 + ad * ad);
        c = u_amb * base * mix(1.0, 0.55 + 0.45 * att, step(0.0000001, u_att));
        for (int i = 0; i < 4; i++) {
            float on = step(float(i) + 0.5, u_nl);
            if (i == 1) on *= mix(1.0, att, step(0.0000001, u_att));
            vec3 L = normalize(u_ldir[i]);
            float d = max(dot(n, L), 0.0);
            vec3 H = normalize(L + V);
            float s = pow(max(dot(n, H), 0.0), 48.0) * u_spec;
            c += on * u_lcol[i] * (base * d + vec3(s));
        }
    }
    c = mix(c, u_flat * vec3(1.0) + (1.0 - u_flat) * c, u_flat);
    c = mix(c, u_hlcol, u_hl);
    float fd = length(v_eye) * u_fog;
    c = mix(u_fogcol, c, exp(-fd * fd));
    gl_FragColor = vec4(c, v_col.a * u_alpha);
}
"""

VS_LINE = """
#version 120
attribute vec3 a_pos;
attribute vec4 a_col;
uniform mat4 u_mvp;
uniform vec4 u_color;
uniform float u_usevc;
uniform float u_psize;
varying vec3 v_world;
varying vec4 v_col;
varying float v_dist;
void main() {
    v_world = a_pos;
    v_col = mix(u_color, a_col, u_usevc);
    gl_Position = u_mvp * vec4(a_pos, 1.0);
    v_dist = gl_Position.w;
    gl_PointSize = u_psize;
}
"""

FS_LINE = """
#version 120
uniform vec4 u_plane;
uniform float u_clip;
uniform float u_alpha;
uniform float u_fog;
uniform vec3 u_fogcol;
varying vec3 v_world;
varying vec4 v_col;
varying float v_dist;
void main() {
    if (u_clip > 0.5 && dot(u_plane.xyz, v_world) + u_plane.w > 0.0) discard;
    float fd = v_dist * u_fog;
    gl_FragColor = vec4(mix(u_fogcol, v_col.rgb, exp(-fd * fd)), v_col.a * u_alpha);
}
"""

STD_VIEWS = {
    # name: (view direction, up) for a Z-up world
    "Front": ((0, 1, 0), (0, 0, 1)),
    "Back": ((0, -1, 0), (0, 0, 1)),
    "Left": ((1, 0, 0), (0, 0, 1)),
    "Right": ((-1, 0, 0), (0, 0, 1)),
    "Top": ((0, 0, -1), (0, 1, 0)),
    "Bottom": ((0, 0, 1), (0, -1, 0)),
    "Isometric": ((-1, 1, -1), (0, 0, 1)),
    "Isometric (back)": ((1, -1, -1), (0, 0, 1)),
}

LIGHT_SCHEMES = {
    # name: (ambient, [(dir in eye space, colour)], specular)
    "Headlamp": ((0.22, 0.22, 0.22), [((0.0, 0.0, 1.0), (0.85, 0.85, 0.85))], 0.25),
    "CAD": ((0.25, 0.25, 0.27), [((0.3, 0.5, 1.0), (0.65, 0.65, 0.65)), ((-0.6, -0.2, 0.6), (0.3, 0.3, 0.32)),
                                  ((0.0, -0.8, 0.2), (0.12, 0.12, 0.14))], 0.3),
    "White": ((0.3, 0.3, 0.3), [((0.4, 0.6, 1.0), (0.6, 0.6, 0.6)), ((-0.5, -0.4, 0.7), (0.35, 0.35, 0.35))], 0.2),
    "Day": ((0.3, 0.3, 0.32), [((0.2, 0.9, 0.6), (0.75, 0.72, 0.65)), ((-0.6, -0.3, 0.6), (0.25, 0.28, 0.33))], 0.25),
    "Night": ((0.08, 0.08, 0.14), [((0.3, 0.8, 0.5), (0.35, 0.38, 0.6))], 0.15),
    "Hard": ((0.08, 0.08, 0.08), [((0.6, 0.6, 0.6), (1.0, 1.0, 1.0))], 0.6),
    "Primary": ((0.15, 0.15, 0.15), [((1, 0.2, 0.5), (0.7, 0.15, 0.15)), ((-1, 0.2, 0.5), (0.15, 0.6, 0.15)),
                                      ((0, 1, 0.5), (0.15, 0.2, 0.7))], 0.2),
    "Blue": ((0.12, 0.14, 0.25), [((0.3, 0.6, 1.0), (0.45, 0.55, 0.95))], 0.2),
    "Red": ((0.25, 0.1, 0.1), [((0.3, 0.6, 1.0), (0.95, 0.45, 0.4))], 0.2),
    "Cube": ((0.2, 0.2, 0.2), [((1, 0, 0.3), (0.45, 0.45, 0.45)), ((-1, 0, 0.3), (0.45, 0.45, 0.45)),
                                ((0, 1, 0.3), (0.35, 0.35, 0.35)), ((0, -1, 0.3), (0.35, 0.35, 0.35))], 0.15),
    "None": ((1.0, 1.0, 1.0), [], 0.0),
    # "Interior" (walk-through): ceiling light from the world up direction + head torch, set in paintGL
    "Interior": ((0.30, 0.30, 0.31), [((0.0, 1.0, 0.3), (0.50, 0.49, 0.47)), ((0.0, 0.0, 1.0), (0.62, 0.62, 0.60))], 0.18),
}

MODES = ["Solid", "SolidOutline", "SolidWireframe", "ShadedIllustration", "Illustration", "Transparent",
         "TransparentWireframe", "Wireframe", "HiddenWireframe", "ShadedVertices", "Vertices", "BoundingBox"]


def qmat(M):
    m = np.asarray(M, np.float32)
    return QMatrix4x4(*[float(x) for x in m.reshape(-1)])


def perspective(fovy, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy) / 2)
    M = np.zeros((4, 4))
    M[0, 0] = f / aspect
    M[1, 1] = f
    M[2, 2] = (far + near) / (near - far)
    M[2, 3] = 2 * far * near / (near - far)
    M[3, 2] = -1
    return M


def orthographic(h, aspect, near, far):
    w = h * aspect
    M = np.eye(4)
    M[0, 0] = 2.0 / w
    M[1, 1] = 2.0 / h
    M[2, 2] = -2.0 / (far - near)
    M[2, 3] = -(far + near) / (far - near)
    return M


def rotation(axis, angle):
    a = np.asarray(axis, float)
    a /= np.linalg.norm(a) or 1.0
    c, s = math.cos(angle), math.sin(angle)
    x, y, z = a
    return np.array([[c + x * x * (1 - c), x * y * (1 - c) - z * s, x * z * (1 - c) + y * s],
                     [y * x * (1 - c) + z * s, c + y * y * (1 - c), y * z * (1 - c) - x * s],
                     [z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)]])


def feature_edges(tri, angle_deg=30.0):
    """Boundary and sharp edges of a triangle soup -> (M*2,3) float32."""
    t = np.asarray(tri, np.float64).reshape(-1, 3, 3)
    nf = len(t)
    if nf == 0:
        return np.zeros((0, 3), np.float32)
    scale = float(np.abs(t).max()) * 1e-7 + 1e-12
    q = np.round(t.reshape(-1, 3) / scale).astype(np.int64)
    _, vid = np.unique(q, axis=0, return_inverse=True)
    vid = vid.ravel().reshape(-1, 3)
    fn = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    l = np.linalg.norm(fn, axis=1)
    good = l > 0
    fn[good] /= l[good, None]
    e = np.concatenate([vid[:, [0, 1]], vid[:, [1, 2]], vid[:, [2, 0]]])
    ef = np.tile(np.arange(nf), 3)
    ec = np.concatenate([np.zeros(nf, int), np.ones(nf, int), np.full(nf, 2)])
    es = np.sort(e, axis=1)
    key = es[:, 0] * (int(vid.max()) + 1) + es[:, 1]
    order = np.argsort(key, kind="stable")
    ks = key[order]
    start = np.r_[True, ks[1:] != ks[:-1]]
    gid = np.cumsum(start) - 1
    cnt = np.bincount(gid)
    first = order[start]
    keep = np.zeros(len(e), bool)
    # boundary edges (used once) or non-manifold
    single = cnt[gid] != 2
    keep[order[single & start]] = True
    # pairs: compare normals
    pair_first = order[start & (cnt[gid] == 2)]
    sec_mask = (~start) & (cnt[gid] == 2)
    pair_second = order[sec_mask]
    if len(pair_first):
        d = (fn[ef[pair_first]] * fn[ef[pair_second]]).sum(axis=1)
        sharp = d < math.cos(math.radians(angle_deg))
        keep[pair_first[sharp]] = True
    sel = np.nonzero(keep)[0]
    f = ef[sel]
    c = ec[sel]
    a = t[f, c]
    b = t[f, (c + 1) % 3]
    out = np.empty((len(sel) * 2, 3), np.float32)
    out[0::2] = a
    out[1::2] = b
    return out


def all_edges(tri):
    t = np.asarray(tri, np.float32).reshape(-1, 3, 3)
    out = np.empty((len(t) * 6, 3), np.float32)
    out[0::6] = t[:, 0]
    out[1::6] = t[:, 1]
    out[2::6] = t[:, 1]
    out[3::6] = t[:, 2]
    out[4::6] = t[:, 2]
    out[5::6] = t[:, 0]
    return out


def section_lines(tri, n, d):
    """Intersection segments of triangles with the plane n.x + d = 0."""
    t = np.asarray(tri, np.float64).reshape(-1, 3, 3)
    if len(t) == 0:
        return np.zeros((0, 3), np.float32)
    s = t @ np.asarray(n, float) + d
    pos = s > 0
    cnt = pos.sum(axis=1)
    m = (cnt == 1) | (cnt == 2)
    if not m.any():
        return np.zeros((0, 3), np.float32)
    t, s, pos = t[m], s[m], pos[m]
    # lone vertex = the one whose side differs from the other two
    lone = np.where(pos.sum(axis=1) == 1, np.argmax(pos, axis=1), np.argmin(pos, axis=1))
    i0 = lone
    i1 = (lone + 1) % 3
    i2 = (lone + 2) % 3
    r = np.arange(len(t))
    p0, p1, p2 = t[r, i0], t[r, i1], t[r, i2]
    s0, s1, s2 = s[r, i0], s[r, i1], s[r, i2]
    a = p0 + (p1 - p0) * (s0 / (s0 - s1))[:, None]
    b = p0 + (p2 - p0) * (s0 / (s0 - s2))[:, None]
    out = np.empty((len(t) * 2, 3), np.float32)
    out[0::2] = a
    out[1::2] = b
    return out


class _GPUPart:
    __slots__ = ("tri", "ntri_v", "col", "edges", "nedges", "wire", "nwire", "lines", "nlines", "lcol",
                 "points", "npoints", "bbox")

    def __init__(self):
        self.tri = self.col = self.edges = self.wire = self.lines = self.lcol = self.points = self.bbox = None
        self.ntri_v = self.nedges = self.nwire = self.nlines = self.npoints = 0


class GLView(QOpenGLWidget):
    picked = Signal(object)            # part or None
    measured = Signal(object)          # measurement dict
    point_picked = Signal(object)      # dict(point, normal, part) in comment / point modes
    status = Signal(str)
    camera_changed = Signal()
    gl_failed = Signal(str)
    nav_changed = Signal(str)          # "orbit" / "walk" / "fly"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 240)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMouseTracking(True)
        self.model = None
        self.cam = Camera()
        self.up = np.array([0.0, 0.0, 1.0])
        self.mode = "Solid"
        self.lighting = "CAD"
        self.bg_top = (1.0, 1.0, 1.0)
        self.bg_bottom = (1.0, 1.0, 1.0)
        self.edge_color = (0.08, 0.09, 0.11)
        self.select_color = (0.12, 0.55, 1.0)
        self.selected = set()
        self.ghost_others = False
        self.section = None          # dict(normal, d, show_plane, cap, outline)
        self._sec_lines = None
        self._sec_vbo = None
        self._sec_n = 0
        self.measure_mode = None     # None/"distance"/"angle"/"radius"/"point"/"comment"
        self.mpoints = []
        self.measurements = []
        self.markers = []            # comment markers [(point, label)]
        self.unit = ""
        self.unit_scale = 1.0
        self.snap = True
        self.show_axes = True
        self._gpu = {}
        self._dirty = True
        self._ok = False
        self._drag = None
        self._last = None
        self._hover = None
        self._turntable = True
        self.crease = 30.0
        self.point_size = 4.0
        self.line_width = 1.0
        from .walk3d import WalkController
        self.walk = WalkController(self)

    # ------------------------------------------------------------ model
    def set_model(self, model):
        self.model = model
        self.selected = set()
        self.measurements = []
        self.mpoints = []
        self._release_gpu()
        self._dirty = True
        self.section = None
        self._sec_lines = None
        self.fit(update=False)
        self.update()

    def _release_gpu(self):
        if not self._gpu:
            return
        try:
            self.makeCurrent()
            for g in self._gpu.values():
                for b in (g.tri, g.col, g.edges, g.wire, g.lines, g.lcol, g.points):
                    if b is not None:
                        b.destroy()
            if self._sec_vbo is not None:
                self._sec_vbo.destroy()
                self._sec_vbo = None
            self.doneCurrent()
        except Exception:
            pass
        self._gpu = {}

    # --------------------------------------------------------------- GL
    def initializeGL(self):
        try:
            self.f = self.context().functions()
            self.prog = self._program(VS_MESH, FS_MESH, ["a_pos", "a_nrm", "a_col"])
            self.lprog = self._program(VS_LINE, FS_LINE, ["a_pos", "a_col"])
            self._ok = True
            ver = self.f.glGetString(0x1F02) or ""
            ren = self.f.glGetString(0x1F01) or ""
            self.gl_info = "%s, %s" % (ren, ver)
        except Exception as e:
            self._ok = False
            self.gl_info = str(e)
            QTimer.singleShot(0, lambda: self.gl_failed.emit(str(e)))

    def _program(self, vs, fs, attrs):
        p = QOpenGLShaderProgram(self)
        if not p.addShaderFromSourceCode(QOpenGLShader.Vertex, vs):
            raise RuntimeError("vertex shader: " + p.log())
        if not p.addShaderFromSourceCode(QOpenGLShader.Fragment, fs):
            raise RuntimeError("fragment shader: " + p.log())
        for i, a in enumerate(attrs):
            p.bindAttributeLocation(a, i)
        if not p.link():
            raise RuntimeError("shader link: " + p.log())
        return p

    def _vbo(self, arr):
        a = np.ascontiguousarray(arr, np.float32)
        b = QOpenGLBuffer(QOpenGLBuffer.VertexBuffer)
        b.create()
        b.bind()
        b.allocate(a.tobytes(), a.nbytes)
        b.release()
        return b

    def _upload(self):
        if self.model is None:
            return
        for i, p in enumerate(self.model.parts):
            if i in self._gpu:
                continue
            g = _GPUPart()
            if p.tri is not None and len(p.tri):
                inter = np.empty((len(p.tri), 6), np.float32)
                inter[:, :3] = p.tri
                inter[:, 3:] = p.nrm
                g.tri = self._vbo(inter)
                g.ntri_v = len(p.tri)
                if p.col is not None:
                    g.col = self._vbo(p.col)
            if p.lines is not None and len(p.lines):
                g.lines = self._vbo(p.lines)
                g.nlines = len(p.lines)
                if p.line_col is not None:
                    g.lcol = self._vbo(p.line_col)
            if p.points is not None and len(p.points):
                g.points = self._vbo(p.points)
                g.npoints = len(p.points)
            if p.bbox is not None:
                lo, hi = p.bbox
                c = np.array([[lo[0], lo[1], lo[2]], [hi[0], lo[1], lo[2]], [hi[0], hi[1], lo[2]], [lo[0], hi[1], lo[2]],
                              [lo[0], lo[1], hi[2]], [hi[0], lo[1], hi[2]], [hi[0], hi[1], hi[2]], [lo[0], hi[1], hi[2]]])
                e = [0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7]
                g.bbox = self._vbo(c[e])
            self._gpu[i] = g
        self._dirty = False

    def _edges(self, i, part, kind):
        g = self._gpu.get(i)
        if g is None or part.tri is None or not len(part.tri):
            return None, 0
        if kind == "feature":
            if g.edges is None:
                e = feature_edges(part.tri, self.crease)
                g.edges = self._vbo(e) if len(e) else False
                g.nedges = len(e)
            return (g.edges or None), g.nedges
        if g.wire is None:
            e = all_edges(part.tri)
            g.wire = self._vbo(e)
            g.nwire = len(e)
        return g.wire, g.nwire

    def reset_edges(self):
        self.makeCurrent()
        for g in self._gpu.values():
            if g.edges:
                g.edges.destroy()
            g.edges = None
        self.doneCurrent()
        self.update()

    # ----------------------------------------------------------- camera
    def bounds(self, visible=True):
        if self.model is None:
            return np.array([-1.0, -1, -1]), np.array([1.0, 1, 1])
        return self.model.bbox(visible_only=visible)

    def radius(self):
        lo, hi = self.bounds(False)
        return float(np.linalg.norm(hi - lo) / 2) or 1.0

    def fit(self, parts=None, update=True):
        if self.walk.active and update:
            self.set_nav("orbit")
        if parts:
            bbs = [p.bbox for p in parts if p.bbox is not None]
            if not bbs:
                return
            lo = np.min([b[0] for b in bbs], axis=0)
            hi = np.max([b[1] for b in bbs], axis=0)
        else:
            lo, hi = self.bounds(True)
        c = (lo + hi) / 2
        r = float(np.linalg.norm(hi - lo) / 2) or 1.0
        self.cam.target = c
        aspect = max(self.width(), 1) / max(self.height(), 1)
        fov = self.cam.fov
        half = math.radians(fov) / 2
        k = 1.0 if aspect >= 1 else 1.0 / aspect
        self.cam.dist = r * k / math.sin(half) * 1.04
        self.cam.ortho_h = 2 * r * k * 1.04
        if update:
            self.camera_changed.emit()
            self.update()

    def set_nav(self, mode):
        """'orbit' (rotate around the model) or first-person 'walk' / 'fly'."""
        mode = mode if mode in ("walk", "fly") else "orbit"
        cur = self.walk.mode or "orbit"
        if mode == cur:
            return
        if mode == "orbit":
            self.walk.leave()
        else:
            self.walk.enter(mode)
        self.setFocus()
        self.nav_changed.emit(mode)
        self.update()

    def set_std_view(self, name):
        if self.walk.active:
            self.set_nav("orbit")
        d, up = STD_VIEWS[name]
        if self.up[1] > 0.5:  # Y-up model: map Z-up definitions
            T = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]], float)
            d = T @ np.asarray(d, float)
            up = T @ np.asarray(up, float)
        cam = look_camera(d, up, self.cam.target, self.cam.dist, self.cam.fov)
        cam.ortho = self.cam.ortho
        cam.ortho_h = self.cam.ortho_h
        self.cam = cam
        self.fit()

    def set_camera(self, cam):
        if cam is None:
            self.fit()
            return
        c = cam.copy()
        if getattr(cam, "_ortho_scale", None) and c.ortho:
            c.ortho_h = None
        if c.ortho and not c.ortho_h:
            c.ortho_h = 2 * math.tan(math.radians(30) / 2) * c.dist
        self.cam = c
        if self.walk.active:
            self.walk.sync_from_camera()
            self.walk._apply()
        self.camera_changed.emit()
        self.update()

    def proj_matrix(self):
        w, h = max(self.width(), 1), max(self.height(), 1)
        aspect = w / h
        if self.walk.active:
            near, far = self.walk.near_far()
            return perspective(self.cam.fov, aspect, near, far)
        lo, hi = self.bounds(False)
        r = float(np.linalg.norm(hi - lo) / 2) or 1.0
        ctr = (lo + hi) / 2
        dc = float(np.dot(self.cam.eye - ctr, self.cam.R[:, 2]))
        near = max(dc - r * 1.6, r * 1e-3, self.cam.dist * 1e-3)
        far = dc + r * 1.6
        if far <= near:
            far = near + r * 4
        if self.cam.ortho:
            near = dc - r * 2 - self.cam.dist
            far = dc + r * 2
            return orthographic(self.cam.ortho_h or 1.0, aspect, near, far)
        return perspective(self.cam.fov, aspect, near, far)

    def mvp(self):
        return self.proj_matrix() @ self.cam.view_matrix()

    def world_per_pixel(self, depth=None):
        h = max(self.height(), 1)
        if self.cam.ortho:
            return (self.cam.ortho_h or 1.0) / h
        d = depth if depth is not None else self.cam.dist
        return 2 * d * math.tan(math.radians(self.cam.fov) / 2) / h

    def project(self, pts):
        """world points (N,3) -> screen (N,2) and depth validity"""
        P = np.asarray(pts, float).reshape(-1, 3)
        M = self.mvp()
        h = np.c_[P, np.ones(len(P))] @ M.T
        w = h[:, 3:4]
        ok = w[:, 0] > 1e-9
        w[~ok] = 1e-9
        ndc = h[:, :3] / w
        sx = (ndc[:, 0] + 1) * 0.5 * self.width()
        sy = (1 - ndc[:, 1]) * 0.5 * self.height()
        return np.c_[sx, sy], ok & (np.abs(ndc[:, 2]) <= 1.2)

    def ray(self, x, y):
        w, h = max(self.width(), 1), max(self.height(), 1)
        nx = 2.0 * x / w - 1.0
        ny = 1.0 - 2.0 * y / h
        Minv = np.linalg.inv(self.mvp())
        a = Minv @ np.array([nx, ny, -1.0, 1.0])
        b = Minv @ np.array([nx, ny, 1.0, 1.0])
        a = a[:3] / a[3]
        b = b[:3] / b[3]
        d = b - a
        return a, d / (np.linalg.norm(d) or 1.0)

    # ------------------------------------------------------------ paint
    def paintGL(self):
        f = getattr(self, "f", None)
        if f is None or not self._ok:
            return
        bg = self.bg_top
        f.glClearColor(bg[0], bg[1], bg[2], 1.0)
        f.glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        if self.model is None:
            self._overlay()
            return
        if self._dirty:
            self._upload()
        f.glEnable(GL_DEPTH_TEST)
        f.glDepthFunc(GL_LEQUAL)
        f.glEnable(GL_PROGRAM_POINT_SIZE)
        try:
            f.glEnable(GL_MULTISAMPLE)
        except Exception:
            pass
        mvp = self.mvp()
        view = self.cam.view_matrix()
        mode = self.mode
        clip = self.section is not None
        plane = (0.0, 0.0, 0.0, 0.0)
        if clip:
            n = self.section["normal"]
            plane = (float(n[0]), float(n[1]), float(n[2]), float(self.section["d"]))
        amb, lights, spec = LIGHT_SCHEMES.get(self.lighting, LIGHT_SCHEMES["CAD"])
        if self.lighting in ("Artwork",) and self.model.lights:
            amb, lights, spec = self._artwork_lights(view)
        elif self.lighting == "Artwork":
            amb, lights, spec = LIGHT_SCHEMES["CAD"]
        att = 0.0
        if self.lighting == "Interior":
            amb, lights, spec = LIGHT_SCHEMES["Interior"]
            upe = self.cam.R.T @ (np.asarray(self.up, float) / (np.linalg.norm(self.up) or 1.0))
            sky = upe * 0.9 + np.array([0.0, 0.0, 0.25])      # overhead light, slightly from the viewer
            lights = [(tuple(sky), lights[0][1]), lights[1]]
            att = float(self.walk.light_attenuation())
        transparent_mode = mode in ("Transparent", "TransparentWireframe")
        lit = mode not in ("Illustration", "Vertices", "Wireframe", "HiddenWireframe", "BoundingBox")
        draw_tri = mode not in ("Wireframe", "Vertices", "BoundingBox")
        fill_only_depth = mode == "HiddenWireframe"
        # ---- meshes ---------------------------------------------------------
        p = self.prog
        p.bind()
        p.setUniformValue("u_mvp", qmat(mvp))
        p.setUniformValue("u_view", qmat(view))
        p.setUniformValue("u_plane", plane[0], plane[1], plane[2], plane[3])
        p.setUniformValue1f("u_clip", 1.0 if clip else 0.0)
        cap = self.section.get("cap", (0.85, 0.35, 0.25)) if clip else (0.8, 0.3, 0.2)
        p.setUniformValue("u_capcol", QVector3D(*cap))
        p.setUniformValue1f("u_lit", 1.0 if (lit and self.lighting != "None") else 0.0)
        p.setUniformValue("u_amb", QVector3D(*amb))
        p.setUniformValue1f("u_spec", float(spec))
        p.setUniformValue1f("u_nl", float(len(lights)))
        p.setUniformValue("u_hlcol", QVector3D(*self.select_color))
        p.setUniformValue1f("u_flat", 0.85 if mode == "Illustration" else 0.0)
        fog = float(self.walk.fog_density())
        p.setUniformValue1f("u_fog", fog)
        p.setUniformValue1f("u_att", att)
        p.setUniformValue("u_fogcol", QVector3D(*[float(x) for x in self.bg_top[:3]]))
        for k in range(4):
            if k < len(lights):
                d, c = lights[k]
            else:
                d, c = (0.0, 0.0, 1.0), (0.0, 0.0, 0.0)
            p.setUniformValue("u_ldir[%d]" % k, QVector3D(*[float(x) for x in d]))
            p.setUniformValue("u_lcol[%d]" % k, QVector3D(*[float(x) for x in c]))
        parts = self.model.parts
        order_opaque, order_trans = [], []
        for i, part in enumerate(parts):
            if not part.visible:
                continue
            op = part.opacity
            if transparent_mode:
                op = min(op, 0.45)
            if self.ghost_others and self.selected and i not in self.selected:
                op = min(op, 0.18)
            (order_trans if op < 0.999 else order_opaque).append((i, op))
        if draw_tri:
            if fill_only_depth:
                f.glColorMask(False, False, False, False)
            f.glEnable(GL_POLYGON_OFFSET_FILL)
            f.glPolygonOffset(1.0, 1.0)
            for i, op in order_opaque:
                self._draw_mesh(i, parts[i], 1.0)
            if fill_only_depth:
                f.glColorMask(True, True, True, True)
            if order_trans and not fill_only_depth:
                # back to front
                eye = self.cam.eye
                order_trans.sort(key=lambda t: -float(np.linalg.norm(((parts[t[0]].bbox[0] + parts[t[0]].bbox[1]) / 2
                                                                       if parts[t[0]].bbox is not None else eye) - eye)))
                f.glEnable(GL_BLEND)
                f.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
                f.glDepthMask(False)
                for i, op in order_trans:
                    self._draw_mesh(i, parts[i], op)
                f.glDepthMask(True)
                f.glDisable(GL_BLEND)
            f.glDisable(GL_POLYGON_OFFSET_FILL)
        p.release()
        # ---- lines / edges / points -------------------------------------------
        lp = self.lprog
        lp.bind()
        lp.setUniformValue("u_mvp", qmat(mvp))
        lp.setUniformValue("u_plane", plane[0], plane[1], plane[2], plane[3])
        lp.setUniformValue1f("u_clip", 1.0 if clip else 0.0)
        lp.setUniformValue1f("u_psize", float(self.point_size))
        lp.setUniformValue1f("u_fog", fog)
        lp.setUniformValue("u_fogcol", QVector3D(*[float(x) for x in self.bg_top[:3]]))
        f.glLineWidth(self.line_width)
        edges_kind = {"SolidOutline": "feature", "ShadedIllustration": "feature", "Illustration": "feature",
                      "SolidWireframe": "all", "TransparentWireframe": "all", "Wireframe": "all",
                      "HiddenWireframe": "all"}.get(mode)
        for i, part in enumerate(parts):
            if not part.visible:
                continue
            g = self._gpu.get(i)
            if g is None:
                continue
            sel = i in self.selected
            alpha = 1.0
            if self.ghost_others and self.selected and not sel:
                alpha = 0.25
            if edges_kind and g.ntri_v:
                buf, n = self._edges(i, part, edges_kind)
                if buf is not None and n:
                    if mode in ("Wireframe", "HiddenWireframe", "TransparentWireframe"):
                        col = part.color if part.col is None else (0.15, 0.15, 0.15, 1.0)
                        col = tuple(min(1.0, c * 0.85) for c in col[:3]) + (1.0,)
                    else:
                        col = self.edge_color + (1.0,)
                    if sel:
                        col = self.select_color + (1.0,)
                    self._draw_lines(buf, n, col, alpha, GL_LINES)
            if g.nlines:
                col = self.select_color + (1.0,) if sel else part.line_color
                self._draw_lines(g.lines, g.nlines, col, alpha * part.opacity, GL_LINES, g.lcol if not sel else None)
            if g.npoints or (mode in ("Vertices", "ShadedVertices") and g.ntri_v):
                col = self.select_color + (1.0,) if sel else part.point_color
                if g.npoints:
                    self._draw_lines(g.points, g.npoints, col, alpha, GL_POINTS)
                if mode in ("Vertices", "ShadedVertices") and g.ntri_v:
                    self._draw_tri_points(g, part, sel, alpha)
            if mode == "BoundingBox" and g.bbox is not None:
                col = self.select_color + (1.0,) if sel else part.color
                self._draw_lines(g.bbox, 24, col, alpha, GL_LINES)
        # section outline
        if clip and self.section.get("outline", True):
            if self._sec_lines is None:
                self._compute_section_lines()
            if self._sec_n:
                f.glDisable(GL_DEPTH_TEST)
                lp.setUniformValue1f("u_clip", 0.0)
                f.glLineWidth(2.0)
                self._draw_lines(self._sec_vbo, self._sec_n, tuple(self.section.get("line", (0.9, 0.1, 0.1))) + (1.0,),
                                 1.0, GL_LINES)
                f.glLineWidth(self.line_width)
                f.glEnable(GL_DEPTH_TEST)
        lp.release()
        # section plane (translucent quad)
        if clip and self.section.get("show_plane", False):
            self._draw_plane(mvp)
        f.glDisable(GL_DEPTH_TEST)
        self._overlay()

    def _artwork_lights(self, view):
        lights = []
        amb = np.zeros(3)
        ctr = (self.bounds(False)[0] + self.bounds(False)[1]) / 2
        for typ, v, col, inten in self.model.lights:
            c = np.asarray(col, float) * float(inten if inten else 1.0)
            if typ == "ambient":
                amb += c
                continue
            if typ == "directional":
                d = -np.asarray(v, float)
            else:
                d = np.asarray(v, float) - ctr
            d = view[:3, :3] @ d
            lights.append((tuple(d), tuple(np.clip(c, 0, 1.2))))
        if not lights:
            return LIGHT_SCHEMES["CAD"]
        amb = np.clip(amb, 0.12, 0.6)
        return tuple(amb), lights[:4], 0.25

    def _draw_mesh(self, i, part, op):
        g = self._gpu.get(i)
        if g is None or not g.ntri_v:
            return
        p = self.prog
        f = self.f
        g.tri.bind()
        p.enableAttributeArray(0)
        p.setAttributeBuffer(0, GL_FLOAT, 0, 3, 24)
        p.enableAttributeArray(1)
        p.setAttributeBuffer(1, GL_FLOAT, 12, 3, 24)
        g.tri.release()
        if g.col is not None:
            g.col.bind()
            p.enableAttributeArray(2)
            p.setAttributeBuffer(2, GL_FLOAT, 0, 4, 16)
            g.col.release()
            p.setUniformValue1f("u_usevc", 1.0)
        else:
            p.disableAttributeArray(2)
            p.setUniformValue1f("u_usevc", 0.0)
        c = part.color
        if self.mode == "Illustration":
            c = (0.96, 0.96, 0.96, 1.0)
        p.setUniformValue("u_color", float(c[0]), float(c[1]), float(c[2]), 1.0)
        p.setUniformValue1f("u_alpha", float(op))
        p.setUniformValue1f("u_hl", 0.45 if i in self.selected else 0.0)
        f.glDrawArrays(GL_TRIANGLES, 0, g.ntri_v)
        p.disableAttributeArray(0)
        p.disableAttributeArray(1)
        p.disableAttributeArray(2)

    def _draw_lines(self, buf, n, col, alpha, prim, colbuf=None):
        lp = self.lprog
        buf.bind()
        lp.enableAttributeArray(0)
        lp.setAttributeBuffer(0, GL_FLOAT, 0, 3, 12)
        buf.release()
        if colbuf is not None:
            colbuf.bind()
            lp.enableAttributeArray(1)
            lp.setAttributeBuffer(1, GL_FLOAT, 0, 4, 16)
            colbuf.release()
            lp.setUniformValue1f("u_usevc", 1.0)
        else:
            lp.disableAttributeArray(1)
            lp.setUniformValue1f("u_usevc", 0.0)
        lp.setUniformValue("u_color", float(col[0]), float(col[1]), float(col[2]), float(col[3] if len(col) > 3 else 1))
        lp.setUniformValue1f("u_alpha", float(alpha))
        if alpha < 0.999:
            self.f.glEnable(GL_BLEND)
            self.f.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        self.f.glDrawArrays(prim, 0, n)
        if alpha < 0.999:
            self.f.glDisable(GL_BLEND)
        lp.disableAttributeArray(0)
        lp.disableAttributeArray(1)

    def _draw_tri_points(self, g, part, sel, alpha):
        lp = self.lprog
        g.tri.bind()
        lp.enableAttributeArray(0)
        lp.setAttributeBuffer(0, GL_FLOAT, 0, 3, 24)
        g.tri.release()
        lp.disableAttributeArray(1)
        lp.setUniformValue1f("u_usevc", 0.0)
        c = self.select_color + (1.0,) if sel else (0.1, 0.1, 0.12, 1.0)
        lp.setUniformValue("u_color", float(c[0]), float(c[1]), float(c[2]), 1.0)
        lp.setUniformValue1f("u_alpha", float(alpha))
        self.f.glDrawArrays(GL_POINTS, 0, g.ntri_v)
        lp.disableAttributeArray(0)

    def _draw_plane(self, mvp):
        lo, hi = self.bounds(False)
        ctr = (lo + hi) / 2
        r = float(np.linalg.norm(hi - lo) / 2) or 1.0
        n = np.asarray(self.section["normal"], float)
        d = float(self.section["d"])
        p0 = ctr - n * (np.dot(n, ctr) + d)
        a = np.cross(n, [0, 0, 1.0] if abs(n[2]) < 0.9 else [1.0, 0, 0])
        a /= np.linalg.norm(a)
        b = np.cross(n, a)
        s = r * 1.1
        quad = np.array([p0 - a * s - b * s, p0 + a * s - b * s, p0 + a * s + b * s,
                         p0 - a * s - b * s, p0 + a * s + b * s, p0 - a * s + b * s], np.float32)
        outline = np.array([quad[0], quad[1], quad[1], quad[2], quad[2], quad[5], quad[5], quad[0]], np.float32)
        lp = self.lprog
        lp.bind()
        lp.setUniformValue("u_mvp", qmat(mvp))
        lp.setUniformValue1f("u_clip", 0.0)
        buf = self._vbo(quad)
        f = self.f
        f.glEnable(GL_DEPTH_TEST)
        f.glDepthMask(False)
        col = self.section.get("plane_color", (0.2, 0.55, 0.95))
        self._draw_lines(buf, 6, tuple(col) + (1.0,), 0.18, GL_TRIANGLES)
        buf.destroy()
        buf = self._vbo(outline)
        self._draw_lines(buf, 8, tuple(col) + (1.0,), 0.9, GL_LINES)
        buf.destroy()
        f.glDepthMask(True)
        lp.release()

    # ---------------------------------------------------------- section
    def set_section(self, sec):
        self.section = sec
        self._sec_lines = None
        self.update()

    def _compute_section_lines(self):
        n = np.asarray(self.section["normal"], float)
        d = float(self.section["d"])
        segs = []
        for part in self.model.parts:
            if part.visible and part.tri is not None and len(part.tri):
                lo, hi = part.bbox
                # quick reject: bbox completely on one side
                corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
                s = corners @ n + d
                if (s > 0).all() or (s < 0).all():
                    continue
                segs.append(section_lines(part.tri, n, d))
        self._sec_lines = np.concatenate(segs) if segs else np.zeros((0, 3), np.float32)
        self.makeCurrent()
        if self._sec_vbo is not None:
            self._sec_vbo.destroy()
            self._sec_vbo = None
        self._sec_n = len(self._sec_lines)
        if self._sec_n:
            self._sec_vbo = self._vbo(self._sec_lines)

    def section_length(self):
        if self._sec_lines is None or not len(self._sec_lines):
            return 0.0
        s = self._sec_lines.reshape(-1, 2, 3)
        return float(np.linalg.norm(s[:, 1] - s[:, 0], axis=1).sum())

    # ---------------------------------------------------------- picking
    def pick(self, x, y, want_snap=False):
        if self.model is None:
            return None
        o, d = self.ray(x, y)
        best = None
        n_plane = None
        if self.section is not None:
            n_plane = (np.asarray(self.section["normal"], float), float(self.section["d"]))
        for i, part in enumerate(self.model.parts):
            if not part.visible or part.tri is None or not len(part.tri) or part.bbox is None:
                continue
            lo, hi = part.bbox
            pad = (hi - lo) * 1e-6 + 1e-9
            if not _ray_box(o, d, lo - pad, hi + pad):
                continue
            hit = _ray_tris(o, d, part.tri, n_plane)
            if hit is not None and (best is None or hit[0] < best[0]):
                best = (hit[0], i, hit[1])
        lines_hit = self._pick_lines(x, y)
        if best is None and lines_hit is None:
            return None
        if best is None or (lines_hit is not None and lines_hit["t"] < best[0]):
            return lines_hit
        t, i, fi = best
        part = self.model.parts[i]
        P = o + d * t
        tri = part.tri.reshape(-1, 3, 3)[fi].astype(float)
        nrm = np.cross(tri[1] - tri[0], tri[2] - tri[0])
        nrm /= np.linalg.norm(nrm) or 1.0
        res = {"point": P, "normal": nrm, "part": part, "index": i, "tri": tri, "t": t, "snap": "surface"}
        if want_snap and self.snap:
            self._snap(res, x, y)
        return res

    def _pick_lines(self, x, y, tol=6.0):
        best = None
        for i, part in enumerate(self.model.parts):
            if not part.visible or part.lines is None or not len(part.lines):
                continue
            seg = part.lines.reshape(-1, 2, 3).astype(float)
            a2, oka = self.project(seg[:, 0])
            b2, okb = self.project(seg[:, 1])
            p = np.array([x, y], float)
            ab = b2 - a2
            l2 = (ab * ab).sum(axis=1)
            l2[l2 == 0] = 1e-9
            t = np.clip(((p - a2) * ab).sum(axis=1) / l2, 0, 1)
            q = a2 + ab * t[:, None]
            dist = np.linalg.norm(q - p, axis=1)
            dist[~(oka & okb)] = 1e9
            k = int(np.argmin(dist))
            if dist[k] <= tol:
                W = seg[k, 0] + (seg[k, 1] - seg[k, 0]) * t[k]
                tt = float(np.dot(W - self.cam.eye, -self.cam.R[:, 2]))
                if best is None or tt < best["t"]:
                    best = {"point": W, "normal": None, "part": part, "index": i, "tri": None, "t": tt,
                            "snap": "edge", "seg": seg[k]}
        return best

    def _snap(self, res, x, y, vtol=10.0, etol=7.0):
        tri = res["tri"]
        s2, ok = self.project(tri)
        p = np.array([x, y], float)
        dv = np.linalg.norm(s2 - p, axis=1)
        k = int(np.argmin(dv))
        if dv[k] <= vtol:
            res["point"] = tri[k]
            res["snap"] = "vertex"
            return
        best = None
        for a, b in ((0, 1), (1, 2), (2, 0)):
            A, B = s2[a], s2[b]
            ab = B - A
            l2 = float(ab @ ab) or 1e-9
            t = min(1.0, max(0.0, float((p - A) @ ab) / l2))
            q = A + ab * t
            dd = float(np.linalg.norm(q - p))
            if dd <= etol and (best is None or dd < best[0]):
                best = (dd, a, b, t)
        if best is not None:
            _, a, b, t = best
            # midpoint snap
            if abs(t - 0.5) < 0.08:
                t = 0.5
                res["snap"] = "midpoint"
            else:
                res["snap"] = "edge"
            res["point"] = tri[a] + (tri[b] - tri[a]) * t
            res["edge"] = (tri[a], tri[b])

    # ------------------------------------------------------------ mouse
    def mousePressEvent(self, e):
        self._last = e.position()
        self._press = e.position()
        self._moved = False
        if e.button() == Qt.LeftButton:
            self._drag = "pan" if (e.modifiers() & Qt.ShiftModifier) else (
                "zoom" if (e.modifiers() & Qt.ControlModifier) else "rotate")
        elif e.button() == Qt.MiddleButton:
            self._drag = "pan"
        elif e.button() == Qt.RightButton:
            self._drag = "zoom_r"
        e.accept()

    def mouseMoveEvent(self, e):
        pos = e.position()
        if self._drag and self._last is not None:
            dx = pos.x() - self._last.x()
            dy = pos.y() - self._last.y()
            if abs(pos.x() - self._press.x()) + abs(pos.y() - self._press.y()) > 3:
                self._moved = True
            if self._moved and self.walk.active:
                if self._drag == "rotate":
                    self.walk.look(dx, dy)
                elif self._drag == "pan":
                    self.walk.strafe(dx, dy)
                elif self._drag in ("zoom", "zoom_r"):
                    self.walk.dolly(dy)
            elif self._moved:
                if self._drag == "rotate":
                    self.orbit(dx, dy)
                elif self._drag == "pan":
                    self.pan(dx, dy)
                elif self._drag in ("zoom", "zoom_r"):
                    self.zoom(math.exp(dy * 0.01))
            self._last = pos
        elif self.measure_mode:
            self._hover = self.pick(pos.x(), pos.y(), want_snap=True)
            self.update()

    def mouseReleaseEvent(self, e):
        drag = self._drag
        self._drag = None
        if not getattr(self, "_moved", False):
            pos = e.position()
            if e.button() == Qt.LeftButton:
                self._click(pos.x(), pos.y(), e.modifiers())
            elif e.button() == Qt.RightButton and drag == "zoom_r":
                self.customContextMenuRequested.emit(pos.toPoint())
        e.accept()

    def mouseDoubleClickEvent(self, e):
        if self.measure_mode:
            return
        hit = self.pick(e.position().x(), e.position().y())
        if self.walk.active:
            if hit is not None and "point" in hit:
                self.walk.stand_at(hit)
            return
        if hit is not None:
            # zoom about the picked point
            self.cam.target = hit["point"].copy()
            self.cam.dist = max(float(np.dot(self.cam.eye - hit["point"], self.cam.R[:, 2])), self.radius() * 0.02)
            self.zoom(0.6)
        else:
            self.fit()

    def wheelEvent(self, e):
        steps = e.angleDelta().y() / 120.0
        if steps == 0:
            return
        if self.walk.active:
            self.walk.wheel(steps)
            return
        factor = 0.85 ** steps
        pos = e.position()
        hit = self.pick(pos.x(), pos.y()) if (self.model is not None and self.model.ntri < 400000) else None
        if hit is not None:
            P = hit["point"]
            # zoom toward the point under the cursor
            self.cam.target = self.cam.target + (P - self.cam.target) * (1 - factor) * (1 if steps > 0 else 0.0)
        self.zoom(factor)

    def keyPressEvent(self, e):
        k = e.key()
        if self.walk.active and not (e.modifiers() & Qt.AltModifier) and self.walk.key_press(e):
            return
        if k == Qt.Key_F:
            self.fit()
        elif k == Qt.Key_Escape:
            if self.walk.active and not self.mpoints:
                self.set_nav("orbit")
                return
            self.mpoints = []
            self._hover = None
            self.update()
        elif k in (Qt.Key_Left, Qt.Key_Right, Qt.Key_Up, Qt.Key_Down):
            step = 15
            dx = {Qt.Key_Left: -step, Qt.Key_Right: step}.get(k, 0)
            dy = {Qt.Key_Up: -step, Qt.Key_Down: step}.get(k, 0)
            if e.modifiers() & Qt.ShiftModifier:
                self.pan(dx, dy)
            else:
                self.orbit(dx, dy)
        elif k in (Qt.Key_Plus, Qt.Key_Equal):
            self.zoom(0.85)
        elif k == Qt.Key_Minus:
            self.zoom(1 / 0.85)
        else:
            super().keyPressEvent(e)

    def keyReleaseEvent(self, e):
        if self.walk.active and self.walk.key_release(e):
            return
        super().keyReleaseEvent(e)

    def focusOutEvent(self, e):
        self.walk.focus_lost()
        super().focusOutEvent(e)

    def orbit(self, dx, dy):
        a = math.radians(dx * 0.45)
        b = math.radians(dy * 0.45)
        R = self.cam.R
        if self._turntable:
            up = self.up / np.linalg.norm(self.up)
            Rz = rotation(up, -a)
            R = Rz @ R
            Rx = rotation(R[:, 0], -b)
            Rn = Rx @ R
            # keep from flipping over the pole
            if np.dot(Rn[:, 1], up) > 0.02 or abs(np.dot(R[:, 1], up)) < 0.02:
                R = Rn
        else:
            R = rotation(R[:, 1], -a) @ R
            R = rotation(R[:, 0], -b) @ R
        u, _, vt = np.linalg.svd(R)
        self.cam.R = u @ vt
        self.camera_changed.emit()
        self.update()

    def pan(self, dx, dy):
        wpp = self.world_per_pixel()
        self.cam.target = self.cam.target - self.cam.R[:, 0] * dx * wpp + self.cam.R[:, 1] * dy * wpp
        self.camera_changed.emit()
        self.update()

    def zoom(self, factor):
        if self.cam.ortho:
            self.cam.ortho_h = max((self.cam.ortho_h or 1.0) * factor, 1e-9)
        self.cam.dist = max(self.cam.dist * factor, self.radius() * 1e-4)
        self.camera_changed.emit()
        self.update()

    def _click(self, x, y, mods):
        if self.measure_mode:
            hit = self.pick(x, y, want_snap=True)
            if hit is None:
                return
            self._measure_click(hit)
            return
        hit = self.pick(x, y)
        if hit is None:
            if not (mods & Qt.ControlModifier):
                self.selected = set()
            self.picked.emit(None)
        else:
            i = hit["index"]
            if mods & Qt.ControlModifier:
                self.selected ^= {i}
            else:
                self.selected = {i}
            self.picked.emit(hit)
        self.update()

    # ------------------------------------------------------ measuring
    def set_measure_mode(self, mode):
        self.measure_mode = mode
        self.mpoints = []
        self._hover = None
        self.setCursor(Qt.CrossCursor if mode else Qt.ArrowCursor)
        self.update()

    def _measure_click(self, hit):
        mode = self.measure_mode
        if mode in ("comment", "point_pick"):
            self.point_picked.emit(hit)
            return
        self.mpoints.append(hit)
        need = {"distance": 2, "angle": 3, "radius": 3, "point": 1, "faceangle": 2}.get(mode, 2)
        if len(self.mpoints) >= need:
            pts = [h["point"].astype(float) for h in self.mpoints]
            m = {"type": mode, "points": pts}
            if mode == "distance":
                v = pts[1] - pts[0]
                m["value"] = float(np.linalg.norm(v))
                m["delta"] = v
            elif mode == "angle":
                a = pts[0] - pts[1]
                b = pts[2] - pts[1]
                c = float(np.dot(a, b) / ((np.linalg.norm(a) * np.linalg.norm(b)) or 1.0))
                m["value"] = math.degrees(math.acos(max(-1.0, min(1.0, c))))
            elif mode == "faceangle":
                n1 = self.mpoints[0].get("normal")
                n2 = self.mpoints[1].get("normal")
                if n1 is None or n2 is None:
                    self.mpoints = []
                    return
                c = float(np.dot(n1, n2))
                m["value"] = math.degrees(math.acos(max(-1.0, min(1.0, abs(c)))))
                m["value"] = 180.0 - m["value"] if c < 0 and False else m["value"]
            elif mode == "radius":
                ctr, r, nrm = circle3(*pts)
                if ctr is None:
                    self.status.emit("The three points are collinear - pick points on an arc or circle.")
                    self.mpoints = []
                    self.update()
                    return
                m["value"] = r
                m["center"] = ctr
                m["normal"] = nrm
            elif mode == "point":
                m["value"] = 0.0
            self.measurements.append(m)
            self.mpoints = []
            self.measured.emit(m)
        self.update()

    def fmt_len(self, v):
        v = v * self.unit_scale
        a = abs(v)
        if a >= 1000:
            s = "%.1f" % v
        elif a >= 10:
            s = "%.2f" % v
        elif a >= 0.1:
            s = "%.3f" % v
        else:
            s = "%.4g" % v
        return s + ((" " + self.unit) if self.unit else "")

    def measurement_text(self, m):
        t = m["type"]
        if t == "distance":
            d = m["delta"] * self.unit_scale
            return "Distance %s   (dX %.4g, dY %.4g, dZ %.4g)" % (self.fmt_len(m["value"]), d[0], d[1], d[2])
        if t == "angle":
            return "Angle %.3f°" % m["value"]
        if t == "faceangle":
            return "Angle between faces %.3f°" % m["value"]
        if t == "radius":
            c = m["center"] * self.unit_scale
            return "Radius %s   Diameter %s   Centre (%.4g, %.4g, %.4g)" % (
                self.fmt_len(m["value"]), self.fmt_len(2 * m["value"]), c[0], c[1], c[2])
        if t == "point":
            p = m["points"][0] * self.unit_scale
            return "Point (%.4g, %.4g, %.4g)%s" % (p[0], p[1], p[2], (" " + self.unit) if self.unit else "")
        return ""

    # ---------------------------------------------------------- overlay
    def _overlay(self):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        try:
            if self.model is None:
                p.setPen(QColor("#5B6675"))
                p.drawText(self.rect(), Qt.AlignCenter, "No 3D model")
                return
            if self.show_axes:
                self._draw_axes(p)
            font = QFont(self.font())
            font.setPointSizeF(max(8.0, font.pointSizeF()))
            p.setFont(font)
            for m in self.measurements:
                self._draw_measure(p, m, QColor("#D32F2F"))
            if self.mpoints:
                for h in self.mpoints:
                    self._marker(p, h["point"], QColor("#1565C0"))
                if self._hover is not None:
                    pts = [h["point"] for h in self.mpoints] + [self._hover["point"]]
                    s, ok = self.project(np.array(pts))
                    p.setPen(QPen(QColor("#1565C0"), 1.2, Qt.DashLine))
                    for a in range(len(s) - 1):
                        p.drawLine(QPointF(*s[a]), QPointF(*s[a + 1]))
            if self._hover is not None and self.measure_mode:
                h = self._hover
                s, ok = self.project(np.array([h["point"]]))
                if ok[0]:
                    c = QColor({"vertex": "#2E7D32", "midpoint": "#6A1B9A", "edge": "#E65100"}.get(h["snap"], "#1565C0"))
                    p.setPen(QPen(c, 2))
                    p.setBrush(Qt.NoBrush)
                    x, y = s[0]
                    if h["snap"] == "vertex":
                        p.drawRect(QRectF(x - 6, y - 6, 12, 12))
                    elif h["snap"] == "midpoint":
                        path = QPainterPath()
                        path.moveTo(x, y - 7)
                        path.lineTo(x + 7, y + 6)
                        path.lineTo(x - 7, y + 6)
                        path.closeSubpath()
                        p.drawPath(path)
                    elif h["snap"] == "edge":
                        p.drawLine(QPointF(x - 7, y - 7), QPointF(x + 7, y + 7))
                        p.drawLine(QPointF(x - 7, y + 7), QPointF(x + 7, y - 7))
                    else:
                        p.drawEllipse(QPointF(x, y), 4, 4)
            for k, (pt, label) in enumerate(self.markers):
                self._comment_marker(p, pt, label, k + 1)
            if self.walk.active:
                self._draw_walk_hud(p)
        finally:
            p.end()

    def _draw_walk_hud(self, p):
        cx, cy = self.width() / 2.0, self.height() / 2.0
        p.setPen(QPen(QColor(255, 255, 255, 200), 3))
        p.drawLine(QPointF(cx - 8, cy), QPointF(cx + 8, cy))
        p.drawLine(QPointF(cx, cy - 8), QPointF(cx, cy + 8))
        p.setPen(QPen(QColor(20, 30, 45, 220), 1.2))
        p.drawLine(QPointF(cx - 7, cy), QPointF(cx + 7, cy))
        p.drawLine(QPointF(cx, cy - 7), QPointF(cx, cy + 7))
        txt = self.walk.hud()
        if txt:
            fm = QFontMetricsF(p.font())
            w = fm.horizontalAdvance(txt) + 16
            r = QRectF(self.width() - w - 10, self.height() - fm.height() - 16, w, fm.height() + 8)
            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(QColor(14, 42, 71, 200)))
            p.drawRoundedRect(r, 4, 4)
            p.setPen(QColor("white"))
            p.drawText(r, Qt.AlignCenter, txt)
            p.setBrush(Qt.NoBrush)

    def _marker(self, p, pt, color):
        s, ok = self.project(np.array([pt]))
        if not ok[0]:
            return None
        x, y = s[0]
        p.setPen(QPen(QColor("white"), 3))
        p.drawEllipse(QPointF(x, y), 3.5, 3.5)
        p.setPen(QPen(color, 2))
        p.setBrush(QBrush(color))
        p.drawEllipse(QPointF(x, y), 3, 3)
        p.setBrush(Qt.NoBrush)
        return x, y

    def _label(self, p, x, y, text, color):
        fm = QFontMetricsF(p.font())
        w = fm.horizontalAdvance(text) + 10
        h = fm.height() + 4
        r = QRectF(x + 8, y - h - 4, w, h)
        if r.right() > self.width() - 4:
            r.moveRight(x - 8)
        if r.top() < 2:
            r.moveTop(y + 6)
        p.setPen(QPen(color, 1))
        p.setBrush(QBrush(QColor(255, 255, 255, 230)))
        p.drawRoundedRect(r, 3, 3)
        p.setPen(color)
        p.drawText(r, Qt.AlignCenter, text)
        p.setBrush(Qt.NoBrush)

    def _draw_measure(self, p, m, color):
        pts = m["points"]
        s, ok = self.project(np.array(pts))
        if not ok.all():
            return
        p.setPen(QPen(color, 1.6))
        t = m["type"]
        if t == "distance":
            p.drawLine(QPointF(*s[0]), QPointF(*s[1]))
            mid = (s[0] + s[1]) / 2
            for q in pts:
                self._marker(p, q, color)
            self._label(p, mid[0], mid[1], self.fmt_len(m["value"]), color)
        elif t == "angle":
            p.drawLine(QPointF(*s[1]), QPointF(*s[0]))
            p.drawLine(QPointF(*s[1]), QPointF(*s[2]))
            for q in pts:
                self._marker(p, q, color)
            self._label(p, s[1][0], s[1][1], "%.2f°" % m["value"], color)
        elif t == "faceangle":
            for q in pts:
                self._marker(p, q, color)
            p.setPen(QPen(color, 1.2, Qt.DashLine))
            p.drawLine(QPointF(*s[0]), QPointF(*s[1]))
            mid = (s[0] + s[1]) / 2
            self._label(p, mid[0], mid[1], "%.2f°" % m["value"], color)
        elif t == "radius":
            ctr, r, nrm = m["center"], m["value"], m["normal"]
            a = np.cross(nrm, [0, 0, 1.0] if abs(nrm[2]) < 0.9 else [1.0, 0, 0])
            a /= np.linalg.norm(a)
            b = np.cross(nrm, a)
            ang = np.linspace(0, 2 * math.pi, 73)
            circ = ctr + r * (np.outer(np.cos(ang), a) + np.outer(np.sin(ang), b))
            cs, cok = self.project(circ)
            p.setPen(QPen(color, 1.2, Qt.DashLine))
            for k in range(len(cs) - 1):
                if cok[k] and cok[k + 1]:
                    p.drawLine(QPointF(*cs[k]), QPointF(*cs[k + 1]))
            for q in pts:
                self._marker(p, q, color)
            c2, _ = self.project(np.array([ctr]))
            p.setPen(QPen(color, 1.2))
            x, y = c2[0]
            p.drawLine(QPointF(x - 6, y), QPointF(x + 6, y))
            p.drawLine(QPointF(x, y - 6), QPointF(x, y + 6))
            p.drawLine(QPointF(x, y), QPointF(*s[0]))
            self._label(p, x, y, "R " + self.fmt_len(r), color)
        elif t == "point":
            self._marker(p, pts[0], color)
            q = pts[0] * self.unit_scale
            self._label(p, s[0][0], s[0][1], "%.4g, %.4g, %.4g" % (q[0], q[1], q[2]), color)

    def _comment_marker(self, p, pt, label, n):
        s, ok = self.project(np.array([pt]))
        if not ok[0]:
            return
        x, y = s[0]
        c = QColor("#F9A825")
        path = QPainterPath()
        path.addRoundedRect(QRectF(x - 2, y - 26, 24, 20), 4, 4)
        path.moveTo(x, y)
        path.lineTo(x + 2, y - 8)
        path.lineTo(x + 9, y - 8)
        path.closeSubpath()
        p.setPen(QPen(QColor("#7A5A00"), 1))
        p.setBrush(QBrush(c))
        p.drawPath(path)
        p.setPen(QColor("#3A2A00"))
        p.drawText(QRectF(x - 2, y - 26, 24, 20), Qt.AlignCenter, str(n))
        p.setBrush(Qt.NoBrush)

    def _draw_axes(self, p):
        R = self.cam.R
        size = 34
        ox, oy = 46, self.height() - 46
        axes = [((1, 0, 0), QColor("#D32F2F"), "X"), ((0, 1, 0), QColor("#2E7D32"), "Y"), ((0, 0, 1), QColor("#1565C0"), "Z")]
        items = []
        for v, c, name in axes:
            e = R.T @ np.asarray(v, float)
            items.append((e[2], e, c, name))
        items.sort(key=lambda t: t[0])
        for _, e, c, name in items:
            x = ox + e[0] * size
            y = oy - e[1] * size
            p.setPen(QPen(c, 2.2))
            p.drawLine(QPointF(ox, oy), QPointF(x, y))
            p.drawText(QRectF(x - 8, y - 8, 16, 16), Qt.AlignCenter, name)

    # ---------------------------------------------------------- snapshot
    def snapshot(self, w=None, h=None):
        img = self.grabFramebuffer()
        if w and h:
            img = img.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        return img


def _ray_box(o, d, lo, hi):
    with np.errstate(divide="ignore", invalid="ignore"):
        inv = 1.0 / np.where(np.abs(d) < 1e-15, 1e-15, d)
    t1 = (lo - o) * inv
    t2 = (hi - o) * inv
    tmin = np.max(np.minimum(t1, t2))
    tmax = np.min(np.maximum(t1, t2))
    return tmax >= max(tmin, 0.0)


def _ray_tris(o, d, tri, plane=None, chunk=400000):
    """Nearest ray / triangle hit: (t, face index) or None (Moller-Trumbore)."""
    T = tri.reshape(-1, 3, 3)
    best = None
    for s in range(0, len(T), chunk):
        t = T[s:s + chunk].astype(np.float64)
        v0 = t[:, 0]
        e1 = t[:, 1] - v0
        e2 = t[:, 2] - v0
        pv = np.cross(d, e2)
        det = (e1 * pv).sum(axis=1)
        ok = np.abs(det) > 1e-14
        inv = np.zeros_like(det)
        inv[ok] = 1.0 / det[ok]
        tv = o - v0
        u = (tv * pv).sum(axis=1) * inv
        ok &= (u >= -1e-9) & (u <= 1 + 1e-9)
        qv = np.cross(tv, e1)
        v = (qv @ d) * inv
        ok &= (v >= -1e-9) & (u + v <= 1 + 1e-9)
        tt = (e2 * qv).sum(axis=1) * inv
        ok &= tt > 1e-9
        if plane is not None and ok.any():
            n, dd = plane
            P = o[None, :] + d[None, :] * tt[:, None]
            ok &= (P @ n + dd) <= 0
        if ok.any():
            idx = np.nonzero(ok)[0]
            k = idx[np.argmin(tt[idx])]
            if best is None or tt[k] < best[0]:
                best = (float(tt[k]), int(s + k))
    return best


def circle3(a, b, c):
    """Circle through three 3D points -> (centre, radius, normal)."""
    a, b, c = (np.asarray(x, float) for x in (a, b, c))
    ab = b - a
    ac = c - a
    n = np.cross(ab, ac)
    nn = float(np.dot(n, n))
    if nn < 1e-20 * max(1.0, float(np.dot(ab, ab)) * float(np.dot(ac, ac))):
        return None, None, None
    ctr = a + (np.cross(n, ab) * np.dot(ac, ac) + np.cross(ac, n) * np.dot(ab, ab)) / (2 * nn)
    return ctr, float(np.linalg.norm(ctr - a)), n / math.sqrt(nn)
