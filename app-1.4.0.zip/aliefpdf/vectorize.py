"""Raster to vector conversion of scanned drawings (centre-line tracing).

Pipeline (all in pixel space, x to the right, y down):
  1. ink detection: background levelled, thin dark strokes found with a black-hat filter (works on grey shading,
     uneven light and coloured paper), very dark pixels always ink; specks removed, pin holes filled
  2. solid areas (filled arrow heads, blocks) separated: they become filled outlines, not centre lines
  3. thinning (Guo-Hall) to a 1-pixel skeleton = the centre line of every stroke, staircase pixels removed
  4. skeleton traced into a graph (end points, junctions, paths); short skeleton spurs pruned;
     straight continuations through crossings merged into one line
  5. every path fitted with sub-pixel accuracy: straight lines, circles, arcs and polylines
     (least-squares line fit of all centre-line pixels, corners at the intersection of the fitted lines)
  6. clean-up: corners and T-junctions closed exactly, scan rotation removed, nearly horizontal / vertical lines
     made exact, stroke width measured (thin / thick layers, line weight)

Only numpy and OpenCV (core functions) are used.
"""
import math

import numpy as np
import cv2

# ---------------------------------------------------------------- neighbourhood code tables
# bit order: N, NE, E, SE, S, SW, W, NW  (p2 .. p9)
_K = np.array([[128, 1, 2], [64, 0, 4], [32, 16, 8]], np.float32)
_NB = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]


def _bits(c):
    return [(c >> k) & 1 for k in range(8)]


def _guo_hall_lut(it):
    lut = np.zeros(256, np.uint8)
    for c in range(256):
        p2, p3, p4, p5, p6, p7, p8, p9 = _bits(c)
        C = ((not p2) and (p3 or p4)) + ((not p4) and (p5 or p6)) + ((not p6) and (p7 or p8)) + ((not p8) and (p9 or p2))
        N1 = (p9 or p2) + (p3 or p4) + (p5 or p6) + (p7 or p8)
        N2 = (p2 or p3) + (p4 or p5) + (p6 or p7) + (p8 or p9)
        N = min(N1, N2)
        m = ((p6 or p7 or (not p9)) and p8) if it == 0 else ((p2 or p3 or (not p5)) and p4)
        if C == 1 and 2 <= N <= 3 and not m:
            lut[c] = 1
    return lut


def _components(c):
    """number of 8-connected groups among the set neighbours of a pixel"""
    on = [k for k in range(8) if (c >> k) & 1]
    if not on:
        return 0
    pos = {k: _NB[k] for k in on}
    seen, groups = set(), 0
    for k in on:
        if k in seen:
            continue
        groups += 1
        stack = [k]
        seen.add(k)
        while stack:
            a = stack.pop()
            for b in on:
                if b not in seen and max(abs(pos[a][0] - pos[b][0]), abs(pos[a][1] - pos[b][1])) == 1:
                    seen.add(b)
                    stack.append(b)
    return groups


_GH = (_guo_hall_lut(0), _guo_hall_lut(1))
_COMP = np.array([_components(c) for c in range(256)], np.uint8)
_CNT = np.array([bin(c).count("1") for c in range(256)], np.uint8)
_STAIR = np.zeros(256, np.uint8)
for _c in range(256):
    b = _bits(_c)
    corner = (b[0] and b[2]) or (b[2] and b[4]) or (b[4] and b[6]) or (b[6] and b[0])
    if _CNT[_c] >= 2 and _COMP[_c] == 1 and corner:
        _STAIR[_c] = 1


def _code(img01):
    return cv2.filter2D(img01, cv2.CV_8U, _K, borderType=cv2.BORDER_CONSTANT)


# ---------------------------------------------------------------- 1. ink
def ink_mask(gray, dpi, threshold=0, speck_mm=0.2, max_line_mm=1.2):
    """bool array: True = ink (line) pixel"""
    h, w = gray.shape
    # background level (paper colour, uneven light): large closing on a reduced image
    s = max(1, int(round(dpi / 50.0)))
    small = cv2.resize(gray, (max(1, w // s), max(1, h // s)), interpolation=cv2.INTER_AREA)
    k = max(5, int(dpi / s * 0.12) | 1)
    bg = cv2.morphologyEx(small, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    bg = cv2.GaussianBlur(bg, (0, 0), k / 3.0)
    bg = cv2.resize(bg, (w, h), interpolation=cv2.INTER_LINEAR)
    bg = np.maximum(bg, 1).astype(np.uint8)
    sig = max(0.5, 0.7 * dpi / 300.0)
    smooth = cv2.GaussianBlur(gray, (0, 0), sig)                          # scan noise / JPEG artefacts
    norm = cv2.divide(smooth, bg, scale=255)                              # levelled paper = 255 (uint8, saturated)
    del smooth, bg
    # thin dark strokes relative to their surroundings (also inside grey shading)
    kk = max(5, int(dpi * max_line_mm / 25.4) | 1)
    se = cv2.getStructuringElement(cv2.MORPH_RECT, (kk, kk))
    clo = cv2.morphologyEx(norm, cv2.MORPH_CLOSE, se)
    # relative darkness of a pixel against its local surroundings (paper or grey shading): 0 .. 255
    rel = cv2.divide(cv2.subtract(clo, norm), np.maximum(clo, 24), scale=255)
    del clo
    if threshold and threshold > 0:
        t_hi = float(threshold)
        t_lo = t_hi * 0.6
    else:
        sample = rel[::3, ::3].reshape(-1)
        sample = sample[sample > 8]
        if sample.size > 100:
            t_otsu, _ = cv2.threshold(sample.reshape(1, -1), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        else:
            t_otsu = 80.0
        bgv = rel[::3, ::3].reshape(-1)
        bgv = bgv[bgv < t_otsu / 2.0].astype(np.float32)
        med = float(np.median(bgv)) if bgv.size else 0.0
        mad = float(np.median(np.abs(bgv - med))) * 1.4826 if bgv.size else 5.0
        t_lo = float(min(max(med + 6.0 * mad, 30.0), t_otsu * 0.6))
        t_hi = float(min(max(t_otsu * 0.8, t_lo + 10.0), 130.0))
    dark = norm < 60
    weak = ((rel >= t_lo) | dark).astype(np.uint8)
    strong = (rel >= t_hi) | dark
    # hysteresis: faint parts are kept when they touch a clear stroke or are long (a faint line, not noise)
    n, lab, st, _ = cv2.connectedComponentsWithStats(weak, connectivity=8)
    keep = np.zeros(n, bool)
    keep[np.unique(lab[strong])] = True
    long_px = 2.0 / 25.4 * dpi
    mx = np.maximum(st[1:, cv2.CC_STAT_WIDTH], st[1:, cv2.CC_STAT_HEIGHT]).astype(np.float32)
    thin_long = (mx >= long_px) & (st[1:, cv2.CC_STAT_AREA] <= mx * (0.45 / 25.4 * dpi))
    keep[1:] |= thin_long
    keep[0] = False
    # clear strokes are cut at a middle level (no thickening by their blurred edges); faint lines keep the low level
    has_strong = np.zeros(n, bool)
    has_strong[np.unique(lab[strong])] = True
    t_mid = (t_lo + t_hi) / 2.0
    ink = keep[lab] & ((rel >= t_mid) | dark | ~has_strong[lab])
    ink = ink.astype(np.uint8)
    # pin holes inside strokes
    inv = (1 - ink).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(inv, connectivity=4)
    small_holes = np.zeros(n, bool)
    small_holes[1:] = st[1:, cv2.CC_STAT_AREA] <= 3
    ink[small_holes[lab]] = 1
    # specks
    min_area = max(2, int((speck_mm / 25.4 * dpi) ** 2))
    n, lab, st, _ = cv2.connectedComponentsWithStats(ink, connectivity=8)
    keep = np.zeros(n, bool)
    keep[1:] = (st[1:, cv2.CC_STAT_AREA] >= min_area) | (np.maximum(st[1:, cv2.CC_STAT_WIDTH], st[1:, cv2.CC_STAT_HEIGHT])
                                                         >= 3 * math.sqrt(min_area))
    ink = keep[lab]
    return ink, norm


def shading_regions(norm, ink, dpi, level=200, min_mm=3.0):
    """grey shaded areas (not lines): outlines for an optional SHADING layer"""
    m = ((norm < level) & ~cv2.dilate(ink.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    min_area = (min_mm / 25.4 * dpi) ** 2
    cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    return _contour_groups(cnts, hier, min_area, eps=1.5)


def _contour_groups(cnts, hier, min_area, eps=0.8):
    out = []
    if hier is None:
        return out
    hier = hier[0]
    for i, c in enumerate(cnts):
        if hier[i][3] != -1:
            continue
        if cv2.contourArea(c) < min_area:
            continue
        outer = cv2.approxPolyDP(c, eps, True).reshape(-1, 2).astype(float)
        holes = []
        j = hier[i][2]
        while j != -1:
            if cv2.contourArea(cnts[j]) >= max(4.0, min_area * 0.05):
                holes.append(cv2.approxPolyDP(cnts[j], eps, True).reshape(-1, 2).astype(float))
            j = hier[j][0]
        if len(outer) >= 3:
            out.append((outer, holes))
    return out


# ---------------------------------------------------------------- 2./3. thinning
def thin(ink, progress=None):
    img = ink.astype(np.uint8)
    ys, xs = np.nonzero(img)
    if len(ys) == 0:
        return img.astype(bool)
    y0, y1, x0, x1 = max(0, ys.min() - 1), ys.max() + 2, max(0, xs.min() - 1), xs.max() + 2
    roi = img[y0:y1, x0:x1].copy()
    it = 0
    while True:
        changed = 0
        for sub in (0, 1):
            code = _code(roi)
            mark = cv2.LUT(code, _GH[sub]) & roi
            nz = int(cv2.countNonZero(mark))
            if nz:
                roi[mark.astype(bool)] = 0
                changed += nz
        it += 1
        if progress:
            progress(it)
        if not changed or it > 200:
            break
    # staircase pixels (two passes with a checker board so neighbours are never removed together)
    yy, xx = np.indices(roi.shape)
    parity = ((yy + xx) & 1).astype(np.uint8)
    for par in (0, 1):
        code = _code(roi)
        mark = cv2.LUT(code, _STAIR) & roi & (parity == par).astype(np.uint8)
        roi[mark.astype(bool)] = 0
    out = np.zeros_like(img)
    out[y0:y1, x0:x1] = roi
    return out.astype(bool)


# ---------------------------------------------------------------- 4. tracing
class Graph:
    def __init__(self):
        self.edges = []          # [ [na, nb, pts(list of (x, y))] ]
        self.node_xy = {}        # node id -> (x, y)
        self.node_kind = {}      # node id -> 'end' | 'junction'


def trace(skel):
    H, W = skel.shape
    Wp = W + 2
    P = np.zeros((H + 2, Wp), np.uint8)
    P[1:-1, 1:-1] = skel
    code = _code(P)
    code[P == 0] = 0
    comp = cv2.LUT(code, _COMP)
    kind = np.zeros_like(P)
    kind[(P == 1) & (comp == 2)] = 1                    # regular
    kind[(P == 1) & (comp <= 1)] = 2                    # end point (or isolated)
    kind[(P == 1) & (comp >= 3)] = 3                    # junction
    # junction clusters -> one node each
    nj, jlab = cv2.connectedComponents((kind == 3).astype(np.uint8), connectivity=8)
    g = Graph()
    flat_kind = kind.ravel()
    flat_code = code.ravel()
    jl = jlab.ravel()
    if nj > 1:
        idx = np.flatnonzero(jl)
        lab = jl[idx]
        ys, xs = idx // Wp - 1, idx % Wp - 1
        cnt = np.bincount(lab, minlength=nj)
        sx = np.bincount(lab, xs, minlength=nj)
        sy = np.bincount(lab, ys, minlength=nj)
        for k in range(1, nj):
            g.node_xy[k] = (sx[k] / cnt[k], sy[k] / cnt[k])
            g.node_kind[k] = "junction"
    next_id = nj
    ends = np.flatnonzero(flat_kind == 2)
    end_node = {}
    for e in ends.tolist():
        end_node[e] = next_id
        g.node_xy[next_id] = (e % Wp - 1.0, e // Wp - 1.0)
        g.node_kind[next_id] = "end"
        next_id += 1

    def nid(f):
        k = flat_kind[f]
        if k == 3:
            return int(jl[f])
        if k == 2:
            return end_node[f]
        return None

    offs = [-Wp, -Wp + 1, 1, Wp + 1, Wp, Wp - 1, -1, -Wp - 1]
    four = {-Wp, 1, Wp, -1}
    nbr = [tuple(offs[b] for b in range(8) if (c >> b) & 1) for c in range(256)]
    kb = flat_kind.tobytes()
    cb = flat_code.tobytes()
    vis = bytearray(len(kb))
    done_pairs = set()

    def xy(f):
        return (f % Wp - 1.0, f // Wp - 1.0)

    def walk(start, first):
        pts = [start, first]
        vis[first] = 1
        prev, cur = start, first
        while True:
            cands = [cur + o for o in nbr[cb[cur]] if cur + o != prev]
            nodes = [c for c in cands if kb[c] >= 2 and not (c == start and len(pts) <= 2)]
            if nodes:
                pts.append(nodes[0])
                return pts
            regs = [c for c in cands if kb[c] == 1 and not vis[c]]
            if not regs:
                return pts
            if len(regs) > 1:
                regs.sort(key=lambda c: (c - cur) not in four)
            nxt = regs[0]
            for r in regs[1:]:
                # a side pixel without any other unvisited neighbour is a bump of the same stroke
                if all((r + o == cur or r + o == nxt or vis[r + o] or kb[r + o] == 0) for o in nbr[cb[r]]):
                    vis[r] = 1
            vis[nxt] = 1
            pts.append(nxt)
            prev, cur = cur, nxt

    node_pixels = np.flatnonzero(flat_kind >= 2).tolist()
    for q in node_pixels:
        a = nid(q)
        for o in nbr[cb[q]]:
            r = q + o
            k = kb[r]
            if k == 1:
                if vis[r]:
                    continue
                pts = walk(q, r)
                last = pts[-1]
                b = nid(last) if kb[last] >= 2 else None
                if b is None:                       # dead end on a regular pixel: make it an end point
                    b = next_id
                    g.node_xy[b] = xy(last)
                    g.node_kind[b] = "end"
                    next_id += 1
                g.edges.append([a, b, [xy(f) for f in pts]])
            elif k >= 2:
                b = nid(r)
                if a == b:
                    continue
                key = (min(q, r), max(q, r))
                if key in done_pairs:
                    continue
                done_pairs.add(key)
                g.edges.append([a, b, [xy(q), xy(r)]])
    # closed loops without any node (circles, rectangles drawn as one stroke)
    regular = np.flatnonzero(flat_kind == 1)
    for s in regular.tolist():
        if vis[s]:
            continue
        vis[s] = 1
        nb = [s + o for o in nbr[cb[s]] if kb[s + o] == 1 and not vis[s + o]]
        if not nb:
            continue
        pts = walk(s, nb[0])
        loop = [xy(f) for f in pts]
        if len(loop) >= 3:
            loop.append(loop[0])
            nidl = next_id
            g.node_xy[nidl] = loop[0]
            g.node_kind[nidl] = "loop"
            next_id += 1
            g.edges.append([nidl, nidl, loop])
    # junction ends -> the junction centre
    for e in g.edges:
        for side in (0, 1):
            n = e[side]
            if g.node_kind.get(n) == "junction":
                if side == 0:
                    e[2][0] = g.node_xy[n]
                else:
                    e[2][-1] = g.node_xy[n]
    return g


def _plen(pts):
    a = np.asarray(pts)
    return float(np.hypot(*np.diff(a, axis=0).T).sum()) if len(a) > 1 else 0.0


def _degree(g):
    deg = {}
    for a, b, _p in g.edges:
        deg[a] = deg.get(a, 0) + 1
        deg[b] = deg.get(b, 0) + 1
    return deg


def _merge_deg2(g):
    """join the two edges at every junction that has only two edges left"""
    edges = dict(enumerate(g.edges))
    inc = {}
    for i, (a, b, _p) in edges.items():
        inc.setdefault(a, set()).add(i)
        inc.setdefault(b, set()).add(i)
    nid = len(edges)
    stack = [n for n, st in inc.items() if len(st) == 2 and g.node_kind.get(n) == "junction"]
    while stack:
        n = stack.pop()
        st = inc.get(n)
        if not st or len(st) != 2 or g.node_kind.get(n) != "junction":
            continue
        i, j = tuple(st)
        ei, ej = edges[i], edges[j]
        if ei[0] == ei[1] or ej[0] == ej[1]:
            continue
        pi = ei[2] if ei[1] == n else ei[2][::-1]
        a = ei[0] if ei[1] == n else ei[1]
        pj = ej[2] if ej[0] == n else ej[2][::-1]
        b = ej[1] if ej[0] == n else ej[0]
        del edges[i]
        del edges[j]
        for x in (a, b):
            inc[x].discard(i)
            inc[x].discard(j)
        inc[n] = set()
        edges[nid] = [a, b, pi + pj[1:]]
        inc[a].add(nid)
        inc[b].add(nid)
        nid += 1
        g.node_kind[n] = "gone"
        for x in (a, b):
            if len(inc[x]) == 2 and g.node_kind.get(x) == "junction":
                stack.append(x)
    g.edges = list(edges.values())


def prune(g, spur_px, dist=None):
    """remove skeleton spurs: short branches from a junction to a free end, shorter than the local stroke width"""
    H, W = dist.shape if dist is not None else (0, 0)

    def limit(n):
        if dist is None:
            return spur_px
        x, y = g.node_xy[n]
        hw = float(dist[min(max(int(round(y)), 0), H - 1), min(max(int(round(x)), 0), W - 1)])
        return min(spur_px, max(2.5, 1.5 * hw + 1.0))

    for _round in range(3):
        deg = _degree(g)
        keep = []
        removed = 0
        cand = {}
        for k, e in enumerate(g.edges):
            a, b, p = e
            ka, kb_ = g.node_kind.get(a), g.node_kind.get(b)
            j = None
            if ka == "end" and kb_ == "junction" and deg.get(b, 0) >= 3:
                j = b
            elif kb_ == "end" and ka == "junction" and deg.get(a, 0) >= 3:
                j = a
            if j is not None and _plen(p) < limit(j):
                cand.setdefault(j, []).append(k)
        # two short branches pointing in opposite directions are a real tick / cross mark, not skeleton noise
        protect = set()
        for j, ks in cand.items():
            if len(ks) < 2:
                continue
            dirs = []
            for k in ks:
                a, b, p = g.edges[k]
                q = np.asarray(p[-1] if a == j else p[0], float) - np.asarray(g.node_xy[j], float)
                L = math.hypot(*q)
                dirs.append(q / L if L > 1e-6 else None)
            for x in range(len(ks)):
                for y in range(x + 1, len(ks)):
                    if dirs[x] is not None and dirs[y] is not None and float(np.dot(dirs[x], dirs[y])) < -0.9:
                        protect.update((ks[x], ks[y]))
        spurs = {k for ks in cand.values() for k in ks} - protect
        for k, e in enumerate(g.edges):
            a, b, p = e
            ka, kb_ = g.node_kind.get(a), g.node_kind.get(b)
            if k in spurs:
                removed += 1
                continue
            if ka == "end" and kb_ == "end" and _plen(p) < 1.5:
                removed += 1
                continue
            keep.append(e)
        g.edges = keep
        _merge_deg2(g)
        if not removed:
            break


def _end_dir(pts, at_start, reach):
    """unit direction pointing away from the node along the path"""
    a = np.asarray(pts if at_start else pts[::-1], float)
    if len(a) < 2:
        return None
    d = np.hypot(*(a - a[0]).T)
    k = int(np.searchsorted(d, reach))
    k = min(max(k, 1), len(a) - 1)
    seg = a[: k + 1]
    if len(seg) >= 3:
        c = seg.mean(axis=0)
        _u, _s, vt = np.linalg.svd(seg - c)
        v = vt[0]
        if np.dot(v, seg[-1] - seg[0]) < 0:
            v = -v
    else:
        v = seg[-1] - seg[0]
    nrm = np.hypot(*v)
    return v / nrm if nrm > 1e-9 else None


def merge_straight(g, reach_px, max_deg=12.0):
    """at crossings / T-junctions join the two edges that continue each other in a straight line"""
    cos_lim = math.cos(math.radians(max_deg))
    for _round in range(4):
        merged = False
        deg = _degree(g)
        inc = {}
        for i, (a, b, p) in enumerate(g.edges):
            if a == b:
                continue
            if g.node_kind.get(a) == "junction":
                inc.setdefault(a, []).append((i, True))
            if g.node_kind.get(b) == "junction":
                inc.setdefault(b, []).append((i, False))
        used = set()
        new_edges = []
        for n, ends in inc.items():
            if deg.get(n, 0) < 3:
                continue
            dirs = []
            for i, at_start in ends:
                if i in used:
                    continue
                if _plen(g.edges[i][2]) < reach_px * 0.8:
                    continue
                d = _end_dir(g.edges[i][2], at_start, reach_px)
                if d is not None:
                    dirs.append((i, at_start, d))
            pairs = []
            for x in range(len(dirs)):
                for y in range(x + 1, len(dirs)):
                    if dirs[x][0] == dirs[y][0]:
                        continue
                    c = -float(np.dot(dirs[x][2], dirs[y][2]))
                    if c >= cos_lim:
                        pairs.append((c, x, y))
            pairs.sort(reverse=True)
            taken = set()
            for c, x, y in pairs:
                if x in taken or y in taken:
                    continue
                i, si, _ = dirs[x]
                j, sj, _ = dirs[y]
                if i in used or j in used:
                    continue
                taken.update((x, y))
                ei, ej = g.edges[i], g.edges[j]
                pi = ei[2] if not si else ei[2][::-1]          # ends at n
                ai = ei[1] if si else ei[0]
                pj = ej[2] if sj else ej[2][::-1]              # starts at n
                bj = ej[1] if sj else ej[0]
                new_edges.append([ai, bj, pi + pj[1:], n])
                used.update((i, j))
        if not new_edges:
            break
        g.edges = [e for k, e in enumerate(g.edges) if k not in used] + [e[:3] for e in new_edges]
        merged = True
        if not merged:
            break


# ---------------------------------------------------------------- 5. fitting
def _rdp(a, eps):
    n = len(a)
    if n < 3:
        return [0, n - 1]
    keep = np.zeros(n, bool)
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        p, q = a[i], a[j]
        d = q - p
        L = math.hypot(d[0], d[1])
        seg = a[i + 1:j]
        if L < 1e-9:
            dist = np.hypot(*(seg - p).T)
        else:
            dist = np.abs(d[0] * (seg[:, 1] - p[1]) - d[1] * (seg[:, 0] - p[0])) / L
        k = int(np.argmax(dist))
        if dist[k] > eps:
            m = i + 1 + k
            keep[m] = True
            stack.append((i, m))
            stack.append((m, j))
    return list(np.flatnonzero(keep))


def _fit_line(pts):
    c = pts.mean(axis=0)
    if len(pts) < 2:
        return c, np.array([1.0, 0.0])
    _u, _s, vt = np.linalg.svd(pts - c, full_matrices=False)
    return c, vt[0]


def _intersect(c1, d1, c2, d2):
    den = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(den) < 1e-9:
        return None
    t = ((c2[0] - c1[0]) * d2[1] - (c2[1] - c1[1]) * d2[0]) / den
    return c1 + t * d1


def _proj(c, d, p):
    return c + np.dot(p - c, d) * d


def fit_circle(pts):
    x, y = pts[:, 0], pts[:, 1]
    A = np.column_stack([x, y, np.ones_like(x)])
    b = -(x * x + y * y)
    try:
        sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    except Exception:
        return None
    cx, cy = -sol[0] / 2.0, -sol[1] / 2.0
    r2 = cx * cx + cy * cy - sol[2]
    if r2 <= 0:
        return None
    r = math.sqrt(r2)
    res = np.abs(np.hypot(x - cx, y - cy) - r)
    return cx, cy, r, float(res.max()), float(np.sqrt((res * res).mean()))


def _remove_chamfers(verts, corner):
    """the centre line of a thick stroke cuts every sharp corner and bulges at T-junctions: a run of short segments
    between two long ones is replaced by the intersection of the long ones (exact corner), or removed when the long
    ones continue each other in a straight line"""
    v = [np.asarray(p, float) for p in verts]
    if corner <= 0 or len(v) < 4:
        return np.array(v)
    changed = True
    while changed and len(v) >= 4:
        changed = False
        seg = [math.hypot(*(v[k + 1] - v[k])) for k in range(len(v) - 1)]
        k = 0
        while k < len(seg):
            if seg[k] >= corner:
                k += 1
                continue
            j = k
            while j < len(seg) and seg[j] < corner:
                j += 1
            # short run = segments k .. j-1, long neighbours = k-1 and j
            if k >= 1 and j < len(seg) and seg[k - 1] >= 1.5 * corner and seg[j] >= 1.5 * corner and \
                    sum(seg[k:j]) < 3 * corner:
                a, b = v[k - 1], v[k]
                c, d = v[j], v[j + 1]
                d1 = (b - a) / seg[k - 1]
                d2 = (d - c) / seg[j]
                cross = abs(d1[0] * d2[1] - d1[1] * d2[0])
                if cross >= math.sin(math.radians(20)):
                    p = _intersect(a, d1, c, d2)
                    if p is not None and math.hypot(*(p - (b + c) / 2.0)) <= 2.0 * corner:
                        v[k:j + 1] = [p]
                        changed = True
                        break
                elif np.dot(d1, d2) > 0:
                    off = abs(d1[0] * (c[1] - a[1]) - d1[1] * (c[0] - a[0]))
                    if off <= corner * 0.5:
                        del v[k:j + 1]
                        changed = True
                        break
            k = j
    return np.array(v)


def fit_path(pts, tol, circles=True, closed=False, corner=0.0):
    """-> list of entities: ('line', p0, p1) | ('arc', cx, cy, r, p0, pm, p1) | ('circle', cx, cy, r) | ('poly', pts, closed)"""
    a = np.asarray(pts, float)
    if len(a) < 2:
        return []
    L = _plen(a)
    if L < 0.75:
        return []
    if closed and circles and len(a) >= 12:
        fc = fit_circle(a[:-1])
        if fc and fc[2] >= 2.0 and fc[3] <= max(tol * 1.6, min(fc[2] * 0.02, 2.5 * tol)):
            ext = a.max(axis=0) - a.min(axis=0)
            if ext.min() >= 1.7 * fc[2]:
                return [("circle", fc[0], fc[1], fc[2])]
    idx = _rdp(a, tol)
    if len(idx) == 2 and not closed:
        c, d = _fit_line(a)
        return [("line", _proj(c, d, a[0]), _proj(c, d, a[-1]))]
    # one smooth curve = one arc?
    if circles and not closed:
        arc = _arc_from(a, tol)
        if arc is not None:
            return [("arc", arc[0], arc[1], arc[2], a[0], a[len(a) // 2], a[-1])]
    # polyline: refit every straight run, vertices at the intersection of neighbouring fitted lines
    segs = []
    for s_, e_ in zip(idx[:-1], idx[1:]):
        sub = a[s_:e_ + 1]
        c, d = _fit_line(sub)
        segs.append((c, d))
    verts = [_proj(segs[0][0], segs[0][1], a[0])]
    for k in range(len(segs) - 1):
        c1, d1 = segs[k]
        c2, d2 = segs[k + 1]
        p = None
        if abs(d1[0] * d2[1] - d1[1] * d2[0]) > math.sin(math.radians(6)):
            p = _intersect(c1, d1, c2, d2)
        orig = a[idx[k + 1]]
        if p is None or np.hypot(*(p - orig)) > 3 * tol + 1.0:
            p = orig
        verts.append(p)
    verts.append(_proj(segs[-1][0], segs[-1][1], a[-1]))
    if closed:
        verts[-1] = verts[0]
    verts = _remove_chamfers(verts, corner)
    # split at sharp corners; smooth runs between corners may be arcs (fitted on all original points)
    dv = np.diff(verts, axis=0)
    ln = np.hypot(dv[:, 0], dv[:, 1])
    u = dv / np.maximum(ln, 1e-9)[:, None]
    turn = np.degrees(np.arccos(np.clip((u[:-1] * u[1:]).sum(axis=1), -1, 1))) if len(u) > 1 else np.zeros(0)
    cut = [0] + [k + 1 for k, t in enumerate(turn) if t > 28 or ln[k] > 25 * tol or ln[k + 1] > 25 * tol] + [len(verts) - 1]
    cut = sorted(set(cut))
    out = []
    for ci, cj in zip(cut[:-1], cut[1:]):
        if cj - ci == 1:
            if ln[ci] > 1e-6:
                out.append(("line", verts[ci], verts[cj]))
            continue
        dense = a[idx[ci]:idx[cj] + 1]
        arc = _arc_from(dense, tol) if circles else None
        if arc is not None:
            out.append(("arc", arc[0], arc[1], arc[2], verts[ci], dense[len(dense) // 2], verts[cj]))
        else:
            out.append(("poly", verts[ci:cj + 1], False))
    if closed and len(out) > 1 and all(o[0] == "line" for o in out):
        return [("poly", verts, True)]
    return out


def _arc_from(dense, tol):
    if len(dense) < 8:
        return None
    fc = fit_circle(dense)
    if not fc:
        return None
    cx, cy, r, mx, _rms = fc
    chord = math.hypot(*(dense[-1] - dense[0]))
    L = _plen(dense)
    if mx > tol * 1.5 or r < 2.0 or r > 5.0 * L:
        return None
    sag = r - math.sqrt(max(0.0, r * r - (chord / 2.0) ** 2)) if chord < 2 * r else r
    if sag < 1.5 * tol:
        return None
    ang = np.unwrap(np.arctan2(dense[:, 1] - cy, dense[:, 0] - cx))
    sweep = abs(ang[-1] - ang[0])
    if sweep < math.radians(20) or sweep > math.radians(355):
        return None
    step = np.diff(ang) * np.sign(ang[-1] - ang[0])
    if np.any(step < -0.25):
        return None
    return cx, cy, r


# ---------------------------------------------------------------- 6. clean-up
def _snap_ends(entities, g_nodes, tol_px):
    """close corners, T-junctions and small gaps: a line end near another line moves to the intersection"""
    lines = [k for k, e in enumerate(entities) if e["kind"] == "line"]
    if not lines:
        return entities
    # tiny connector pieces left by the skeleton inside a junction are dropped
    short = tol_px * 0.6
    ends = {}
    for k in lines:
        for key in ("p0", "p1"):
            p = entities[k][key]
            ends.setdefault((int(p[0] // 4), int(p[1] // 4)), []).append(k)

    def touches(k, p, rad):
        cx, cy = int(p[0] // 4), int(p[1] // 4)
        for gx in (cx - 1, cx, cx + 1):
            for gy in (cy - 1, cy, cy + 1):
                for j in ends.get((gx, gy), ()):
                    if j != k:
                        for key in ("p0", "p1"):
                            if math.hypot(*(entities[j][key] - p)) <= rad:
                                return True
        return False
    drop = set()
    for k in lines:
        e = entities[k]
        L = math.hypot(*(e["p1"] - e["p0"]))
        rad = max(0.75, 0.3 * L)
        if e["layer"] != "TEXT" and L < short and touches(k, e["p0"], rad) and touches(k, e["p1"], rad):
            drop.add(k)
    lines = [k for k in lines if k not in drop]
    cell = max(32.0, 4 * tol_px)
    grid = {}
    P0 = np.array([entities[k]["p0"] for k in lines])
    P1 = np.array([entities[k]["p1"] for k in lines])
    lo = np.minimum(P0, P1) - tol_px
    hi = np.maximum(P0, P1) + tol_px
    for n, k in enumerate(lines):
        for gx in range(int(lo[n, 0] // cell), int(hi[n, 0] // cell) + 1):
            for gy in range(int(lo[n, 1] // cell), int(hi[n, 1] // cell) + 1):
                grid.setdefault((gx, gy), []).append(k)
    for k in lines:
        e = entities[k]
        for key, other in (("p0", "p1"), ("p1", "p0")):
            p, q = e[key], e[other]
            d = p - q
            L = math.hypot(*d)
            if L < 2 * tol_px:
                continue
            d = d / L
            best = None
            for j in grid.get((int(p[0] // cell), int(p[1] // cell)), ()):
                if j == k:
                    continue
                t = entities[j]
                a, b = t["p0"], t["p1"]
                u = b - a
                Lu = math.hypot(*u)
                if Lu < 1e-6:
                    continue
                u = u / Lu
                # distance of the end point from the other segment
                s_ = np.dot(p - a, u)
                if s_ < -tol_px or s_ > Lu + tol_px:
                    continue
                dist = abs(u[0] * (p[1] - a[1]) - u[1] * (p[0] - a[0]))
                if dist > tol_px:
                    continue
                if abs(d[0] * u[1] - d[1] * u[0]) < math.sin(math.radians(15)):
                    continue                      # (nearly) parallel: no corner to close
                x = _intersect(q, d, a, u)
                if x is None:
                    continue
                move = math.hypot(*(x - p))
                if move <= tol_px * 1.5 and (best is None or move < best[0]):
                    best = (move, x)
            if best is not None:
                e[key] = best[1]
    return [e for k, e in enumerate(entities) if k not in drop]


def _merge_collinear(entities, tol):
    """pieces of one straight line (split at crossings and ticks) are joined into a single LINE"""
    alive = {k: e for k, e in enumerate(entities) if e["kind"] == "line"}
    if not alive:
        return entities
    q = 0.75

    def key(p):
        return (int(round(p[0] / q)), int(round(p[1] / q)))
    ends = {}
    for k, e in alive.items():
        for side in ("p0", "p1"):
            ends.setdefault(key(e[side]), set()).add((k, side))
    lim = math.cos(math.radians(1.5))
    changed = True
    rounds = 0
    while changed and rounds < 6:
        changed = False
        rounds += 1
        for kk in list(ends.keys()):
            group = set()
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    group |= ends.get((kk[0] + dx, kk[1] + dy), set())
            group = [(k, sd) for k, sd in group if k in alive]
            if len(group) < 2:
                continue
            best = None
            for x in range(len(group)):
                for y in range(x + 1, len(group)):
                    (k1, s1), (k2, s2) = group[x], group[y]
                    if k1 == k2:
                        continue
                    e1, e2 = alive[k1], alive[k2]
                    if e1["layer"] != e2["layer"]:
                        continue
                    o1 = "p1" if s1 == "p0" else "p0"
                    o2 = "p1" if s2 == "p0" else "p0"
                    d1 = e1[s1] - e1[o1]
                    d2 = e2[o2] - e2[s2]
                    L1, L2 = math.hypot(*d1), math.hypot(*d2)
                    if L1 < 1e-6 or L2 < 1e-6:
                        continue
                    c = float(np.dot(d1, d2)) / (L1 * L2)
                    if c >= lim and (best is None or c > best[0]):
                        best = (c, k1, s1, o1, k2, s2, o2)
            if best is None:
                continue
            _c, k1, s1, o1, k2, s2, o2 = best
            e1, e2 = alive[k1], alive[k2]
            a, b = e1[o1], e2[o2]
            ab = b - a
            Lab = math.hypot(*ab)
            j = (e1[s1] + e2[s2]) / 2.0
            if Lab < 1e-6 or abs(ab[0] * (j[1] - a[1]) - ab[1] * (j[0] - a[0])) / Lab > 0.6 * tol:
                continue
            for side, kx in ((s1, k1), (o1, k1), (s2, k2), (o2, k2)):
                st = ends.get(key(alive[kx][side]))
                if st:
                    st.discard((kx, side))
            new = dict(e1)
            new["p0"], new["p1"] = np.array(a, float), np.array(b, float)
            new["width"] = (e1["width"] * L1_len(e1) + e2["width"] * L1_len(e2)) / max(1e-6, L1_len(e1) + L1_len(e2))
            del alive[k2]
            alive[k1] = new
            for side in ("p0", "p1"):
                ends.setdefault(key(new[side]), set()).add((k1, side))
            changed = True
    out = []
    for k, e in enumerate(entities):
        if e["kind"] != "line":
            out.append(e)
        elif k in alive:
            out.append(alive[k])
    return out


def L1_len(e):
    return math.hypot(*(e["p1"] - e["p0"]))


def _rotate(p, c, ang):
    ca, sa = math.cos(ang), math.sin(ang)
    q = p - c
    return np.array([c[0] + q[0] * ca - q[1] * sa, c[1] + q[0] * sa + q[1] * ca])


def deskew_angle(entities, min_len):
    angs, wts = [], []
    for e in entities:
        if e["kind"] != "line":
            continue
        d = e["p1"] - e["p0"]
        L = math.hypot(*d)
        if L < min_len:
            continue
        a = math.degrees(math.atan2(d[1], d[0]))
        a = (a + 45) % 90 - 45
        if abs(a) <= 4:
            angs.append(a)
            wts.append(L)
    if len(angs) < 8:
        return 0.0
    o = np.argsort(angs)
    a = np.array(angs)[o]
    w = np.array(wts)[o]
    cw = np.cumsum(w)
    med = float(a[np.searchsorted(cw, cw[-1] / 2.0)])
    return med if abs(med) >= 0.02 else 0.0


# ---------------------------------------------------------------- main
def vectorize(gray, dpi, rgb=None, tol=1.0, threshold=0, speck_mm=0.2, circles=True, fills=True, text_layer=True,
              deskew=True, ortho=True, shading=False, text_mm=6.0, progress=None):
    """gray: uint8 page image (white paper). Returns dict with entities in pixel coordinates.

    entities: dicts {kind: line|arc|circle|poly, ..., width: stroke width px, layer: LINES|THICK|TEXT|CIRCLES, color}
    fills: [(outer, [holes])], shading: [(outer, [holes])], skew: degrees removed
    """
    def P(msg, f):
        if progress and progress(f, msg) is False:
            raise RuntimeError("cancelled")

    P("Finding the lines on the scan…", 0.05)
    ink, norm = ink_mask(gray, dpi, threshold=threshold, speck_mm=speck_mm)
    ink8 = ink.astype(np.uint8)
    dist = cv2.distanceTransform(ink8, cv2.DIST_L2, 3)
    P("Thinning strokes to their centre line…", 0.15)
    sk0 = thin(ink)
    hw = float(np.median(dist[sk0])) if sk0.any() else 1.0          # typical half stroke width
    fill_out = []
    if fills:
        core_r = max(3.0 * hw + 1.0, 0.45 / 25.4 * dpi)
        core = (dist >= core_r).astype(np.uint8)
        if core.any():
            r = int(math.ceil(core_r)) + 1
            region = cv2.dilate(core, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))) & ink8
            cnts, hier = cv2.findContours(region, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
            fill_out = _contour_groups(cnts, hier, min_area=(2 * core_r) ** 2, eps=max(0.7, tol * 0.8))
            if fill_out:
                ink8 = ink8 & (1 - region)
                ink = ink8.astype(bool)
                P("Thinning strokes to their centre line…", 0.25)
                sk0 = thin(ink)
    shade = shading_regions(norm, ink, dpi) if shading else []
    # component classes: small components = text / symbols
    labels = None
    small = None
    if text_layer:
        n, labels, st, _ = cv2.connectedComponentsWithStats(ink8, connectivity=8)
        tpx = text_mm / 25.4 * dpi
        small = np.zeros(n, bool)
        small[1:] = np.maximum(st[1:, cv2.CC_STAT_WIDTH], st[1:, cv2.CC_STAT_HEIGHT]) <= tpx
    P("Tracing centre lines…", 0.4)
    g = trace(sk0)
    P("Cleaning junctions…", 0.6)
    spur = max(3.0, 2.6 * hw + 1.5)
    prune(g, spur * 1.6, dist)
    merge_straight(g, reach_px=max(6.0, 4.0 * hw + 4.0))
    P("Fitting lines, arcs and circles…", 0.7)
    ents = []
    widths = []
    H, W = gray.shape
    for a, b, pts in g.edges:
        if len(pts) < 2:
            continue
        closed = a == b and g.node_kind.get(a) == "loop"
        arr = np.asarray(pts)
        ix = np.clip(np.round(arr[:, 0]).astype(int), 0, W - 1)
        iy = np.clip(np.round(arr[:, 1]).astype(int), 0, H - 1)
        wpx = 2.0 * float(np.median(dist[iy, ix])) if len(ix) else 1.0
        layer = "LINES"
        if labels is not None:
            lab = labels[iy[len(iy) // 2], ix[len(ix) // 2]]
            if lab and small[lab]:
                layer = "TEXT"
        col = None
        if rgb is not None:
            c = rgb[iy, ix].reshape(-1, 3).mean(axis=0)
            col = tuple(int(v) for v in c)
        for e in fit_path(pts, tol, circles=circles, closed=closed, corner=2.0 * hw + 2.0):
            d = {"kind": e[0], "width": wpx, "layer": layer, "color": col, "nodes": (a, b)}
            if e[0] == "line":
                d.update(p0=np.asarray(e[1], float), p1=np.asarray(e[2], float))
            elif e[0] == "arc":
                d.update(c=np.array([e[1], e[2]]), r=e[3], p0=np.asarray(e[4], float), pm=np.asarray(e[5], float),
                         p1=np.asarray(e[6], float))
            elif e[0] == "circle":
                d.update(c=np.array([e[1], e[2]]), r=e[3])
                if layer != "TEXT":
                    d["layer"] = "CIRCLES"
            else:
                d.update(pts=np.asarray(e[1], float), closed=e[2])
            ents.append(d)
            widths.append(wpx)
    P("Closing corners and straightening…", 0.85)
    ents = _snap_ends(ents, g.node_kind, tol_px=max(3.0, 3.0 * hw + 2.0))
    skew = 0.0
    if deskew:
        skew = deskew_angle(ents, min_len=max(40.0, dpi * 0.2))
        if skew:
            c = np.array([W / 2.0, H / 2.0])
            ang = -math.radians(skew)
            for e in ents:
                for key in ("p0", "p1", "pm", "c"):
                    if key in e:
                        e[key] = _rotate(e[key], c, ang)
                if "pts" in e:
                    e["pts"] = np.array([_rotate(p, c, ang) for p in e["pts"]])
            fill_out = [(np.array([_rotate(p, c, ang) for p in o]), [np.array([_rotate(p, c, ang) for p in h]) for h in hs])
                        for o, hs in fill_out]
            shade = [(np.array([_rotate(p, c, ang) for p in o]), [np.array([_rotate(p, c, ang) for p in h]) for h in hs])
                     for o, hs in shade]
    ents = _merge_collinear(ents, tol)
    if ortho:
        lim = math.radians(0.4)
        for e in ents:
            if e["kind"] != "line":
                continue
            d = e["p1"] - e["p0"]
            a = math.atan2(d[1], d[0])
            for target in (0.0, math.pi / 2, math.pi, -math.pi / 2, -math.pi):
                if abs(a - target) <= lim:
                    m = (e["p0"] + e["p1"]) / 2.0
                    if abs(target) in (0.0, math.pi):
                        e["p0"] = np.array([e["p0"][0], m[1]])
                        e["p1"] = np.array([e["p1"][0], m[1]])
                    else:
                        e["p0"] = np.array([m[0], e["p0"][1]])
                        e["p1"] = np.array([m[0], e["p1"][1]])
                    break
    if widths:
        mw = float(np.median(widths))
        for e in ents:
            if e["layer"] == "LINES" and e["width"] >= 1.6 * mw and e["width"] >= mw + 1.5:
                e["layer"] = "THICK"
    P("Done", 1.0)
    return {"entities": ents, "fills": fill_out, "shading": shade, "skew": skew, "half_width": hw,
            "size": (W, H), "dpi": dpi}
