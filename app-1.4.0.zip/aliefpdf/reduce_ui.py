"""Reduce File Size dialog (current document or many files)."""
import os

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QComboBox, QCheckBox, QLineEdit,
                               QPushButton, QListWidget, QRadioButton, QButtonGroup, QDialogButtonBox, QFileDialog,
                               QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QAbstractItemView)

from . import theme
from . import reduce as R
from .settings import settings


class ReduceDialog(QDialog):
    def __init__(self, main, pdfdoc=None):
        super().__init__(main)
        self.main = main
        self.pdfdoc = pdfdoc
        self.setWindowTitle("Reduce File Size")
        self.setWindowIcon(theme.icon("zip-box-outline"))
        self.setMinimumWidth(640)
        lay = QVBoxLayout(self)
        intro = QLabel("Makes the PDF smaller. In <b>Lossless</b> mode text, lines, graphics and image pixels stay exactly "
                       "the same - only the way they are stored is improved, and the result is checked page by page.")
        intro.setWordWrap(True)
        lay.addWidget(intro)

        g = QGroupBox("Files")
        gl = QVBoxLayout(g)
        self.r_cur = QRadioButton()
        self.r_many = QRadioButton("Several PDF files")
        bg = QButtonGroup(self)
        bg.addButton(self.r_cur)
        bg.addButton(self.r_many)
        if pdfdoc is not None:
            size = self._doc_size(pdfdoc)
            self.r_cur.setText("This document: %s  (%s)" % (pdfdoc.title, R.fmt_size(size) if size else "not saved yet"))
            self.r_cur.setChecked(True)
        else:
            self.r_cur.setText("This document (none open)")
            self.r_cur.setEnabled(False)
            self.r_many.setChecked(True)
        gl.addWidget(self.r_cur)
        gl.addWidget(self.r_many)
        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list.setMaximumHeight(130)
        gl.addWidget(self.list)
        row = QHBoxLayout()
        self.b_add = QPushButton(theme.icon("file-plus-outline"), "Add files…")
        self.b_dir = QPushButton(theme.icon("folder-plus-outline"), "Add folder…")
        self.b_rem = QPushButton(theme.icon("delete-outline"), "Remove")
        self.b_add.clicked.connect(self._add)
        self.b_dir.clicked.connect(self._add_dir)
        self.b_rem.clicked.connect(lambda: [self.list.takeItem(self.list.row(i)) for i in self.list.selectedItems()])
        for b in (self.b_add, self.b_dir, self.b_rem):
            row.addWidget(b)
        row.addStretch(1)
        gl.addLayout(row)
        lay.addWidget(g)

        g2 = QGroupBox("Quality")
        f = QFormLayout(g2)
        self.preset = QComboBox()
        for k, p in R.PRESETS.items():
            self.preset.addItem(p["label"], k)
        k = settings().get("reduce_preset", "lossless")
        self.preset.setCurrentIndex(max(0, self.preset.findData(k)))
        f.addRow("Images", self.preset)
        self.note = QLabel()
        self.note.setWordWrap(True)
        self.note.setStyleSheet("color:#5B6675;")
        f.addRow("", self.note)
        self.c_fonts = QCheckBox("Reduce embedded fonts to the characters that are used")
        self.c_priv = QCheckBox("Remove editing data of the creating program (AutoCAD / Illustrator) and page thumbnails")
        self.c_img = QCheckBox("Store images more compactly without changing any pixel (black && white scans: G4)")
        self.c_meta = QCheckBox("Remove document information (title, author, keywords)")
        self.c_verify = QCheckBox("Check the result page by page (recommended)")
        for c, key, val in ((self.c_fonts, "reduce_fonts", True), (self.c_priv, "reduce_private", True),
                            (self.c_img, "reduce_images", True), (self.c_meta, "reduce_meta", False),
                            (self.c_verify, "reduce_verify", True)):
            c.setChecked(bool(settings().get(key, val)))
            f.addRow("", c)
        lay.addWidget(g2)

        g3 = QGroupBox("Save to")
        f3 = QFormLayout(g3)
        self.suffix = QLineEdit(settings().get("reduce_suffix", "_reduced"))
        f3.addRow("Name ending", self.suffix)
        orow = QHBoxLayout()
        self.same = QCheckBox("Same folder as the original")
        self.same.setChecked(bool(settings().get("reduce_same_dir", True)))
        self.outdir = QLineEdit(settings().get("reduce_outdir", "") or settings().get("last_save_dir", "") or os.path.expanduser("~"))
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self.outdir.setText(QFileDialog.getExistingDirectory(self, "Output folder", self.outdir.text())
                                                      or self.outdir.text()))
        orow.addWidget(self.same)
        orow.addWidget(self.outdir, 1)
        orow.addWidget(b)
        f3.addRow("Folder", orow)
        self.open_after = QCheckBox("Open the reduced file when finished")
        self.open_after.setChecked(bool(settings().get("reduce_open", True)))
        f3.addRow("", self.open_after)
        lay.addWidget(g3)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Reduce size")
        bb.button(QDialogButtonBox.Ok).setIcon(theme.icon("zip-box-outline"))
        bb.accepted.connect(self.run)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        for w in (self.r_cur, self.r_many, self.same):
            w.toggled.connect(self._sync)
        self.preset.currentIndexChanged.connect(self._sync)
        self.setAcceptDrops(True)
        self._sync()

    @staticmethod
    def _doc_size(d):
        if d.path and os.path.exists(d.path) and not d.modified:
            return os.path.getsize(d.path)
        return 0

    def _sync(self, *a):
        many = self.r_many.isChecked()
        for w in (self.list, self.b_add, self.b_dir, self.b_rem):
            w.setEnabled(many)
        self.outdir.setEnabled(not self.same.isChecked())
        k = self.preset.currentData()
        if k == "lossless":
            self.note.setText("Nothing visible changes: text stays text, lines stay vectors, every image pixel is kept.")
        else:
            p = R.PRESETS[k]
            self.note.setText("Text and vector lines are never touched. Only photos / scans sharper than %d dpi are reduced "
                              "to %d dpi (black & white scans to %d dpi); smaller images stay as they are."
                              % (p["threshold"], p["dpi"], int(p["dpi"] * 1.5)))

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            p = u.toLocalFile()
            if p.lower().endswith(".pdf"):
                self.list.addItem(p)
        self.r_many.setChecked(True)

    def _add(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "PDF files", settings().get("last_dir", ""), "PDF (*.pdf)")
        for p in fs:
            self.list.addItem(p)
        if fs:
            self.r_many.setChecked(True)

    def _add_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Folder with PDF files", settings().get("last_dir", ""))
        if not d:
            return
        for fn in sorted(os.listdir(d)):
            if fn.lower().endswith(".pdf"):
                self.list.addItem(os.path.join(d, fn))
        self.r_many.setChecked(True)

    def _target(self, src_path, title):
        base = os.path.splitext(os.path.basename(src_path or title))[0]
        folder = os.path.dirname(src_path) if (self.same.isChecked() and src_path) else self.outdir.text().strip()
        folder = folder or os.path.expanduser("~")
        out = os.path.join(folder, base + (self.suffix.text().strip() or "_reduced") + ".pdf")
        if src_path and os.path.abspath(out) == os.path.abspath(src_path):
            out = os.path.join(folder, base + "_reduced.pdf")
        return out

    def _save_settings(self):
        s = settings()
        s.set("reduce_preset", self.preset.currentData())
        for c, key in ((self.c_fonts, "reduce_fonts"), (self.c_priv, "reduce_private"), (self.c_img, "reduce_images"),
                       (self.c_meta, "reduce_meta"), (self.c_verify, "reduce_verify"), (self.same, "reduce_same_dir"),
                       (self.open_after, "reduce_open")):
            s.set(key, c.isChecked())
        s.set("reduce_suffix", self.suffix.text().strip() or "_reduced")
        s.set("reduce_outdir", self.outdir.text().strip())
        s.save()

    def run(self):
        from .dialogs import run_with_progress
        self._save_settings()
        kw = dict(preset=self.preset.currentData(), subset_fonts=self.c_fonts.isChecked(), remove_private=self.c_priv.isChecked(),
                  recompress_images=self.c_img.isChecked(), remove_metadata=self.c_meta.isChecked(), verify=self.c_verify.isChecked())
        jobs = []
        if self.r_cur.isChecked() and self.pdfdoc is not None:
            d = self.pdfdoc
            src = d.path if (d.path and os.path.exists(d.path) and not d.modified) else d.doc.tobytes(garbage=0)
            jobs.append((src, self._target(d.path, d.title), d.password, d.title))
        else:
            files = [self.list.item(k).text() for k in range(self.list.count())]
            if not files:
                QMessageBox.information(self, "Reduce File Size", "Add the PDF files first.")
                return
            for p in files:
                jobs.append((p, self._target(p, p), None, os.path.basename(p)))
        for _src, out, _pw, _t in jobs:
            os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)

        def job(progress=None):
            res = []
            for k, (src, out, pw, title) in enumerate(jobs):
                def sub(i, n, msg, k=k, title=title):
                    return progress(k * 10 + int(10 * i / max(1, n)), len(jobs) * 10,
                                    ("%s - " % title if len(jobs) > 1 else "") + msg)
                try:
                    r = R.reduce_pdf(src, out, password=pw, progress=sub, **kw)
                    r["title"] = title
                    res.append(r)
                except Exception as e:
                    from .convert import Cancelled
                    if isinstance(e, Cancelled):
                        raise
                    res.append({"title": title, "error": str(e)})
            return res

        res = run_with_progress(self, "Reducing file size…", job)
        if not res:
            return
        self.results = res
        self.accept()
        ResultDialog(self.parent(), res).exec()
        ok = [r for r in res if "error" not in r]
        if ok and self.open_after.isChecked() and len(ok) == 1 and self.main is not None:
            try:
                self.main.open_files([ok[0]["path"]])
            except Exception:
                QDesktopServices.openUrl(QUrl.fromLocalFile(ok[0]["path"]))


class ResultDialog(QDialog):
    def __init__(self, parent, results):
        super().__init__(parent)
        self.setWindowTitle("Reduce File Size - result")
        self.setMinimumWidth(720)
        lay = QVBoxLayout(self)
        tb, ta = sum(r.get("before", 0) for r in results if "error" not in r), sum(r.get("after", 0) for r in results if "error" not in r)
        head = QLabel()
        head.setTextFormat(Qt.RichText)
        if tb:
            head.setText("<span style='font-size:13pt'><b>%s  →  %s</b></span> &nbsp; (%s smaller)"
                         % (R.fmt_size(tb), R.fmt_size(ta), "%.0f %%" % max(0.0, 100.0 - ta * 100.0 / tb)))
        lay.addWidget(head)
        t = QTableWidget(len(results), 5)
        t.setHorizontalHeaderLabels(["File", "Before", "After", "Smaller", "Check"])
        t.verticalHeader().hide()
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for i, r in enumerate(results):
            t.setItem(i, 0, QTableWidgetItem(r.get("title", "")))
            if "error" in r:
                t.setItem(i, 1, QTableWidgetItem("-"))
                t.setItem(i, 4, QTableWidgetItem(r["error"]))
                continue
            t.setItem(i, 1, QTableWidgetItem(R.fmt_size(r["before"])))
            t.setItem(i, 2, QTableWidgetItem(R.fmt_size(r["after"])))
            t.setItem(i, 3, QTableWidgetItem("%.0f %%" % max(0.0, 100.0 - r["after"] * 100.0 / max(1, r["before"]))))
            if "diff_pct" in r:
                chk = ("identical on %d checked page(s)" % r["verified_pages"]) if r["diff_pct"] <= 0.05 else \
                    ("checked %d page(s), images slightly softer" % r["verified_pages"])
            else:
                chk = "not checked"
            t.setItem(i, 4, QTableWidgetItem(chk))
        t.resizeColumnsToContents()
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        t.setMaximumHeight(min(420, 34 + 32 * len(results)))
        lay.addWidget(t)
        done = [r for r in results if "error" not in r]
        if len(done) == 1:
            steps = QLabel("<br>".join("• " + s for s in done[0]["steps"]) + "<br><br>Saved as: <b>%s</b>" % done[0]["path"])
            steps.setWordWrap(True)
            steps.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lay.addWidget(steps)
        row = QHBoxLayout()
        if done:
            b = QPushButton(theme.icon("folder-open-outline"), "Open folder")
            b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(done[0]["path"]))))
            row.addWidget(b)
        row.addStretch(1)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(self.accept)
        row.addWidget(bb)
        lay.addLayout(row)
