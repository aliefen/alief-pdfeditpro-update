"""Document model: wraps a PyMuPDF document with caches, undo/redo and save logic."""
import json
import os
import tempfile
import time
import itertools

import pymupdf
from PySide6.QtCore import QObject, Signal

_doc_ids = itertools.count(1)
_mu = pymupdf.mupdf


class PdfDoc(QObject):
    pages_changed = Signal(object)    # list of page indices, or None for all pages
    structure_changed = Signal()      # page count / order / size changed
    modified_changed = Signal(bool)
    annots_changed = Signal()
    snap_ready = Signal(int)          # page whose OSnap index became available

    UNDO_LIMIT_BYTES = 450 * 1024 * 1024
    UNDO_LIMIT_STEPS = 40

    def __init__(self, doc, path=None, password=None):
        super().__init__()
        self.uid = next(_doc_ids)
        self.doc = doc
        self.path = path
        self.password = password
        self.modified = False
        self.undo_stack = []
        self.redo_stack = []
        self.search_hits = {}          # page -> list of quads (unrotated coords)
        self.search_current = None     # (page, index)
        self.content_dirty = False     # page content differs from the file on disk
        self._reset_caches()

    # ------------------------------------------------------------------ open
    @staticmethod
    def open_path(path, ask_password=None):
        """Open a file. ask_password(attempt) -> str|None is called for protected files."""
        doc = pymupdf.open(path)
        password = None
        if doc.needs_pass:
            attempt = 0
            while True:
                pw = ask_password(attempt) if ask_password else None
                if pw is None:
                    doc.close()
                    return None
                if doc.authenticate(pw):
                    password = pw
                    break
                attempt += 1
        if not doc.is_pdf:
            # images / XPS / EPUB etc. -> convert to PDF in memory so it is editable
            data = doc.convert_to_pdf()
            doc.close()
            doc = pymupdf.open("pdf", data)
            pd = PdfDoc(doc, None, None)
            pd.source_name = os.path.basename(path)
            pd.modified = True
            return pd
        return PdfDoc(doc, path, password)

    @staticmethod
    def new_blank(width=595.0, height=842.0):
        doc = pymupdf.open()
        doc.new_page(width=width, height=height)
        pd = PdfDoc(doc, None, None)
        pd.modified = True
        return pd

    # ---------------------------------------------------------------- caches
    def _reset_caches(self):
        n = self.doc.page_count
        self.epoch = getattr(self, "epoch", 0) + 1   # part of every render-cache key
        self.gen = [0] * n             # any change on the page (content or comments)
        self.content_gen = [0] * n     # page content only (comments excluded)
        self._dl = {}
        self._cdl = {}
        self._odl = {}
        self._scale_cache = {}
        self._snap = {}
        self._snap_pending = set()
        self._words = {}
        self._annot_cache = {}
        self._sizes = None
        self._rot = None
        self._origin_cache = {}

    @property
    def title(self):
        if self.path:
            return os.path.basename(self.path)
        return getattr(self, "source_name", None) or "Untitled.pdf"

    @property
    def page_count(self):
        return self.doc.page_count

    def page(self, i):
        return self.doc.load_page(i)

    def page_sizes(self):
        if self._sizes is None:
            sizes, rots = [], []
            for i in range(self.doc.page_count):
                p = self.doc.load_page(i)
                r = p.rect
                sizes.append((r.width, r.height))
                rots.append((pymupdf.Matrix(p.rotation_matrix), pymupdf.Matrix(p.derotation_matrix), p.rotation))
            self._sizes, self._rot = sizes, rots
        return self._sizes

    def rot_info(self, i):
        self.page_sizes()
        return self._rot[i]

    def to_unrot(self, i, x, y):
        m = self.rot_info(i)[1]
        p = pymupdf.Point(x, y) * m
        return p.x, p.y

    def to_disp(self, i, x, y):
        m = self.rot_info(i)[0]
        p = pymupdf.Point(x, y) * m
        return p.x, p.y

    def display_list(self, i):
        """Display list of content + comments (used for reports)."""
        key = (i, self.gen[i])
        dl = self._dl.get(key)
        if dl is None:
            if len(self._dl) > 8:
                for k in list(self._dl.keys())[:4]:
                    self._dl.pop(k, None)
            dl = self.doc.load_page(i).get_displaylist(annots=True)
            self._dl[key] = dl
        return dl

    def content_dl(self, i):
        """Display list of the page content only (kept while only comments change)."""
        key = (i, self.content_gen[i])
        dl = self._cdl.get(key)
        if dl is None:
            if len(self._cdl) > 24:
                for k in list(self._cdl.keys())[:8]:
                    self._cdl.pop(k, None)
            dl = self.doc.load_page(i).get_displaylist(annots=False)
            self._cdl[key] = dl
        return dl

    def overlay_dl(self, i):
        """Low-level display list of comments + form fields of page i, or None if there are none."""
        key = (i, self.gen[i])
        if key in self._odl:
            return self._odl[key]
        dl = None
        try:
            page = self.doc.load_page(i)
            if page.first_annot is not None or page.first_widget is not None:
                pdfp = _mu.pdf_page_from_fz_page(page.this)
                dl = _mu.FzDisplayList(_mu.FzRect(_mu.FzRect.Fixed_INFINITE))
                dev = _mu.fz_new_list_device(dl)
                try:
                    _mu.pdf_run_page_annots(pdfp, dev, _mu.FzMatrix(), _mu.FzCookie())
                    _mu.pdf_run_page_widgets(pdfp, dev, _mu.FzMatrix(), _mu.FzCookie())
                finally:
                    _mu.fz_close_device(dev)
        except Exception:
            dl = False      # low-level API unavailable: callers fall back to the combined list
        if len(self._odl) > 64:
            for k in list(self._odl.keys())[:16]:
                self._odl.pop(k, None)
        self._odl[key] = dl
        return dl

    def draw_overlay(self, i, pix, matrix):
        """Draw the comments of page i onto pix (pymupdf.Pixmap) with the given matrix. Returns pix."""
        odl = self.overlay_dl(i)
        if not odl:
            return pix
        m = _mu.FzMatrix(matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f)
        dev = _mu.fz_new_draw_device(m, pix.this)
        try:
            _mu.fz_run_display_list(odl, dev, _mu.FzMatrix(), _mu.FzRect(_mu.FzRect.Fixed_INFINITE), _mu.FzCookie())
        finally:
            _mu.fz_close_device(dev)
        return pix

    def render(self, i, matrix, clip=None, alpha=False):
        """Pixmap of page i (content + comments). clip is in page display coordinates."""
        odl = self.overlay_dl(i)
        if odl is False:
            return self.display_list(i).get_pixmap(matrix=matrix, clip=clip, alpha=alpha)
        pix = self.content_dl(i).get_pixmap(matrix=matrix, clip=clip, alpha=alpha)
        if odl:
            self.draw_overlay(i, pix, matrix)
        return pix

    def words(self, i):
        key = (i, self.gen[i])
        w = self._words.get(key)
        if w is None:
            w = self.doc.load_page(i).get_text("words", sort=True)
            self._words[key] = w
        return w

    def snap_index(self, i, request=True):
        """OSnap index of page i, or None while it is being built in the background."""
        key = (self.epoch, i, self.content_gen[i])
        s = self._snap.get(key)
        if s is None and request and key not in self._snap_pending:
            self._request_snap(i, key)
        return s

    def _request_snap(self, i, key):
        from .snap import BUILDER, SnapIndex
        self._snap_pending.add(key)
        if self.path and not self.content_dirty and os.path.exists(self.path):
            source, pno = self.path, i
        else:
            tmp = pymupdf.open()
            try:
                tmp.insert_pdf(self.doc, from_page=i, to_page=i, annots=False, links=False, widgets=False)
                source = tmp.tobytes(garbage=0)
            finally:
                tmp.close()
            pno = 0

        def done(arrays):
            self._snap_pending.discard(key)
            if arrays is None:
                return
            try:
                idx = SnapIndex(arrays)
            except Exception:
                return
            if len(self._snap) > 8:
                self._snap.pop(next(iter(self._snap)), None)
            self._snap[key] = idx
            try:
                self.snap_ready.emit(i)
            except RuntimeError:
                pass
        BUILDER.submit(source, pno, self.password, done)

    def annot_list(self, i):
        """List of lightweight dicts describing annotations of page i (unrotated coords)."""
        key = (i, self.gen[i])
        lst = self._annot_cache.get(key)
        if lst is None:
            lst = []
            page = self.doc.load_page(i)
            for a in page.annots():
                try:
                    info = a.info
                    t = a.type[1]
                    d = {"xref": a.xref, "type": t, "rect": tuple(a.rect), "content": info.get("content", ""),
                         "author": info.get("title", ""), "subject": info.get("subject", ""),
                         "date": info.get("modDate") or info.get("creationDate", ""),
                         "vertices": None, "colors": a.colors, "flags": a.flags}
                    if t in ("Line", "Polygon", "PolyLine", "Ink"):
                        v = a.vertices
                        if t == "Ink" and v:
                            d["vertices"] = [[tuple(p) for p in stroke] for stroke in v]
                        elif v:
                            d["vertices"] = [tuple(p) for p in v]
                    d["status"] = self.get_key_str(a.xref, "AliefStatus")
                    d["measure"] = self.get_key_str(a.xref, "AliefMeasure")
                    d["group"] = self.get_key_str(a.xref, "AliefGroup")
                    d["blend"] = self.get_key_str(a.xref, "BM") or "Normal"
                    cl = self.get_key_str(a.xref, "AliefCloud") if t == "Polygon" else ""
                    if cl:
                        try:
                            d["cloud"] = json.loads(cl)
                        except Exception:
                            d["cloud"] = {"arc": 9.0}
                    if t == "FileAttachment":
                        try:
                            d["file"] = a.file_info.get("filename", "")
                        except Exception:
                            d["file"] = ""
                    lst.append(d)
                except Exception:
                    continue
            self._annot_cache[key] = lst
        return lst

    # --------------------------------------------------------------- PDF keys
    def get_key_str(self, xref, key):
        try:
            t, v = self.doc.xref_get_key(xref, key)
            if t == "string":
                return v
            if t == "name":
                return v.lstrip("/")
        except Exception:
            pass
        return ""

    def set_key_str(self, xref, key, value):
        if value is None or value == "":
            self.doc.xref_set_key(xref, key, "null")
        else:
            self.doc.xref_set_key(xref, key, pymupdf.get_pdf_str(str(value)))

    # ----------------------------------------------------------- page scale
    def get_scale(self, i):
        """Measurement scale of page i: dict(m_per_pt, unit, label) or None (cached)."""
        key = (i, self.gen[i])
        if key in self._scale_cache:
            v = self._scale_cache[key]
            return dict(v) if v else None
        val = None
        page = self.doc.load_page(i)
        s = self.get_key_str(page.xref, "AliefScale")
        if s:
            try:
                val = json.loads(s)
            except Exception:
                val = None
        if len(self._scale_cache) > 2000:
            self._scale_cache.clear()
        self._scale_cache[key] = val
        return dict(val) if val else None

    def set_scale(self, pages, scale):
        self._scale_cache.clear()
        for i in pages:
            page = self.doc.load_page(i)
            self.set_key_str(page.xref, "AliefScale", json.dumps(scale) if scale else "")
            if scale:
                self._write_viewport(page, scale)
        self.set_modified(True)

    def _write_viewport(self, page, scale):
        """Write a standard /VP /Measure dictionary so Acrobat / PDF-XChange also see the scale."""
        try:
            from .measure import UNIT_TO_M
            unit = scale.get("unit", "mm")
            c = scale["m_per_pt"] / UNIT_TO_M[unit]
            mb = page.mediabox
            label = scale.get("label", "") or ""
            area_u = "sq " + unit
            vp = ("[<</Type/Viewport/BBox[%g %g %g %g]/Name(Alief Scale)/Measure<</Type/Measure/Subtype/RL"
                  "/R%s/X[<</Type/NumberFormat/U%s/C %.10g/D 1000>>]/D[<</Type/NumberFormat/U%s/C 1/D 1000>>]"
                  "/A[<</Type/NumberFormat/U%s/C 1/D 1000>>]>>>>]") % (
                mb.x0, mb.y0, mb.x1, mb.y1, pymupdf.get_pdf_str(label), pymupdf.get_pdf_str(unit), c,
                pymupdf.get_pdf_str(unit), pymupdf.get_pdf_str(area_u))
            self.doc.xref_set_key(page.xref, "VP", vp)
        except Exception:
            pass

    def get_origin(self, i):
        key = (i, self.gen[i]) if i < len(self.gen) else None
        cache = self.__dict__.setdefault("_origin_cache", {})
        if key in cache:
            return cache[key]
        val = None
        page = self.doc.load_page(i)
        s = self.get_key_str(page.xref, "AliefOrigin")
        if s:
            try:
                x, y = json.loads(s)
                val = (float(x), float(y))
            except Exception:
                pass
        if len(cache) > 500:
            cache.clear()
        cache[key] = val
        return val

    def three_d(self, i):
        """[(xref, rect, has_poster)] of the 3D annotations of page i (cached)."""
        cache = self.__dict__.setdefault("_3d_cache", {})
        try:
            key = (i, self.gen[i])
        except Exception:
            key = (i, 0)
        if key in cache:
            return cache[key]
        from . import pdf3d
        try:
            val = pdf3d.page_3d_rects(self.doc, i)
        except Exception:
            val = []
        if len(cache) > 400:
            cache.clear()
        cache[key] = val
        return val

    def set_origin(self, i, pt):
        self._origin_cache = {}
        page = self.doc.load_page(i)
        self.set_key_str(page.xref, "AliefOrigin", json.dumps(list(pt)) if pt else "")
        self.set_modified(True)

    # ---------------------------------------------------------- modification
    def set_modified(self, flag=True):
        if self.modified != flag:
            self.modified = flag
            self.modified_changed.emit(flag)

    def _snapshot(self):
        return self.doc.tobytes(garbage=0)

    def checkpoint(self):
        """Call BEFORE a modification so it can be undone."""
        try:
            snap = self._snapshot()
        except Exception:
            return
        self.undo_stack.append(snap)
        self.redo_stack.clear()
        total = sum(len(s) for s in self.undo_stack)
        while self.undo_stack and (len(self.undo_stack) > self.UNDO_LIMIT_STEPS or total > self.UNDO_LIMIT_BYTES):
            total -= len(self.undo_stack.pop(0))

    def commit(self, pages=None, structure=False, annots=True, content=True):
        """Call AFTER a modification: refresh caches and notify views.

        content=False means only comments / form fields / page keys changed, so the cached
        page rendering and the OSnap index stay valid (fast path for comments and measuring).
        """
        self.set_modified(True)
        if structure or self.doc.page_count != len(self.gen):
            self.content_dirty = True
            self._reset_caches()
            self.structure_changed.emit()
        else:
            idx = range(self.doc.page_count) if pages is None else pages
            for i in idx:
                if 0 <= i < len(self.gen):
                    self.gen[i] += 1
                    if content:
                        self.content_gen[i] += 1
            if content:
                self.content_dirty = True
            self.pages_changed.emit(None if pages is None else list(pages))
        if annots:
            self.annots_changed.emit()

    def _reload_bytes(self, data):
        doc = pymupdf.open("pdf", data)
        if doc.needs_pass and self.password:
            doc.authenticate(self.password)
        old = self.doc
        self.doc = doc
        try:
            old.close()
        except Exception:
            pass
        self.content_dirty = True
        self._reset_caches()
        self.structure_changed.emit()
        self.annots_changed.emit()

    def can_undo(self):
        return bool(self.undo_stack)

    def can_redo(self):
        return bool(self.redo_stack)

    def undo(self):
        if not self.undo_stack:
            return False
        self.redo_stack.append(self._snapshot())
        self._reload_bytes(self.undo_stack.pop())
        self.set_modified(True)
        return True

    def redo(self):
        if not self.redo_stack:
            return False
        self.undo_stack.append(self._snapshot())
        self._reload_bytes(self.redo_stack.pop())
        self.set_modified(True)
        return True

    def replace_document(self, newdoc, checkpoint=True):
        if checkpoint:
            self.checkpoint()
        old = self.doc
        self.doc = newdoc
        if old is not newdoc:
            try:
                old.close()
            except Exception:
                pass
        self._reset_caches()
        self.set_modified(True)
        self.structure_changed.emit()
        self.annots_changed.emit()

    # ------------------------------------------------------------------ save
    def save(self, path=None, encryption=None, **enc):
        """Save to path (default: current path). Returns the saved path.

        encryption: None keeps the current security, or a pymupdf.PDF_ENCRYPT_* value.
        """
        target = path or self.path
        if not target:
            raise ValueError("No file name")
        same = self.path and os.path.normcase(os.path.abspath(target)) == os.path.normcase(os.path.abspath(self.path))
        keep = encryption is None
        enc_mode = pymupdf.PDF_ENCRYPT_KEEP if keep else encryption
        # fast path: incremental save into the same file
        if same and keep and self.doc.name and self.doc.can_save_incrementally():
            try:
                self.doc.save(target, incremental=True, encryption=pymupdf.PDF_ENCRYPT_KEEP)
                self.content_dirty = False
                self.set_modified(False)
                return target
            except Exception:
                pass
        folder = os.path.dirname(os.path.abspath(target)) or "."
        fd, tmp = tempfile.mkstemp(suffix=".pdf", dir=folder)
        os.close(fd)
        try:
            self.doc.save(tmp, garbage=1, deflate=True, encryption=enc_mode, **enc)
            if same and self.doc.name:
                # file is held open by MuPDF: close, replace, reopen
                self.doc.close()
            os.replace(tmp, target)
        except Exception:
            try:
                os.remove(tmp)
            except Exception:
                pass
            raise
        if same and self.doc.is_closed:
            self._reopen(target)
        elif not same or not self.doc.name:
            # Save As, or in-memory document (after undo / conversion): attach to the new file
            if not keep and encryption == pymupdf.PDF_ENCRYPT_NONE:
                self.password = None
            self._reopen(target)
        self.path = target
        if not keep and encryption == pymupdf.PDF_ENCRYPT_NONE:
            self.password = None
        elif enc.get("user_pw"):
            self.password = enc.get("user_pw")
        self.content_dirty = False
        self.set_modified(False)
        return target

    def _reopen(self, path):
        try:
            if not self.doc.is_closed:
                self.doc.close()
        except Exception:
            pass
        doc = pymupdf.open(path)
        if doc.needs_pass and self.password:
            doc.authenticate(self.password)
        self.doc = doc
        self._reset_caches()
        self.structure_changed.emit()

    def close(self):
        try:
            self.doc.close()
        except Exception:
            pass

    # ----------------------------------------------------------- utilities
    def security_info(self):
        d = self.doc
        perms = d.permissions
        names = [("Print", pymupdf.PDF_PERM_PRINT), ("Modify", pymupdf.PDF_PERM_MODIFY),
                 ("Copy", pymupdf.PDF_PERM_COPY), ("Annotate", pymupdf.PDF_PERM_ANNOTATE),
                 ("Fill forms", pymupdf.PDF_PERM_FORM), ("Assemble", pymupdf.PDF_PERM_ASSEMBLE),
                 ("Print high quality", pymupdf.PDF_PERM_PRINT_HQ)]
        enc = (d.metadata or {}).get("encryption")
        return {"encrypted": bool(d.is_encrypted or enc), "method": enc or "None",
                "needs_pass": bool(self.password),
                "perms": [(n, bool(perms & v)) for n, v in names],
                "signed": bool(self.has_signatures())}

    def has_signatures(self):
        try:
            for i in range(self.doc.page_count):
                for w in self.doc.load_page(i).widgets():
                    if w.field_type == pymupdf.PDF_WIDGET_TYPE_SIGNATURE:
                        return True
        except Exception:
            pass
        return False


def now_pdf_date():
    return pymupdf.get_pdf_now()


def stamp_annot_info(annot, author, subject="", content=""):
    """Set common info (author / subject / content / dates) on a new annotation."""
    info = {"title": author or "", "subject": subject or "", "content": content or ""}
    try:
        annot.set_info(info)
    except Exception:
        pass
