# -*- coding: utf-8 -*-
"""
PDF side of the 3D review: 3D comments (ISO 32000-2 Markup3D: a text
annotation whose /ExData links the 3D annotation and stores the 3D view the
comment was written in), posters (appearance stream of the 3D annotation)
and pages with 3D snapshots.
"""
from __future__ import annotations

import re

import numpy as np
import pymupdf
from PySide6.QtCore import QBuffer, QIODevice, QByteArray

from . import pdf3d
from .settings import settings


def _pdfdoc(owner):
    """Accept a PdfDoc or the main window and return the PdfDoc."""
    if hasattr(owner, "checkpoint") and hasattr(owner, "doc"):
        return owner
    d = owner.doc() if callable(getattr(owner, "doc", None)) else None
    if d is None:
        raise RuntimeError("No PDF document is open.")
    return d


def _pdf_text(s):
    s = s or ""
    try:
        s.encode("latin-1")
        return "(" + s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)").replace("\r", "\\r").replace("\n", "\\n") + ")"
    except UnicodeEncodeError:
        return "<FEFF" + s.encode("utf-16-be").hex().upper() + ">"


def view_dict(cam, name, mode=None):
    M = cam.c2w()
    vals = pdf3d.c2w_to_pdf(M)
    c2w = " ".join("%.9g" % v for v in vals)
    if cam.ortho:
        proj = "<</Subtype/O/OS 1/OB/F>>"
    else:
        proj = "<</Subtype/P/FOV %.6g/PS/Min>>" % float(cam.fov)
    rm = "/RM<</Type/3DRenderMode/Subtype/%s>>" % mode if mode in pdf3d.RENDER_MODES else ""
    extra = "/AliefOH %.9g" % float(cam.ortho_h or 0) if cam.ortho else ""
    return "<</Type/3DView/XN%s/IN%s/MS/M/C2W[%s]/CO %.9g/P%s%s%s>>" % (
        _pdf_text(name), _pdf_text(name), c2w, float(cam.dist), proj, rm, extra)


def _page_annot_xrefs(doc, pno):
    page = doc.load_page(pno)
    t, v = doc.xref_get_key(page.xref, "Annots")
    if t == "xref":
        v = doc.xref_object(int(v.split()[0]), compressed=True)
    if t == "null":
        return []
    return [int(m.group(1)) for m in re.finditer(r"(\d+)\s+0\s+R", v or "")]


def list_comments(owner, annot):
    """3D comments linked to *annot* (list of dicts)."""
    pd = _pdfdoc(owner)
    doc = pd.doc
    out = []
    pages = [annot.page] + [p for p in range(len(doc)) if p != annot.page]
    for pno in pages[:200]:
        try:
            xrefs = _page_annot_xrefs(doc, pno)
        except Exception:
            continue
        for x in xrefs:
            try:
                t, v = doc.xref_get_key(x, "ExData")
            except Exception:
                continue
            if t == "null":
                continue
            ed = doc.xref_object(int(v.split()[0]), compressed=True) if t == "xref" else v
            if "/Markup3D" not in ed:
                continue
            ref = pdf3d._get(ed, "3DA")
            if pdf3d._ref(ref or "") != annot.xref:
                continue
            res = pdf3d._Resolver(doc)
            cam = None
            vt = res.deref(pdf3d._get(ed, "3DV"))
            if vt and vt.strip().startswith("<<"):
                try:
                    v3 = pdf3d._parse_view(res, vt, 0)
                    cam = _camera_from_view(v3, vt)
                except Exception:
                    cam = None
            pt = pdf3d._nums(pdf3d._get(ed, "AliefP3D") or "")
            obj = doc.xref_object(x, compressed=True)
            text = pdf3d._pdf_str_value(pdf3d._get(obj, "Contents")) or ""
            author = pdf3d._pdf_str_value(pdf3d._get(obj, "T")) or ""
            mode = None
            if vt:
                rm = res.deref(pdf3d._get(vt, "RM"))
                if rm:
                    s = pdf3d._get(rm, "Subtype")
                    mode = s.lstrip("/") if s else None
            out.append({"xref": x, "page": pno, "text": text, "author": author, "camera": cam,
                        "point": pt[:3] if len(pt) >= 3 else None, "mode": mode})
        if pno == annot.page and out:
            pass
    return out


def _camera_from_view(v3, vt):
    from .scene3d import Camera
    if v3.c2w is None:
        return None
    cam = Camera()
    cam.set_from_c2w(v3.c2w, v3.co if v3.co and v3.co > 0 else 1.0)
    if v3.ortho:
        cam.ortho = True
        oh = pdf3d._num(pdf3d._get(vt, "AliefOH"), None)
        cam.ortho_h = oh if oh else None
    elif v3.fov:
        cam.fov = float(v3.fov)
    return cam


def add_comment(owner, annot, text, cam, point, mode=None):
    from . import annots as AN
    pd = _pdfdoc(owner)
    doc = pd.doc
    pd.checkpoint()
    page = doc.load_page(annot.page)
    existing = len(list_comments(pd, annot))
    r = annot.rect or page.rect
    x = min(r.x1 + 6, page.rect.width - 22)
    if x < r.x1:
        x = max(r.x0 + 4, r.x1 - 26)
    y = min(r.y0 + 4 + 24 * existing, page.rect.height - 24)
    author = settings().get("author") or "Reviewer"
    a = AN.create_note(page, (x, y), text, {"icon": "Comment", "stroke": (1.0, 0.78, 0.1)}, author)
    try:
        a.set_info(title=author, subject="3D comment", content=text)
        a.update()
    except Exception:
        pass
    xref = a.xref
    name = "3D comment %d" % (existing + 1)
    p = [float(v) for v in np.asarray(point, float).reshape(-1)[:3]]
    ed = "<</Type/ExData/Subtype/Markup3D/3DA %d 0 R/3DV %s/AliefP3D[%.9g %.9g %.9g]>>" % (
        annot.xref, view_dict(cam, name, mode), p[0], p[1], p[2])
    doc.xref_set_key(xref, "ExData", ed)
    pd.commit(pages=[annot.page], content=False)
    return xref


def edit_comment(owner, c, text):
    pd = _pdfdoc(owner)
    doc = pd.doc
    pd.checkpoint()
    page = doc.load_page(c["page"])
    for a in page.annots():
        if a.xref == c["xref"]:
            info = a.info
            info["content"] = text
            a.set_info(info)
            a.update()
            break
    pd.commit(pages=[c["page"]], content=False)


def delete_comment(owner, c):
    pd = _pdfdoc(owner)
    doc = pd.doc
    pd.checkpoint()
    page = doc.load_page(c["page"])
    for a in page.annots():
        if a.xref == c["xref"]:
            page.delete_annot(a)
            break
    pd.commit(pages=[c["page"]], content=False)


def _jpeg(img, quality=88):
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.WriteOnly)
    img.convertToFormat(img.Format.Format_RGB888).save(buf, "JPEG", quality)
    buf.close()
    return bytes(ba)


def _png(img):
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.WriteOnly)
    img.save(buf, "PNG")
    buf.close()
    return bytes(ba)


def set_poster(owner, annot, img):
    """Use *img* (QImage) as the normal appearance (poster) of the 3D annotation."""
    pd = _pdfdoc(owner)
    doc = pd.doc
    pd.checkpoint()
    r = pdf3d._nums(doc.xref_get_key(annot.xref, "Rect")[1])
    w = abs(r[2] - r[0]) or 100.0
    h = abs(r[3] - r[1]) or 100.0
    data = _jpeg(img)
    ix = doc.get_new_xref()
    doc.update_object(ix, "<</Type/XObject/Subtype/Image/Width %d/Height %d/ColorSpace/DeviceRGB/BitsPerComponent 8"
                          "/Filter/DCTDecode>>" % (img.width(), img.height()))
    doc.update_stream(ix, data, compress=False)
    # keep the image aspect ratio inside the annotation rectangle
    ar = img.width() / max(1, img.height())
    if w / h > ar:
        dh = h
        dw = h * ar
    else:
        dw = w
        dh = w / ar
    ox, oy = (w - dw) / 2, (h - dh) / 2
    cs = ("q 1 1 1 rg 0 0 %.3f %.3f re f Q q %.4f 0 0 %.4f %.4f %.4f cm /Poster Do Q" % (w, h, dw, dh, ox, oy)).encode()
    fx = doc.get_new_xref()
    doc.update_object(fx, "<</Type/XObject/Subtype/Form/BBox[0 0 %.3f %.3f]/Resources<</XObject<</Poster %d 0 R>>>>>>"
                          % (w, h, ix))
    doc.update_stream(fx, cs, compress=True)
    doc.xref_set_key(annot.xref, "AP", "<</N %d 0 R>>" % fx)
    pd.commit(pages=[annot.page], content=True)


def insert_image_page(owner, img, after=None, title="3D view"):
    pd = _pdfdoc(owner)
    doc = pd.doc
    pd.checkpoint()
    landscape = img.width() >= img.height()
    W, H = (841.89, 595.28) if landscape else (595.28, 841.89)
    at = (after + 1) if after is not None else len(doc)
    page = doc.new_page(at, width=W, height=H)
    m = 36
    page.insert_text((m, m + 6), title or "3D view", fontname="helv", fontsize=12, color=(0.1, 0.15, 0.3))
    page.insert_image(pymupdf.Rect(m, m + 18, W - m, H - m), stream=_png(img), keep_proportion=True)
    pd.commit(structure=True)
    return at
