# -*- coding: utf-8 -*-
"""
Universal 3D (U3D, ECMA-363) reader for ALIEF PDF EDITOR PRO.

Decodes the U3D files that are embedded in 3D PDF annotations
(/3DD stream with /Subtype /U3D):  scene graph (group, model, light and
view nodes with their transforms), CLOD triangle meshes (base mesh *and*
progressive continuation blocks), line sets, point sets, shading
modifiers, lit-texture shaders, materials, textures, lights and views.

The arithmetic decoder and the progressive-mesh reconstruction follow the
ECMA-363 reference implementation (Intel U3D library, Apache License 2.0,
Copyright (c) 1999-2006 Intel Corporation) so that the decoded symbol stream
matches the encoder bit for bit.  This is an independent Python port.
"""
from __future__ import annotations

import math
import struct

import numpy as np

# ---------------------------------------------------------------- constants
AC_STATIC_FULL = 0x400
AC_MAX_RANGE = AC_STATIC_FULL + 0x3FFF
ELEPHANT = 0x1FFF

# compression contexts (IFXACContext.h)
C_BASE_SHADING = 1
C_NUM_NEW_FACES = 1
C_SHADING_ID = 65
C_ORIENT = 2
C_THIRD_TYPE = 3
C_LOCAL_3RD = 4
C_STAY_MOVE = 15
C_POS_SIGNS = 20
C_POS_X, C_POS_Y, C_POS_Z = 21, 22, 23
C_NEW_DIFF_CNT = 99
C_DIFF_SIGN = 100
C_NEW_SPEC_CNT = 101
C_SPEC_SIGN = 102
C_TEX_SIGN = 103
C_DIFF_KEEP, C_DIFF_CTYPE, C_DIFF_NEW, C_DIFF_LOCAL, C_DIFF_GLOBAL = 104, 105, 106, 107, 108
C_SPEC_KEEP, C_SPEC_CTYPE, C_SPEC_NEW, C_SPEC_LOCAL, C_SPEC_GLOBAL = 109, 110, 111, 112, 113
C_TEX_KEEP, C_TEX_CTYPE, C_TEX_NEW, C_TEX_LOCAL, C_TEX_GLOBAL = 114, 115, 116, 117, 118
C_VC_SPLIT_LOCAL, C_VC_SPLIT_GLOBAL = 119, 120
C_TC_SPLIT_LOCAL, C_TC_SPLIT_GLOBAL = 121, 122
C_NEW_TEX_CNT = 123
C_TC_SPLIT_TYPE = 29
C_TC_DIFF_SIGNS = 32
C_TC_U, C_TC_V, C_TC_S, C_TC_T = 33, 34, 35, 36
C_TC_DUP = 39
C_NUM_LOCAL_NORMALS = 40
C_NRM_SIGNS = 41
C_NRM_X, C_NRM_Y, C_NRM_Z = 42, 43, 44
C_NRM_LOCAL_IDX = 45
C_VC_SPLIT_TYPE = 55
C_VC_DUP = 56
C_VC_R, C_VC_G, C_VC_B, C_VC_A = 60, 61, 62, 63
C_LINE_SHADING = 1
C_POINT_SHADING = 1

UPDATE_CHANGE = 1
UPDATE_NEW, UPDATE_LOCAL, UPDATE_GLOBAL = 1, 2, 3
ORIENT_LEFT, ORIENT_RIGHT = 1, 2
THIRD_LOCAL = 1
PRED_NONE, PRED_MOVE, PRED_STAY, PRED_MOVE2, PRED_STAY2 = 0, 1, 2, 3, 4

# block types
BT_HEADER = 0x00443355
BT_FILEREF = 0xFFFFFF12
BT_MODCHAIN = 0xFFFFFF14
BT_PRIORITY = 0xFFFFFF15
BT_NEWOBJTYPE = 0xFFFFFF16
BT_GROUP = 0xFFFFFF21
BT_MODEL = 0xFFFFFF22
BT_LIGHT = 0xFFFFFF23
BT_VIEW = 0xFFFFFF24
BT_CLOD_DECL = 0xFFFFFF31
BT_POINT_DECL = 0xFFFFFF36
BT_LINE_DECL = 0xFFFFFF37
BT_CLOD_BASE = 0xFFFFFF3B
BT_CLOD_PROG = 0xFFFFFF3C
BT_POINT_CONT = 0xFFFFFF3E
BT_LINE_CONT = 0xFFFFFF3F
BT_GLYPH = 0xFFFFFF41
BT_SUBDIV = 0xFFFFFF42
BT_ANIM = 0xFFFFFF43
BT_BONEW = 0xFFFFFF44
BT_SHADING = 0xFFFFFF45
BT_CLODMOD = 0xFFFFFF46
BT_LIGHT_RES = 0xFFFFFF51
BT_VIEW_RES = 0xFFFFFF52
BT_SHADER = 0xFFFFFF53
BT_MATERIAL = 0xFFFFFF54
BT_TEX_DECL = 0xFFFFFF55
BT_MOTION = 0xFFFFFF56
BT_TEX_CONT = 0xFFFFFF5C

_REV8 = bytes(int('{:08b}'.format(i)[::-1], 2) for i in range(256))
_REV15 = [0] * 32768
for _i in range(32768):
    _v, _r = _i, 0
    for _k in range(15):
        _r = (_r << 1) | (_v & 1)
        _v >>= 1
    _REV15[_i] = _r
del _i, _v, _r, _k


class U3DError(Exception):
    pass


# ------------------------------------------------------- native decoder
_NATIVE = None


def _native():
    """ctypes handle of the C CLOD decoder (aliefpdf/native), or None."""
    global _NATIVE
    if _NATIVE is not None:
        return _NATIVE or None
    _NATIVE = False
    import os
    if os.environ.get("ALIEF_U3D_PURE"):
        return None
    try:
        import ctypes
        here = os.path.join(os.path.dirname(os.path.abspath(__file__)), "native")
        names = ["u3dclod.dll"] if os.name == "nt" else ["libu3dclod.so", "u3dclod.so"]
        lib = None
        for n in names:
            f = os.path.join(here, n)
            if os.path.isfile(f):
                lib = ctypes.CDLL(f)
                break
        if lib is None:
            return None
        P = ctypes.c_void_p
        u32p = ctypes.POINTER(ctypes.c_uint32)
        f32p = ctypes.POINTER(ctypes.c_float)
        lib.u3c_new.restype = P
        lib.u3c_new.argtypes = [ctypes.c_uint32, u32p, u32p, ctypes.c_uint32, f32p, ctypes.c_uint32,
                                ctypes.c_uint32, ctypes.c_uint32]
        lib.u3c_base.restype = ctypes.c_int
        lib.u3c_base.argtypes = [P, ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint32]
        lib.u3c_prog.restype = ctypes.c_int
        lib.u3c_prog.argtypes = [P, ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint32]
        lib.u3c_error.restype = ctypes.c_char_p
        lib.u3c_error.argtypes = [P]
        lib.u3c_free.restype = None
        lib.u3c_free.argtypes = [P]
        lib.u3c_counts.restype = None
        lib.u3c_counts.argtypes = [P, u32p]
        lib.u3c_export.restype = None
        lib.u3c_export.argtypes = [P, f32p, f32p, f32p, f32p, f32p, u32p, u32p, u32p, u32p, u32p, u32p]
        _NATIVE = lib
    except Exception:
        _NATIVE = False
    return _NATIVE or None


class _NativeMesh:
    def __init__(self, lib, mesh):
        import ctypes
        self.lib = lib
        n = len(mesh.shadings)
        A = (ctypes.c_uint32 * n)(*[d.attrs for d in mesh.shadings])
        L = (ctypes.c_uint32 * n)(*[d.layers for d in mesh.shadings])
        Q = (ctypes.c_float * 5)(*mesh.iq)
        self.h = lib.u3c_new(n, A, L, 1 if mesh.exclude_normals else 0, Q, mesh.final_res,
                             min(mesh.max_desc[0], 0xFFFFFFFF), min(mesh.max_desc[1], 0xFFFFFFFF))
        if not self.h:
            raise U3DError("native decoder unavailable")

    def _run(self, fn, body, off):
        data = bytes(body) + b"\0" * 8
        if fn(self.h, data, len(data), off) != 0:
            raise U3DError((self.lib.u3c_error(self.h) or b"decode error").decode("ascii", "replace"))

    def base(self, body, off):
        self._run(self.lib.u3c_base, body, off)

    def prog(self, body, off):
        self._run(self.lib.u3c_prog, body, off)

    def res(self):
        import ctypes
        c = (ctypes.c_uint32 * 8)()
        self.lib.u3c_counts(self.h, c)
        return c[6]

    def export(self):
        import ctypes
        c = (ctypes.c_uint32 * 8)()
        self.lib.u3c_counts(self.h, c)
        npos, nn, nd, ns, nt, nf = c[0], c[1], c[2], c[3], c[4], c[5]
        out = {
            "pos": np.zeros((npos, 3), np.float32), "nrm": np.zeros((nn, 3), np.float32),
            "dif": np.zeros((nd, 4), np.float32), "spc": np.zeros((ns, 4), np.float32),
            "tex": np.zeros((nt, 4), np.float32), "fpos": np.zeros((nf, 3), np.uint32),
            "fnrm": np.zeros((nf, 3), np.uint32), "fdif": np.zeros((nf, 3), np.uint32),
            "fspc": np.zeros((nf, 3), np.uint32), "ftex": np.zeros((nf, 3), np.uint32),
            "fshade": np.zeros(nf, np.uint32)}
        fp = lambda a: a.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
        up = lambda a: a.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32))
        self.lib.u3c_export(self.h, fp(out["pos"]), fp(out["nrm"]), fp(out["dif"]), fp(out["spc"]),
                            fp(out["tex"]), up(out["fpos"]), up(out["fnrm"]), up(out["fdif"]),
                            up(out["fspc"]), up(out["ftex"]), up(out["fshade"]))
        # internal colour order is BGRA
        for k in ("dif", "spc"):
            if len(out[k]):
                out[k] = out[k][:, [2, 1, 0, 3]].copy()
        out["res"] = c[6]
        return out

    def close(self):
        if self.h:
            self.lib.u3c_free(self.h)
            self.h = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


# --------------------------------------------------------- dynamic histogram
class _Hist:
    """Adaptive frequency table (IFXHistogramDynamic) on a Fenwick tree."""
    __slots__ = ("cnt", "tree", "n", "total", "top")

    def __init__(self):
        self.n = 128
        self.cnt = [0] * self.n
        self.tree = [0] * (self.n + 1)
        self.total = 0
        self.top = 64
        self._add(0, 1)

    def _add(self, s, d):
        self.cnt[s] += d
        self.total += d
        i = s + 1
        t = self.tree
        n = self.n
        while i <= n:
            t[i] += d
            i += i & -i

    def _grow(self, s):
        n = self.n
        while n <= s:
            n *= 2
        self.cnt.extend([0] * (n - self.n))
        self.n = n
        self._rebuild()
        while self.top * 2 <= n:
            self.top *= 2

    def _rebuild(self):
        n = self.n
        t = [0] * (n + 1)
        cnt = self.cnt
        for i in range(1, n + 1):
            t[i] += cnt[i - 1]
            j = i + (i & -i)
            if j <= n:
                t[j] += t[i]
        self.tree = t
        self.total = sum(cnt)

    def cum(self, s):
        """sum of the counts of the symbols < s"""
        if s >= self.n:
            return self.total
        r = 0
        t = self.tree
        i = s
        while i > 0:
            r += t[i]
            i -= i & -i
        return r

    def freq(self, s):
        return self.cnt[s] if s < self.n else 0

    def find(self, f):
        """largest symbol s with cum(s) <= f"""
        pos = 0
        rem = f
        t = self.tree
        n = self.n
        step = self.top
        while step:
            p = pos + step
            if p <= n and t[p] <= rem:
                pos = p
                rem -= t[p]
            step >>= 1
        return pos

    def add_symbol(self, s):
        if s > 0xFFFF:
            return
        if self.total >= ELEPHANT:
            c = self.cnt
            for i in range(self.n):
                c[i] >>= 1
            c[0] += 1
            self._rebuild()
        if s >= self.n:
            self._grow(s)
        self._add(s, 1)


# ------------------------------------------------------------- bit reader
class BitReader:
    """U3D bit stream reader with the ECMA-363 arithmetic decoder."""

    def __init__(self, data: bytes):
        self.d = bytes(data) + b"\0" * 8
        self.size = len(data)
        self.pos = 0          # bit position
        self.high = 0xFFFF
        self.low = 0
        self.uf = 0           # underflow bit count
        self.ctx = {}

    # raw helpers ---------------------------------------------------------
    def _bits(self, pos, n):
        b = pos >> 3
        if b >= self.size + 4:
            raise U3DError("unexpected end of U3D block")
        return (int.from_bytes(self.d[b:b + 4], "little") >> (pos & 7)) & ((1 << n) - 1)

    # arithmetic decoding -------------------------------------------------
    def _decode(self, hist, nsym):
        pos = self.pos
        if (pos >> 3) > self.size + 4:
            raise U3DError("unexpected end of U3D block")
        d = self.d
        b = pos >> 3
        code = ((d[b] >> (pos & 7)) & 1) << 15
        p2 = pos + 1 + self.uf
        b = p2 >> 3
        code |= _REV15[(int.from_bytes(d[b:b + 4], "little") >> (p2 & 7)) & 0x7FFF]
        low = self.low
        high = self.high
        rng = high + 1 - low
        if hist is None:
            total = nsym
            cf = (total * (1 + code - low) - 1) // rng
            value = cf + 1
            vcum = cf
            vfreq = 1
        else:
            total = hist.total
            cf = (total * (1 + code - low) - 1) // rng
            value = hist.find(cf)
            vcum = hist.cum(value)
            vfreq = hist.cnt[value]
            hist.add_symbol(value)
        high = low - 1 + rng * (vcum + vfreq) // total
        low = low + rng * vcum // total
        bc = 0
        while (low & 0x8000) == (high & 0x8000):
            low = (low & 0x7FFF) << 1
            high = ((high & 0x7FFF) << 1) | 1
            bc += 1
        if bc:
            bc += self.uf
            self.uf = 0
        uf = 0
        while (low & 0x4000) and not (high & 0x4000):
            low = (low & 0x3FFF) << 1
            high = ((high & 0x3FFF) << 1) | 0x8001
            uf += 1
        self.uf += uf
        self.low = low
        self.high = high
        self.pos = pos + bc
        return value

    def _symbol(self, context):
        if context == 0:
            return self._decode(None, 256)
        if context > AC_STATIC_FULL:
            return self._decode(None, context - AC_STATIC_FULL)
        h = self.ctx.get(context)
        if h is None:
            h = self.ctx[context] = _Hist()
        return self._decode(h, 0)

    # primitive reads -----------------------------------------------------
    def u8(self):
        if self.high == 0xFFFF and self.low == 0 and self.uf == 0:
            v = self._bits(self.pos, 8)
            self.pos += 8
            return v
        v = self._decode(None, 256) - 1
        return _REV8[v & 0xFF]

    def u16(self):
        a = self.u8()
        return a | (self.u8() << 8)

    def u32(self):
        a = self.u8()
        a |= self.u8() << 8
        a |= self.u8() << 16
        return a | (self.u8() << 24)

    def u64(self):
        a = self.u32()
        return a | (self.u32() << 32)

    def i32(self):
        v = self.u32()
        return v - (1 << 32) if v & 0x80000000 else v

    def f32(self):
        return struct.unpack("<f", struct.pack("<I", self.u32()))[0]

    def f64(self):
        return struct.unpack("<d", struct.pack("<Q", self.u64()))[0]

    def f32s(self, n):
        return [self.f32() for _ in range(n)]

    def string(self):
        n = self.u16()
        b = bytes(self.u8() for _ in range(n))
        try:
            return b.decode("utf-8")
        except UnicodeDecodeError:
            return b.decode("latin-1")

    def cu32(self, context):
        if context and context < AC_MAX_RANGE:
            s = self._symbol(context)
            if s:
                return s - 1
            v = self.u32()
            if context <= AC_STATIC_FULL:
                self.ctx[context].add_symbol(v + 1)
            return v
        return self.u32()

    def cu16(self, context):
        if context and context < AC_MAX_RANGE:
            s = self._symbol(context)
            if s:
                return s - 1
            v = self.u16()
            if context <= AC_STATIC_FULL:
                self.ctx[context].add_symbol(v + 1)
            return v
        return self.u16()

    def cu8(self, context):
        if context and context < AC_MAX_RANGE:
            s = self._symbol(context)
            if s:
                return s - 1
            v = self.u8()
            if context <= AC_STATIC_FULL:
                self.ctx[context].add_symbol(v + 1)
            return v
        return self.u8()

    def byte_pos(self):
        return (self.pos + 7) >> 3


# -------------------------------------------------------------- containers
def iter_blocks(data, off=0, end=None):
    end = len(data) if end is None else end
    while off + 12 <= end:
        t, ds, ms = struct.unpack_from("<III", data, off)
        p = off + 12
        if p + ds > end + 3:
            break
        body = data[p:p + ds]
        p += (ds + 3) & ~3
        meta = data[p:p + ms]
        p += (ms + 3) & ~3
        yield t, body, meta
        off = p


class Node:
    __slots__ = ("name", "kind", "parents", "resource", "visibility", "view")

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind          # group / model / light / view
        self.parents = []         # [(parent_name, 4x4 matrix)]
        self.resource = ""
        self.visibility = 3
        self.view = None


class Material:
    def __init__(self, name):
        self.name = name
        self.attrs = 0x3F
        self.ambient = (0.0, 0.0, 0.0)
        self.diffuse = (0.75, 0.75, 0.75)
        self.specular = (0.0, 0.0, 0.0)
        self.emissive = (0.0, 0.0, 0.0)
        self.reflectivity = 0.0
        self.opacity = 1.0


class Shader:
    def __init__(self, name):
        self.name = name
        self.attrs = 1
        self.material = ""
        self.textures = []        # texture names (channel order)
        self.alpha_ref = 0.0
        self.alpha_func = 0
        self.blend = 0


class Texture:
    def __init__(self, name):
        self.name = name
        self.width = 0
        self.height = 0
        self.type = 0x0E
        self.formats = []         # [(compression, channels, attrs, size)]
        self.images = {}          # index -> bytes


class Light:
    def __init__(self, name):
        self.name = name
        self.type = 1
        self.color = (1.0, 1.0, 1.0)
        self.attenuation = (1.0, 0.0, 0.0)
        self.spot = 180.0
        self.intensity = 1.0
        self.attrs = 1


class MeshShading:
    __slots__ = ("attrs", "layers", "dims", "orig_id")

    def __init__(self, attrs, layers, dims, orig_id):
        self.attrs = attrs
        self.layers = layers
        self.dims = dims
        self.orig_id = orig_id

    @property
    def diffuse(self):
        return bool(self.attrs & 1)

    @property
    def specular(self):
        return bool(self.attrs & 2)


class Mesh:
    """Reconstructed CLOD triangle mesh (author mesh)."""

    kind = "mesh"

    def __init__(self, name):
        self.name = name
        self.attrs = 0
        self.max_desc = (0,) * 7
        self.shadings = []
        self.min_res = 0
        self.final_res = 0
        self.iq = [1.0] * 5       # pos, normal, tex, diffuse, specular
        self.crease = 0.0
        # reconstruction state
        self.positions = []       # list of [x,y,z]
        self.normals = []
        self.diffuse = []         # [r,g,b,a]
        self.specular = []
        self.texcoords = []
        self.fpos = []            # face position corners [a,b,c]
        self.fnrm = []
        self.fdif = []
        self.fspc = []
        self.ftex = []            # per face: list per layer [a,b,c]
        self.fshade = []
        self.adj = []             # position -> set of faces
        self.native = None        # _NativeMesh when the C decoder is used
        self.np = None            # exported numpy arrays
        self.complete = False
        self.res = 0

    @property
    def exclude_normals(self):
        return bool(self.attrs & 1)


class LineSet:
    kind = "lines"

    def __init__(self, name):
        self.name = name
        self.shadings = []
        self.iq = [1.0] * 5
        self.positions = []
        self.normals = []
        self.diffuse = []
        self.specular = []
        self.texcoords = []
        self.lines = []           # [a, b]
        self.lnrm = []
        self.ldif = []
        self.lshade = []
        self.max_desc = (0,) * 7
        self.by_pos = {}          # position -> [line indices]


class PointSet:
    kind = "points"

    def __init__(self, name):
        self.name = name
        self.shadings = []
        self.iq = [1.0] * 5
        self.positions = []
        self.normals = []
        self.diffuse = []
        self.specular = []
        self.texcoords = []
        self.points = []
        self.pdif = []
        self.pshade = []
        self.max_desc = (0,) * 7


def _desc_sets(s):
    """descending ordered list of a python set (IFXSetX ordering)"""
    return sorted(s, reverse=True)


def _qmul(a, b):
    return (a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
            a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
            a[0] * b[2] + a[2] * b[0] + a[3] * b[1] - a[1] * b[3],
            a[0] * b[3] + a[3] * b[0] + a[1] * b[2] - a[2] * b[1])


def _qinterp(t, q1, q2):
    cosom = q1[0] * q2[0] + q1[1] * q2[1] + q1[2] * q2[2] + q1[3] * q2[3]
    if cosom < 0.0:
        cosom = -cosom
        to = (-q2[0], -q2[1], -q2[2], -q2[3])
    else:
        to = q2
    if (1.0 - cosom) > 1e-6:
        cosom = min(1.0, cosom)
        omega = math.acos(cosom)
        sinom = math.sin(omega)
        if sinom == 0.0:
            s0, s1 = 1.0 - t, t
        else:
            s0 = math.sin((1.0 - t) * omega) / sinom
            s1 = math.sin(t * omega) / sinom
    else:
        s0, s1 = 1.0 - t, t
    return (s0 * q1[0] + s1 * to[0], s0 * q1[1] + s1 * to[1],
            s0 * q1[2] + s1 * to[2], s0 * q1[3] + s1 * to[3])


def _norm3(v):
    l = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if l == 0.0:
        return [0.0, 0.0, 0.0]
    return [v[0] / l, v[1] / l, v[2] / l]


# ------------------------------------------------------------------ scene
class Scene:
    def __init__(self):
        self.nodes = {}
        self.node_order = []
        self.resources = {}       # model resources: Mesh / LineSet / PointSet
        self.shaders = {}
        self.materials = {}
        self.textures = {}
        self.lights = {}
        self.views = {}
        self.shading = {}         # node name -> list of shader-name lists
        self.units = 1.0
        self.profile = 0
        self.warnings = []
        self.version = 0
        self.encoding = 106

    # ---------------------------------------------------------------- API
    def warn(self, msg):
        if msg not in self.warnings:
            self.warnings.append(msg)

    def world_instances(self):
        """Yield (node, 4x4 world matrix) for every instance of every node."""
        cache = {}

        def worlds(name, depth=0):
            if name in cache:
                return cache[name]
            node = self.nodes.get(name)
            out = []
            if node is None or depth > 64:
                return [np.eye(4)]
            if not node.parents:
                out = [np.eye(4)]
            for pname, m in node.parents:
                if pname == "" or pname == "<NULL>" or pname not in self.nodes:
                    out.append(m)
                else:
                    for pw in worlds(pname, depth + 1):
                        out.append(pw @ m)
            cache[name] = out
            return out

        for name in self.node_order:
            node = self.nodes[name]
            for w in worlds(name):
                yield node, w


def _read_node_common(br, node):
    node.name = br.string()
    n = br.u32()
    for _ in range(n):
        pname = br.string()
        m = np.array(br.f32s(16), dtype=np.float64).reshape(4, 4).T
        node.parents.append((pname, m))


def _read_shading_descs(br, count, lineset=False):
    out = []
    for _ in range(count):
        attrs = br.u32()
        layers = br.u32()
        dims = [br.u32() for _ in range(layers)]
        orig = br.u32()
        out.append(MeshShading(attrs, layers, dims, orig))
    return out


def _skip_skeleton(br):
    nb = br.u32()
    for _ in range(nb):
        br.string()
        br.string()
        attrs = br.u32()
        br.f32s(1 + 3 + 4)
        if attrs & 1:
            br.u32()
            br.f32()
        if attrs & 2:
            br.f32s(8)
        br.f32s(6)
    return nb


class _Loader:
    def __init__(self, scene):
        self.s = scene

    # -------------------------------------------------------- dispatcher
    def block(self, t, body, meta, chain_type=None, chain_name=None):
        s = self.s
        try:
            if t == BT_HEADER:
                br = BitReader(body)
                s.version = br.i32()
                s.profile = br.u32()
                br.u32()
                br.u64()
                s.encoding = br.u32()
                if s.profile & 0x8:
                    s.units = br.f64()
            elif t == BT_MODCHAIN:
                self.modchain(body)
            elif t in (BT_GROUP, BT_MODEL, BT_LIGHT, BT_VIEW):
                self.node(t, body)
            elif t == BT_CLOD_DECL:
                self.clod_decl(body)
            elif t == BT_CLOD_BASE:
                self.clod_base(body)
            elif t == BT_CLOD_PROG:
                self.clod_prog(body)
            elif t == BT_LINE_DECL:
                self.line_decl(body)
            elif t == BT_LINE_CONT:
                self.line_cont(body)
            elif t == BT_POINT_DECL:
                self.point_decl(body)
            elif t == BT_POINT_CONT:
                self.point_cont(body)
            elif t == BT_SHADING:
                self.shading(body, chain_name)
            elif t == BT_SHADER:
                self.shader(body)
            elif t == BT_MATERIAL:
                self.material(body)
            elif t == BT_LIGHT_RES:
                self.light_res(body)
            elif t == BT_VIEW_RES:
                pass
            elif t == BT_TEX_DECL:
                self.tex_decl(body)
            elif t == BT_TEX_CONT:
                self.tex_cont(body)
            elif t in (BT_PRIORITY, BT_NEWOBJTYPE, BT_FILEREF, BT_ANIM, BT_MOTION,
                       BT_BONEW, BT_SUBDIV, BT_CLODMOD):
                pass
            elif t == BT_GLYPH:
                s.warn("2D glyph modifier is not supported")
        except (U3DError, IndexError, struct.error, KeyError, ValueError) as e:
            s.warn("block 0x%08X: %s" % (t, e))

    def modchain(self, body):
        br = BitReader(body)
        name = br.string()
        ln = len(name.encode("utf-8"))
        ctype = br.u32()
        attrs = br.u32()
        pos = 2 + ln + 8
        if attrs & 1:
            pos += 16
        if attrs & 2:
            pos += 24
        pos += (4 - ((2 + ln) & 3)) & 3
        if pos + 4 > len(body):
            return
        count = struct.unpack_from("<I", body, pos)[0]
        pos += 4
        n = 0
        for t, b, m in iter_blocks(body, pos):
            self.block(t, b, m, ctype, name)
            n += 1
            if n >= count:
                break

    def node(self, t, body):
        br = BitReader(body)
        kind = {BT_GROUP: "group", BT_MODEL: "model", BT_LIGHT: "light", BT_VIEW: "view"}[t]
        node = Node("", kind)
        _read_node_common(br, node)
        if t == BT_MODEL:
            node.resource = br.string()
            try:
                node.visibility = br.u32()
            except Exception:
                node.visibility = 3
        elif t == BT_LIGHT:
            node.resource = br.string()
        elif t == BT_VIEW:
            node.resource = br.string()
            try:
                attrs = br.u32()
                near = br.f32()
                far = br.f32()
                mode = attrs & ~1
                proj = br.f32()
                if mode in (4, 6):
                    br.f32()
                    proj = br.f32()
                node.view = {"attrs": attrs, "near": near, "far": far,
                             "ortho": mode == 2, "proj": proj}
            except Exception:
                node.view = None
        s = self.s
        if node.name not in s.nodes:
            s.node_order.append(node.name)
        s.nodes[node.name] = node

    # ------------------------------------------------------------ shading
    def shading(self, body, chain_name):
        br = BitReader(body)
        name = br.string()
        br.u32()            # chain index
        br.u32()            # attributes
        nl = br.u32()
        lists = []
        for _ in range(nl):
            nsh = br.u32()
            lists.append([br.string() for _ in range(nsh)])
        self.s.shading[name or chain_name or ""] = lists

    def shader(self, body):
        br = BitReader(body)
        sh = Shader(br.string())
        sh.attrs = br.u32()
        sh.alpha_ref = br.f32()
        sh.alpha_func = br.u32()
        sh.blend = br.u32()
        br.u32()            # render pass flags
        chans = br.u32()
        br.u32()            # alpha texture channels
        sh.material = br.string()
        for i in range(8):
            if chans & (1 << i):
                tex = br.string()
                br.f32()        # intensity
                br.u8()
                br.u8()
                br.f32()
                br.u8()
                br.f32s(16)
                br.f32s(16)
                br.u8()
                sh.textures.append(tex)
        self.s.shaders[sh.name] = sh

    def material(self, body):
        br = BitReader(body)
        m = Material(br.string())
        m.attrs = br.u32()
        m.ambient = tuple(br.f32s(3))
        m.diffuse = tuple(br.f32s(3))
        m.specular = tuple(br.f32s(3))
        m.emissive = tuple(br.f32s(3))
        m.reflectivity = br.f32()
        m.opacity = br.f32()
        self.s.materials[m.name] = m

    def light_res(self, body):
        br = BitReader(body)
        li = Light(br.string())
        li.attrs = br.u32()
        li.type = br.u8()
        c = br.f32s(4)
        li.color = tuple(c[:3])
        li.attenuation = tuple(br.f32s(3))
        li.spot = br.f32()
        li.intensity = br.f32()
        self.s.lights[li.name] = li

    def tex_decl(self, body):
        br = BitReader(body)
        tx = Texture(br.string())
        tx.height = br.u32()
        tx.width = br.u32()
        tx.type = br.u8()
        n = br.u32()
        for _ in range(n):
            comp = br.u8()
            ch = br.u8()
            attrs = br.u16()
            if attrs & 1:
                nu = br.u32()
                for _ in range(nu):
                    br.string()
                size = 0
            else:
                size = br.u32()
            tx.formats.append((comp, ch, attrs, size))
        self.s.textures[tx.name] = tx

    def tex_cont(self, body):
        br = BitReader(body)
        name = br.string()
        idx = br.u32()
        tx = self.s.textures.get(name)
        start = br.byte_pos()
        if tx is not None:
            tx.images[idx] = bytes(body[start:])

    # --------------------------------------------------------------- CLOD
    def clod_decl(self, body):
        br = BitReader(body)
        m = Mesh(br.string())
        br.u32()            # chain index
        m.attrs = br.u32()
        desc = tuple(br.u32() for _ in range(7))
        m.max_desc = desc
        m.shadings = _read_shading_descs(br, desc[6])
        m.min_res = br.u32()
        m.final_res = br.u32()
        br.u32()
        br.u32()
        br.u32()
        m.iq = br.f32s(5)
        m.crease = br.f32()
        br.f32()
        br.f32()
        try:
            _skip_skeleton(br)
        except Exception:
            pass
        m.adj = []
        self.s.resources[m.name] = m

    def _mesh(self, name):
        m = self.s.resources.get(name)
        if not isinstance(m, Mesh):
            raise U3DError("CLOD continuation for undeclared mesh %r" % name)
        return m

    def clod_base(self, body):
        br = BitReader(body)
        m = self._mesh(br.string())
        br.u32()
        nat = self._native_for(m)
        if nat is not None:
            nat.base(body, br.byte_pos())
            m.res = nat.res()
            m.complete = m.res >= m.final_res
            return
        nf, npos, nn, nd, ns, nt = (br.u32() for _ in range(6))
        if npos > max(m.final_res, m.max_desc[1]) + 1 or nf > m.max_desc[0] + 64 or \
                (npos + nn) * 12 + (nd + ns + nt) * 16 > len(body):
            raise U3DError("corrupt base mesh counts")
        m.positions = [br.f32s(3) for _ in range(npos)]
        m.normals = [br.f32s(3) for _ in range(nn)]
        m.diffuse = [br.f32s(4) for _ in range(nd)]
        m.specular = [br.f32s(4) for _ in range(ns)]
        m.texcoords = [br.f32s(4) for _ in range(nt)]
        exn = m.exclude_normals
        sh = m.shadings
        cp, cn, cd, cs, ct = (AC_STATIC_FULL + npos, AC_STATIC_FULL + nn, AC_STATIC_FULL + nd,
                              AC_STATIC_FULL + ns, AC_STATIC_FULL + nt)
        fpos, fnrm, fdif, fspc, ftex, fshade = m.fpos, m.fnrm, m.fdif, m.fspc, m.ftex, m.fshade
        for _ in range(nf):
            sid = br.cu32(C_BASE_SHADING)
            if sid >= len(sh):
                raise U3DError("invalid shading id")
            d = sh[sid]
            P = [0, 0, 0]
            N = [0, 0, 0]
            D = [0, 0, 0]
            S = [0, 0, 0]
            T = [[0, 0, 0] for _ in range(d.layers)]
            for c in range(3):
                P[c] = br.cu32(cp)
                if not exn:
                    N[c] = br.cu32(cn)
                if d.attrs & 1:
                    D[c] = br.cu32(cd)
                if d.attrs & 2:
                    S[c] = br.cu32(cs)
                for L in range(d.layers):
                    T[L][c] = br.cu32(ct)
            fshade.append(sid)
            fpos.append(P)
            fnrm.append(N)
            fdif.append(D)
            fspc.append(S)
            ftex.append(T)
        need = npos + 1
        if len(m.adj) < need:
            m.adj.extend(set() for _ in range(need - len(m.adj)))
        for fi, P in enumerate(fpos):
            for p in P:
                m.adj[p].add(fi)
        m.res = npos
        if m.final_res <= npos:
            m.complete = True

    # set adjacency helpers -------------------------------------------------
    @staticmethod
    def _attr_set(m, pos, faces_attr, flag=None, layer=None):
        out = set()
        fpos = m.fpos
        sh = m.shadings
        for f in m.adj[pos]:
            d = sh[m.fshade[f]]
            if flag is not None and not (d.attrs & flag):
                continue
            if layer is not None and d.layers <= layer:
                continue
            P = fpos[f]
            if P[0] == pos:
                c = 0
            elif P[1] == pos:
                c = 1
            elif P[2] == pos:
                c = 2
            else:
                continue
            if layer is not None:
                out.add(m.ftex[f][layer][c])
            else:
                out.add(faces_attr[f][c])
        return _desc_sets(out)

    def _face_normal(self, m, f):
        P = m.fpos[f]
        A = m.positions[P[0]]
        B = m.positions[P[1]]
        C = m.positions[P[2]]
        d1 = (B[0] - A[0], B[1] - A[1], B[2] - A[2])
        d2 = (C[0] - A[0], C[1] - A[1], C[2] - A[2])
        e = 1e-7
        if (abs(d1[0]) < e and abs(d1[1]) < e and abs(d1[2]) < e) or \
                (abs(d2[0]) < e and abs(d2[1]) < e and abs(d2[2]) < e):
            return None
        d1 = _norm3(d1)
        d2 = _norm3(d2)
        n = (d1[1] * d2[2] - d1[2] * d2[1], d1[2] * d2[0] - d1[0] * d2[2],
             d1[0] * d2[1] - d1[1] * d2[0])
        if abs(n[0]) < e and abs(n[1]) < e and abs(n[2]) < e:
            return None
        return _norm3(n)

    def _native_for(self, m):
        nat = getattr(m, "native", None)
        if nat is None and not m.fpos and not m.positions and m.shadings:
            lib = _native()
            if lib is not None:
                try:
                    nat = m.native = _NativeMesh(lib, m)
                except U3DError:
                    nat = None
        return nat

    def clod_prog(self, body):
        br = BitReader(body)
        m = self._mesh(br.string())
        br.u32()
        nat = self._native_for(m)
        if nat is not None:
            nat.prog(body, br.byte_pos())
            m.res = nat.res()
            m.complete = m.res >= m.final_res
            return
        start = br.u32()
        end = br.u32()
        if start != m.res:
            # out-of-order block: positions must be continuous
            raise U3DError("progressive block out of order (%d != %d)" % (start, m.res))
        lim_pos = max(m.final_res, m.max_desc[1]) + 1
        lim_faces = m.max_desc[0] + 64 + lim_pos // 4
        if end < start or end > lim_pos or end - start > len(body) * 8:
            raise U3DError("corrupt resolution range")
        need = end + 1
        if len(m.adj) < need:
            m.adj.extend(set() for _ in range(need - len(m.adj)))
        exn = m.exclude_normals
        iqp, iqn, iqt, iqd, iqs = m.iq
        sh = m.shadings
        fpos, fnrm, fdif, fspc, ftex, fshade = m.fpos, m.fnrm, m.fdif, m.fspc, m.ftex, m.fshade
        adj = m.adj
        # the "previous attribute" registers are reset for every block
        prev = {"sd": 0, "ud": 0, "td": 0, "ss": 0, "us": 0, "ts": 0,
                "st": 0, "ut": 0, "tt": 0}
        cu32, cu16, cu8 = br.cu32, br.cu16, br.cu8
        for res in range(start, end):
            split = cu32(AC_STATIC_FULL + res)
            if split >= len(adj):
                raise U3DError("split index out of range")
            split_faces = _desc_sets(adj[split])
            nd0, ns0, nt0 = len(m.diffuse), len(m.specular), len(m.texcoords)
            posset = set()
            for f in split_faces:
                posset.update(fpos[f])
            posset.discard(split)
            # ---- new colours / texcoords ----------------------------------
            for kind in ("d", "s"):
                cnt = cu16(C_NEW_DIFF_CNT if kind == "d" else C_NEW_SPEC_CNT)
                if not cnt:
                    continue
                arr = m.diffuse if kind == "d" else m.specular
                faces_attr = fdif if kind == "d" else fspc
                members = self._attr_set(m, split, faces_attr, 1 if kind == "d" else 2)
                if members:
                    acc = [0.0, 0.0, 0.0, 0.0]
                    for i in members:
                        c = arr[i]
                        acc[0] += c[0]
                        acc[1] += c[1]
                        acc[2] += c[2]
                        acc[3] += c[3]
                    k = float(len(members))
                    pred = [acc[0] / k, acc[1] / k, acc[2] / k, acc[3] / k]
                else:
                    pred = [0.0, 0.0, 0.0, 0.0]
                iq = iqd if kind == "d" else iqs
                for _ in range(cnt):
                    sg = cu8(C_DIFF_SIGN if kind == "d" else C_SPEC_SIGN)
                    v = [cu32(C_VC_R), cu32(C_VC_G), cu32(C_VC_B), cu32(C_VC_A)]
                    # stream order is the internal BGRA order; we keep RGBA
                    dv = [(-iq if sg & (1 << j) else iq) * v[j] for j in range(4)]
                    arr.append([dv[2] + pred[0], dv[1] + pred[1], dv[0] + pred[2], dv[3] + pred[3]])
            cnt = cu16(C_NEW_TEX_CNT)
            if cnt:
                members = self._attr_set(m, split, None, layer=0)
                if members:
                    acc = [0.0, 0.0, 0.0, 0.0]
                    for i in members:
                        c = m.texcoords[i]
                        for j in range(4):
                            acc[j] += c[j]
                    k = float(len(members))
                    pred = [a / k for a in acc]
                else:
                    pred = [0.0, 0.0, 0.0, 0.0]
                for _ in range(cnt):
                    sg = cu8(C_TEX_SIGN)
                    v = [cu32(C_TC_U), cu32(C_TC_V), cu32(C_TC_S), cu32(C_TC_T)]
                    m.texcoords.append([(-iqt if sg & (1 << j) else iqt) * v[j] + pred[j]
                                        for j in range(4)])
            # ---- new faces --------------------------------------------------
            nnew = cu32(C_NUM_NEW_FACES)
            if len(fpos) + nnew > lim_faces:
                raise U3DError("more faces than declared")
            left = set()
            right = set()
            nf0 = len(fpos)
            new_faces = []
            for j in range(nnew):
                sid = cu32(C_SHADING_ID)
                orient = cu8(C_ORIENT)
                ttype = cu8(C_THIRD_TYPE)
                if ttype == THIRD_LOCAL:
                    li = cu32(C_LOCAL_3RD)
                    ps = _desc_sets(posset)
                    if li >= len(ps):
                        raise U3DError("local third index out of range")
                    third = ps[li]
                else:
                    third = cu32(AC_STATIC_FULL + res)
                    posset.add(third)
                if orient == ORIENT_LEFT:
                    left.add(third)
                    P = [split, res, third]
                elif orient == ORIENT_RIGHT:
                    right.add(third)
                    P = [res, split, third]
                else:
                    P = [split, res, third]
                if sid >= len(sh):
                    raise U3DError("invalid shading id")
                new_faces.append((sid, P))
            for sid, P in new_faces:
                fshade.append(sid)
                fpos.append(P)
                fnrm.append([0, 0, 0])
                fdif.append([0, 0, 0])
                fspc.append([0, 0, 0])
                ftex.append([[0, 0, 0] for _ in range(sh[sid].layers)])
            # ---- stay / move ------------------------------------------------
            move_faces = set()
            move_pos = set()
            stay_pos = set()
            for f in split_faces:
                P = fpos[f]
                pred = PRED_NONE
                if split == P[0]:
                    o1, o2 = P[1], P[2]
                elif split == P[1]:
                    o1, o2 = P[2], P[0]
                elif split == P[2]:
                    o1, o2 = P[0], P[1]
                else:
                    o1 = o2 = None
                if o1 is not None:
                    if o1 in right:
                        pred = PRED_MOVE
                    elif o2 in right:
                        pred = PRED_STAY
                    elif o1 in left:
                        pred = PRED_STAY
                    elif o2 in left:
                        pred = PRED_MOVE
                if pred == PRED_NONE:
                    if P[0] in move_pos or P[1] in move_pos or P[2] in move_pos:
                        pred = PRED_MOVE2
                    elif P[0] in stay_pos or P[1] in stay_pos or P[2] in stay_pos:
                        pred = PRED_STAY2
                sm = cu8(C_STAY_MOVE + pred)
                if sm == 1:
                    move_faces.add(f)
                    move_pos.update(P)
                    move_pos.discard(split)
                else:
                    stay_pos.update(P)
                    stay_pos.discard(split)
            # ---- face updates for moved faces --------------------------------
            updates = []      # (array, face, corner, value) applied at end
            for f in _desc_sets(move_faces):
                P = fpos[f]
                corner = 0 if P[0] == split else (1 if P[1] == split else (2 if P[2] == split else 3))
                updates.append((fpos, f, corner, res))
                d = sh[fshade[f]]
                for kind in ("d", "s"):
                    if not (d.attrs & (1 if kind == "d" else 2)):
                        continue
                    if kind == "d":
                        ck, ct, cn_, cl, cg = C_DIFF_KEEP, C_DIFF_CTYPE, C_DIFF_NEW, C_DIFF_LOCAL, C_DIFF_GLOBAL
                    else:
                        ck, ct, cn_, cl, cg = C_SPEC_KEEP, C_SPEC_CTYPE, C_SPEC_NEW, C_SPEC_LOCAL, C_SPEC_GLOBAL
                    keep = cu8(ck)
                    if keep == UPDATE_CHANGE:
                        typ = cu8(ct)
                        if typ == UPDATE_NEW:
                            idx = cu32(cn_)
                        elif typ == UPDATE_LOCAL:
                            idx = cu32(cl)
                        else:
                            idx = cu32(cg)
                        faces_attr = fdif if kind == "d" else fspc
                        if typ == UPDATE_NEW:
                            val = idx + (nd0 if kind == "d" else ns0)
                        elif typ == UPDATE_LOCAL:
                            mem = self._attr_set(m, split, faces_attr, 1 if kind == "d" else 2)
                            val = mem[idx] if idx < len(mem) else 0
                        else:
                            val = idx
                        if corner < 3:
                            updates.append((faces_attr, f, corner, val))
                for L in range(d.layers):
                    keep = cu8(C_TEX_KEEP)
                    if keep == UPDATE_CHANGE:
                        typ = cu8(C_TEX_CTYPE)
                        if typ == UPDATE_NEW:
                            idx = cu32(C_TEX_NEW)
                            val = idx + nt0
                        elif typ == UPDATE_LOCAL:
                            idx = cu32(C_TEX_LOCAL)
                            mem = self._attr_set(m, split, None, layer=L)
                            val = mem[idx] if idx < len(mem) else 0
                        else:
                            val = cu32(C_TEX_GLOBAL)
                        if corner < 3:
                            updates.append(("tex", f, (L, corner), val))
            # ---- attributes of the new faces -------------------------------
            for j, (sid, P) in enumerate(new_faces):
                fi = nf0 + j
                if P[0] == res:
                    cnew = 0
                    csp, cth = (1, 2) if P[1] == split else (2, 1)
                elif P[1] == res:
                    cnew = 1
                    csp, cth = (0, 2) if P[0] == split else (2, 0)
                else:
                    cnew = 2
                    csp, cth = (1, 0) if P[1] == split else (0, 1)
                third = P[cth]
                d = sh[sid]
                for kind in ("d", "s"):
                    if not (d.attrs & (1 if kind == "d" else 2)):
                        continue
                    faces_attr = fdif if kind == "d" else fspc
                    flag = 1 if kind == "d" else 2
                    dup = cu8(C_VC_DUP)
                    split_set = self._attr_set(m, split, faces_attr, flag)
                    vals = []
                    for bit, which in ((1, "s"), (2, "u")):
                        if not (dup & bit):
                            typ = cu8(C_VC_SPLIT_TYPE)
                            if typ == UPDATE_LOCAL:
                                li = cu32(C_VC_SPLIT_LOCAL)
                                v = split_set[li] if li < len(split_set) else 0
                            else:
                                v = cu32(C_VC_SPLIT_GLOBAL)
                        else:
                            v = prev[which + kind]
                        vals.append(v)
                    third_set = self._attr_set(m, third, faces_attr, flag)
                    if not (dup & 4):
                        typ = cu8(C_VC_SPLIT_TYPE)
                        if typ == UPDATE_LOCAL:
                            li = cu32(C_VC_SPLIT_LOCAL)
                            v = third_set[li] if li < len(third_set) else 0
                        else:
                            v = cu32(C_VC_SPLIT_GLOBAL)
                    else:
                        v = prev["t" + kind]
                    vals.append(v)
                    F = faces_attr[fi]
                    F[csp], F[cnew], F[cth] = vals
                    prev["s" + kind], prev["u" + kind], prev["t" + kind] = vals
                for L in range(d.layers):
                    dup = cu8(C_TC_DUP)
                    split_set = self._attr_set(m, split, None, layer=L)
                    vals = []
                    for bit, which in ((1, "s"), (2, "u")):
                        if not (dup & bit):
                            typ = cu8(C_TC_SPLIT_TYPE)
                            if typ == UPDATE_LOCAL:
                                li = cu32(C_TC_SPLIT_LOCAL)
                                v = split_set[li] if li < len(split_set) else 0
                            else:
                                v = cu32(C_TC_SPLIT_GLOBAL)
                        else:
                            v = prev[which + "t"]
                        vals.append(v)
                    third_set = self._attr_set(m, third, None, layer=L)
                    if not (dup & 4):
                        typ = cu8(C_TC_SPLIT_TYPE)
                        if typ == UPDATE_LOCAL:
                            li = cu32(C_TC_SPLIT_LOCAL)
                            v = third_set[li] if li < len(third_set) else 0
                        else:
                            v = cu32(C_TC_SPLIT_GLOBAL)
                    else:
                        v = prev["tt"]
                    vals.append(v)
                    F = ftex[fi][L]
                    F[csp], F[cnew], F[cth] = vals
                    prev["st"], prev["ut"], prev["tt"] = vals
            # ---- adjacency update -------------------------------------------
            for f in move_faces:
                adj[split].discard(f)
                adj[res].add(f)
            for j, (sid, P) in enumerate(new_faces):
                fi = nf0 + j
                for p in P:
                    adj[p].add(fi)
            new_face_set = _desc_sets(adj[res])
            new_posset = set()
            for f in new_face_set:
                new_posset.update(fpos[f])
            # ---- new position -------------------------------------------------
            pred = m.positions[split] if res > 0 and split < len(m.positions) else [0.0, 0.0, 0.0]
            sg = cu8(C_POS_SIGNS)
            dx = cu32(C_POS_X)
            dy = cu32(C_POS_Y)
            dz = cu32(C_POS_Z)
            m.positions.append([(-iqp if sg & 1 else iqp) * dx + pred[0],
                                (-iqp if sg & 2 else iqp) * dy + pred[1],
                                (-iqp if sg & 4 else iqp) * dz + pred[2]])
            # apply the position / colour / texcoord face updates
            for arr, f, corner, val in updates:
                if arr == "tex":
                    L, c = corner
                    ftex[f][L][c] = val
                elif corner < 3:
                    arr[f][corner] = val
            # ---- normals ------------------------------------------------------
            if not exn:
                nold = len(m.normals)
                new_normals = []
                for p in _desc_sets(new_posset):
                    nfs = _desc_sets(adj[p])
                    nloc = cu32(C_NUM_LOCAL_NORMALS)
                    if nloc > 4096:
                        raise U3DError("corrupt normal count")
                    face_n = []
                    for f in nfs:
                        fn = self._face_normal(m, f)
                        if fn is not None:
                            face_n.append(fn)
                    predn = []
                    if face_n:
                        predn.append(list(face_n[0]))
                    while len(predn) < nloc:
                        far_d = 1.0
                        far_i = 0
                        for k, fnk in enumerate(face_n):
                            mind = -2.0
                            for q in predn:
                                dd = fnk[0] * q[0] + fnk[1] * q[1] + fnk[2] * q[2]
                                if dd > mind:
                                    mind = dd
                            if mind < far_d:
                                far_d = mind
                                far_i = k
                        predn.append(list(face_n[far_i]) if face_n else [0.0, 0.0, 0.0])
                    if predn:
                        counts = [0] * len(predn)
                        for fnk in face_n:
                            best = 0
                            mind = -2.0
                            for l, q in enumerate(predn):
                                dd = fnk[0] * q[0] + fnk[1] * q[1] + fnk[2] * q[2]
                                if dd > mind:
                                    mind = dd
                                    best = l
                            q = _qinterp(1.0 / (counts[best] + 1), (0.0,) + tuple(predn[best]),
                                         (0.0,) + tuple(fnk))
                            predn[best] = [q[1], q[2], q[3]]
                            counts[best] += 1
                    loc = []
                    for k in range(nloc):
                        sg = cu8(C_NRM_SIGNS)
                        ux = cu32(C_NRM_X)
                        uy = cu32(C_NRM_Y)
                        uz = cu32(C_NRM_Z)
                        fx = (-iqn if sg & 2 else iqn) * ux
                        fy = (-iqn if sg & 4 else iqn) * uy
                        fz = (-iqn if sg & 8 else iqn) * uz
                        t2 = min(1.0, fx * fx + fy * fy + fz * fz)
                        fw = math.sqrt(1.0 - t2)
                        if sg & 1:
                            fw = -fw
                        pn = predn[k] if k < len(predn) else [0.0, 0.0, 0.0]
                        q = _qmul((0.0, pn[0], pn[1], pn[2]), (fw, fx, fy, fz))
                        loc.append([q[1], q[2], q[3]])
                    base = nold + len(new_normals)
                    for f in nfs:
                        bi = cu32(C_NRM_LOCAL_IDX)
                        P = fpos[f]
                        if P[0] == p:
                            fnrm[f][0] = base + bi
                        elif P[1] == p:
                            fnrm[f][1] = base + bi
                        elif P[2] == p:
                            fnrm[f][2] = base + bi
                    new_normals.extend(loc)
                m.normals.extend(new_normals)
            m.res = res + 1
        if m.res >= m.final_res:
            m.complete = True

    # ------------------------------------------------------------ lines
    def _set_decl(self, body, cls):
        br = BitReader(body)
        o = cls(br.string())
        br.u32()            # chain index
        br.u32()            # reserved
        desc = tuple(br.u32() for _ in range(7))
        o.max_desc = desc
        o.shadings = _read_shading_descs(br, desc[6])
        br.u32()
        br.u32()
        br.u32()
        o.iq = br.f32s(5)
        self.s.resources[o.name] = o
        return o

    def line_decl(self, body):
        self._set_decl(body, LineSet)

    def point_decl(self, body):
        self._set_decl(body, PointSet)

    def line_cont(self, body):
        br = BitReader(body)
        o = self.s.resources.get(br.string())
        if not isinstance(o, LineSet):
            raise U3DError("line set continuation without declaration")
        br.u32()
        start = br.u32()
        end = br.u32()
        if start != len(o.positions) or end < start or end > o.max_desc[1] + 1 or end - start > len(body) * 8:
            raise U3DError("corrupt %s continuation" % o.kind)
        lim_prim = o.max_desc[0] + 64
        iqp, iqn, iqt, iqd, iqs = o.iq
        cu32, cu8 = br.cu32, br.cu8
        sh = o.shadings
        has_tex = o.max_desc[5] > 0
        for cur in range(start, end):
            split = cu32(AC_STATIC_FULL + (cur if cur > 1 else 1))
            sg = cu8(C_POS_SIGNS)
            d = [cu32(C_POS_X), cu32(C_POS_Y), cu32(C_POS_Z)]
            pred = o.positions[split] if cur > 0 and split < len(o.positions) else [0.0, 0.0, 0.0]
            o.positions.append([(-iqp if sg & (1 << j) else iqp) * d[j] + pred[j] for j in range(3)])
            nloc = cu32(C_NUM_LOCAL_NORMALS)
            if nloc > 4096:
                raise U3DError("corrupt normal count")
            if nloc:
                predn = [0.0, 0.0, 0.0]
                if cur > 0 and o.lines:
                    acc = [0.0, 0.0, 0.0]
                    k = 0
                    for li in o.by_pos.get(split, ()):
                        a, b = o.lines[li]
                        other = b if a == split else a
                        if other < cur:
                            na, nb = o.lnrm[li]
                            nidx = na if a == split else nb
                            if nidx < len(o.normals):
                                nv = o.normals[nidx]
                                acc = [acc[0] + nv[0], acc[1] + nv[1], acc[2] + nv[2]]
                                k += 1
                    if k:
                        predn = _norm3(acc)
                for _ in range(nloc):
                    sg = cu8(C_NRM_SIGNS)
                    d = [cu32(C_NRM_X), cu32(C_NRM_Y), cu32(C_NRM_Z)]
                    o.normals.append([(-iqn if sg & (1 << j) else iqn) * d[j] + predn[j]
                                      for j in range(3)])
            nl = cu32(C_NUM_NEW_FACES)
            if len(o.lines) + nl > lim_prim:
                raise U3DError("more lines than declared")
            for _ in range(nl):
                sid = cu32(C_LINE_SHADING)
                endi = cu32(AC_STATIC_FULL + cur)
                d = sh[sid] if sid < len(sh) else MeshShading(0, 0, [], 0)
                nrm_idx = [0, 0]
                dif_idx = [0, 0]
                for ip in range(2):
                    nrm_idx[ip] = cu32(C_NRM_LOCAL_IDX)
                    for flag in (1, 2):
                        if d.attrs & flag:
                            dup = cu8(C_VC_DUP)
                            arr = o.diffuse if flag == 1 else o.specular
                            iq = iqd if flag == 1 else iqs
                            if dup == 0:
                                sg = cu8(C_NRM_SIGNS)
                                v = [cu32(C_VC_R), cu32(C_VC_G), cu32(C_VC_B), cu32(C_VC_A)]
                                pc = self._line_color_pred(o, flag == 1, cur, split)
                                arr.append([(-iq if sg & (1 << j) else iq) * v[j] + pc[j]
                                            for j in range(4)])
                            if flag == 1:
                                dif_idx[ip] = len(arr) - 1
                    if has_tex:
                        for L in range(d.layers):
                            dup = cu8(C_TC_DUP)
                            if dup == 0:
                                sg = cu8(C_TC_DIFF_SIGNS)
                                v = [cu32(C_TC_U), cu32(C_TC_V), cu32(C_TC_S), cu32(C_TC_T)]
                                o.texcoords.append([(-iqt if sg & (1 << min(j, 2)) else iqt) * v[j]
                                                    for j in range(4)])
                li = len(o.lines)
                o.lines.append([endi, cur])
                o.lshade.append(sid)
                old = len(o.normals) - nloc
                o.lnrm.append([old + nrm_idx[0], old + nrm_idx[1]])
                o.ldif.append(dif_idx if d.attrs & 1 else None)
                o.by_pos.setdefault(endi, []).append(li)
                o.by_pos.setdefault(cur, []).append(li)

    @staticmethod
    def _line_color_pred(o, diffuse, cur, split):
        arr = o.diffuse if diffuse else o.specular
        if cur == 0 or not o.lines or not arr:
            return [0.0, 0.0, 0.0, 0.0]
        acc = [0.0, 0.0, 0.0, 0.0]
        k = 0
        for li in o.by_pos.get(split, ()):
            a, b = o.lines[li]
            other = b if a == split else a
            if other >= cur:
                continue
            idx = o.ldif[li] if diffuse else getattr(o, "lspc", {}).get(li)
            if not idx:
                continue
            ci = idx[0] if a == split else idx[1]
            if ci < len(arr):
                c = arr[ci]
                acc = [acc[j] + c[j] for j in range(4)]
                k += 1
        # the reference implementation scales the sum by the line count
        return [a * k for a in acc]

    def point_cont(self, body):
        br = BitReader(body)
        o = self.s.resources.get(br.string())
        if not isinstance(o, PointSet):
            raise U3DError("point set continuation without declaration")
        br.u32()
        start = br.u32()
        end = br.u32()
        if start != len(o.positions) or end < start or end > o.max_desc[1] + 1 or end - start > len(body) * 8:
            raise U3DError("corrupt %s continuation" % o.kind)
        lim_prim = o.max_desc[0] + 64
        iqp, iqn, iqt, iqd, iqs = o.iq
        cu32, cu8 = br.cu32, br.cu8
        sh = o.shadings
        has_tex = o.max_desc[5] > 0
        for cur in range(start, end):
            split = cu32(AC_STATIC_FULL + (cur if cur > 1 else 1))
            sg = cu8(C_POS_SIGNS)
            d = [cu32(C_POS_X), cu32(C_POS_Y), cu32(C_POS_Z)]
            pred = o.positions[split] if cur > 0 and split < len(o.positions) else [0.0, 0.0, 0.0]
            o.positions.append([(-iqp if sg & (1 << j) else iqp) * d[j] + pred[j] for j in range(3)])
            nloc = cu32(C_NUM_LOCAL_NORMALS)
            if nloc > 4096:
                raise U3DError("corrupt normal count")
            for _ in range(nloc):
                sg = cu8(C_NRM_SIGNS)
                d = [cu32(C_NRM_X), cu32(C_NRM_Y), cu32(C_NRM_Z)]
                o.normals.append([(-iqn if sg & (1 << j) else iqn) * d[j] for j in range(3)])
            npnt = cu32(C_NUM_NEW_FACES)
            if len(o.points) + npnt > lim_prim:
                raise U3DError("more points than declared")
            for _ in range(npnt):
                sid = cu32(C_POINT_SHADING)
                d = sh[sid] if sid < len(sh) else MeshShading(0, 0, [], 0)
                cu32(C_NRM_LOCAL_IDX)
                didx = None
                for flag in (1, 2):
                    if d.attrs & flag:
                        dup = cu8(C_VC_DUP)
                        arr = o.diffuse if flag == 1 else o.specular
                        iq = iqd if flag == 1 else iqs
                        if dup == 0:
                            sg = cu8(C_NRM_SIGNS)
                            v = [cu32(C_VC_R), cu32(C_VC_G), cu32(C_VC_B), cu32(C_VC_A)]
                            arr.append([(-iq if sg & (1 << j) else iq) * v[j] for j in range(4)])
                        if flag == 1:
                            didx = len(arr) - 1
                if has_tex:
                    for L in range(d.layers):
                        dup = cu8(C_TC_DUP)
                        if dup == 0:
                            sg = cu8(C_TC_DIFF_SIGNS)
                            v = [cu32(C_TC_U), cu32(C_TC_V), cu32(C_TC_S), cu32(C_TC_T)]
                            o.texcoords.append([(-iqt if sg & (1 << min(j, 2)) else iqt) * v[j]
                                                for j in range(4)])
                o.points.append(cur)
                o.pshade.append(sid)
                o.pdif.append(didx)


def load(data: bytes) -> Scene:
    """Parse a complete U3D file (bytes) into a Scene."""
    data = bytes(data)
    if len(data) < 12 or struct.unpack_from("<I", data, 0)[0] != BT_HEADER:
        raise U3DError("not a U3D file")
    scene = Scene()
    ld = _Loader(scene)
    for t, body, meta in iter_blocks(data):
        ld.block(t, body, meta)
    for r in scene.resources.values():
        if isinstance(r, Mesh):
            _finalize_mesh(r)
            if not r.complete:
                scene.warn("mesh %r incomplete (%d/%d vertices)" % (r.name, r.res, r.final_res))
    return scene


def _finalize_mesh(m):
    """Convert the reconstruction state to compact numpy arrays."""
    if m.np is not None:
        return
    if m.native is not None:
        try:
            m.np = m.native.export()
        finally:
            m.native.close()
            m.native = None
    else:
        nf = len(m.fpos)
        m.np = {
            "pos": np.asarray(m.positions, np.float32).reshape(-1, 3),
            "nrm": np.asarray(m.normals, np.float32).reshape(-1, 3),
            "dif": np.asarray(m.diffuse, np.float32).reshape(-1, 4),
            "spc": np.asarray(m.specular, np.float32).reshape(-1, 4),
            "tex": np.asarray(m.texcoords, np.float32).reshape(-1, 4),
            "fpos": np.asarray(m.fpos, np.uint32).reshape(-1, 3),
            "fnrm": np.asarray(m.fnrm, np.uint32).reshape(-1, 3),
            "fdif": np.asarray(m.fdif, np.uint32).reshape(-1, 3),
            "fspc": np.asarray(m.fspc, np.uint32).reshape(-1, 3),
            "ftex": np.asarray([(t[0] if t else [0, 0, 0]) for t in m.ftex], np.uint32).reshape(-1, 3),
            "fshade": np.asarray(m.fshade, np.uint32).reshape(-1),
            "res": m.res}
    # free the python reconstruction state
    m.positions = m.normals = m.diffuse = m.specular = m.texcoords = []
    m.fpos = m.fnrm = m.fdif = m.fspc = m.ftex = m.fshade = []
    m.adj = []


# ------------------------------------------------------------- flattening
def mesh_arrays(m):
    """Per-corner arrays of a decoded Mesh (unindexed triangles).

    Returns dict: pos (N,3) float32, nrm (N,3) float32 or None,
    col (N,4) float32 or None, uv (N,2) float32 or None, shade (F,) int32,
    faces (F,3) int32 position indices, positions (P,3)."""
    _finalize_mesh(m)
    d = m.np
    P = d["pos"]
    fp = d["fpos"].astype(np.int64)
    F = len(fp)
    if F == 0 or len(P) == 0:
        return None
    bad = (fp >= len(P)).any(axis=1)
    if bad.any():
        keep = ~bad
        fp = fp[keep]
        sel = keep
        F = len(fp)
        if F == 0:
            return None
    else:
        sel = None

    def S(a):
        return a if sel is None else a[sel]

    shade = S(d["fshade"]).astype(np.int32)
    out = {"positions": P, "faces": fp.astype(np.int32), "shade": shade}
    out["pos"] = P[fp.reshape(-1)]
    nrm = None
    N = d["nrm"]
    if len(N) and not m.exclude_normals:
        fn = S(d["fnrm"]).astype(np.int64).reshape(-1)
        ok = fn < len(N)
        nrm = np.zeros((F * 3, 3), np.float32)
        nrm[ok] = N[fn[ok]]
        l = np.linalg.norm(nrm, axis=1)
        good = l > 1e-12
        nrm[good] /= l[good, None]
        if good.sum() < 0.5 * len(good):
            nrm = None
    out["nrm"] = nrm
    col = None
    D = d["dif"]
    if len(D):
        attrs = np.array([sd.attrs for sd in m.shadings] or [0], np.uint32)
        has = np.repeat((attrs[np.clip(shade, 0, len(attrs) - 1)] & 1) > 0, 3)
        if has.any():
            fd = np.clip(S(d["fdif"]).astype(np.int64).reshape(-1), 0, len(D) - 1)
            col = np.ones((F * 3, 4), np.float32)
            col[has] = D[fd[has]]
            np.clip(col, 0.0, 1.0, out=col)
            out["col_mask"] = has
    out["col"] = col
    uv = None
    T = d["tex"]
    if len(T):
        layers = np.array([sd.layers for sd in m.shadings] or [0], np.uint32)
        has = np.repeat(layers[np.clip(shade, 0, len(layers) - 1)] > 0, 3)
        if has.any():
            ft = np.clip(S(d["ftex"]).astype(np.int64).reshape(-1), 0, len(T) - 1)
            uv = np.zeros((F * 3, 2), np.float32)
            uv[has] = T[ft[has], :2]
    out["uv"] = uv
    return out
