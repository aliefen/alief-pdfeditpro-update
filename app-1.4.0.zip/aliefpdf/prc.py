# -*- coding: utf-8 -*-
"""
PRC (Product Representation Compact, ISO 14739-1) reader for the 3D review
of ALIEF PDF EDITOR PRO.

The bit-level PRC structures are read by a small interpreter driven by the
declarative PRC schema of the prc-rs project (data/prc_schema.json, MIT
License, Copyright (c) 2025-2026 Kristof Ralovich), including the PRC
"schema" extension mechanism for entities written by newer authoring tools.
From the decoded file structures we build the assembly (product
occurrences, part definitions, representation items with their transforms
and styles) and the triangle / wire tessellations (PRC_TYPE_TESS_3D and
PRC_TYPE_TESS_3D_Wire).  Highly compressed tessellations
(PRC_TYPE_TESS_3D_Compressed) and exact B-rep geometry without
tessellation are reported as not displayable.
"""
from __future__ import annotations

import json
import math
import os
import re
import struct
import zlib

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))


class PRCError(Exception):
    pass


class PRCUnsupported(PRCError):
    pass


# ----------------------------------------------------------- constants
PRC_TYPES = {
    "PRC_TYPE_ROOT": 0, "PRC_TYPE_ROOT_PRCBase": 1, "PRC_TYPE_ROOT_PRCBaseWithGraphics": 2,
    "PRC_TYPE_CRV": 10, "PRC_TYPE_SURF": 75, "PRC_TYPE_TOPO": 140, "PRC_TYPE_TESS": 170, "PRC_TYPE_MISC": 200,
    "PRC_TYPE_RI": 230, "PRC_TYPE_ASM": 300, "PRC_TYPE_MKP": 500, "PRC_TYPE_GRAPH": 700, "PRC_TYPE_MATH": 900,
    "PRC_TYPE_CRV_Base": 11, "PRC_TYPE_CRV_Blend02Boundary": 12, "PRC_TYPE_CRV_NURBS": 13, "PRC_TYPE_CRV_Circle": 14,
    "PRC_TYPE_CRV_Composite": 15, "PRC_TYPE_CRV_OnSurf": 16, "PRC_TYPE_CRV_Ellipse": 17, "PRC_TYPE_CRV_Equation": 18,
    "PRC_TYPE_CRV_Helix": 19, "PRC_TYPE_CRV_Hyperbola": 20, "PRC_TYPE_CRV_Intersection": 21, "PRC_TYPE_CRV_Line": 22,
    "PRC_TYPE_CRV_Offset": 23, "PRC_TYPE_CRV_Parabola": 24, "PRC_TYPE_CRV_PolyLine": 25, "PRC_TYPE_CRV_Transform": 26,
    "PRC_TYPE_SURF_Base": 76, "PRC_TYPE_SURF_Blend01": 77, "PRC_TYPE_SURF_Blend02": 78, "PRC_TYPE_SURF_Blend03": 79,
    "PRC_TYPE_SURF_NURBS": 80, "PRC_TYPE_SURF_Cone": 81, "PRC_TYPE_SURF_Cylinder": 82, "PRC_TYPE_SURF_Cylindrical": 83,
    "PRC_TYPE_SURF_Offset": 84, "PRC_TYPE_SURF_Pipe": 85, "PRC_TYPE_SURF_Plane": 86, "PRC_TYPE_SURF_Ruled": 87,
    "PRC_TYPE_SURF_Sphere": 88, "PRC_TYPE_SURF_Revolution": 89, "PRC_TYPE_SURF_Extrusion": 90,
    "PRC_TYPE_SURF_FromCurves": 91, "PRC_TYPE_SURF_Torus": 92, "PRC_TYPE_SURF_Transform": 93,
    "PRC_TYPE_SURF_Blend04": 94, "PRC_TYPE_TOPO_Context": 141, "PRC_TYPE_TOPO_Item": 142,
    "PRC_TYPE_TOPO_MultipleVertex": 143, "PRC_TYPE_TOPO_UniqueVertex": 144, "PRC_TYPE_TOPO_WireEdge": 145,
    "PRC_TYPE_TOPO_Edge": 146, "PRC_TYPE_TOPO_CoEdge": 147, "PRC_TYPE_TOPO_Loop": 148, "PRC_TYPE_TOPO_Face": 149,
    "PRC_TYPE_TOPO_Shell": 150, "PRC_TYPE_TOPO_Connex": 151, "PRC_TYPE_TOPO_Body": 152,
    "PRC_TYPE_TOPO_SingleWireBody": 153, "PRC_TYPE_TOPO_BrepData": 154, "PRC_TYPE_TOPO_SingleWireBodyCompress": 155,
    "PRC_TYPE_TOPO_BrepDataCompress": 156, "PRC_TYPE_TOPO_WireBody": 157, "PRC_TYPE_TESS_Base": 171,
    "PRC_TYPE_TESS_3D": 172, "PRC_TYPE_TESS_3D_Compressed": 173, "PRC_TYPE_TESS_Face": 174,
    "PRC_TYPE_TESS_3D_Wire": 175, "PRC_TYPE_TESS_Markup": 176, "PRC_TYPE_MISC_Attribute": 201,
    "PRC_TYPE_MISC_CartesianTransformation": 202, "PRC_TYPE_MISC_EntityReference": 203,
    "PRC_TYPE_MISC_MarkupLinkedItem": 204, "PRC_TYPE_MISC_ReferenceOnPRCBase": 205,
    "PRC_TYPE_MISC_ReferenceOnTopology": 206, "PRC_TYPE_MISC_GeneralTransformation": 207,
    "PRC_TYPE_RI_RepresentationItem": 231, "PRC_TYPE_RI_BrepModel": 232, "PRC_TYPE_RI_Curve": 233,
    "PRC_TYPE_RI_Direction": 234, "PRC_TYPE_RI_Plane": 235, "PRC_TYPE_RI_PointSet": 236,
    "PRC_TYPE_RI_PolyBrepModel": 237, "PRC_TYPE_RI_PolyWire": 238, "PRC_TYPE_RI_Set": 239,
    "PRC_TYPE_RI_CoordinateSystem": 240, "PRC_TYPE_ASM_ModelFile": 301, "PRC_TYPE_ASM_FileStructure": 302,
    "PRC_TYPE_ASM_FileStructureGlobals": 303, "PRC_TYPE_ASM_FileStructureTree": 304,
    "PRC_TYPE_ASM_FileStructureTessellation": 305, "PRC_TYPE_ASM_FileStructureGeometry": 306,
    "PRC_TYPE_ASM_FileStructureExtraGeometry": 307, "PRC_TYPE_ASM_ProductOccurrence": 310,
    "PRC_TYPE_ASM_PartDefinition": 311, "PRC_TYPE_ASM_Filter": 320, "PRC_TYPE_MKP_View": 501,
    "PRC_TYPE_MKP_Markup": 502, "PRC_TYPE_MKP_Leader": 503, "PRC_TYPE_MKP_AnnotationItem": 504,
    "PRC_TYPE_MKP_AnnotationSet": 505, "PRC_TYPE_MKP_AnnotationReference": 506, "PRC_TYPE_GRAPH_Style": 701,
    "PRC_TYPE_GRAPH_Material": 702, "PRC_TYPE_GRAPH_Picture": 703, "PRC_TYPE_GRAPH_TextureApplication": 711,
    "PRC_TYPE_GRAPH_TextureDefinition": 712, "PRC_TYPE_GRAPH_TextureTransformation": 713,
    "PRC_TYPE_GRAPH_LinePattern": 721, "PRC_TYPE_GRAPH_FillPattern": 722, "PRC_TYPE_GRAPH_DottingPattern": 723,
    "PRC_TYPE_GRAPH_HatchingPattern": 724, "PRC_TYPE_GRAPH_SolidPattern": 725,
    "PRC_TYPE_GRAPH_VPicturePattern": 726, "PRC_TYPE_GRAPH_AmbientLight": 731, "PRC_TYPE_GRAPH_PointLight": 732,
    "PRC_TYPE_GRAPH_DirectionalLight": 733, "PRC_TYPE_GRAPH_SpotLight": 734,
    "PRC_TYPE_GRAPH_SceneDisplayParameters": 741, "PRC_TYPE_GRAPH_Camera": 742, "PRC_TYPE_MATH_FCT_1D": 901,
    "PRC_TYPE_MATH_FCT_1D_Polynom": 902, "PRC_TYPE_MATH_FCT_1D_Trigonometric": 903,
    "PRC_TYPE_MATH_FCT_1D_Fraction": 904, "PRC_TYPE_MATH_FCT_1D_ArctanCos": 905,
    "PRC_TYPE_MATH_FCT_1D_Combination": 906, "PRC_TYPE_MATH_FCT_3D": 910, "PRC_TYPE_MATH_FCT_3D_Linear": 911,
    "PRC_TYPE_MATH_FCT_3D_NonLinear": 912}
CONSTS = {"PRC_TRANSFORMATION_Identity": 0, "PRC_TRANSFORMATION_Translate": 1, "PRC_TRANSFORMATION_Rotate": 2,
          "PRC_TRANSFORMATION_Mirror": 4, "PRC_TRANSFORMATION_Scale": 8, "PRC_TRANSFORMATION_NonUniformScale": 16,
          "PRC_TRANSFORMATION_NonOrtho": 32, "PRC_TRANSFORMATION_Homogeneous": 64,
          "TextureApplicationMode::AlphaTest": 2, "TextureApplicationMode::Lighting": 1,
          "TextureApplicationMode::TextureColor": 4, "TextureMappingType::Operator": 3,
          "TextureMappingType::Stored": 1, "TextureMappingType::Parametric": 2, "TextureFunction::Blend": 3,
          "TextureFunction::Modulate": 1, "TextureFunction::Replace": 2, "TextureFunction::Decal": 4}
TESS_KINDS = [  # flag, kind, one_normal, textured
    (0x0002, "tri", False, False), (0x0004, "fan", False, False), (0x0008, "strip", False, False),
    (0x0020, "tri", True, False), (0x0040, "fan", True, False), (0x0080, "strip", True, False),
    (0x0200, "tri", False, True), (0x0400, "fan", False, True), (0x0800, "strip", False, True),
    (0x2000, "tri", True, True), (0x4000, "fan", True, True), (0x8000, "strip", True, True)]
NORMAL_SINGLE = 0x40000000

# ------------------------------------------------------------- doubles
_DTAB = None


def _double_table():
    global _DTAB
    if _DTAB is None:
        t = {}
        with open(os.path.join(_HERE, "data", "prc_double_table.txt")) as f:
            for row in f.read().split(";"):
                e, n, b, hi, lo = (int(x) for x in row.split(","))
                t[(n << 24) | b] = (e, (hi << 32) | lo)
        _DTAB = t
    return _DTAB


# ------------------------------------------------------------ bit reader
class BitReader:
    """MSB-first bit reader over a decompressed PRC section."""

    __slots__ = ("d", "p", "n")

    def __init__(self, data):
        self.d = bytes(data) + b"\0" * 8
        self.p = 0
        self.n = len(data) * 8

    def bit(self):
        p = self.p
        if p >= self.n:
            raise PRCError("unexpected end of PRC section")
        self.p = p + 1
        return (self.d[p >> 3] >> (7 - (p & 7))) & 1

    def bits(self, k):
        if k == 0:
            return 0
        p = self.p
        if p + k > self.n:
            raise PRCError("unexpected end of PRC section")
        b0 = p >> 3
        off = p & 7
        nb = (off + k + 7) >> 3
        v = int.from_bytes(self.d[b0:b0 + nb], "big")
        self.p = p + k
        return (v >> (nb * 8 - off - k)) & ((1 << k) - 1)

    # builtins ----------------------------------------------------------
    def boolean(self):
        return self.bit() == 1

    def uchar(self):
        return self.bits(8)

    def char(self):
        v = self.bits(8)
        return v - 256 if v & 0x80 else v

    def ushort(self):
        lo = self.bits(8)
        return lo | (self.bits(8) << 8)

    def uint(self):
        v = 0
        i = 0
        # the continuation bit is read before the byte count check (ISO 14739-1)
        while self.bit() and i < 4:
            v |= self.bits(8) << (8 * i)
            i += 1
        return v

    def int(self):
        v = 0
        j = 0
        while self.bit() and j < 4:
            v |= self.bits(8) << (8 * j)
            j += 1
        if j > 0:
            sh = (4 - j) * 8
            v = (v << sh) & 0xFFFFFFFF
            if v & 0x80000000:
                v -= 1 << 32
            v >>= sh
        return v

    def double(self):
        tab = _DTAB or _double_table()
        code = 0
        found = None
        for i in range(1, 23):
            code = (code << 1) | self.bit()
            found = tab.get((i << 24) | code)
            if found is not None:
                break
        if found is None:
            raise PRCError("invalid PRC double coding")
        is_exp, u = found
        if not is_exp and i == 2 and code == 1:
            return 0.0
        b = bytearray(struct.pack("<Q", u))
        if self.bit():
            b[7] |= 0x80
        if not is_exp:
            return struct.unpack("<d", bytes(b))[0]
        if not self.bit():
            return struct.unpack("<d", bytes(b))[0]
        b[6] |= self.bits(4) & 0x0F
        lbi = 0
        cbi = 5
        while cbi >= lbi:
            if self.bit():
                b[cbi] = self.bits(8)
            else:
                off = self.bits(3)
                if off == 0:
                    v = b[cbi + 1]
                    while cbi >= lbi:
                        b[cbi] = v
                        cbi -= 1
                    break
                elif off == 6:
                    v = b[cbi + 1]
                    lbi += 1
                    while cbi >= lbi:
                        b[cbi] = v
                        cbi -= 1
                    b[cbi] = self.bits(8)
                    break
                else:
                    if cbi + off >= 8:
                        raise PRCError("invalid PRC double")
                    b[cbi] = b[cbi + off]
            cbi -= 1
        return struct.unpack("<d", bytes(b))[0]

    def string(self):
        if not self.bit():
            return ""
        n = self.uint()
        if n > 1 << 24:
            raise PRCError("string too long")
        if self.p + 8 * n > self.n:
            raise PRCError("unexpected end of PRC section")
        if self.p & 7 == 0:
            s = self.d[self.p >> 3:(self.p >> 3) + n]
            self.p += 8 * n
        else:
            s = bytes(self.bits(8) for _ in range(n))
        try:
            return s.decode("utf-8")
        except UnicodeDecodeError:
            return s.decode("latin-1")

    def userdata(self):
        n = self.uint()
        if self.p + n > self.n:
            raise PRCError("unexpected end of PRC section")
        self.p += n
        return None

    def uint_vb(self, n):
        if n >= 64:
            raise PRCError("bit count too large")
        return self.bits(n)

    def int_vb(self, n):
        if n == 0:
            raise PRCError("IntegerWithVariableBitNumber requires at least 1 bit")
        neg = self.bit()
        v = self.bits(n - 1) if n > 1 else 0
        return -v if neg else v

    def float_bytes(self):
        return struct.unpack("<f", bytes(self.bits(8) for _ in range(4)))[0]

    def uint_array_fast(self, count):
        """count UnsignedIntegers (native accelerated when available)."""
        nat = _native_prc()
        if nat is not None and count > 64:
            return nat.read_uints(self, count)
        return [self.uint() for _ in range(count)]

    def double_array_fast(self, count):
        nat = _native_prc()
        if nat is not None and count > 64:
            return nat.read_doubles(self, count)
        return [self.double() for _ in range(count)]


# ------------------------------------------------- native acceleration
_NATP = None


def _native_prc():
    global _NATP
    if _NATP is not None:
        return _NATP or None
    _NATP = False
    try:
        from . import u3d
        lib = u3d._native()
        if lib is None or not hasattr(lib, "prc_read_uints"):
            return None
        import ctypes
        lib.prc_read_uints.restype = ctypes.c_int64
        lib.prc_read_uints.argtypes = [ctypes.c_char_p, ctypes.c_uint64, ctypes.c_uint64, ctypes.c_uint32,
                                       ctypes.POINTER(ctypes.c_uint32)]
        lib.prc_read_doubles.restype = ctypes.c_int64
        lib.prc_read_doubles.argtypes = [ctypes.c_char_p, ctypes.c_uint64, ctypes.c_uint64, ctypes.c_uint32,
                                         ctypes.POINTER(ctypes.c_double)]
        lib.prc_set_double_table.restype = ctypes.c_int
        lib.prc_set_double_table.argtypes = [ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
                                             ctypes.POINTER(ctypes.c_uint64)]
        tab = _double_table()
        keys = (ctypes.c_uint32 * len(tab))()
        vals = (ctypes.c_uint64 * len(tab))()
        for i, (k, (e, u)) in enumerate(tab.items()):
            keys[i] = k | (0x80000000 if e else 0)
            vals[i] = u
        if lib.prc_set_double_table(len(tab), keys, vals) != 0:
            return None

        class N:
            @staticmethod
            def read_uints(r, count):
                out = np.zeros(count, np.uint32)
                p = lib.prc_read_uints(r.d, r.n, r.p, count, out.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)))
                if p < 0:
                    raise PRCError("unexpected end of PRC section")
                r.p = int(p)
                return out

            @staticmethod
            def read_doubles(r, count):
                out = np.zeros(count, np.float64)
                p = lib.prc_read_doubles(r.d, r.n, r.p, count, out.ctypes.data_as(ctypes.POINTER(ctypes.c_double)))
                if p < 0:
                    raise PRCError("invalid PRC double array")
                r.p = int(p)
                return out

        _NATP = N
    except Exception:
        _NATP = False
    return _NATP or None


# ------------------------------------------------------- schema eval VM
class _SchemaEval:
    """PRC schema extension evaluator (ISO 14739-1 8.4)."""

    STORED_VERSION = 8137

    def __init__(self, schemas):
        self.ops = {}
        for s in schemas or []:
            self.ops[s["entity_type"]] = list(s["schema_tokens"])

    def eval(self, r, type_id):
        ops = self.ops.get(type_id)
        if not ops:
            return
        st = {"op": list(reversed(ops)), "ds": [], "vars": {}}
        guard = 0
        while st["op"]:
            self._do(r, st, False)
            guard += 1
            if guard > 100000:
                raise PRCError("schema evaluation does not terminate")

    @staticmethod
    def _pop(st):
        if not st["op"]:
            raise PRCError("schema stack underflow")
        return st["op"].pop()

    def _do(self, r, st, skip, depth=0):
        if depth > 200:
            raise PRCError("schema nesting too deep")
        if not st["op"]:
            return
        t = self._pop(st)
        ds = st["ds"]
        if t == 0:
            if not skip:
                ds.append(r.boolean())
        elif t == 1:
            if not skip:
                ds.append(r.double())
        elif t == 2:
            if not skip:
                ds.append(r.uchar())
        elif t == 3:
            if not skip:
                ds.append(r.uint())
        elif t == 4:
            if not skip:
                ds.append(r.int())
        elif t == 5:
            if not skip:
                ds.append(r.string())
        elif t == 6:
            father = self._pop(st)
            if not skip:
                self.eval(r, father)
        elif t in (7, 9):
            if not skip:
                ds.append((r.double(), r.double()))
        elif t == 8:
            if not skip:
                ds.append((r.double(), r.double(), r.double()))
        elif t == 10:
            if not skip:
                a = [r.double() for _ in range(4)]
                ds.append(tuple(a[:2]))
                ds.append(tuple(a[2:]))
        elif t == 11:
            if not skip:
                a = [r.double() for _ in range(6)]
                ds.append(tuple(a[:3]))
                ds.append(tuple(a[3:]))
        elif t in (12, 13, 14):
            if not skip:
                raise PRCUnsupported("PRC schema with embedded geometry")
        elif t in (15, 16):
            if skip:
                if t == 15:
                    self._do(r, st, True, depth + 1)
                self._do(r, st, True, depth + 1)
            else:
                if t == 15:
                    self._do(r, st, False, depth + 1)
                    if not ds:
                        raise PRCError("schema for without count")
                    n = int(ds.pop())
                else:
                    n = r.int()
                if n > 1 << 22:
                    raise PRCError("schema loop too long")
                for _ in range(max(0, n - 1)):
                    tmp = {"op": list(st["op"]), "ds": [], "vars": {}}
                    self._do(r, tmp, False, depth + 1)
                    ds.extend(reversed(tmp["ds"]))
                self._do(r, st, n <= 0, depth + 1)
        elif t == 17:
            if skip:
                self._do(r, st, True, depth + 1)
                self._do(r, st, True, depth + 1)
                if st["op"] and st["op"][-1] == 18:
                    self._do(r, st, True, depth + 1)
            else:
                self._do(r, st, False, depth + 1)
                c = ds.pop() if ds else 0
                if isinstance(c, (tuple, str)):
                    raise PRCError("schema if needs a scalar")
                if c:
                    self._do(r, st, False, depth + 1)
                    if st["op"] and st["op"][-1] == 18:
                        self._do(r, st, True, depth + 1)
                else:
                    self._do(r, st, True, depth + 1)
                    if st["op"] and st["op"][-1] == 18:
                        self._do(r, st, False, depth + 1)
        elif t == 18:
            self._do(r, st, skip, depth + 1)
        elif t == 24:
            vid = self._pop(st)
            if skip:
                self._do(r, st, True, depth + 1)
            else:
                self._do(r, st, False, depth + 1)
                st["vars"][vid] = ds.pop() if ds else 0
        elif t == 25:
            vid = self._pop(st)
            if not skip:
                ds.append(st["vars"].get(vid, 0))
        elif t == 26:
            v = self._pop(st)
            if not skip:
                ds.append(v)
        elif t == 37:
            self._do(r, st, skip, depth + 1)
            self._do(r, st, skip, depth + 1)
            if not skip:
                a = ds.pop()
                b = ds.pop()
                ds.append(a == b)
        elif t == 19:
            while st["op"] and st["op"][-1] != 21:
                self._do(r, st, skip, depth + 1)
            self._do(r, st, skip, depth + 1)
        elif t == 21:
            pass
        elif t == 20:
            if skip:
                self._do(r, st, skip, depth + 1)
                while st["op"] and st["op"][-1] != 21:
                    self._do(r, st, skip, depth + 1)
                self._do(r, st, skip, depth + 1)
            else:
                version = self._pop(st)
                inner = not (self.STORED_VERSION < version)
                while st["op"] and st["op"][-1] != 21:
                    self._do(r, st, inner if inner else skip, depth + 1)
                self._do(r, st, skip, depth + 1)
        elif t in (39, 40):
            if st["op"]:
                st["op"].pop()
        else:
            raise PRCError("unsupported PRC schema token %d" % t)


# ------------------------------------------------- expression translator
_TRANS_CACHE = {}


def _translate(expr):
    """Rust condition / size expression of the schema -> python lambda(F, C)."""
    if expr in _TRANS_CACHE:
        return _TRANS_CACHE[expr]
    e = str(expr)
    e = e.replace("?", "")
    for k, v in sorted(CONSTS.items(), key=lambda kv: -len(kv[0])):
        e = e.replace(k, str(v))
    e = re.sub(r"\bas\s+(u8|i8|u16|i16|i32|u32|usize|u64)\b", "", e)
    e = re.sub(r"(\d+)(usize|u32|i32|u8|i8)\b", r"\1", e)
    # if c { a } else { b }
    m = re.match(r"^\s*if\s+(.+?)\s*\{\s*(.+?)\s*\}\s*else\s*\{\s*(.+?)\s*\}\s*$", e)
    if m:
        e = "((%s) if (%s) else (%s))" % (m.group(2), m.group(1), m.group(3))
    e = e.replace("!=", " __NE__ ")
    e = e.replace("&&", " and ").replace("||", " or ")
    e = re.sub(r"!!", " ", e)
    e = re.sub(r"!", " not ", e)
    e = e.replace(" __NE__ ", " != ")
    # context accessors
    e = e.replace("_ctx.get_authoring_version()", "C.authoring_version")
    e = e.replace("_ctx.TESS_3D_Wire__is_inside()", "C.t3dw_inside")
    e = e.replace("_ctx.VertexColors_get_num_colors_remainder()", "C.vc_remainder()")
    e = e.replace("_ctx.get_num_fsi()", "C.num_fsi")
    e = re.sub(r"_ctx\.t3dc\.number_of_faces_stored_in_mesh\(&(\w+)\.a\)", r"C.t3dc_faces(F['\1'])", e)
    e = re.sub(r"_ctx\.t3dc\.number_of_referenced_points\(&(\w+)\.a\)", r"C.t3dc_refpoints(F['\1'])", e)
    e = re.sub(r"_ctx\.(\w+(?:\.\w+)*)", r"C.ctx_get('\1')", e)
    e = e.replace("have_bbox(", "C.have_bbox(")
    # field references
    e = re.sub(r"\b(\w+)\.a\.len\(\)", r"len(F['\1'])", e)

    def chain(m):
        parts = m.group(1).split(".")
        if parts and parts[-1] == "value":
            parts = parts[:-1]
        return "F" + "".join("[%r]" % p for p in parts)

    e = re.sub(r"\bself\.((?:\w+\.)*\w+)", chain, e)
    e = re.sub(r"(?<![\w'\]\.])([a-z_][a-z0-9_]*)\.value\b", r"F['\1']", e)
    e = re.sub(r"\btrue\b", "True", e)
    e = re.sub(r"\bfalse\b", "False", e)
    code = compile(e.strip(), "<prc-schema>", "eval")
    fn = lambda F, C: eval(code, {"len": len}, {"F": F, "C": C})  # noqa: E731
    _TRANS_CACHE[expr] = fn
    return fn


# ----------------------------------------------------------- context
class _Ctx:
    def __init__(self):
        self.authoring_version = 8137
        self.num_fsi = 1
        self.current_name = ""
        self.t3dw_inside = False
        self.t3dw = None
        self.vc_colors = 0
        self.se = _SchemaEval([])
        self.graphics = None
        self.t3dc_nfaces = 0

    def ctx_get(self, name):
        raise PRCUnsupported("PRC compressed B-rep data (%s)" % name)

    def have_bbox(self, b):
        b = int(b) & 0xFF
        return bool(b & 1) or bool(b & 2)

    def vc_remainder(self):
        n = self.vc_colors
        if self.t3dw_inside and self.t3dw is not None:
            n = _wire_colors(self.t3dw)
        return n - 1 if n >= 1 else 0

    def t3dc_faces(self, arr):
        if len(arr) == 0:
            return 0
        return int(max(arr)) + 1

    def t3dc_refpoints(self, arr):
        return int(sum(1 for x in arr if x))


def _wire_colors(w):
    idx, seg = w
    i = 0
    n = 0
    L = len(idx)
    while i < L:
        k = int(idx[i]) & 0x7FFFFFFF
        n += max(0, k - 1) if seg else k
        i += k + 1
    return n


# -------------------------------------------------------- interpreter
class _Parser:
    def __init__(self, schema_path=None):
        p = schema_path or os.path.join(_HERE, "data", "prc_schema.json")
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        self.S = d["structures"]
        self.builtins = set(d["builtins"])
        self.vbr1 = set(d["vbr_1param"])
        self.vbr2 = set(d["vbr_2param"])
        self.aliases = {}
        for n, st in self.S.items():
            for a in st.get("alias", []) or []:
                self.aliases[a] = n
        # precompute the field to call the schema evaluator after
        self.se_after = {}
        for n, st in self.S.items():
            if not n.startswith("PRC_TYPE_"):
                continue
            fl = st["fields"]
            has_ud = any(f["name"] == "user_data" and f["data_type"] == "UserData" for f in fl)
            if len(fl) >= 2 and has_ud:
                self.se_after[n] = fl[-2]["name"]
            elif fl:
                self.se_after[n] = fl[-1]["name"]

    # builtin reader -----------------------------------------------------
    def builtin(self, r, dt, F, f, C):
        if dt == "UnsignedInteger":
            return r.uint()
        if dt == "Boolean":
            return r.boolean()
        if dt == "Double":
            return r.double()
        if dt == "String":
            return r.string()
        if dt == "Character":
            return r.char()
        if dt == "UnsignedCharacter":
            return r.uchar()
        if dt == "UnsignedShort":
            return r.ushort()
        if dt == "Integer":
            return r.int()
        if dt == "UserData":
            return r.userdata()
        if dt == "NumberOfBitsThenUnsignedInteger":
            n = r.bits(5)
            return r.bits(n)
        if dt == "UnsignedIntegerWithVariableBitNumber":
            return r.uint_vb(int(_translate(f["vbr"])(F, C)))
        if dt == "FloatAsBytes":
            return r.float_bytes()
        if dt == "UncompressedBoolArray":
            n = int(_translate(f["vbr"])(F, C))
            if r.p + n > r.n:
                raise PRCError("unexpected end of PRC section")
            return [r.bit() == 1 for _ in range(n)]
        raise PRCUnsupported("PRC highly compressed data (%s)" % dt)

    # structure reader -----------------------------------------------------
    def parse(self, name, r, C, depth=0):
        if depth > 120:
            raise PRCError("PRC structure nesting too deep")
        name = self.aliases.get(name, name)
        st = self.S.get(name)
        if st is None:
            raise PRCUnsupported("PRC structure %s" % name)
        F = {"_t": name}
        oe = st.get("on_enter")
        if oe:
            self.hook(oe, F, C, name)
        se_after = self.se_after.get(name)
        for f in st["fields"]:
            fname = f["name"]
            cond = f.get("condition_rust")
            if cond is not None and not _translate(cond)(F, C):
                F[fname] = None
                if se_after == fname:
                    C.se.eval(r, PRC_TYPES.get(name, -1))
                continue
            dt = f["data_type"]
            if "eligible_type_ids" in f:
                pos = r.p
                tid = r.uint()
                r.p = pos
                tname = None
                for en, _short in f["eligible_type_ids"]:
                    if PRC_TYPES.get(en) == tid:
                        tname = en
                        break
                if tname is None:
                    raise PRCUnsupported("PRC entity type %d in %s.%s" % (tid, name, fname))
                F[fname] = self.parse(tname, r, C, depth + 1)
            elif "is_vec" in f:
                n = int(_translate(f["size"])(F, C))
                if n < 0 or n > 50_000_000:
                    raise PRCError("PRC array too large")
                if dt in self.builtins:
                    if dt == "UnsignedInteger":
                        F[fname] = r.uint_array_fast(n)
                    elif dt == "Double":
                        F[fname] = r.double_array_fast(n)
                    else:
                        F[fname] = [self.builtin(r, dt, F, f, C) for _ in range(n)]
                else:
                    F[fname] = [self.parse(dt, r, C, depth + 1) for _ in range(n)]
            elif "multiplicity" in f:
                n = int(f["multiplicity"])
                if dt in self.builtins:
                    F[fname] = [self.builtin(r, dt, F, f, C) for _ in range(n)]
                else:
                    F[fname] = [self.parse(dt, r, C, depth + 1) for _ in range(n)]
            elif dt in self.builtins:
                F[fname] = self.builtin(r, dt, F, f, C)
            else:
                F[fname] = self.parse(dt, r, C, depth + 1)
            ev = f.get("expected_value")
            if ev and ev[0] == "PrcType":
                want = PRC_TYPES.get(ev[1])
                if want is not None and F[fname] != want:
                    raise PRCError("expected %s in %s (got %r)" % (ev[1], name, F[fname]))
            for hk in ("on_set", "on_set1", "on_set2"):
                h = f.get(hk)
                if h:
                    self.hook(h, F, C, name)
            if se_after == fname:
                C.se.eval(r, PRC_TYPES.get(name, -1))
        ol = st.get("on_leave")
        if ol:
            self.hook(ol, F, C, name)
        if name == "Name":
            if F.get("same_name"):
                F["name"] = C.current_name
        elif name == "PRC_TYPE_ROOT_PRCBaseWithGraphics":
            if F.get("same_graphics"):
                F["graphics_content"] = C.graphics
            else:
                C.graphics = F.get("graphics_content")
        return F

    def hook(self, h, F, C, name):
        if "_ctx.current_name = " in h:
            C.current_name = F.get("name") or ""
        elif h.startswith("_ctx.TESS_3D_Wire__enter"):
            C.t3dw_inside = True
            C.vc_colors = 0
        elif h.startswith("_ctx.TESS_3D_Wire__leave"):
            C.t3dw_inside = False
        elif h.startswith("_ctx.t3dw.set0"):
            C.t3dw = (list(F.get("wire_indexes") or []), False)
        elif h.startswith("_ctx.t3dw.set1"):
            if C.t3dw is not None:
                C.t3dw = (C.t3dw[0], bool(F.get("is_segment_color")))
        elif h.startswith("_ctx.VertexColors_set_num_vertex_colors_from_tess_3d_face"):
            C.vc_colors = _num_face_colors(F.get("used_entities_flag") or 0, F.get("triangulateddata") or [])
        elif h.startswith("if b\"PRC\""):
            pass
        # assertions, debug output and the compressed-tessellation helpers are not needed


def _num_face_colors(flag, tdata):
    if flag & (0x0001 | 0x0010 | 0x0100 | 0x1000):
        raise PRCUnsupported("PRC polyface tessellation")
    n = 0
    i = 0
    for fl, kind, one, tex in TESS_KINDS:
        if not flag & fl:
            continue
        if i >= len(tdata):
            raise PRCError("not enough tessellation data")
        if kind == "tri":
            n += 3 * int(tdata[i])
            i += 1
        else:
            ns = int(tdata[i])
            i += 1
            for _ in range(ns):
                if i >= len(tdata):
                    raise PRCError("not enough tessellation data")
                n += int(tdata[i]) & ~NORMAL_SINGLE
                i += 1
    return n


# ------------------------------------------------------------- file level
class PRCFile:
    def __init__(self):
        self.version_read = 0
        self.version_auth = 0
        self.structures = []      # per file structure: dict(uid, globals, tree, tess, errors)
        self.model = None
        self.warnings = []


def _uid(u):
    return tuple(int(x) for x in u)


def load(data: bytes) -> PRCFile:
    data = bytes(data)
    if data[:3] != b"PRC":
        raise PRCError("not a PRC file")
    if len(data) < 52:
        raise PRCError("PRC header truncated")
    pos = 3
    rd = lambda: struct.unpack_from("<I", data, pos)[0]  # noqa: E731
    out = PRCFile()
    out.version_read = rd()
    pos += 4
    out.version_auth = rd()
    pos += 4
    pos += 32  # unique ids of file and application
    nfs = rd()
    pos += 4
    if nfs > 4096:
        raise PRCError("corrupt PRC header")
    fsd = []
    for _ in range(nfs):
        uid = struct.unpack_from("<4I", data, pos)
        pos += 16
        pos += 4  # reserved
        nsec = struct.unpack_from("<I", data, pos)[0]
        pos += 4
        if nsec != 6:
            raise PRCError("unexpected PRC section count %d" % nsec)
        offs = struct.unpack_from("<6I", data, pos)
        pos += 24
        fsd.append((uid, offs))
    mf_start, mf_end = struct.unpack_from("<2I", data, pos)
    pos += 8
    fsize = len(data)

    def inflate(a, b):
        if not (0 <= a < b <= fsize):
            raise PRCError("invalid PRC section offsets")
        return zlib.decompressobj().decompress(data[a:b], 400 * 1024 * 1024)

    ctx = _Ctx()
    ctx.authoring_version = out.version_auth
    ctx.num_fsi = len(fsd)
    parser = _Parser()
    for uid, (h, g, t, ts, geo, ext) in fsd:
        fs = {"uid": _uid(uid), "globals": None, "tree": None, "tess": None, "errors": []}
        out.structures.append(fs)
        ctx.graphics = None
        ctx.current_name = ""
        try:
            gdata = inflate(g, t)
            r = BitReader(gdata)
            sch = parser.parse("Schema", r, ctx)
            ctx.se = _SchemaEval([{"entity_type": s["entity_type"], "schema_tokens": s["schema_tokens"]}
                                  for s in sch.get("schemas") or []])
            fs["globals"] = parser.parse("PRC_TYPE_ASM_FileStructureGlobals", r, ctx)
        except PRCError as e:
            fs["errors"].append("globals: %s" % e)
            continue
        try:
            fs["tree"] = parser.parse("PRC_TYPE_ASM_FileStructureTree", BitReader(inflate(t, ts)), ctx)
        except PRCError as e:
            fs["errors"].append("tree: %s" % e)
        try:
            fs["tess"] = _parse_tess_section(parser, BitReader(inflate(ts, geo)), ctx, fs)
        except PRCError as e:
            fs["errors"].append("tessellation: %s" % e)
    try:
        ctx.graphics = None
        mf = inflate(mf_start, mf_end)
        r = BitReader(mf)
        sch = parser.parse("Schema", r, ctx)
        ctx.se = _SchemaEval([{"entity_type": s["entity_type"], "schema_tokens": s["schema_tokens"]}
                              for s in sch.get("schemas") or []])
        out.model = parser.parse("PRC_TYPE_ASM_ModelFile", r, ctx)
    except PRCError as e:
        out.warnings.append("model file: %s" % e)
    for fs in out.structures:
        out.warnings.extend(fs["errors"])
    return out


def _parse_tess_section(parser, r, ctx, fs):
    """Tessellation section, tolerant: keeps the tessellations read before an
    unsupported (compressed) one."""
    F = {"_t": "PRC_TYPE_ASM_FileStructureTessellation"}
    tid = r.uint()
    if tid != PRC_TYPES["PRC_TYPE_ASM_FileStructureTessellation"]:
        raise PRCError("tessellation section id %d" % tid)
    parser.parse("ContentPRCBase", r, ctx)
    n = r.uint()
    out = []
    for i in range(n):
        pos = r.p
        t = r.uint()
        r.p = pos
        if t == PRC_TYPES["PRC_TYPE_TESS_3D_Compressed"]:
            fs["errors"].append("highly compressed PRC tessellation is not supported (%d of %d)" % (n - i, n))
            out.extend([None] * (n - i))
            break
        try:
            if t == PRC_TYPES["PRC_TYPE_TESS_3D"]:
                out.append(parser.parse("PRC_TYPE_TESS_3D", r, ctx))
            elif t == PRC_TYPES["PRC_TYPE_TESS_3D_Wire"]:
                out.append(parser.parse("PRC_TYPE_TESS_3D_Wire", r, ctx))
            elif t == PRC_TYPES["PRC_TYPE_TESS_Markup"]:
                out.append(parser.parse("PRC_TYPE_TESS_Markup", r, ctx))
            else:
                raise PRCError("unknown tessellation type %d" % t)
        except PRCUnsupported as e:
            fs["errors"].append(str(e))
            out.extend([None] * (n - i))
            break
    F["tess"] = out
    return F


# ---------------------------------------------------------- geometry
def _transform3d(t):
    M = np.eye(4)
    if t is None:
        return M
    if t.get("_t") == "PRC_TYPE_MISC_GeneralTransformation":
        g = [float(x) for x in t.get("general_transform") or []]
        if len(g) == 16:
            A = np.array(g).reshape(4, 4).T
            if abs(A[3, 0]) + abs(A[3, 1]) + abs(A[3, 2]) > 1e-12 and abs(A[0, 3]) + abs(A[1, 3]) + abs(A[2, 3]) < 1e-12:
                A = A.T
            return A
        return M
    tr = t.get("transform") if t.get("_t") == "PRC_TYPE_MISC_CartesianTransformation" else t
    if tr is None:
        return M
    beh = int(tr.get("behavior") or 0) & 0xFF
    v3 = lambda v: np.array([float(v["x"]), float(v["y"]), float(v["z"])])  # noqa: E731
    x, y, z = np.array([1.0, 0, 0]), np.array([0, 1.0, 0]), np.array([0, 0, 1.0])
    if beh & 0x20 and tr.get("non_ortho_matrix"):
        x, y, z = (v3(v) for v in tr["non_ortho_matrix"])
    elif beh & 0x02 and tr.get("rotation"):
        x = v3(tr["rotation"][0])
        y = v3(tr["rotation"][1])
        z = np.cross(x, y)
        if beh & 0x04:
            z = -z
    s = np.ones(3)
    if beh & 0x10 and tr.get("non_uniform_scale"):
        s = v3(tr["non_uniform_scale"])
    elif beh & 0x08 and tr.get("scale") is not None:
        s = np.full(3, float(tr["scale"]))
    M[:3, 0] = x * s[0]
    M[:3, 1] = y * s[1]
    M[:3, 2] = z * s[2]
    if beh & 0x01 and tr.get("translation"):
        M[:3, 3] = v3(tr["translation"])
    return M


def _graphics(entity):
    """(style index or None, show flag, removed flag, children inherit flag) of a
    PRCBaseWithGraphics carrier."""
    if entity is None:
        return None, True, False, False
    base = entity.get("base")
    if isinstance(base, dict) and base.get("_t") != "PRC_TYPE_ROOT_PRCBaseWithGraphics":
        base = None
    if base is None:
        ic = entity.get("item_content")
        base = ic.get("base") if isinstance(ic, dict) else None
    if not isinstance(base, dict):
        return None, True, False, False
    g = base.get("graphics_content") or {}
    st = int(g.get("biased_index_of_line_style") or 0)
    beh = int(g.get("behavior_bit_field") or 0)
    show = bool(beh & 0x1) or beh == 0
    removed = bool(beh & 0x2000)
    force = bool(beh & 0x0008) and st > 0
    return (st - 1 if st > 0 else None), show, removed, force


def _name(entity):
    try:
        b = entity.get("base")
        while isinstance(b, dict):
            nm = b.get("entity_name")
            if isinstance(nm, dict):
                return nm.get("name") or ""
            b = b.get("base")
        ic = entity.get("item_content")
        if isinstance(ic, dict):
            return _name(ic)
    except Exception:
        pass
    return ""


class _Styles:
    def __init__(self, glob):
        gd = (glob or {}).get("global_data") or {}
        self.colors = [(float(c["red"]), float(c["green"]), float(c["blue"])) for c in gd.get("colors") or []]
        self.materials = [m.get("id") if isinstance(m, dict) and isinstance(m.get("id"), dict) else m
                          for m in gd.get("materials") or []]
        self.styles = gd.get("styles") or []
        self.ref_coords = gd.get("ref_coords") or []

    def color(self, idx):
        """style index -> (r, g, b, a) or None"""
        if idx is None or not (0 <= idx < len(self.styles)):
            return None
        st = self.styles[idx]
        ci = int(st.get("biased_color_index") or 0) - 1
        rgb = None
        alpha = 1.0
        if st.get("is_material"):
            if 0 <= ci < len(self.materials):
                m = self.materials[ci]
                if m.get("_t") == "PRC_TYPE_GRAPH_Material":
                    di = int(m.get("biased_diffuse_index") or 0) - 1
                    if 0 <= di < len(self.colors):
                        rgb = self.colors[di]
                    try:
                        alpha = float(m.get("diffuse_alpha"))
                    except (TypeError, ValueError):
                        alpha = 1.0
                elif m.get("_t") == "PRC_TYPE_GRAPH_TextureApplication":
                    rgb = (0.8, 0.8, 0.8)
        elif 0 <= ci < len(self.colors):
            rgb = self.colors[ci]
        if st.get("is_transparency") and st.get("transparency") is not None:
            alpha = (int(st["transparency"]) & 0xFF) / 255.0
        if rgb is None:
            return None
        if not (0.0 <= alpha <= 1.0):
            alpha = 1.0
        return (max(0.0, min(1.0, rgb[0])), max(0.0, min(1.0, rgb[1])), max(0.0, min(1.0, rgb[2])), alpha)


def tess_triangles(t):
    """PRC_TYPE_TESS_3D -> dict(tri (N*3,3), nrm (N*3,3) or None, style (N,) style index or -1,
    vcol (N*3,4) or None)"""
    coords = np.asarray((t.get("tessellation_coordinates") or {}).get("coordinates") if t.get("tessellation_coordinates") else [],
                        np.float64)
    nrm = np.asarray(t.get("normal_coordinates") if t.get("normal_coordinates") is not None else [], np.float64)
    idx = np.asarray(t.get("triangulated_index_array") if t.get("triangulated_index_array") is not None else [],
                     np.int64)
    faces = t.get("face_tessellation_data") or []
    ncoord = len(coords)
    nnrm = len(nrm)
    has_normals = nnrm > 0
    P, N, ST, VC = [], [], [], []
    any_vc = False
    for fi, face in enumerate(faces):
        flag = int(face.get("used_entities_flag") or 0)
        tdata = [int(x) for x in (face.get("triangulateddata") or [])]
        start = int(face.get("start_triangulated") or 0)
        try:
            pi, ni = _face_tris(idx, start, flag, tdata, has_normals)
        except PRCError:
            if has_normals:
                try:
                    pi, ni = _face_tris(idx, start, flag, tdata, False)
                except PRCError:
                    continue
            else:
                continue
        if not len(pi):
            continue
        ntri = len(pi) // 3
        la = [int(x) for x in (face.get("line_attributes") or [])]
        if len(la) == ntri and ntri > 1:
            st = np.asarray(la, np.int32)
        else:
            st = np.full(ntri, la[0] if la else -1, np.int32)
        vc = None
        vcd = face.get("vertex_color_data")
        if face.get("has_vertex_colors") and isinstance(vcd, dict) and not vcd.get("b_optimized"):
            cols = _vertex_colors(vcd)
            if cols is not None and len(cols) == ntri * 3 and not (flag & 0xCCCC):
                vc = cols
        if vc is not None:
            any_vc = True
        P.append(pi)
        N.append(ni)
        ST.append(st)
        VC.append(vc)
    if not P:
        return None
    pi = np.concatenate(P)
    ni = np.concatenate(N)
    st = np.concatenate(ST)
    vcol = None
    if any_vc:
        vcol = np.concatenate([v if v is not None else np.full((len(p), 4), -1.0, np.float32)
                               for v, p in zip(VC, P)])
    ok = (pi >= 0) & (pi + 2 < ncoord)
    tri_ok = ok.reshape(-1, 3).all(axis=1)
    pi = pi.reshape(-1, 3)[tri_ok].reshape(-1)
    ni = ni.reshape(-1, 3)[tri_ok].reshape(-1)
    st = st[tri_ok]
    if vcol is not None:
        vcol = vcol.reshape(-1, 3, 4)[tri_ok].reshape(-1, 4)
    tri = np.stack([coords[pi], coords[pi + 1], coords[pi + 2]], axis=1).astype(np.float32)
    nrmv = None
    if has_normals and len(ni) and (ni >= 0).all() and (ni + 2 < nnrm).all():
        nrmv = np.stack([nrm[ni], nrm[ni + 1], nrm[ni + 2]], axis=1)
        l = np.linalg.norm(nrmv, axis=1)
        bad = l < 1e-12
        l[bad] = 1.0
        nrmv = (nrmv / l[:, None]).astype(np.float32)
        if bad.mean() > 0.5:
            nrmv = None
    return {"tri": tri, "nrm": nrmv, "style": st, "vcol": vcol}


def _vertex_colors(vcd):
    rgba = bool(vcd.get("is_rgba"))
    if rgba:
        first = vcd.get("color_data_rgba_first_vertex")
        rest = vcd.get("color_data_rgba_remaining_vertices") or []
    else:
        first = vcd.get("color_data_rgb_first_vertex")
        rest = vcd.get("color_data_rgb_remaining_vertices") or []
    if not isinstance(first, dict):
        return None
    cur = list(first.get("color") or [])
    if len(cur) < 3:
        return None
    out = [cur]
    for r in rest:
        if not r.get("is_same"):
            c = r.get("color")
            if isinstance(c, dict):
                cur = list(c.get("color") or cur)
        out.append(cur)
    a = np.asarray(out, np.float32) / 255.0
    if a.shape[1] == 3:
        a = np.c_[a, np.ones(len(a), np.float32)]
    return a[:, :4]


def _face_tris(idx, start, flag, tdata, has_normals):
    if flag & (0x0001 | 0x0010 | 0x0100 | 0x1000):
        raise PRCError("polyface")
    L = len(idx)
    c = start
    i = 0
    P = []
    N = []

    def take(k):
        nonlocal c
        if c + k > L:
            raise PRCError("index overflow")
        v = idx[c:c + k]
        c += k
        return v

    for fl, kind, one, tex in TESS_KINDS:
        if not flag & fl:
            continue
        per = (1 if has_normals and not one else 0) + (1 if tex else 0) + 1
        if kind == "tri":
            if i >= len(tdata):
                raise PRCError("tdata")
            nt = tdata[i]
            i += 1
            if one:
                blk = (1 if has_normals else 0) + 3 * ((1 if tex else 0) + 1)
                a = take(nt * blk).reshape(nt, blk) if nt else np.zeros((0, blk), np.int64)
                pcol = blk - 1
                pts = a[:, [blk - 1 - 2 * ((1 if tex else 0) + 1) + (0 if not tex else 0),
                            blk - 1 - ((1 if tex else 0) + 1), blk - 1]]
                nn = np.repeat(a[:, 0:1], 3, axis=1) if has_normals else np.zeros_like(pts) - 1
                P.append(pts.reshape(-1))
                N.append(nn.reshape(-1))
            else:
                a = take(nt * 3 * per).reshape(nt * 3, per) if nt else np.zeros((0, per), np.int64)
                P.append(a[:, per - 1])
                N.append(a[:, 0] if has_normals else np.full(len(a), -1))
        else:
            if i >= len(tdata):
                raise PRCError("tdata")
            ns = tdata[i]
            i += 1
            for _ in range(ns):
                if i >= len(tdata):
                    raise PRCError("tdata")
                cnt = tdata[i]
                i += 1
                single = bool(cnt & NORMAL_SINGLE) or one
                nv = cnt & ~NORMAL_SINGLE
                if nv < 3:
                    # still consume
                    if single:
                        take((1 if has_normals else 0) + nv * ((1 if tex else 0) + 1))
                    else:
                        take(nv * per)
                    continue
                if single:
                    n0 = take(1)[0] if has_normals else -1
                    k = (1 if tex else 0) + 1
                    a = take(nv * k).reshape(nv, k)
                    pv = a[:, k - 1]
                    nv_idx = np.full(nv, n0)
                else:
                    a = take(nv * per).reshape(nv, per)
                    pv = a[:, per - 1]
                    nv_idx = a[:, 0] if has_normals else np.full(nv, -1)
                if kind == "fan":
                    j = np.arange(1, nv - 1)
                    tri = np.stack([np.zeros_like(j), j, j + 1], axis=1)
                else:
                    j = np.arange(nv - 2)
                    tri = np.stack([j, j + 1, j + 2], axis=1)
                    odd = (j % 2) == 1
                    tri[odd] = tri[odd][:, [1, 0, 2]]
                P.append(pv[tri].reshape(-1))
                N.append(nv_idx[tri].reshape(-1))
    if not P:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    return np.concatenate(P).astype(np.int64), np.concatenate(N).astype(np.int64)


def wire_segments(w):
    coords = np.asarray((w.get("tessellation_coordinates") or {}).get("coordinates") or [], np.float64)
    idx = [int(x) for x in (w.get("wire_indexes") or [])]
    segs = []
    i = 0
    n = len(coords)
    while i < len(idx):
        k = idx[i] & 0x0FFFFFFF
        closing = bool(idx[i] & 0x20000000)
        pts = idx[i + 1:i + 1 + k]
        i += k + 1
        pts = [p for p in pts if 0 <= p and p + 2 < n]
        for a, b in zip(pts[:-1], pts[1:]):
            segs.append((a, b))
        if closing and len(pts) > 2:
            segs.append((pts[-1], pts[0]))
    if not segs:
        return None
    s = np.asarray(segs, np.int64).reshape(-1)
    return np.stack([coords[s], coords[s + 1], coords[s + 2]], axis=1).astype(np.float32)


# ----------------------------------------------------------- to model
def to_model(pf: PRCFile):
    from .scene3d import Model, Part, TreeNode, transform_points, transform_normals, DEFAULT_COLOR
    model = Model()
    model.source = "PRC"
    model.warnings = list(pf.warnings)
    by_uid = {fs["uid"]: k for k, fs in enumerate(pf.structures)}
    units = None
    roots = []
    if pf.model is not None:
        try:
            units = float(pf.model.get("units_in_mm") or 0) or None
        except (TypeError, ValueError):
            units = None
        for ref in pf.model.get("product_occurrences") or []:
            u = ref.get("unique_id") or {}
            uid = (int(u.get("unique_id0") or 0), int(u.get("unique_id1") or 0), int(u.get("unique_id2") or 0),
                   int(u.get("unique_id3") or 0))
            k = by_uid.get(uid)
            if k is not None:
                roots.append((k, int(ref.get("root_index") or 0)))
    if not roots:
        # fall back to every occurrence that is not a child of another one
        for k, fs in enumerate(pf.structures):
            tree = fs.get("tree") or {}
            prods = tree.get("products") or []
            child = set()
            for p in prods:
                ro = p.get("references_product_occurrence") or {}
                child.update(int(x) for x in ro.get("index_child_occurrence") or [])
            for i in range(len(prods)):
                if i not in child:
                    roots.append((k, i))
    model.units = units
    styles = {k: _Styles(fs.get("globals")) for k, fs in enumerate(pf.structures)}
    tess_cache = {}
    counter = [0]
    limit = [0]

    def get_tess(k, ti):
        key = (k, ti)
        if key in tess_cache:
            return tess_cache[key]
        fs = pf.structures[k]
        lst = ((fs.get("tess") or {}).get("tess")) or []
        val = None
        if 0 <= ti < len(lst) and lst[ti] is not None:
            t = lst[ti]
            if t.get("_t") == "PRC_TYPE_TESS_3D":
                val = ("tri", tess_triangles(t))
            elif t.get("_t") == "PRC_TYPE_TESS_3D_Wire":
                val = ("wire", wire_segments(t))
        tess_cache[key] = val
        return val

    def add_item(k, ri, W, style, node, depth, force=False):
        if depth > 64:
            return
        t = ri.get("_t")
        if t == "PRC_TYPE_RI_RepresentationItem":
            ri = ri.get("data") or {}
            t = ri.get("_t")
        st, show, removed, frc = _graphics(ri)
        if removed:
            return
        if st is None or (force and style is not None):
            st = style
        else:
            force = force or frc
        ic = ri.get("item_content") or {}
        Wl = W
        lcs = int(ic.get("biased_index_local_coordinate_system") or 0) - 1
        if lcs >= 0 and lcs < len(styles[k].ref_coords):
            cs = styles[k].ref_coords[lcs]
            Wl = W @ _transform3d(cs.get("transform"))
        if t == "PRC_TYPE_RI_Set":
            nm = _name(ri) or "Set"
            sub = node.add(TreeNode(nm, "group"))
            for it in ri.get("representation_items") or []:
                add_item(k, it, Wl, st, sub, depth + 1, force)
            return
        ti = int(ic.get("biased_index_tessellation") or 0) - 1
        if ti < 0:
            if t in ("PRC_TYPE_RI_BrepModel", "PRC_TYPE_RI_Curve"):
                model.warnings.append("exact B-rep geometry without tessellation is not displayed")
            elif t == "PRC_TYPE_RI_PointSet" and ri.get("points"):
                pts = np.array([[float(p["x"]), float(p["y"]), float(p["z"])] for p in ri["points"]], np.float32)
                part = Part(_name(ri) or "Points")
                part.points = transform_points(Wl, pts)
                c = styles[k].color(st)
                if c:
                    part.point_color = c[:3] + (1.0,)
                part.finish()
                model.parts.append(part)
                node.parts.append(part)
            return
        tv = get_tess(k, ti)
        if tv is None or tv[1] is None:
            return
        counter[0] += 1
        part = Part(_name(ri) or node.name or ("Part %d" % counter[0]))
        part.visible = show
        if tv[0] == "tri":
            T = tv[1]
            tri, nrm = T["tri"], T["nrm"]
            part.tri = transform_points(Wl, tri.reshape(-1, 3))
            if nrm is not None:
                part.nrm = transform_normals(Wl, nrm.reshape(-1, 3))
            if np.linalg.det(Wl[:3, :3]) < 0:
                tt = part.tri.reshape(-1, 3, 3)
                tt[:, [1, 2]] = tt[:, [2, 1]]
                if part.nrm is not None:
                    nn = part.nrm.reshape(-1, 3, 3)
                    nn[:, [1, 2]] = nn[:, [2, 1]]
            base = styles[k].color(st) or DEFAULT_COLOR
            sts = T["style"] if not force else np.full(len(T["style"]), -1, np.int32)
            uniq = np.unique(sts)
            lut = {}
            for u in uniq:
                c = styles[k].color(int(u)) if u >= 0 else None
                lut[int(u)] = c
            face_cols = [c for c in lut.values() if c is not None]
            if len(face_cols) == 1 and len(uniq) == 1:
                base = face_cols[0]
            col = None
            if len(uniq) > 1 and face_cols:
                L = np.array([(lut[int(u)] or base) for u in uniq], np.float32)
                pos = np.searchsorted(uniq, sts)
                col = np.repeat(L[pos], 3, axis=0)
                col[:, 3] = 1.0
            vc = T["vcol"]
            if vc is not None:
                if col is None:
                    col = np.tile(np.array([base[0], base[1], base[2], 1.0], np.float32), (len(vc), 1))
                m = vc[:, 0] >= 0
                col[m] = vc[m]
                col[:, 3] = 1.0
            part.col = col
            part.color = (base[0], base[1], base[2], 1.0)
            part.opacity = base[3]
        else:
            part.lines = transform_points(Wl, tv[1].reshape(-1, 3))
            c = styles[k].color(st)
            if c:
                part.line_color = c[:3] + (1.0,)
        part.finish()
        model.parts.append(part)
        node.parts.append(part)

    def occurrence(k, i, W, style, node, depth, seen, force=False):
        if depth > 48 or (k, i) in seen:
            return
        fs = pf.structures[k]
        prods = ((fs.get("tree") or {}).get("products")) or []
        if not (0 <= i < len(prods)):
            return
        po = prods[i]
        st, show, removed, frc = _graphics(po)
        if removed:
            return
        if st is None or (force and style is not None):
            st = style
        else:
            force = force or frc
        M = W
        if po.get("has_transformation") and po.get("location") is not None:
            M = W @ _transform3d(po["location"])
        nm = _name(po) or "Occurrence %d" % i
        child = node.add(TreeNode(nm, "group"))
        seen = seen | {(k, i)}
        ro = po.get("references_product_occurrence") or {}
        part_idx = int(ro.get("biased_index_part") or 0) - 1
        proto = int(ro.get("biased_index_prototype") or 0) - 1
        ext = int(ro.get("biased_index_external_data") or 0) - 1
        kids = [int(x) for x in ro.get("index_child_occurrence") or []]
        if part_idx >= 0:
            add_part(k, part_idx, M, st, child, depth, force)
        if proto >= 0:
            kp = _file_of(pf, by_uid, k, ro.get("prototype_in_same_file_structure"))
            if kp is not None:
                occurrence(kp, proto, M, st, child, depth + 1, seen, force)
        if ext >= 0:
            ke = _file_of(pf, by_uid, k, ro.get("external_data_in_same_file_structure"))
            if ke is not None:
                occurrence(ke, ext, M, st, child, depth + 1, seen, force)
        for c in kids:
            occurrence(k, c, M, st, child, depth + 1, seen, force)
        if not show:
            for p in child.all_parts():
                p.visible = False

    def add_part(k, pi, W, style, node, depth, force=False):
        fs = pf.structures[k]
        parts = ((fs.get("tree") or {}).get("parts")) or []
        if not (0 <= pi < len(parts)):
            return
        pd = parts[pi]
        st, show, removed, frc = _graphics(pd)
        if removed:
            return
        if st is None or (force and style is not None):
            st = style
        else:
            force = force or frc
        for ri in pd.get("representation_items") or []:
            add_item(k, ri, W, st, node, depth + 1, force)

    for k, i in roots:
        occurrence(k, i, np.eye(4), None, model.root, 0, frozenset())
    _collapse(model.root)
    if not model.parts and any("compressed" in w for w in model.warnings):
        model.warnings.insert(0, "This PRC file uses Adobe's highly compressed tessellation, which cannot be shown yet. "
                                 "Ask for the 3D PDF to be exported with U3D or with uncompressed PRC tessellation.")
    elif not model.parts:
        brep = False
        for fs in pf.structures:
            for pd in ((fs.get("tree") or {}).get("parts")) or []:
                for ri in pd.get("representation_items") or []:
                    t = ri.get("_t")
                    if t == "PRC_TYPE_RI_RepresentationItem":
                        t = (ri.get("data") or {}).get("_t")
                    if t in ("PRC_TYPE_RI_BrepModel", "PRC_TYPE_RI_Curve"):
                        brep = True
        if brep:
            model.warnings.insert(0, "This PRC file contains exact B-rep (NURBS) geometry without a tessellation, which "
                                     "cannot be shown yet. Ask for the 3D PDF to be exported with tessellated geometry "
                                     "(U3D or PRC tessellation).")
    model.warnings = list(dict.fromkeys(model.warnings))
    return model


def _file_of(pf, by_uid, k, fid):
    if fid is None or fid.get("flag"):
        return k
    u = fid.get("unique_id") or {}
    uid = (int(u.get("unique_id0") or 0), int(u.get("unique_id1") or 0), int(u.get("unique_id2") or 0),
           int(u.get("unique_id3") or 0))
    return by_uid.get(uid, k)


def _collapse(node):
    """Drop empty groups and fold single-child chains for a compact tree."""
    for c in list(node.children):
        _collapse(c)
    node.children = [c for c in node.children if c.children or c.parts]
    for c in node.children:
        if len(c.children) == 1 and not c.parts:
            g = c.children[0]
            if not g.parts or True:
                c.children = g.children
                c.parts = g.parts
                for cc in c.children:
                    cc.parent = c
                for p in c.parts:
                    pass
