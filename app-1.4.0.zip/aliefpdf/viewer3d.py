# -*- coding: utf-8 -*-
"""
3D review window of ALIEF PDF EDITOR PRO.

Opens the 3D models embedded in PDF pages (U3D from ALIEF PDF PRO and
other tools, PRC from Acrobat / CAD exporters) or standalone .u3d / .prc
files and offers the review tools: views, projection, render modes,
lighting, background, model tree (show / hide / isolate / transparency),
section plane, measurements (distance, angle, radius, face angle, point),
3D comments stored in the PDF (Markup3D, restore the commented view),
snapshots (clipboard, image file, poster of the 3D annotation) and export
of the visible geometry to STL / OBJ.
"""
from __future__ import annotations

import math
import os
import struct
import threading

import numpy as np
from PySide6.QtCore import Qt, QSize, QTimer, Signal, QObject, QBuffer, QIODevice, QByteArray
from PySide6.QtGui import QAction, QActionGroup, QColor, QKeySequence, QGuiApplication, QImage
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QToolBar, QComboBox, QLabel,
                               QDockWidget, QTreeWidget, QTreeWidgetItem, QListWidget, QListWidgetItem, QSlider,
                               QCheckBox, QPushButton, QFileDialog, QMessageBox, QInputDialog, QColorDialog, QMenu,
                               QToolButton, QStatusBar, QProgressBar, QFormLayout, QGroupBox, QDoubleSpinBox,
                               QApplication, QSizePolicy, QStackedWidget, QTextEdit, QDialog, QDialogButtonBox,
                               QPlainTextEdit)

from . import APP_NAME, theme
from .scene3d import Camera
from .viewer3d_gl import GLView, MODES, LIGHT_SCHEMES, STD_VIEWS

MODE_LABELS = {
    "Solid": "Solid", "SolidOutline": "Solid with edges", "SolidWireframe": "Solid with wireframe",
    "ShadedIllustration": "Shaded illustration", "Illustration": "Illustration (line drawing)",
    "Transparent": "Transparent", "TransparentWireframe": "Transparent wireframe", "Wireframe": "Wireframe",
    "HiddenWireframe": "Hidden-line wireframe", "ShadedVertices": "Shaded vertices", "Vertices": "Vertices",
    "BoundingBox": "Bounding boxes"}
PDF_MODE_MAP = {"SolidWireframe": "SolidWireframe", "ShadedWireframe": "SolidWireframe",
                "TransparentBoundingBox": "BoundingBox", "TransparentBoundingBoxOutline": "BoundingBox",
                "SolidOutline": "SolidOutline"}
UNITS = [("", 1.0), ("mm", 1.0), ("cm", 1.0), ("m", 1.0), ("in", 1.0), ("ft", 1.0)]
BACKGROUNDS = [("White", (1.0, 1.0, 1.0)), ("Light grey", (0.86, 0.88, 0.91)), ("Blue grey", (0.37, 0.42, 0.47)),
               ("Dark", (0.13, 0.14, 0.16)), ("Black", (0.0, 0.0, 0.0))]


class _Loader(QObject):
    done = Signal(object, object)

    def run(self, fn):
        def work():
            try:
                res = fn()
                self.done.emit(res, None)
            except Exception as e:  # pragma: no cover - reported to the user
                import traceback
                self.done.emit(None, "%s\n\n%s" % (e, traceback.format_exc(limit=4)))
        threading.Thread(target=work, daemon=True).start()


class Viewer3DWindow(QMainWindow):
    """Top-level 3D review window.

    pdfdoc: the PdfDoc the annotation belongs to (comments / posters are written to it);
    annot:  pdf3d.Annot3D or None (standalone file)."""

    comments_changed = Signal()

    def __init__(self, parent=None, annot=None, path=None, pdfdoc=None, title=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.annot = annot
        self.path = path
        self.pdfdoc = pdfdoc
        self.model = None
        self.views = []
        self._comments = []
        self._ready = False
        self.setWindowTitle("%s – 3D Review – %s" % (APP_NAME, title or (annot.label if annot else os.path.basename(path or ""))))
        self.setWindowIcon(theme.icon("cube-outline", accent=theme.ICON_ACCENT["measure"]))
        self.resize(1280, 820)
        self.gl = GLView(self)
        self.gl.setContextMenuPolicy(Qt.CustomContextMenu)
        self.gl.customContextMenuRequested.connect(self._context_menu)
        self.gl.picked.connect(self._on_pick)
        self.gl.measured.connect(self._on_measured)
        self.gl.point_picked.connect(self._on_point_picked)
        self.gl.status.connect(lambda s: self.statusBar().showMessage(s, 6000))
        self.gl.gl_failed.connect(self._gl_failed)
        self.stack = QStackedWidget()
        self.msg = QLabel("Loading 3D model…")
        self.msg.setAlignment(Qt.AlignCenter)
        self.msg.setWordWrap(True)
        self.msg.setStyleSheet("font-size:14px; color:#24476F; padding:30px;")
        self.stack.addWidget(self.msg)
        self.stack.addWidget(self.gl)
        self.setCentralWidget(self.stack)
        self._build_toolbars()
        self._build_docks()
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.info = QLabel("")
        sb.addPermanentWidget(self.info)
        self.prog = QProgressBar()
        self.prog.setRange(0, 0)
        self.prog.setMaximumWidth(160)
        sb.addPermanentWidget(self.prog)
        self._loader = _Loader()
        self._loader.done.connect(self._loaded)
        QTimer.singleShot(30, self._start_load)

    # ------------------------------------------------------------ loading
    def _start_load(self):
        from . import scene3d
        if self.annot is not None:
            a = self.annot
            self._loader.run(lambda: scene3d.load_annotation(a))
        elif self.path:
            p = self.path
            self._loader.run(lambda: scene3d.load_file(p))

    def _loaded(self, model, err):
        self.prog.hide()
        if model is None:
            self.msg.setText("The 3D model could not be opened.\n\n%s" % (err or ""))
            self.msg.setTextInteractionFlags(Qt.TextSelectableByMouse)
            return
        if not model.parts:
            txt = "This 3D model contains no displayable geometry."
            if model.warnings:
                txt += "\n\n" + "\n".join(model.warnings[:6])
            self.msg.setText(txt)
            return
        self.model = model
        self.stack.setCurrentWidget(self.gl)
        up = self._guess_up(model)
        self.gl.up = up
        self.up_combo.blockSignals(True)
        self.up_combo.setCurrentIndex(1 if up[1] > 0.5 else 0)
        self.up_combo.blockSignals(False)
        unit, scale = self._model_units(model)
        if unit:
            self._set_unit_text(unit)
        if scale and abs(scale - 1.0) > 1e-12:
            self.scale_spin.setValue(scale)
        self.gl.set_model(model)
        self._fill_tree()
        self._fill_views()
        dv = model.default_view if model.views else None
        if dv is not None and dv < len(model.views):
            self._apply_view(model.views[dv])
        else:
            self.gl.set_std_view("Isometric")
        self._load_comments()
        self._update_info()
        self._ready = True
        if model.warnings:
            self.statusBar().showMessage("Note: " + "; ".join(model.warnings[:3]), 15000)

    def _model_units(self, model):
        """(unit text, scale) for measurements: the PDF /3DU dictionary wins,
        then the PRC file's unit (units_in_mm)."""
        u = self.annot.units if self.annot is not None else None
        if u:
            for key, sk in (("DU", "DSm"), ("UU", "USm"), ("TU", "TSm")):
                if u.get(key):
                    try:
                        s = float(u.get(sk) or 1.0)
                    except (TypeError, ValueError):
                        s = 1.0
                    return u[key], (s if s > 0 else 1.0)
        if model.source == "PRC" and model.units:
            mm = float(model.units)
            for name, f in (("mm", 1.0), ("cm", 10.0), ("m", 1000.0), ("in", 25.4), ("ft", 304.8)):
                if abs(mm - f) < 1e-9 * f:
                    return name, 1.0
            return "mm", mm
        return None, 1.0

    def _guess_up(self, model):
        # ALIEF PDF PRO and most CAD tools are Z-up; U3D samples from 3ds max as well.
        return np.array([0.0, 0.0, 1.0])

    def _gl_failed(self, msg):
        self.msg.setText("OpenGL 2.1 is not available on this computer, the 3D view cannot be shown.\n\n%s\n\n"
                         "Update the graphics driver, or start the program with the environment variable "
                         "QT_OPENGL=software to use the software renderer." % msg)
        self.stack.setCurrentWidget(self.msg)

    # ------------------------------------------------------------- toolbars
    def _act(self, text, icon, slot, tip=None, checkable=False, shortcut=None, accent=None):
        a = QAction(theme.icon(icon, accent=accent), text, self)
        a.setToolTip(tip or text.replace("\n", " "))
        if checkable:
            a.setCheckable(True)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        a.triggered.connect(slot)
        return a

    def _build_toolbars(self):
        tb = QToolBar("View")
        tb.setIconSize(QSize(22, 22))
        tb.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        tb.setMovable(False)
        self.addToolBar(tb)
        tb.addAction(self._act("Fit", "fit-to-screen-outline", lambda: self.gl.fit(), "Fit the visible model (F)", shortcut="F"))
        self.home_act = self._act("Default\nview", "home-outline", self._home, "Return to the default view (Home)", shortcut="Home")
        tb.addAction(self.home_act)
        vb = QToolButton()
        vb.setText("Views")
        vb.setIcon(theme.icon("cube-scan"))
        vb.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        vb.setPopupMode(QToolButton.InstantPopup)
        self.views_menu = QMenu(vb)
        vb.setMenu(self.views_menu)
        tb.addWidget(vb)
        self._rebuild_views_menu()
        self.persp_act = self._act("Perspective", "perspective-more", self._toggle_proj, "Perspective / orthographic projection",
                                   checkable=True)
        self.persp_act.setChecked(True)
        tb.addAction(self.persp_act)
        tb.addSeparator()
        w = QWidget()
        lay = QFormLayout(w)
        lay.setContentsMargins(4, 0, 4, 0)
        lay.setVerticalSpacing(2)
        self.mode_combo = QComboBox()
        for m in MODES:
            self.mode_combo.addItem(MODE_LABELS[m], m)
        self.mode_combo.currentIndexChanged.connect(lambda i: self._set_mode(self.mode_combo.itemData(i)))
        self.light_combo = QComboBox()
        for name in ["CAD", "Headlamp", "Artwork", "White", "Day", "Night", "Hard", "Primary", "Blue", "Red", "Cube", "None"]:
            self.light_combo.addItem({"Artwork": "From file (artwork)", "None": "No lights"}.get(name, name), name)
        self.light_combo.currentIndexChanged.connect(lambda i: self._set_light(self.light_combo.itemData(i)))
        lay.addRow("Render", self.mode_combo)
        lay.addRow("Lighting", self.light_combo)
        tb.addWidget(w)
        bgb = QToolButton()
        bgb.setText("Background")
        bgb.setIcon(theme.icon("format-color-fill"))
        bgb.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        bgb.setPopupMode(QToolButton.InstantPopup)
        m = QMenu(bgb)
        for name, c in BACKGROUNDS:
            m.addAction(theme.color_icon(c), name, lambda c=c: self._set_bg(c))
        m.addAction("Custom colour…", self._custom_bg)
        bgb.setMenu(m)
        tb.addWidget(bgb)
        tb.addSeparator()
        # selection / visibility
        tb.addAction(self._act("Hide", "eye-off-outline", self._hide_sel, "Hide the selected parts"))
        tb.addAction(self._act("Isolate", "eye-circle-outline", self._isolate_sel, "Show only the selected parts"))
        tb.addAction(self._act("Show\nall", "eye-outline", self._show_all, "Show all parts"))
        self.ghost_act = self._act("Ghost\nothers", "cube-unfolded", self._toggle_ghost,
                                   "Make the unselected parts transparent", checkable=True)
        tb.addAction(self.ghost_act)
        tb.addSeparator()
        self.sec_act = self._act("Section", "box-cutter", self._toggle_section, "Cross section plane", checkable=True,
                                 accent=theme.ICON_ACCENT["edit"])
        tb.addAction(self.sec_act)
        # measuring
        self.measure_group = QActionGroup(self)
        self.measure_group.setExclusive(False)
        self.m_acts = {}
        for key, text, icon, tip in (("distance", "Distance", "ruler", "Point to point distance (vertex / edge snap)"),
                                     ("angle", "Angle", "angle-acute", "Angle defined by three points"),
                                     ("faceangle", "Face\nangle", "angle-obtuse", "Angle between two faces"),
                                     ("radius", "Radius", "circle-outline", "Radius / diameter from three points on an arc"),
                                     ("point", "Point", "crosshairs-gps", "Coordinates of a point")):
            a = self._act(text, icon, lambda c=False, k=key: self._set_measure(k), tip, checkable=True,
                          accent=theme.ICON_ACCENT["measure"])
            self.m_acts[key] = a
            tb.addAction(a)
        tb.addAction(self._act("Clear\nmeasures", "eraser", self._clear_measures, "Remove all measurements"))
        tb.addSeparator()
        self.comment_act = self._act("Add 3D\ncomment", "comment-plus-outline", self._start_comment,
                                     "Click a point on the model to attach a comment (saved in the PDF with the view)",
                                     checkable=True, accent=theme.ICON_ACCENT["comment"])
        tb.addAction(self.comment_act)
        snap = QToolButton()
        snap.setText("Snapshot")
        snap.setIcon(theme.icon("camera-outline"))
        snap.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        snap.setPopupMode(QToolButton.InstantPopup)
        sm = QMenu(snap)
        sm.addAction(theme.icon("content-copy"), "Copy view to clipboard", self._snap_copy, QKeySequence("Ctrl+C"))
        sm.addAction(theme.icon("content-save-outline"), "Save view as image…", self._snap_save)
        self.poster_act = sm.addAction(theme.icon("image-outline"), "Use current view as poster of the 3D annotation",
                                       self._snap_poster)
        self.page_img_act = sm.addAction(theme.icon("image-plus"), "Insert view as image on a new PDF page", self._snap_page)
        snap.setMenu(sm)
        tb.addWidget(snap)
        exp = QToolButton()
        exp.setText("Export")
        exp.setIcon(theme.icon("export"))
        exp.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        exp.setPopupMode(QToolButton.InstantPopup)
        em = QMenu(exp)
        em.addAction("Visible parts as STL…", lambda: self._export("stl"))
        em.addAction("Visible parts as OBJ…", lambda: self._export("obj"))
        em.addAction("Embedded 3D stream (U3D / PRC)…", self._export_stream)
        em.addAction("Measurements to CSV…", self._export_measures)
        exp.setMenu(em)
        tb.addWidget(exp)
        # second toolbar row: section and units
        self.addToolBarBreak()
        tb2 = QToolBar("Options")
        tb2.setMovable(False)
        self.addToolBar(tb2)
        tb2.addWidget(QLabel(" Up axis "))
        self.up_combo = QComboBox()
        self.up_combo.addItems(["Z up", "Y up"])
        self.up_combo.currentIndexChanged.connect(self._set_up)
        tb2.addWidget(self.up_combo)
        tb2.addWidget(QLabel("  Rotation "))
        self.rot_combo = QComboBox()
        self.rot_combo.addItems(["Turntable", "Free"])
        self.rot_combo.currentIndexChanged.connect(lambda i: setattr(self.gl, "_turntable", i == 0))
        tb2.addWidget(self.rot_combo)
        tb2.addWidget(QLabel("  Units "))
        self.unit_combo = QComboBox()
        self.unit_combo.setEditable(True)
        self.unit_combo.addItems(["(model units)", "mm", "cm", "m", "in", "ft"])
        self.unit_combo.currentTextChanged.connect(self._unit_changed)
        tb2.addWidget(self.unit_combo)
        tb2.addWidget(QLabel("  Scale ×"))
        self.scale_spin = QDoubleSpinBox()
        self.scale_spin.setDecimals(6)
        self.scale_spin.setRange(1e-6, 1e6)
        self.scale_spin.setValue(1.0)
        self.scale_spin.setToolTip("Multiply model coordinates by this factor for the measurements")
        self.scale_spin.valueChanged.connect(lambda v: (setattr(self.gl, "unit_scale", v), self.gl.update(),
                                                        self._refresh_measure_list()))
        tb2.addWidget(self.scale_spin)
        self.snap_chk = QCheckBox("Snap to vertices / edges")
        self.snap_chk.setChecked(True)
        self.snap_chk.toggled.connect(lambda v: setattr(self.gl, "snap", v))
        tb2.addWidget(self.snap_chk)
        self.axes_chk = QCheckBox("Axes")
        self.axes_chk.setChecked(True)
        self.axes_chk.toggled.connect(lambda v: (setattr(self.gl, "show_axes", v), self.gl.update()))
        tb2.addWidget(self.axes_chk)
        tb2.addWidget(QLabel("  Edge angle "))
        self.crease_spin = QDoubleSpinBox()
        self.crease_spin.setRange(1, 89)
        self.crease_spin.setValue(30)
        self.crease_spin.setSuffix("°")
        self.crease_spin.setToolTip("Edges sharper than this angle are drawn in the outline / illustration modes")
        self.crease_spin.valueChanged.connect(self._crease_changed)
        tb2.addWidget(self.crease_spin)

    def _build_docks(self):
        # model tree
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Model tree"])
        self.tree.itemChanged.connect(self._tree_changed)
        self.tree.itemSelectionChanged.connect(self._tree_selected)
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._tree_menu)
        self.tree.itemDoubleClicked.connect(lambda it, c: self._zoom_item(it))
        d = QDockWidget("Model tree", self)
        d.setObjectName("dock_tree")
        d.setWidget(self.tree)
        self.addDockWidget(Qt.LeftDockWidgetArea, d)
        # views
        self.view_list = QListWidget()
        self.view_list.itemActivated.connect(self._view_activated)
        self.view_list.itemClicked.connect(self._view_activated)
        vw = QWidget()
        vl = QVBoxLayout(vw)
        vl.setContentsMargins(2, 2, 2, 2)
        vl.addWidget(self.view_list)
        bb = QHBoxLayout()
        b = QPushButton(theme.icon("plus"), "Save current view")
        b.clicked.connect(self._save_view)
        bb.addWidget(b)
        vl.addLayout(bb)
        d2 = QDockWidget("Views", self)
        d2.setObjectName("dock_views")
        d2.setWidget(vw)
        self.addDockWidget(Qt.LeftDockWidgetArea, d2)
        # section
        self.sec_box = QGroupBox("Cross section")
        sl = QFormLayout(self.sec_box)
        self.sec_axis = QComboBox()
        self.sec_axis.addItems(["X", "Y", "Z", "View direction", "Selected face"])
        self.sec_axis.currentIndexChanged.connect(self._sec_axis_changed)
        sl.addRow("Plane normal", self.sec_axis)
        self.sec_slider = QSlider(Qt.Horizontal)
        self.sec_slider.setRange(0, 1000)
        self.sec_slider.setValue(500)
        self.sec_slider.valueChanged.connect(self._sec_update)
        sl.addRow("Position", self.sec_slider)
        self.sec_pos = QLabel("")
        sl.addRow("", self.sec_pos)
        self.sec_flip = QCheckBox("Flip side")
        self.sec_flip.toggled.connect(self._sec_update)
        self.sec_plane = QCheckBox("Show plane")
        self.sec_plane.toggled.connect(self._sec_update)
        self.sec_outline = QCheckBox("Section outline")
        self.sec_outline.setChecked(True)
        self.sec_outline.toggled.connect(self._sec_update)
        row = QHBoxLayout()
        row.addWidget(self.sec_flip)
        row.addWidget(self.sec_plane)
        row.addWidget(self.sec_outline)
        sl.addRow(row)
        cb = QPushButton("Cap colour…")
        cb.clicked.connect(self._cap_color)
        sl.addRow(cb)
        self.sec_info = QLabel("")
        self.sec_info.setWordWrap(True)
        sl.addRow(self.sec_info)
        self.sec_box.setEnabled(False)
        # measurements
        self.mlist = QListWidget()
        self.mlist.setContextMenuPolicy(Qt.CustomContextMenu)
        self.mlist.customContextMenuRequested.connect(self._mlist_menu)
        tools = QWidget()
        tl = QVBoxLayout(tools)
        tl.setContentsMargins(2, 2, 2, 2)
        tl.addWidget(self.sec_box)
        tl.addWidget(QLabel("<b>Measurements</b>"))
        tl.addWidget(self.mlist, 1)
        self.part_info = QLabel("")
        self.part_info.setWordWrap(True)
        self.part_info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        tl.addWidget(QLabel("<b>Selection</b>"))
        tl.addWidget(self.part_info)
        d3 = QDockWidget("Tools", self)
        d3.setObjectName("dock_tools")
        d3.setWidget(tools)
        self.addDockWidget(Qt.RightDockWidgetArea, d3)
        # comments
        self.clist = QListWidget()
        self.clist.itemClicked.connect(self._comment_clicked)
        self.clist.setContextMenuPolicy(Qt.CustomContextMenu)
        self.clist.customContextMenuRequested.connect(self._comment_menu)
        cw = QWidget()
        cl = QVBoxLayout(cw)
        cl.setContentsMargins(2, 2, 2, 2)
        cl.addWidget(self.clist)
        b2 = QPushButton(theme.icon("comment-plus-outline", accent=theme.ICON_ACCENT["comment"]), "Add 3D comment")
        b2.clicked.connect(lambda: (self.comment_act.setChecked(True), self._start_comment()))
        cl.addWidget(b2)
        d4 = QDockWidget("3D comments", self)
        d4.setObjectName("dock_comments")
        d4.setWidget(cw)
        self.addDockWidget(Qt.RightDockWidgetArea, d4)
        if self.annot is None:
            d4.hide()

    # --------------------------------------------------------------- views
    def _rebuild_views_menu(self):
        m = self.views_menu
        m.clear()
        for name in STD_VIEWS:
            m.addAction(name, lambda n=name: self.gl.set_std_view(n))
        if self.views:
            m.addSeparator()
            for v in self.views:
                m.addAction(theme.icon("cube-outline"), v.name, lambda v=v: self._apply_view(v))

    def _fill_views(self):
        self.views = list(self.model.views)
        self.view_list.clear()
        for v in self.views:
            it = QListWidgetItem(theme.icon("cube-outline"), v.name)
            it.setData(Qt.UserRole, v)
            self.view_list.addItem(it)
        for name in STD_VIEWS:
            it = QListWidgetItem(theme.icon("axis-arrow"), name)
            it.setData(Qt.UserRole, name)
            self.view_list.addItem(it)
        self._rebuild_views_menu()

    def _view_activated(self, it):
        v = it.data(Qt.UserRole)
        if isinstance(v, str):
            self.gl.set_std_view(v)
        else:
            self._apply_view(v)

    def _apply_view(self, v):
        if v.camera is not None:
            cam = v.camera.copy()
            if cam.ortho and not cam.ortho_h:
                lo, hi = self.gl.bounds(False)
                cam.ortho_h = float(np.linalg.norm(hi - lo)) * 0.6
            self.gl.set_camera(cam)
            self.persp_act.setChecked(not cam.ortho)
        else:
            self.gl.fit()
        if v.bg:
            self._set_bg(v.bg)
        if v.render_mode:
            m = PDF_MODE_MAP.get(v.render_mode, v.render_mode)
            if m in MODES:
                self.mode_combo.setCurrentIndex(MODES.index(m))
        if v.lighting:
            i = self.light_combo.findData(v.lighting)
            if i >= 0:
                self.light_combo.setCurrentIndex(i)
        if v.nodes and self.model is not None:
            for p in self.model.parts:
                ent = v.nodes.get(p.name) or (v.nodes.get(p.node.name) if p.node is not None else None)
                if ent:
                    if "visible" in ent:
                        p.visible = ent["visible"]
                    if "opacity" in ent and ent["opacity"] is not None:
                        p.opacity = max(0.0, min(1.0, ent["opacity"]))
            self._sync_tree_checks()
        if v.sections:
            s = v.sections[0]
            self._enable_section(np.asarray(s["normal"], float), np.asarray(s["center"], float))
        self.gl.update()

    def _home(self):
        if self.model is None:
            return
        if self.model.views:
            self._apply_view(self.model.views[self.model.default_view])
        else:
            self.gl.set_std_view("Isometric")

    def _save_view(self):
        if self.model is None:
            return
        name, ok = QInputDialog.getText(self, "Save view", "View name:", text="View %d" % (len(self.views) + 1))
        if not ok or not name:
            return
        from .scene3d import View
        v = View(name)
        v.camera = self.gl.cam.copy()
        v.bg = self.gl.bg_top
        v.render_mode = self.gl.mode
        self.views.append(v)
        it = QListWidgetItem(theme.icon("cube-outline"), name)
        it.setData(Qt.UserRole, v)
        self.view_list.insertItem(len(self.views) - 1, it)
        self._rebuild_views_menu()

    def _toggle_proj(self, checked):
        cam = self.gl.cam
        if checked and cam.ortho:
            cam.ortho = False
            cam.dist = (cam.ortho_h or 1.0) / (2 * math.tan(math.radians(cam.fov) / 2))
        elif not checked and not cam.ortho:
            cam.ortho = True
            cam.ortho_h = 2 * cam.dist * math.tan(math.radians(cam.fov) / 2)
        self.gl.update()

    def _set_mode(self, m):
        self.gl.mode = m
        self.gl.update()

    def _set_light(self, name):
        self.gl.lighting = name
        self.gl.update()

    def _set_bg(self, c):
        self.gl.bg_top = tuple(c)
        dark = sum(c[:3]) / 3 < 0.45
        self.gl.edge_color = (0.85, 0.87, 0.9) if dark else (0.08, 0.09, 0.11)
        self.gl.update()

    def _custom_bg(self):
        c = QColorDialog.getColor(QColor.fromRgbF(*self.gl.bg_top), self, "Background colour")
        if c.isValid():
            self._set_bg((c.redF(), c.greenF(), c.blueF()))

    def _set_up(self, i):
        self.gl.up = np.array([0.0, 1.0, 0.0]) if i == 1 else np.array([0.0, 0.0, 1.0])
        self.gl.set_std_view("Isometric")

    def _crease_changed(self, v):
        self.gl.crease = float(v)
        self.gl.reset_edges()

    def _unit_changed(self, text):
        t = text.strip()
        self.gl.unit = "" if t.startswith("(") else t
        self.gl.update()
        self._refresh_measure_list()

    def _set_unit_text(self, u):
        i = self.unit_combo.findText(u)
        if i >= 0:
            self.unit_combo.setCurrentIndex(i)
        else:
            self.unit_combo.setEditText(u)

    # ---------------------------------------------------------------- tree
    def _fill_tree(self):
        self.tree.blockSignals(True)
        self.tree.clear()
        self._items = {}
        root = self.model.root

        def add(node, parent_item):
            for ch in node.children:
                it = QTreeWidgetItem([ch.name])
                it.setIcon(0, theme.icon("folder-outline" if ch.kind == "group" and ch.children else "cube-outline"))
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                it.setCheckState(0, Qt.Checked)
                it.setData(0, Qt.UserRole, ("node", ch))
                (parent_item.addChild(it) if parent_item is not None else self.tree.addTopLevelItem(it))
                add(ch, it)
                own = [p for p in ch.parts]
                if len(own) == 1 and own[0].name == ch.name:
                    it.setData(0, Qt.UserRole, ("part", own[0]))
                    self._items[id(own[0])] = it
                else:
                    for p in own:
                        self._part_item(p, it)
            for p in node.parts if node is root else []:
                self._part_item(p, parent_item)

        add(root, None)
        self.tree.expandToDepth(1)
        self.tree.blockSignals(False)
        self._sync_tree_checks()

    def _part_item(self, p, parent_item):
        it = QTreeWidgetItem([p.name])
        it.setIcon(0, theme.color_icon(p.color[:3]) if p.col is None else theme.icon("palette-outline"))
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(0, Qt.Checked if p.visible else Qt.Unchecked)
        it.setData(0, Qt.UserRole, ("part", p))
        if parent_item is None:
            self.tree.addTopLevelItem(it)
        else:
            parent_item.addChild(it)
        self._items[id(p)] = it
        return it

    def _item_parts(self, it):
        kind, obj = it.data(0, Qt.UserRole)
        if kind == "part":
            out = [obj]
            for k in range(it.childCount()):
                out.extend(self._item_parts(it.child(k)))
            return out
        return obj.all_parts()

    def _tree_changed(self, it, col):
        vis = it.checkState(0) == Qt.Checked
        for p in self._item_parts(it):
            p.visible = vis
        self.tree.blockSignals(True)
        self._set_children_check(it, vis)
        self.tree.blockSignals(False)
        self.gl._sec_lines = None
        self.gl.update()
        self._update_info()

    def _set_children_check(self, it, vis):
        for k in range(it.childCount()):
            ch = it.child(k)
            ch.setCheckState(0, Qt.Checked if vis else Qt.Unchecked)
            self._set_children_check(ch, vis)

    def _sync_tree_checks(self):
        self.tree.blockSignals(True)

        def walk(it):
            kind, obj = it.data(0, Qt.UserRole)
            parts = self._item_parts(it)
            vis = any(p.visible for p in parts) if parts else True
            it.setCheckState(0, Qt.Checked if vis else Qt.Unchecked)
            for k in range(it.childCount()):
                walk(it.child(k))

        for k in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(k))
        self.tree.blockSignals(False)

    def _tree_selected(self):
        if self.model is None:
            return
        sel = set()
        idx = {id(p): i for i, p in enumerate(self.model.parts)}
        for it in self.tree.selectedItems():
            for p in self._item_parts(it):
                if id(p) in idx:
                    sel.add(idx[id(p)])
        self.gl.selected = sel
        self.gl.update()
        self._show_part_info([self.model.parts[i] for i in sel])

    def _zoom_item(self, it):
        parts = [p for p in self._item_parts(it) if p.visible]
        if parts:
            self.gl.fit(parts)

    def _tree_menu(self, pos):
        it = self.tree.itemAt(pos)
        m = QMenu(self)
        if it is not None:
            m.addAction(theme.icon("magnify-plus-outline"), "Zoom to", lambda: self._zoom_item(it))
            m.addAction(theme.icon("eye-off-outline"), "Hide", self._hide_sel)
            m.addAction(theme.icon("eye-circle-outline"), "Isolate (show only)", self._isolate_sel)
            m.addAction(theme.icon("opacity"), "Transparency…", self._set_transparency)
            m.addAction(theme.icon("palette-outline"), "Colour…", self._set_part_color)
        m.addAction(theme.icon("eye-outline"), "Show all", self._show_all)
        m.addAction("Expand all", self.tree.expandAll)
        m.addAction("Collapse all", self.tree.collapseAll)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    # -------------------------------------------------------- selection ops
    def _selected_parts(self):
        if self.model is None:
            return []
        return [self.model.parts[i] for i in sorted(self.gl.selected) if i < len(self.model.parts)]

    def _hide_sel(self):
        for p in self._selected_parts():
            p.visible = False
        self.gl.selected = set()
        self._after_visibility()

    def _isolate_sel(self):
        sel = self._selected_parts()
        if not sel:
            return
        ids = {id(p) for p in sel}
        for p in self.model.parts:
            p.visible = id(p) in ids
        self._after_visibility()
        self.gl.fit(sel)

    def _show_all(self):
        if self.model is None:
            return
        for p in self.model.parts:
            p.visible = True
        self._after_visibility()

    def _after_visibility(self):
        self._sync_tree_checks()
        self.gl._sec_lines = None
        self.gl.update()
        self._update_info()

    def _toggle_ghost(self, on):
        self.gl.ghost_others = on
        self.gl.update()

    def _set_transparency(self):
        sel = self._selected_parts()
        if not sel:
            return
        v, ok = QInputDialog.getInt(self, "Transparency", "Opacity of the selected parts (%):",
                                    int(sel[0].opacity * 100), 5, 100, 5)
        if ok:
            for p in sel:
                p.opacity = v / 100.0
            self.gl.update()

    def _set_part_color(self):
        sel = self._selected_parts()
        if not sel:
            return
        c = QColorDialog.getColor(QColor.fromRgbF(*sel[0].color[:3]), self, "Part colour")
        if not c.isValid():
            return
        for p in sel:
            p.color = (c.redF(), c.greenF(), c.blueF(), 1.0)
            p.line_color = p.color
            if p.col is not None:
                p.col = None
        # re-upload colour buffers
        self.gl._release_gpu()
        self.gl._dirty = True
        self.gl.update()

    def _on_pick(self, hit):
        if hit is None:
            self.tree.blockSignals(True)
            self.tree.clearSelection()
            self.tree.blockSignals(False)
            self._show_part_info([])
            return
        part = hit["part"]
        it = self._items.get(id(part))
        if it is not None:
            self.tree.blockSignals(True)
            self.tree.clearSelection()
            for i in self.gl.selected:
                ii = self._items.get(id(self.model.parts[i]))
                if ii is not None:
                    ii.setSelected(True)
            self.tree.scrollToItem(it)
            self.tree.blockSignals(False)
        self._show_part_info(self._selected_parts(), hit)

    def _show_part_info(self, parts, hit=None):
        if not parts:
            self.part_info.setText("")
            return
        lo = np.min([p.bbox[0] for p in parts if p.bbox is not None], axis=0)
        hi = np.max([p.bbox[1] for p in parts if p.bbox is not None], axis=0)
        s = self.gl.unit_scale
        sz = (hi - lo) * s
        ntri = sum(p.ntri for p in parts)
        area = 0.0
        for p in parts:
            if p.tri is not None and len(p.tri):
                t = p.tri.reshape(-1, 3, 3).astype(np.float64)
                area += float(0.5 * np.linalg.norm(np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]), axis=1).sum())
        u = (" " + self.gl.unit) if self.gl.unit else ""
        names = ", ".join(p.name for p in parts[:4]) + (" …" if len(parts) > 4 else "")
        txt = "<b>%s</b><br>%d part(s), %d triangles<br>Size %.4g × %.4g × %.4g%s<br>Surface area %.6g%s²" % (
            names, len(parts), ntri, sz[0], sz[1], sz[2], u, area * s * s, u)
        if hit is not None:
            P = hit["point"] * s
            txt += "<br>Picked point (%.4g, %.4g, %.4g)" % (P[0], P[1], P[2])
        self.part_info.setText(txt)

    # -------------------------------------------------------------- section
    def _toggle_section(self, on):
        self.sec_box.setEnabled(on)
        if on:
            self._sec_update()
        else:
            self.gl.set_section(None)
            self.sec_info.setText("")

    def _sec_normal(self):
        i = self.sec_axis.currentIndex()
        if i == 0:
            n = np.array([1.0, 0, 0])
        elif i == 1:
            n = np.array([0, 1.0, 0])
        elif i == 2:
            n = np.array([0, 0, 1.0])
        elif i == 3:
            n = -self.gl.cam.R[:, 2].copy()
        else:
            n = getattr(self, "_sec_custom", None)
            if n is None:
                n = np.array([1.0, 0, 0])
        return n / (np.linalg.norm(n) or 1.0)

    def _sec_axis_changed(self, i):
        if i == 4:
            sel = getattr(self, "_last_hit", None)
            if sel is not None and sel.get("normal") is not None:
                self._sec_custom = np.asarray(sel["normal"], float)
                P = sel["point"]
                n = self._sec_custom / np.linalg.norm(self._sec_custom)
                lo, hi = self.gl.bounds(False)
                corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
                pr = corners @ n
                t = (float(P @ n) - pr.min()) / ((pr.max() - pr.min()) or 1.0)
                self.sec_slider.blockSignals(True)
                self.sec_slider.setValue(int(round(t * 1000)))
                self.sec_slider.blockSignals(False)
            else:
                self.statusBar().showMessage("Select a face first (click on the model), then choose 'Selected face'.", 6000)
        self._sec_update()

    def _enable_section(self, normal, center):
        self.sec_act.setChecked(True)
        self.sec_box.setEnabled(True)
        self._sec_custom = normal
        self.sec_axis.blockSignals(True)
        self.sec_axis.setCurrentIndex(4)
        self.sec_axis.blockSignals(False)
        lo, hi = self.gl.bounds(False)
        n = normal / (np.linalg.norm(normal) or 1.0)
        corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
        pr = corners @ n
        t = (float(center @ n) - pr.min()) / ((pr.max() - pr.min()) or 1.0)
        self.sec_slider.blockSignals(True)
        self.sec_slider.setValue(int(round(min(1, max(0, t)) * 1000)))
        self.sec_slider.blockSignals(False)
        self._sec_update()

    def _sec_update(self, *_):
        if not self.sec_act.isChecked() or self.model is None:
            return
        n = self._sec_normal()
        lo, hi = self.gl.bounds(False)
        corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
        pr = corners @ n
        a, b = pr.min(), pr.max()
        t = self.sec_slider.value() / 1000.0
        off = a + (b - a) * (0.0005 + 0.999 * t)
        nn = -n if self.sec_flip.isChecked() else n
        d = -off if not self.sec_flip.isChecked() else off
        sec = dict(self.gl.section or {})
        sec.update({"normal": nn, "d": d, "show_plane": self.sec_plane.isChecked(),
                    "outline": self.sec_outline.isChecked()})
        sec.setdefault("cap", (0.86, 0.36, 0.25))
        self.gl.set_section(sec)
        s = self.gl.unit_scale
        u = (" " + self.gl.unit) if self.gl.unit else ""
        self.sec_pos.setText("%.4g%s along (%.3f, %.3f, %.3f)" % (off * s, u, n[0], n[1], n[2]))
        QTimer.singleShot(0, self._sec_len)

    def _sec_len(self):
        if self.gl.section is None:
            return
        if self.gl._sec_lines is None:
            self.gl.makeCurrent()
            self.gl._compute_section_lines()
            self.gl.doneCurrent()
        L = self.gl.section_length() * self.gl.unit_scale
        u = (" " + self.gl.unit) if self.gl.unit else ""
        self.sec_info.setText("Section outline length: %.6g%s" % (L, u))

    def _cap_color(self):
        sec = self.gl.section or {}
        c0 = sec.get("cap", (0.86, 0.36, 0.25))
        c = QColorDialog.getColor(QColor.fromRgbF(*c0), self, "Section cap colour")
        if c.isValid() and self.gl.section is not None:
            self.gl.section["cap"] = (c.redF(), c.greenF(), c.blueF())
            self.gl.update()

    # ---------------------------------------------------------- measuring
    def _set_measure(self, key):
        on = self.m_acts[key].isChecked()
        for k, a in self.m_acts.items():
            if k != key:
                a.setChecked(False)
        self.comment_act.setChecked(False)
        self.gl.set_measure_mode(key if on else None)
        hints = {"distance": "Click two points (vertices and edges snap).",
                 "angle": "Click three points: first leg, vertex, second leg.",
                 "faceangle": "Click two faces.",
                 "radius": "Click three points on a circular edge or arc.",
                 "point": "Click a point to show its coordinates."}
        if on:
            self.statusBar().showMessage(hints[key] + "  Esc cancels the current measurement.", 10000)

    def _on_measured(self, m):
        self._refresh_measure_list()

    def _refresh_measure_list(self):
        self.mlist.clear()
        for k, m in enumerate(self.gl.measurements):
            it = QListWidgetItem("%d. %s" % (k + 1, self.gl.measurement_text(m)))
            it.setData(Qt.UserRole, k)
            self.mlist.addItem(it)

    def _clear_measures(self):
        self.gl.measurements = []
        self.gl.mpoints = []
        self._refresh_measure_list()
        self.gl.update()

    def _mlist_menu(self, pos):
        it = self.mlist.itemAt(pos)
        m = QMenu(self)
        if it is not None:
            k = it.data(Qt.UserRole)
            m.addAction("Copy", lambda: QGuiApplication.clipboard().setText(it.text()))
            m.addAction("Delete", lambda: (self.gl.measurements.pop(k), self._refresh_measure_list(), self.gl.update()))
            if self.annot is not None and self.pdfdoc is not None:
                m.addAction(theme.icon("comment-plus-outline"), "Save as 3D comment",
                            lambda: self._measure_to_comment(k))
        m.addAction("Copy all", lambda: QGuiApplication.clipboard().setText(
            "\n".join(self.mlist.item(i).text() for i in range(self.mlist.count()))))
        m.exec(self.mlist.viewport().mapToGlobal(pos))

    # ----------------------------------------------------------- comments
    def _start_comment(self, *_):
        if self.annot is None or self.pdfdoc is None:
            QMessageBox.information(self, "3D comments", "3D comments are stored in the PDF; open the model from a PDF page.")
            self.comment_act.setChecked(False)
            return
        on = self.comment_act.isChecked()
        for a in self.m_acts.values():
            a.setChecked(False)
        self.gl.set_measure_mode("comment" if on else None)
        if on:
            self.statusBar().showMessage("Click the point on the model the comment refers to.", 10000)

    def _on_point_picked(self, hit):
        self._last_hit = hit
        if self.gl.measure_mode != "comment":
            return
        text = _ask_text(self, "3D comment", "Comment (saved in the PDF together with the current view):")
        self.comment_act.setChecked(False)
        self.gl.set_measure_mode(None)
        if not text:
            return
        self._write_comment(text, hit["point"])

    def _measure_to_comment(self, k):
        m = self.gl.measurements[k]
        self._write_comment(self.gl.measurement_text(m), m["points"][-1])

    def _write_comment(self, text, point):
        try:
            from . import comments3d as C3
            C3.add_comment(self.pdfdoc, self.annot, text, self.gl.cam, point, self.gl.mode)
        except Exception as e:
            QMessageBox.warning(self, "3D comment", "The comment could not be saved:\n%s" % e)
            return
        self._load_comments()
        self.statusBar().showMessage("3D comment added to page %d of the PDF." % (self.annot.page + 1), 6000)

    def _load_comments(self):
        self.clist.clear()
        self.gl.markers = []
        if self.annot is None or self.pdfdoc is None:
            return
        try:
            from . import comments3d as C3
            self._comments = C3.list_comments(self.pdfdoc, self.annot)
        except Exception:
            self._comments = []
        for k, c in enumerate(self._comments):
            it = QListWidgetItem(theme.icon("comment-text-outline"), "%d. %s — %s" % (k + 1, c["text"], c.get("author") or ""))
            it.setToolTip(c["text"])
            it.setData(Qt.UserRole, k)
            self.clist.addItem(it)
            if c.get("point") is not None:
                self.gl.markers.append((np.asarray(c["point"], float), c["text"]))
        self.gl.update()

    def _comment_clicked(self, it):
        c = self._comments[it.data(Qt.UserRole)]
        if c.get("camera") is not None:
            self.gl.set_camera(c["camera"])
            self.persp_act.setChecked(not c["camera"].ortho)
        if c.get("mode") in MODES:
            self.mode_combo.setCurrentIndex(MODES.index(c["mode"]))

    def _comment_menu(self, pos):
        it = self.clist.itemAt(pos)
        if it is None:
            return
        c = self._comments[it.data(Qt.UserRole)]
        m = QMenu(self)
        m.addAction("Go to view", lambda: self._comment_clicked(it))
        m.addAction("Edit text…", lambda: self._comment_edit(c))
        m.addAction(theme.icon("delete-outline"), "Delete", lambda: self._comment_delete(c))
        m.exec(self.clist.viewport().mapToGlobal(pos))

    def _comment_edit(self, c):
        text = _ask_text(self, "Edit 3D comment", "Comment:", c["text"])
        if text is None:
            return
        from . import comments3d as C3
        C3.edit_comment(self.pdfdoc, c, text)
        self._load_comments()

    def _comment_delete(self, c):
        from . import comments3d as C3
        C3.delete_comment(self.pdfdoc, c)
        self._load_comments()

    # ------------------------------------------------------------ snapshot
    def _snap_copy(self):
        img = self.gl.snapshot()
        QGuiApplication.clipboard().setImage(img)
        self.statusBar().showMessage("3D view copied to the clipboard (%d × %d)." % (img.width(), img.height()), 5000)

    def _snap_save(self):
        f, _ = QFileDialog.getSaveFileName(self, "Save 3D view", "3D view.png", "PNG image (*.png);;JPEG image (*.jpg)")
        if f:
            self.gl.snapshot().save(f)

    def _snap_poster(self):
        if self.annot is None or self.pdfdoc is None:
            QMessageBox.information(self, "Poster", "Open the model from a PDF page to set the poster image.")
            return
        img = self.gl.snapshot()
        from . import comments3d as C3
        try:
            C3.set_poster(self.pdfdoc, self.annot, img)
        except Exception as e:
            QMessageBox.warning(self, "Poster", "The poster could not be set:\n%s" % e)
            return
        self.statusBar().showMessage("The poster (printed / inactive appearance) of the 3D annotation was updated.", 6000)

    def _snap_page(self):
        if self.pdfdoc is None or getattr(self.pdfdoc, "doc", None) is None:
            QMessageBox.information(self, "Insert image", "No PDF document is open.")
            return
        img = self.gl.snapshot()
        from . import comments3d as C3
        try:
            pno = C3.insert_image_page(self.pdfdoc, img, after=(self.annot.page if self.annot else None),
                                       title=self.model.title if self.model else "3D view")
        except Exception as e:
            QMessageBox.warning(self, "Insert image", str(e))
            return
        self.statusBar().showMessage("3D view inserted as page %d." % (pno + 1), 6000)

    # --------------------------------------------------------------- export
    def _visible_tris(self):
        out = []
        for p in self.model.parts:
            if p.visible and p.tri is not None and len(p.tri):
                out.append((p, p.tri))
        return out

    def _export(self, fmt):
        if self.model is None:
            return
        base = os.path.splitext(self.model.title or "model")[0] or "model"
        f, _ = QFileDialog.getSaveFileName(self, "Export", base + "." + fmt,
                                           "STL (*.stl)" if fmt == "stl" else "Wavefront OBJ (*.obj)")
        if not f:
            return
        parts = self._visible_tris()
        s = float(self.gl.unit_scale)
        try:
            if fmt == "stl":
                write_stl(f, [t * s for _, t in parts])
            else:
                write_obj(f, [(p.name, t * s, p.color) for p, t in parts])
        except Exception as e:
            QMessageBox.warning(self, "Export", str(e))
            return
        self.statusBar().showMessage("Exported %d parts to %s" % (len(parts), f), 6000)

    def _export_stream(self):
        if self.annot is None:
            QMessageBox.information(self, "Export", "The model was opened from a file.")
            return
        ext = "prc" if self.annot.subtype == "PRC" else "u3d"
        f, _ = QFileDialog.getSaveFileName(self, "Save 3D stream", "model." + ext, "%s (*.%s)" % (ext.upper(), ext))
        if f:
            with open(f, "wb") as fh:
                fh.write(self.annot.data)

    def _export_measures(self):
        if not self.gl.measurements:
            return
        f, _ = QFileDialog.getSaveFileName(self, "Export measurements", "measurements.csv", "CSV (*.csv)")
        if not f:
            return
        import csv
        with open(f, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["#", "Type", "Value", "Unit", "Points"])
            for k, m in enumerate(self.gl.measurements):
                unit = "deg" if m["type"] in ("angle", "faceangle") else self.gl.unit
                val = m["value"] * (1 if unit == "deg" else self.gl.unit_scale)
                pts = "; ".join("(%.6g, %.6g, %.6g)" % tuple(p * self.gl.unit_scale) for p in m["points"])
                w.writerow([k + 1, m["type"], "%.6g" % val, unit, pts])

    # -------------------------------------------------------------- misc
    def _context_menu(self, pos):
        m = QMenu(self)
        m.addAction("Fit", self.gl.fit)
        m.addAction("Default view", self._home)
        vm = m.addMenu("Standard views")
        for name in STD_VIEWS:
            vm.addAction(name, lambda n=name: self.gl.set_std_view(n))
        m.addSeparator()
        m.addAction("Hide selected", self._hide_sel)
        m.addAction("Isolate selected", self._isolate_sel)
        m.addAction("Show all", self._show_all)
        m.addSeparator()
        m.addAction("Copy view", self._snap_copy)
        m.exec(self.gl.mapToGlobal(pos))

    def _update_info(self):
        if self.model is None:
            return
        vis = [p for p in self.model.parts if p.visible]
        ntri = sum(p.ntri for p in vis)
        lo, hi = self.model.bbox(visible_only=True)
        s = self.gl.unit_scale
        sz = (hi - lo) * s
        self.info.setText("%s  |  %d/%d parts  |  %s triangles  |  %.4g × %.4g × %.4g" % (
            self.model.source, len(vis), len(self.model.parts), format(ntri, ","), sz[0], sz[1], sz[2]))

    def closeEvent(self, e):
        try:
            self.gl._release_gpu()
        except Exception:
            pass
        super().closeEvent(e)


def _ask_text(parent, title, label, text=""):
    d = QDialog(parent)
    d.setWindowTitle(title)
    lay = QVBoxLayout(d)
    lay.addWidget(QLabel(label))
    ed = QPlainTextEdit(text)
    ed.setMinimumSize(380, 120)
    lay.addWidget(ed)
    bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    bb.accepted.connect(d.accept)
    bb.rejected.connect(d.reject)
    lay.addWidget(bb)
    if d.exec() != QDialog.Accepted:
        return None
    return ed.toPlainText().strip()


def write_stl(path, tris_list):
    total = sum(len(t) // 3 for t in tris_list)
    with open(path, "wb") as f:
        f.write(b"ALIEF PDF EDITOR PRO STL export".ljust(80, b" "))
        f.write(struct.pack("<I", total))
        for t in tris_list:
            T = np.asarray(t, np.float32).reshape(-1, 3, 3)
            n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
            l = np.linalg.norm(n, axis=1)
            l[l == 0] = 1
            n = (n / l[:, None]).astype(np.float32)
            rec = np.zeros(len(T), dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
            rec["n"] = n
            rec["v"] = T
            f.write(rec.tobytes())


def write_obj(path, parts):
    base = os.path.splitext(path)[0]
    mtl = base + ".mtl"
    with open(mtl, "w", encoding="utf-8") as fm:
        for k, (name, t, c) in enumerate(parts):
            fm.write("newmtl m%d\nKd %.4f %.4f %.4f\nd %.3f\n\n" % (k, c[0], c[1], c[2], 1.0))
    with open(path, "w", encoding="utf-8") as f:
        f.write("# ALIEF PDF EDITOR PRO OBJ export\nmtllib %s\n" % os.path.basename(mtl))
        off = 1
        for k, (name, t, c) in enumerate(parts):
            T = np.asarray(t, np.float64).reshape(-1, 3)
            # weld identical vertices to keep the file small
            scale = float(np.abs(T).max()) * 1e-9 + 1e-15
            key = np.round(T / scale).astype(np.int64)
            uniq, inv = np.unique(key, axis=0, return_inverse=True)
            inv = inv.ravel()
            V = np.zeros((len(uniq), 3))
            V[inv] = T
            f.write("o %s\nusemtl m%d\n" % (name.replace(" ", "_") or "part%d" % k, k))
            f.write("".join("v %.7g %.7g %.7g\n" % tuple(v) for v in V))
            F = inv.reshape(-1, 3) + off
            f.write("".join("f %d %d %d\n" % tuple(x) for x in F))
            off += len(V)
