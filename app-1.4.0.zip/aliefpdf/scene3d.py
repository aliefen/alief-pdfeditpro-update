# -*- coding: utf-8 -*-
"""
Viewer-side 3D model: flattened parts (world space triangles, lines and
points with colours), the model tree, the predefined views and the lights,
built from a decoded U3D scene or PRC file.
"""
from __future__ import annotations

import math

import numpy as np

DEFAULT_COLOR = (0.75, 0.75, 0.78, 1.0)


class Part:
    def __init__(self, name):
        self.name = name
        self.node = None          # TreeNode
        self.tri = None           # (N*3, 3) float32 world positions (unindexed)
        self.nrm = None           # (N*3, 3) float32 or None (computed when missing)
        self.col = None           # (N*3, 4) float32 per-vertex colours or None
        self.color = DEFAULT_COLOR
        self.lines = None         # (M*2, 3) float32 world line segments
        self.line_col = None      # (M*2, 4) or None
        self.line_color = (0.1, 0.1, 0.1, 1.0)
        self.points = None        # (K, 3)
        self.point_color = (0.1, 0.1, 0.1, 1.0)
        self.visible = True
        self.opacity = 1.0
        self.double_sided = True
        self.bbox = None

    @property
    def ntri(self):
        return 0 if self.tri is None else len(self.tri) // 3

    def finish(self):
        pts = [a for a in (self.tri, self.lines, self.points) if a is not None and len(a)]
        if pts:
            allp = np.concatenate(pts)
            ok = np.isfinite(allp).all(axis=1)
            allp = allp[ok]
            if len(allp):
                self.bbox = (allp.min(0), allp.max(0))
        if self.tri is not None and len(self.tri):
            if self.nrm is None:
                self.nrm = flat_normals(self.tri)
            else:
                fix_normals(self.tri, self.nrm)


class TreeNode:
    def __init__(self, name, kind="group"):
        self.name = name
        self.kind = kind
        self.children = []
        self.parts = []           # Part objects directly under this node
        self.parent = None
        self.visible = True

    def add(self, child):
        child.parent = self
        self.children.append(child)
        return child

    def all_parts(self):
        out = list(self.parts)
        for c in self.children:
            out.extend(c.all_parts())
        return out


class Camera:
    """Simple camera: target, distance, orientation (rotation matrix whose
    columns are the camera right / up / back axes in world space)."""

    def __init__(self):
        self.target = np.zeros(3)
        self.dist = 10.0
        self.R = np.eye(3)
        self.fov = 30.0
        self.ortho = False
        self.ortho_h = 10.0

    def copy(self):
        c = Camera()
        c.target = self.target.copy()
        c.dist = self.dist
        c.R = self.R.copy()
        c.fov = self.fov
        c.ortho = self.ortho
        c.ortho_h = self.ortho_h
        return c

    @property
    def eye(self):
        return self.target + self.R[:, 2] * self.dist

    def c2w(self):
        M = np.eye(4)
        M[:3, :3] = self.R
        M[:3, 3] = self.eye
        return M

    def view_matrix(self):
        M = np.eye(4)
        Rt = self.R.T
        M[:3, :3] = Rt
        M[:3, 3] = -Rt @ self.eye
        return M

    def set_from_c2w(self, M, dist=None):
        R = np.asarray(M, float)[:3, :3].copy()
        # orthonormalise
        x = R[:, 0] / (np.linalg.norm(R[:, 0]) or 1.0)
        z = R[:, 2] / (np.linalg.norm(R[:, 2]) or 1.0)
        y = np.cross(z, x)
        y /= np.linalg.norm(y) or 1.0
        x = np.cross(y, z)
        self.R = np.column_stack([x, y, z])
        eye = np.asarray(M, float)[:3, 3]
        if dist is not None and dist > 0:
            self.dist = float(dist)
        self.target = eye - self.R[:, 2] * self.dist


class View:
    def __init__(self, name):
        self.name = name
        self.camera = None        # Camera or None (fit)
        self.bg = None
        self.render_mode = None
        self.lighting = None
        self.nodes = {}
        self.sections = []


class Model:
    def __init__(self):
        self.parts = []
        self.root = TreeNode("Model", "root")
        self.views = []
        self.default_view = 0
        self.lights = []          # [(type, position/direction, color, intensity)]
        self.warnings = []
        self.source = "U3D"
        self.units = None
        self.title = ""

    def bbox(self, visible_only=False):
        bbs = [p.bbox for p in self.parts if p.bbox is not None and (p.visible or not visible_only)]
        if not bbs:
            return np.array([-1.0, -1, -1]), np.array([1.0, 1, 1])
        lo = np.min([b[0] for b in bbs], axis=0)
        hi = np.max([b[1] for b in bbs], axis=0)
        return lo, hi

    @property
    def ntri(self):
        return sum(p.ntri for p in self.parts)

    def find_node(self, name):
        st = [self.root]
        while st:
            n = st.pop()
            if n.name == name:
                return n
            st.extend(n.children)
        return None


# ---------------------------------------------------------------- utils
def flat_normals(tri):
    t = tri.reshape(-1, 3, 3).astype(np.float64)
    n = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    l = np.linalg.norm(n, axis=1)
    l[l == 0] = 1.0
    n /= l[:, None]
    return np.repeat(n, 3, axis=0).astype(np.float32)


def fix_normals(tri, nrm):
    """Replace corner normals that point away from their face (decoder or
    exporter artefacts) by the face normal."""
    fn = flat_normals(tri)
    d = (fn * nrm).sum(axis=1)
    bad = ~np.isfinite(d) | (d < 0.05)
    if bad.any():
        nrm[bad] = fn[bad]


def smooth_normals(tri, crease_deg=40.0):
    """Corner normals averaged over faces sharing a position within the crease angle."""
    t = tri.reshape(-1, 3)
    fn = flat_normals(tri).reshape(-1, 3, 3)[:, 0]
    nf = len(fn)
    scale = float(np.abs(t).max()) * 1e-7 + 1e-12
    key = np.round(t / scale).astype(np.int64)
    _, inv = np.unique(key, axis=0, return_inverse=True)
    inv = inv.ravel()
    acc = np.zeros((inv.max() + 1, 3))
    fa = np.repeat(fn, 3, axis=0)
    np.add.at(acc, inv, fa)
    l = np.linalg.norm(acc, axis=1)
    l[l == 0] = 1.0
    acc /= l[:, None]
    out = acc[inv]
    cosc = math.cos(math.radians(crease_deg))
    sharp = (out * fa).sum(axis=1) < cosc
    out[sharp] = fa[sharp]
    return out.astype(np.float32)


def transform_points(M, p):
    p = np.asarray(p, np.float64)
    return (p @ M[:3, :3].T + M[:3, 3]).astype(np.float32)


def transform_normals(M, n):
    A = M[:3, :3]
    try:
        N = np.linalg.inv(A).T
    except np.linalg.LinAlgError:
        N = A
    out = np.asarray(n, np.float64) @ N.T
    l = np.linalg.norm(out, axis=1)
    l[l == 0] = 1.0
    out /= l[:, None]
    if np.linalg.det(A) < 0:
        pass
    return out.astype(np.float32)


def look_camera(direction, up, target, dist, fov=30.0):
    """Camera looking along *direction* (world) with *up* hint."""
    d = np.asarray(direction, float)
    d /= np.linalg.norm(d) or 1.0
    z = -d
    upv = np.asarray(up, float)
    x = np.cross(upv, z)
    if np.linalg.norm(x) < 1e-6:
        x = np.cross(np.array([0.0, 1.0, 0.0]) if abs(z[1]) < 0.9 else np.array([1.0, 0, 0]), z)
    x /= np.linalg.norm(x)
    y = np.cross(z, x)
    c = Camera()
    c.R = np.column_stack([x, y, z])
    c.target = np.asarray(target, float)
    c.dist = float(dist)
    c.fov = fov
    return c


# ------------------------------------------------------------ from U3D
def from_u3d(scene, annot=None):
    from . import u3d as U
    model = Model()
    model.source = "U3D"
    model.warnings = list(scene.warnings)
    units = scene.units if scene.units and scene.units > 0 else 1.0
    model.units = units
    # ---- tree -----------------------------------------------------------
    tnodes = {}
    for name in scene.node_order:
        nd = scene.nodes[name]
        if nd.kind in ("group", "model"):
            tnodes[name] = TreeNode(name or "(unnamed)", nd.kind)
    for name, tn in tnodes.items():
        nd = scene.nodes[name]
        parent = None
        for pname, _m in nd.parents:
            if pname in tnodes and pname != name:
                parent = tnodes[pname]
                break
        # guard against cycles
        p = parent
        depth = 0
        while p is not None and depth < 256:
            if p is tn:
                parent = None
                break
            p = p.parent
            depth += 1
        (parent or model.root).add(tn)
    # ---- parts ------------------------------------------------------------
    flat_cache = {}
    counts = {}
    for node, W in scene.world_instances():
        if node.kind != "model":
            continue
        res = scene.resources.get(node.resource)
        if res is None:
            continue
        counts[node.name] = counts.get(node.name, 0) + 1
        part = Part(node.name if counts[node.name] == 1 else "%s [%d]" % (node.name, counts[node.name]))
        part.node = tnodes.get(node.name)
        part.visible = node.visibility != 0
        part.double_sided = node.visibility in (2, 3) or True
        lists = scene.shading.get(node.name)
        shader_for = _shader_resolver(scene, lists)
        if isinstance(res, U.Mesh):
            if res.name not in flat_cache:
                flat_cache[res.name] = U.mesh_arrays(res)
            A = flat_cache[res.name]
            if A is None:
                continue
            part.tri = transform_points(W, A["pos"])
            part.nrm = transform_normals(W, A["nrm"]) if A["nrm"] is not None else None
            if np.linalg.det(W[:3, :3]) < 0:
                t = part.tri.reshape(-1, 3, 3)
                t[:, [1, 2]] = t[:, [2, 1]]
                if part.nrm is not None:
                    nn = part.nrm.reshape(-1, 3, 3)
                    nn[:, [1, 2]] = nn[:, [2, 1]]
            shade = A["shade"]
            ids = np.unique(shade)
            colors = {}
            opac = []
            use_vc = False
            for sid in ids:
                c, op, vc = shader_for(int(sid))
                colors[int(sid)] = c
                opac.append(op)
                use_vc = use_vc or vc
            if len(ids) == 1 and not (use_vc and A["col"] is not None):
                c = colors[int(ids[0])]
                part.color = (c[0], c[1], c[2], 1.0)
            else:
                lut = np.array([colors.get(int(s), DEFAULT_COLOR)[:3] + (1.0,) for s in range(int(ids.max()) + 1)],
                               np.float32)
                col = np.repeat(lut[np.clip(shade, 0, len(lut) - 1)], 3, axis=0)
                if use_vc and A["col"] is not None and "col_mask" in A:
                    mk = A["col_mask"]
                    col[mk] = A["col"][mk]
                part.col = col
            part.opacity = float(min(opac)) if opac else 1.0
        elif isinstance(res, U.LineSet):
            if not res.lines or not res.positions:
                continue
            P = np.asarray(res.positions, np.float32)
            L = np.asarray(res.lines, np.int64)
            L = L[(L < len(P)).all(axis=1)]
            part.lines = transform_points(W, P[L.reshape(-1)])
            c, op, vc = shader_for(int(res.lshade[0]) if res.lshade else 0)
            part.line_color = (c[0], c[1], c[2], 1.0)
            if res.diffuse and vc:
                D = np.asarray(res.diffuse, np.float32)
                idx = []
                for li, d in enumerate(res.ldif):
                    idx.extend(d if d else [0, 0])
                idx = np.clip(np.asarray(idx, np.int64), 0, len(D) - 1)
                if len(idx) == len(part.lines):
                    part.line_col = np.clip(D[idx][:, [2, 1, 0, 3]], 0, 1)
            part.opacity = op
        elif isinstance(res, U.PointSet):
            if not res.points or not res.positions:
                continue
            P = np.asarray(res.positions, np.float32)
            idx = np.asarray([i for i in res.points if i < len(P)], np.int64)
            part.points = transform_points(W, P[idx])
            c, op, vc = shader_for(int(res.pshade[0]) if res.pshade else 0)
            part.point_color = (c[0], c[1], c[2], 1.0)
        else:
            continue
        part.finish()
        model.parts.append(part)
        if part.node is not None:
            part.node.parts.append(part)
        else:
            model.root.parts.append(part)
    # remove empty groups
    _prune(model.root)
    # ---- views ------------------------------------------------------------
    u3d_views = {}
    for node, W in scene.world_instances():
        if node.kind == "view" and node.name not in u3d_views:
            cam = Camera()
            info = node.view or {}
            cam.ortho = bool(info.get("ortho"))
            proj = info.get("proj") or 30.0
            if cam.ortho:
                cam.ortho_h = float(proj) if proj and proj > 0 else 10.0
            else:
                cam.fov = float(proj) if 1.0 < (proj or 0) < 170.0 else 30.0
            cam._c2w = W
            u3d_views[node.name] = cam
    model._u3d_views = u3d_views
    # ---- lights -----------------------------------------------------------
    for node, W in scene.world_instances():
        if node.kind != "light":
            continue
        li = scene.lights.get(node.resource)
        if li is None:
            continue
        if li.type == 0:
            model.lights.append(("ambient", None, li.color, li.intensity))
        elif li.type == 1:
            d = -W[:3, 2]
            model.lights.append(("directional", d / (np.linalg.norm(d) or 1), li.color, li.intensity))
        else:
            model.lights.append(("point", W[:3, 3].copy(), li.color, li.intensity))
    return model


def _prune(node):
    node.children = [c for c in node.children if _prune(c)]
    return bool(node.children or node.parts) or node.kind == "root"


def _shader_resolver(scene, lists):
    def get(sid):
        name = None
        if lists:
            lst = lists[sid] if sid < len(lists) else lists[-1]
            if lst:
                name = lst[0]
        sh = scene.shaders.get(name) if name else None
        if sh is None and not lists and len(scene.shaders) == 1:
            sh = next(iter(scene.shaders.values()))
        if sh is None:
            return DEFAULT_COLOR, 1.0, True
        mat = scene.materials.get(sh.material)
        if mat is None:
            return DEFAULT_COLOR, 1.0, bool(sh.attrs & 4)
        c = tuple(float(max(0.0, min(1.0, x))) for x in mat.diffuse)
        if sum(c) < 0.03 and sum(mat.emissive) > 0.03:
            c = tuple(float(max(0.0, min(1.0, x))) for x in mat.emissive)
        op = float(mat.opacity) if 0.0 <= mat.opacity <= 1.0 else 1.0
        return c + (1.0,), op, bool(sh.attrs & 4)
    return get


def apply_pdf_views(model, annot):
    """Attach the PDF predefined views (/VA) to a model."""
    lo, hi = model.bbox()
    centre = (lo + hi) / 2
    radius = float(np.linalg.norm(hi - lo) / 2) or 1.0
    u3dv = getattr(model, "_u3d_views", {}) or {}
    views = []
    if annot is not None and annot.views:
        for v in annot.views:
            mv = View(v.name)
            cam = None
            if v.c2w is not None:
                cam = Camera()
                co = v.co if v.co and v.co > 0 else None
                if co is None:
                    # distance from the eye to the model centre along the view axis
                    eye = v.c2w[:3, 3]
                    fwd = -v.c2w[:3, 2]
                    co = float(np.dot(centre - eye, fwd))
                    if co <= 0:
                        co = float(np.linalg.norm(centre - eye)) or radius * 3
                cam.set_from_c2w(v.c2w, co)
            elif v.u3d_path and v.u3d_path in u3dv:
                cam = _cam_from_u3d(u3dv[v.u3d_path], centre, radius)
            if cam is not None:
                if v.ortho:
                    cam.ortho = True
                    if v.ortho_scale and v.ortho_scale > 0:
                        cam.ortho_h = None
                        cam._ortho_scale = v.ortho_scale
                elif v.fov:
                    cam.fov = float(v.fov) if 1.0 < v.fov < 170 else cam.fov
            mv.camera = cam
            mv.bg = v.bg
            mv.render_mode = v.render_mode
            mv.lighting = v.lighting
            mv.nodes = v.nodes
            mv.sections = v.sections
            views.append(mv)
        model.default_view = annot.default_view if annot.default_view < len(views) else 0
    if not views and u3dv:
        for name, c in u3dv.items():
            mv = View(name)
            mv.camera = _cam_from_u3d(c, centre, radius)
            views.append(mv)
        model.default_view = 0
    model.views = views
    return model


def _cam_from_u3d(c, centre, radius):
    cam = Camera()
    cam.fov = c.fov
    cam.ortho = c.ortho
    cam.ortho_h = c.ortho_h
    W = c._c2w
    eye = W[:3, 3]
    back = W[:3, 2] / (np.linalg.norm(W[:3, 2]) or 1.0)
    d = float(np.dot(eye - centre, back))
    if d <= radius * 0.05:
        d = float(np.linalg.norm(eye - centre)) or radius * 3
    cam.set_from_c2w(W, d)
    return cam


def load_annotation(annot):
    """Decode an Annot3D (pdf3d) into a Model."""
    data = annot.data
    if annot.subtype == "PRC" or data[:3] == b"PRC":
        from . import prc
        model = prc.to_model(prc.load(data))
    else:
        from . import u3d
        model = from_u3d(u3d.load(data), annot)
    model.title = annot.title
    apply_pdf_views(model, annot)
    return model


def load_file(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:3] == b"PRC":
        from . import prc
        model = prc.to_model(prc.load(data))
    else:
        from . import u3d
        model = from_u3d(u3d.load(data))
    import os
    model.title = os.path.basename(path)
    apply_pdf_views(model, None)
    return model
