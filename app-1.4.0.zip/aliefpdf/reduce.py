"""Reduce PDF file size.

The default mode is lossless: text, vector graphics and image pixels are not changed at all, only stored more
efficiently. The result is rendered again and compared with the original page by page; when a step changes the
appearance it is undone automatically.

Lossless steps
  * embedded fonts reduced to the characters that are used (font subsetting)
  * duplicate objects, images and fonts merged; unused objects removed
  * all streams compressed, objects packed into compressed object streams
  * private editing data of the creating program (Illustrator / AutoCAD PieceInfo) and page thumbnails removed
  * black & white scans re-encoded as CCITT G4 (lossless fax compression)
  * Flate images re-compressed with PNG prediction (same pixels, fewer bytes)

Optional image presets (only for photos / scans inside the PDF, never for text or vector lines)
  * print  : images sharper than 360 dpi reduced to 300 dpi, JPEG quality 92
  * screen : images sharper than 180 dpi reduced to 150 dpi, JPEG quality 85
"""
import io
import os
import time
import zlib

import numpy as np
import pymupdf

PRESETS = {
    "lossless": {"label": "Lossless - identical text, graphics and images (recommended)", "dpi": 0, "quality": 0},
    "print": {"label": "Print quality - images above 360 dpi reduced to 300 dpi (JPEG 92)", "dpi": 300, "threshold": 360,
              "quality": 92},
    "ebook": {"label": "High quality - images above 260 dpi reduced to 220 dpi (JPEG 90)", "dpi": 220, "threshold": 260,
              "quality": 90},
    "screen": {"label": "Screen / e-mail - images above 180 dpi reduced to 150 dpi (JPEG 85)", "dpi": 150, "threshold": 180,
               "quality": 85},
}


def _cancelled():
    try:
        from .convert import Cancelled
        return Cancelled()
    except Exception:
        return RuntimeError("cancelled")


def _p(progress, i, n, msg):
    if progress and progress(i, n, msg) is False:
        raise _cancelled()
    return True


def _images(doc):
    out = []
    for x in range(1, doc.xref_length()):
        try:
            if doc.xref_get_key(x, "Subtype")[1] == "/Image":
                out.append(x)
        except Exception:
            pass
    return out


def _int(doc, x, key, default=0):
    try:
        t, v = doc.xref_get_key(x, key)
        return int(float(v)) if t in ("int", "float") else default
    except Exception:
        return default


# ------------------------------------------------------------------ private data / thumbnails
def remove_private_data(doc):
    """PieceInfo (Illustrator / AutoCAD editing data), page thumbnails. Returns number of entries removed."""
    n = 0
    cat = doc.pdf_catalog()
    for key in ("PieceInfo",):
        if doc.xref_get_key(cat, key)[0] != "null":
            doc.xref_set_key(cat, key, "null")
            n += 1
    for page in doc:
        for key in ("PieceInfo", "Thumb"):
            if doc.xref_get_key(page.xref, key)[0] != "null":
                doc.xref_set_key(page.xref, key, "null")
                n += 1
    # form XObjects may carry PieceInfo too
    for x in range(1, doc.xref_length()):
        try:
            if doc.xref_get_key(x, "Subtype")[1] == "/Form" and doc.xref_get_key(x, "PieceInfo")[0] != "null":
                doc.xref_set_key(x, "PieceInfo", "null")
                n += 1
        except Exception:
            pass
    return n


# ------------------------------------------------------------------ lossless image re-encoding
def _g4_encode(raw, w, h):
    """1-bit packed rows -> (CCITT G4 bytes, BlackIs1 guess)."""
    from PIL import Image
    im = Image.frombytes("1", (w, h), raw)
    buf = io.BytesIO()
    im.save(buf, "TIFF", compression="group4", tiffinfo={278: h})
    tif = buf.getvalue()
    t = Image.open(io.BytesIO(tif))
    offs, cnts = t.tag_v2.get(273), t.tag_v2.get(279)
    if not isinstance(offs, (tuple, list)):
        offs, cnts = (offs,), (cnts,)
    data = b"".join(tif[o:o + c] for o, c in zip(offs, cnts))
    return data, t.tag_v2.get(262) == 1


def _png_predict(raw, w, h, n):
    a = np.frombuffer(raw, np.uint8).reshape(h, w * n).astype(np.int16)
    up = np.vstack([np.zeros((1, w * n), np.int16), a[:-1]])
    left = np.hstack([np.zeros((h, n), np.int16), a[:, :-n]])
    ul = np.hstack([np.zeros((h, n), np.int16), up[:, :-n]])
    p = left + up - ul
    pa, pb, pc = np.abs(p - left), np.abs(p - up), np.abs(p - ul)
    paeth = np.where((pa <= pb) & (pa <= pc), left, np.where(pb <= pc, up, ul))
    cands = [(c & 255).astype(np.uint8) for c in (a, a - left, a - up, a - ((left + up) >> 1), a - paeth)]
    scores = np.stack([np.abs(c.view(np.int8).astype(np.int16)).sum(axis=1) for c in cands])
    best = scores.argmin(axis=0)
    out = np.empty((h, w * n + 1), np.uint8)
    out[:, 0] = best
    for k in range(5):
        rows = best == k
        if rows.any():
            out[rows, 1:] = cands[k][rows]
    return out.tobytes()


def _restore(doc, x, obj, raw):
    doc.update_object(x, obj)
    doc.update_stream(x, raw, compress=0)
    # update_stream with compress=0 drops the filter keys: put the original dictionary back
    doc.update_object(x, obj)


def recompress_images_lossless(doc, progress=None, cancel=None):
    """Same pixels, smaller streams. Returns (images changed, bytes saved)."""
    changed, saved = 0, 0
    xs = _images(doc)
    for k, x in enumerate(xs):
        if cancel and cancel():
            break
        if k % 10 == 0:
            _p(progress, k, len(xs), "Images (lossless) %d / %d" % (k, len(xs)))
        try:
            flt = doc.xref_get_key(x, "Filter")[1]
            if flt not in ("/FlateDecode", "null", "[/FlateDecode]"):
                continue                                    # JPEG, JPX, JBIG2, CCITT: already compact - keep as is
            if doc.xref_get_key(x, "DecodeParms")[0] != "null" and "Predictor" in doc.xref_get_key(x, "DecodeParms")[1]:
                pred = True
            else:
                pred = False
            w, h = _int(doc, x, "Width"), _int(doc, x, "Height")
            bpc = _int(doc, x, "BitsPerComponent", 1 if doc.xref_get_key(x, "ImageMask")[1] == "true" else 8)
            if w <= 0 or h <= 0 or w * h < 4096:
                continue
            old_raw = doc.xref_stream_raw(x)
            obj = doc.xref_object(x, compressed=True)
            samples = doc.xref_stream(x)
            if bpc == 1:
                if len(samples) != ((w + 7) // 8) * h:
                    continue
                data, _bi = _g4_encode(samples, w, h)
                if len(data) >= len(old_raw) * 0.97:
                    continue
                ok = False
                for black_is_1 in (_bi, not _bi):
                    doc.update_stream(x, data, compress=0)
                    doc.xref_set_key(x, "Filter", "/CCITTFaxDecode")
                    doc.xref_set_key(x, "DecodeParms", "<</K -1 /Columns %d /Rows %d /BlackIs1 %s>>"
                                     % (w, h, "true" if black_is_1 else "false"))
                    if doc.xref_stream(x) == samples:
                        ok = True
                        break
                if not ok:
                    _restore(doc, x, obj, old_raw)
                    continue
                changed += 1
                saved += len(old_raw) - len(data)
            elif bpc == 8 and not pred:
                n = len(samples) // (w * h) if w * h else 0
                if n not in (1, 3, 4) or n * w * h != len(samples):
                    continue
                data = zlib.compress(_png_predict(samples, w, h, n), 9)
                if len(data) >= len(old_raw) * 0.97:
                    continue
                doc.update_stream(x, data, compress=0)
                doc.xref_set_key(x, "Filter", "/FlateDecode")
                doc.xref_set_key(x, "DecodeParms", "<</Predictor 15 /Colors %d /BitsPerComponent 8 /Columns %d>>" % (n, w))
                if doc.xref_stream(x) != samples:
                    _restore(doc, x, obj, old_raw)
                    continue
                changed += 1
                saved += len(old_raw) - len(data)
        except Exception:
            continue
    return changed, saved


def _image_dpi(doc):
    """{xref: highest effective dpi at which the image is shown}"""
    out = {}
    for page in doc:
        try:
            infos = page.get_image_info(xrefs=True)
        except Exception:
            continue
        for inf in infos:
            x = inf.get("xref")
            if not x:
                continue
            bb = pymupdf.Rect(inf["bbox"])
            if bb.width <= 0.5 or bb.height <= 0.5:
                continue
            tr = inf.get("transform")
            if tr:
                m = pymupdf.Matrix(tr)
                wi = (m.a * m.a + m.b * m.b) ** 0.5 / 72.0
                hi = (m.c * m.c + m.d * m.d) ** 0.5 / 72.0
            else:
                wi, hi = bb.width / 72.0, bb.height / 72.0
            if wi <= 0 or hi <= 0:
                continue
            dpi = max(inf.get("width", 0) / wi, inf.get("height", 0) / hi)
            out[x] = max(out.get(x, 0), dpi)
    return out


def _cs_n(doc, x):
    t, v = doc.xref_get_key(x, "ColorSpace")
    if t == "name":
        return {"/DeviceRGB": 3, "/DeviceGray": 1}.get(v, 0)
    if t == "array" and "/ICCBased" in v:
        try:
            ref = int(v.split()[1])
            return _int(doc, ref, "N")
        except Exception:
            return 0
    if t == "xref":
        try:
            ref = int(v.split()[0])
            o = doc.xref_object(ref, compressed=True)
            if "/ICCBased" in o:
                r2 = int(o.split("/ICCBased")[1].split()[0])
                return _int(doc, r2, "N")
            return {"/DeviceRGB": 3, "/DeviceGray": 1}.get(o.strip(), 0)
        except Exception:
            return 0
    return 0


def downsample_images(doc, preset, progress=None, cancel=None):
    """Lossy preset: only photos / scans sharper than the threshold are reduced (text and vectors untouched).

    Line-art images (few colours) stay lossless at the lower resolution; photos become JPEG. An image is only
    replaced when the result is smaller. Returns (images changed, bytes saved).
    """
    from PIL import Image
    p = PRESETS[preset]
    dpis = _image_dpi(doc)
    changed, saved = 0, 0
    items = sorted(dpis.items())
    for k, (x, dpi) in enumerate(items):
        if cancel and cancel():
            break
        if k % 5 == 0:
            _p(progress, k, len(items), "Images %d / %d" % (k, len(items)))
        try:
            if doc.xref_get_key(x, "ImageMask")[1] == "true" or doc.xref_get_key(x, "Mask")[0] != "null":
                continue
            flt = doc.xref_get_key(x, "Filter")[1]
            if "JPX" in flt or "JBIG2" in flt:
                continue
            bpc = _int(doc, x, "BitsPerComponent", 8)
            n = _cs_n(doc, x)
            bitonal = bpc == 1
            if not bitonal and (bpc != 8 or n not in (1, 3)):
                continue
            limit = p["threshold"] * (1.5 if bitonal else 1.0)
            if dpi <= limit:
                continue
            target = p["dpi"] * (1.5 if bitonal else 1.0)
            f = target / dpi
            w, h = _int(doc, x, "Width"), _int(doc, x, "Height")
            nw, nh = max(1, int(round(w * f))), max(1, int(round(h * f)))
            if nw * nh < 64:
                continue
            old = len(doc.xref_stream_raw(x))
            smask = 0
            t, v = doc.xref_get_key(x, "SMask")
            if t == "xref":
                smask = int(v.split()[0])
                old += len(doc.xref_stream_raw(smask))
            pix = pymupdf.Pixmap(doc, x)
            if pix.alpha:
                pix = pymupdf.Pixmap(pix, 0)
            mode = {1: "L", 3: "RGB"}.get(pix.n)
            if mode is None:
                continue
            im = Image.frombytes(mode, (pix.width, pix.height), pix.samples)
            im = im.resize((nw, nh), Image.LANCZOS)
            buf = io.BytesIO()
            if bitonal:
                im = im.point(lambda v: 255 if v >= 128 else 0).convert("1")
                im.save(buf, "PNG", optimize=True)
            else:
                thumb = im.copy()
                thumb.thumbnail((256, 256))
                few = thumb.getcolors(maxcolors=300) is not None and "DCT" not in flt
                if few:
                    im.save(buf, "PNG", optimize=True)
                else:
                    im.save(buf, "JPEG", quality=p["quality"], optimize=True, subsampling=0 if p["quality"] >= 90 else 2)
            new_img = buf.getvalue()
            if smask:
                mp = pymupdf.Pixmap(doc, smask)
                mi = Image.frombytes("L", (mp.width, mp.height), mp.samples).resize((nw, nh), Image.LANCZOS)
                rgba = im.convert("RGBA") if im.mode != "1" else im.convert("L").convert("RGBA")
                rgba.putalpha(mi)
                b2 = io.BytesIO()
                rgba.save(b2, "PNG", optimize=True)
                new_img = b2.getvalue()
            if len(new_img) >= old * 0.9:
                continue
            obj = doc.xref_object(x, compressed=True)
            raw = doc.xref_stream_raw(x)
            doc[0].replace_image(x, stream=new_img)
            new_size = len(doc.xref_stream_raw(x))
            t2, v2 = doc.xref_get_key(x, "SMask")
            if t2 == "xref":
                new_size += len(doc.xref_stream_raw(int(v2.split()[0])))
            if new_size >= old:
                _restore(doc, x, obj, raw)
                continue
            changed += 1
            saved += old - new_size
        except Exception:
            continue
    return changed, saved


# ------------------------------------------------------------------ verification
def _render_diff(a, b, pages, dpi=60):
    worst = 0.0
    for i in pages:
        pa = a[i].get_pixmap(dpi=dpi, alpha=False, annots=True)
        pb = b[i].get_pixmap(dpi=dpi, alpha=False, annots=True)
        if (pa.width, pa.height) != (pb.width, pb.height):
            return 255.0
        A = np.frombuffer(pa.samples, np.uint8).astype(np.int16)
        B = np.frombuffer(pb.samples, np.uint8).astype(np.int16)
        d = np.abs(A - B)
        # fraction of noticeably different pixels (anti-aliasing differences of single pixels are ignored)
        frac = float((d > 48).mean()) * 100.0
        worst = max(worst, frac)
    return worst


def _sample_pages(n, k=24):
    if n <= k:
        return list(range(n))
    step = n / float(k)
    return sorted(set(int(i * step) for i in range(k)) | {n - 1})


# ------------------------------------------------------------------ main entry
def reduce_pdf(src, out_path, preset="lossless", subset_fonts=True, remove_private=True, remove_metadata=False,
               recompress_images=True, verify=True, password=None, progress=None):
    """src: file path or PDF bytes. Writes out_path. Returns a report dict."""
    t0 = time.time()
    is_bytes = isinstance(src, (bytes, bytearray))
    before_size = len(src) if is_bytes else os.path.getsize(src)

    def _open():
        d = pymupdf.open("pdf", bytes(src)) if is_bytes else pymupdf.open(src)
        if d.needs_pass and not (password and d.authenticate(password)):
            d.close()
            raise RuntimeError("This file needs its open password.")
        return d

    orig = _open()
    report = {"before": before_size, "steps": [], "preset": preset}
    steps = 7

    def work(do_subset, do_clean):
        doc = _open()
        notes = []
        _p(progress, 1, steps, "Removing editing data and thumbnails…")
        if remove_private:
            n = remove_private_data(doc)
            if n:
                notes.append("Editing data of the creating program / thumbnails removed (%d)" % n)
        if remove_metadata:
            try:
                doc.set_metadata({})
                doc.del_xml_metadata()
                notes.append("Metadata removed")
            except Exception:
                pass
        if do_subset:
            _p(progress, 2, steps, "Reducing embedded fonts to the characters used…")
            try:
                nf = sum(1 for pg in doc for f in pg.get_fonts() if f[1] not in ("n/a", ""))
                doc.subset_fonts()
                if nf:
                    notes.append("Embedded fonts reduced to the characters that are used")
            except Exception:
                pass
        if preset != "lossless":
            _p(progress, 3, steps, "Images…")
            try:
                c, s = downsample_images(doc, preset)
                if c:
                    notes.append("%d image(s) reduced to %d dpi (%s saved)" % (c, PRESETS[preset]["dpi"], fmt_size(s)))
            except Exception:
                pass
        if recompress_images:
            _p(progress, 4, steps, "Re-encoding images without loss…")
            c, s = recompress_images_lossless(doc)
            if c:
                notes.append("%d image(s) stored more compactly, same pixels (%s saved)" % (c, fmt_size(s)))
        _p(progress, 5, steps, "Merging duplicates, compressing and writing…")
        out = doc.tobytes(garbage=4, deflate=True, deflate_images=True, deflate_fonts=True, use_objstms=1,
                          clean=do_clean, compression_effort=100)
        doc.close()
        notes.insert(0, "Duplicate objects merged, unused objects removed, everything compressed")
        return out, notes

    attempts = [(subset_fonts, False), (False, False)]
    result, notes, diff = None, [], None
    for k, (do_subset, do_clean) in enumerate(attempts):
        out, notes = work(do_subset, do_clean)
        if not verify:
            result = out
            break
        _p(progress, 6, steps, "Checking the result page by page…")
        chk = pymupdf.open("pdf", out)
        pages = _sample_pages(orig.page_count)
        try:
            diff = _render_diff(orig, chk, pages)
        except Exception:
            diff = 255.0
        chk.close()
        limit = 0.05 if preset == "lossless" else 3.0
        if diff <= limit or k == len(attempts) - 1:
            result = out
            report["verified_pages"] = len(pages)
            report["diff_pct"] = diff
            if k > 0:
                notes.append("Font subsetting skipped for this file (it changed the look)")
            break
    orig.close()
    if len(result) >= before_size and not is_bytes:
        # nothing to gain: keep the original bytes
        with open(src, "rb") as f:
            result = f.read()
        notes = ["The file is already stored compactly - no further reduction possible without loss"]
    with open(out_path, "wb") as f:
        f.write(result)
    report.update(after=len(result), steps=notes, seconds=time.time() - t0, path=out_path)
    _p(progress, steps, steps, "Done")
    return report


def fmt_size(n):
    if n >= 1048576:
        return "%.2f MB" % (n / 1048576.0)
    return "%.0f KB" % (n / 1024.0)
