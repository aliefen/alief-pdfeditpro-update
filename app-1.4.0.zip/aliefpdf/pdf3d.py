# -*- coding: utf-8 -*-
"""
3D content of PDF documents (ISO 32000 section 13.6, 3D artwork).

Finds the 3D annotations of a document, extracts their 3D streams
(U3D / PRC), the predefined views (/VA with /C2W, /CO, /P, /BG, /RM, /LS,
/NA and /SA cross sections), the default view and the activation settings.
Works with the PDFs written by ALIEF PDF PRO and by other 3D PDF tools
(Acrobat, Tetra4D, CAD exporters, LaTeX media9/movie15, ...).
"""
from __future__ import annotations

import re

import numpy as np

RENDER_MODES = ["Solid", "SolidWireframe", "Transparent", "TransparentWireframe", "BoundingBox",
                "TransparentBoundingBox", "TransparentBoundingBoxOutline", "Wireframe",
                "ShadedWireframe", "HiddenWireframe", "Vertices", "ShadedVertices", "Illustration",
                "SolidOutline", "ShadedIllustration"]
LIGHTING = ["Artwork", "None", "White", "Day", "Night", "Hard", "Primary", "Blue", "Red", "Cube",
            "CAD", "Headlamp"]


class View3D:
    """A predefined 3D view.  Cameras use the OpenGL convention internally:
    camera-to-world matrix whose -Z axis is the viewing direction, +Y up."""

    def __init__(self, name="View"):
        self.name = name
        self.c2w = None           # 4x4 numpy (GL convention) or None
        self.u3d_path = None      # name of a U3D view node
        self.co = None            # centre-of-orbit distance
        self.ortho = False
        self.fov = None           # degrees (perspective)
        self.ortho_scale = None
        self.bg = None            # (r, g, b)
        self.render_mode = None
        self.lighting = None
        self.nodes = {}           # name -> {"visible": bool, "opacity": float, "M": 4x4}
        self.sections = []        # [{"center", "normal", "opacity", "color", "intersect"}]


class Annot3D:
    def __init__(self):
        self.page = 0
        self.xref = 0
        self.stream_xref = 0
        self.rect = None          # pymupdf.Rect (page coordinates)
        self.subtype = "U3D"      # U3D or PRC
        self.data = b""
        self.views = []
        self.default_view = 0
        self.activation = "PC"
        self.toolbar = True
        self.model_tree = False
        self.title = ""
        self.units = None         # dict from /3DU
        self.has_js = False

    @property
    def label(self):
        t = self.title or ("3D model (%s)" % self.subtype)
        return "%s - page %d" % (t, self.page + 1)


# --------------------------------------------------------------- helpers
def _num(s, default=None):
    try:
        return float(s)
    except (TypeError, ValueError):
        return default


def _nums(s):
    return [float(x) for x in re.findall(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", s or "")]


def _pdf_string(doc, xref, key):
    try:
        t, v = doc.xref_get_key(xref, key)
    except Exception:
        return None
    if t == "string":
        return v
    if t == "name":
        return v.lstrip("/")
    return None


def _key(doc, xref, key):
    try:
        return doc.xref_get_key(xref, key)
    except Exception:
        return ("null", "null")


def _ref(v):
    m = re.match(r"\s*(\d+)\s+\d+\s+R", v or "")
    return int(m.group(1)) if m else 0


def c2w_from_pdf(vals):
    """PDF /C2W (12 numbers, camera looks along +z, y down) -> 4x4 GL camera-to-world."""
    a = np.asarray(vals[:12], dtype=np.float64)
    x, y, z, t = a[0:3], a[3:6], a[6:9], a[9:12]
    M = np.eye(4)
    M[:3, 0] = x
    M[:3, 1] = -y
    M[:3, 2] = -z
    M[:3, 3] = t
    return M


def c2w_to_pdf(M):
    x = M[:3, 0]
    y = -M[:3, 1]
    z = -M[:3, 2]
    t = M[:3, 3]
    return list(map(float, np.concatenate([x, y, z, t])))


# ------------------------------------------------------- object parsing
class _ObjReader:
    """Reads keys of direct / indirect dictionaries through PyMuPDF by
    temporarily materialising direct sub-dictionaries as text."""

    def __init__(self, doc):
        self.doc = doc

    def dict_text(self, xref, key):
        t, v = _key(self.doc, xref, key)
        if t == "xref":
            r = _ref(v)
            return self.doc.xref_object(r, compressed=True) if r else "", r
        if t == "dict":
            return v, 0
        return "", 0


def _split_top_dicts(arr_text):
    """Split the text of a PDF array of dictionaries into the dictionaries."""
    out = []
    depth = 0
    start = None
    i = 0
    s = arr_text
    n = len(s)
    in_str = 0
    while i < n:
        c = s[i]
        if in_str:
            if c == "\\":
                i += 2
                continue
            if c == "(":
                in_str += 1
            elif c == ")":
                in_str -= 1
        elif c == "(":
            in_str = 1
        elif s.startswith("<<", i):
            if depth == 0:
                start = i
            depth += 1
            i += 2
            continue
        elif s.startswith(">>", i):
            depth -= 1
            i += 2
            if depth == 0 and start is not None:
                out.append(s[start:i])
                start = None
            continue
        elif c == "<" and depth == 0:
            pass
        i += 1
    return out


def _get(d, key):
    """Value text of /key in a dictionary text (top level only)."""
    s = d
    k = "/" + key
    depth = 0
    i = 0
    n = len(s)
    in_str = 0
    while i < n:
        c = s[i]
        if in_str:
            if c == "\\":
                i += 2
                continue
            if c == "(":
                in_str += 1
            elif c == ")":
                in_str -= 1
            i += 1
            continue
        if c == "(":
            in_str = 1
            i += 1
            continue
        if s.startswith("<<", i):
            depth += 1
            i += 2
            continue
        if s.startswith(">>", i):
            depth -= 1
            i += 2
            continue
        if c == "[":
            depth += 1
        elif c == "]":
            depth -= 1
        elif depth == 1 and s.startswith(k, i) and (i + len(k) >= n or not (s[i + len(k)].isalnum() or s[i + len(k)] in "_.-")):
            j = i + len(k)
            while j < n and s[j] in " \r\n\t":
                j += 1
            return _value_at(s, j)
        i += 1
    return None


def _value_at(s, j):
    n = len(s)
    if j >= n:
        return None
    if s.startswith("<<", j):
        depth = 0
        i = j
        while i < n:
            if s.startswith("<<", i):
                depth += 1
                i += 2
                continue
            if s.startswith(">>", i):
                depth -= 1
                i += 2
                if depth == 0:
                    return s[j:i]
                continue
            i += 1
        return s[j:]
    c = s[j]
    if c == "[":
        depth = 0
        i = j
        in_str = 0
        while i < n:
            ch = s[i]
            if in_str:
                if ch == "\\":
                    i += 2
                    continue
                if ch == "(":
                    in_str += 1
                elif ch == ")":
                    in_str -= 1
            elif ch == "(":
                in_str = 1
            elif ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
                if depth == 0:
                    return s[j:i + 1]
            i += 1
        return s[j:]
    if c == "(":
        depth = 0
        i = j
        while i < n:
            ch = s[i]
            if ch == "\\":
                i += 2
                continue
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return s[j:i + 1]
            i += 1
        return s[j:]
    m = re.match(r"\d+\s+\d+\s+R|/[^\s/<>\[\]()]*|<[0-9A-Fa-f\s]*>|[-+]?[\d.]+(?:[eE][-+]?\d+)?|true|false|null",
                 s[j:])
    return m.group(0) if m else None


def _pdf_str_value(v):
    """Decode a PDF literal or hex string (text form)."""
    if v is None:
        return None
    v = v.strip()
    if v.startswith("("):
        body = v[1:-1]
        out = []
        i = 0
        while i < len(body):
            c = body[i]
            if c == "\\" and i + 1 < len(body):
                n = body[i + 1]
                mp = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f", "(": "(", ")": ")", "\\": "\\"}
                if n in mp:
                    out.append(mp[n])
                    i += 2
                    continue
                m = re.match(r"[0-7]{1,3}", body[i + 1:])
                if m:
                    out.append(chr(int(m.group(0), 8)))
                    i += 1 + len(m.group(0))
                    continue
                i += 1
                continue
            out.append(c)
            i += 1
        s = "".join(out)
        if s.startswith("\xfe\xff"):
            try:
                s = s[2:].encode("latin-1").decode("utf-16-be")
            except Exception:
                pass
        return s
    if v.startswith("<") and not v.startswith("<<"):
        h = re.sub(r"\s", "", v[1:-1])
        if len(h) % 2:
            h += "0"
        b = bytes.fromhex(h)
        if b.startswith(b"\xfe\xff"):
            return b[2:].decode("utf-16-be", "replace")
        return b.decode("latin-1")
    if v.startswith("/"):
        return v[1:]
    return v


class _Resolver:
    def __init__(self, doc):
        self.doc = doc

    def deref(self, v):
        """value text -> (dictionary/array text) following indirect refs"""
        if v is None:
            return None
        r = _ref(v) if re.match(r"\s*\d+\s+\d+\s+R\s*$", v) else 0
        if r:
            try:
                return self.doc.xref_object(r, compressed=True)
            except Exception:
                return None
        return v


def _parse_view(res, vtext, index):
    v = View3D("View %d" % (index + 1))
    name = _pdf_str_value(_get(vtext, "XN")) or _pdf_str_value(_get(vtext, "IN"))
    if name:
        v.name = name
    ms = _get(vtext, "MS")
    if ms == "/U3D":
        p = res.deref(_get(vtext, "U3DPath"))
        if p is not None:
            if p.strip().startswith("["):
                parts = re.findall(r"\((?:\\.|[^\\)])*\)", p)
                v.u3d_path = _pdf_str_value(parts[-1]) if parts else None
            else:
                v.u3d_path = _pdf_str_value(p)
    c2w = res.deref(_get(vtext, "C2W"))
    if c2w is not None:
        vals = _nums(c2w)
        if len(vals) >= 12:
            v.c2w = c2w_from_pdf(vals)
    co = _get(vtext, "CO")
    if co is not None:
        v.co = _num(co)
    p = res.deref(_get(vtext, "P"))
    if p:
        sub = _get(p, "Subtype")
        if sub == "/O":
            v.ortho = True
            v.ortho_scale = _num(_get(p, "OS"), None)
        else:
            v.fov = _num(_get(p, "FOV"), None)
    bg = res.deref(_get(vtext, "BG"))
    if bg:
        c = _nums(res.deref(_get(bg, "C")) or "")
        if len(c) >= 3:
            v.bg = tuple(max(0.0, min(1.0, x)) for x in c[:3])
    rm = res.deref(_get(vtext, "RM"))
    if rm:
        s = _get(rm, "Subtype")
        if s:
            v.render_mode = s.lstrip("/")
    ls = res.deref(_get(vtext, "LS"))
    if ls:
        s = _get(ls, "Subtype")
        if s:
            v.lighting = s.lstrip("/")
    na = res.deref(_get(vtext, "NA"))
    if na:
        for nd in _split_top_dicts(na if na.strip().startswith("[") else "[" + na + "]"):
            nm = _pdf_str_value(_get(nd, "N"))
            if nm is None:
                continue
            ent = {}
            vis = _get(nd, "V")
            if vis is not None:
                ent["visible"] = vis.strip() != "false"
            op = _get(nd, "O")
            if op is not None:
                ent["opacity"] = _num(op, 1.0)
            mm = res.deref(_get(nd, "M"))
            if mm:
                vals = _nums(mm)
                if len(vals) >= 12:
                    M = np.eye(4)
                    M[:3, 0] = vals[0:3]
                    M[:3, 1] = vals[3:6]
                    M[:3, 2] = vals[6:9]
                    M[:3, 3] = vals[9:12]
                    ent["M"] = M
            v.nodes[nm] = ent
    sa = res.deref(_get(vtext, "SA"))
    if sa:
        for sd in _split_top_dicts(sa):
            c = _nums(res.deref(_get(sd, "C")) or "0 0 0")
            o = res.deref(_get(sd, "O")) or ""
            on = re.findall(r"null|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", o)
            # orientation: [null angle angle] etc -> rotations about x/y/z; default plane x = const
            normal = _section_normal(on)
            pc = _nums(res.deref(_get(sd, "PC")) or "")
            ic = _nums(res.deref(_get(sd, "IC")) or "")
            v.sections.append({
                "center": tuple((c + [0, 0, 0])[:3]),
                "normal": normal,
                "opacity": _num(_get(sd, "PO"), 0.5),
                "color": tuple(pc[1:4]) if len(pc) >= 4 else (1.0, 1.0, 1.0),
                "intersect": (_get(sd, "IV") or "false") == "true",
                "icolor": tuple(ic[1:4]) if len(ic) >= 4 else (0.0, 1.0, 0.0)})
    return v


def _section_normal(on):
    """/O orientation array of a cross section: [ax ay az] where one entry
    is null; the plane is initially the x=const plane rotated about the
    remaining axes (degrees)."""
    import math
    try:
        vals = [None if t == "null" else float(t) for t in on[:3]]
    except Exception:
        return (1.0, 0.0, 0.0)
    if len(vals) < 3:
        return (1.0, 0.0, 0.0)
    n = np.array([1.0, 0.0, 0.0])
    ax = [np.array([1.0, 0, 0]), np.array([0, 1.0, 0]), np.array([0, 0, 1.0])]
    for i, a in enumerate(vals):
        if a is None or a == 0:
            continue
        t = math.radians(a)
        k = ax[i]
        n = n * math.cos(t) + np.cross(k, n) * math.sin(t) + k * np.dot(k, n) * (1 - math.cos(t))
    return tuple(float(x) for x in n)


# ----------------------------------------------------------------- API
def find_3d(doc, pages=None):
    """All 3D annotations of a pymupdf Document (list of Annot3D)."""
    out = []
    res = _Resolver(doc)
    rng = range(len(doc)) if pages is None else pages
    for pno in rng:
        try:
            page = doc[pno]
            annots_val = doc.xref_get_key(page.xref, "Annots")
        except Exception:
            continue
        if annots_val[0] == "null":
            continue
        arr = annots_val[1]
        if annots_val[0] == "xref":
            arr = doc.xref_object(_ref(arr), compressed=True)
        for m in re.finditer(r"(\d+)\s+0\s+R", arr or ""):
            ax = int(m.group(1))
            try:
                if doc.xref_get_key(ax, "Subtype") != ("name", "/3D"):
                    continue
            except Exception:
                continue
            a = _read_annot(doc, res, page, ax)
            if a is not None:
                out.append(a)
    return out


def _read_annot(doc, res, page, ax):
    a = Annot3D()
    a.page = page.number
    a.xref = ax
    try:
        r = _nums(doc.xref_get_key(ax, "Rect")[1])
        import pymupdf
        if len(r) >= 4:
            x0, y0, x1, y1 = min(r[0], r[2]), min(r[1], r[3]), max(r[0], r[2]), max(r[1], r[3])
            rect = pymupdf.Rect(x0, y0, x1, y1) * page.transformation_matrix
            rect.normalize()
            a.rect = rect
    except Exception:
        a.rect = None
    a.title = (_pdf_str_value(_get(doc.xref_object(ax, compressed=True), "Contents")) or
               _pdf_str_value(_get(doc.xref_object(ax, compressed=True), "NM")) or "")
    t, v = _key(doc, ax, "3DD")
    sx = _ref(v) if t == "xref" else 0
    if not sx:
        return None
    # a 3D reference dictionary (/Type /3DRef /3DD ...) points to the stream
    try:
        if doc.xref_get_key(sx, "Type") == ("name", "/3DRef"):
            sx = _ref(doc.xref_get_key(sx, "3DD")[1])
    except Exception:
        pass
    if not sx or not doc.xref_is_stream(sx):
        return None
    a.stream_xref = sx
    st = doc.xref_get_key(sx, "Subtype")
    a.subtype = st[1].lstrip("/") if st[0] == "name" else "U3D"
    try:
        a.data = doc.xref_stream(sx)
    except Exception:
        return None
    if a.data[:3] == b"PRC":
        a.subtype = "PRC"
    elif a.data[:4] == b"U3D\0":
        a.subtype = "U3D"
    sobj = doc.xref_object(sx, compressed=True)
    va = res.deref(_get(sobj, "VA"))
    if va:
        for i, vd in enumerate(_split_top_dicts(va)):
            vt = res.deref(vd) if not vd.strip().startswith("<<") else vd
            try:
                a.views.append(_parse_view(res, vt, i))
            except Exception:
                pass
        # indirect view references inside the array
        if not a.views:
            for i, m in enumerate(re.finditer(r"(\d+)\s+0\s+R", va)):
                try:
                    a.views.append(_parse_view(res, doc.xref_object(int(m.group(1)), compressed=True), i))
                except Exception:
                    pass
    aobj = doc.xref_object(ax, compressed=True)
    dv = _get(aobj, "3DV") or _get(sobj, "DV")
    if dv is not None:
        dvs = dv.strip()
        if re.match(r"^\d+$", dvs):
            a.default_view = int(dvs)
        elif dvs.startswith("/"):
            name = dvs[1:]
            a.default_view = {"F": 0, "L": max(0, len(a.views) - 1)}.get(name, 0)
        elif dvs.startswith("("):
            nm = _pdf_str_value(dvs)
            for i, vw in enumerate(a.views):
                if vw.name == nm:
                    a.default_view = i
        else:
            vt = res.deref(dvs)
            if vt and vt.strip().startswith("<<"):
                try:
                    a.views.insert(0, _parse_view(res, vt, 0))
                    a.default_view = 0
                except Exception:
                    pass
    if a.default_view >= len(a.views):
        a.default_view = 0
    act = res.deref(_get(aobj, "3DA"))
    if act:
        aa = _get(act, "A")
        if aa:
            a.activation = aa.lstrip("/")
        a.toolbar = (_get(act, "TB") or "true") != "false"
        a.model_tree = (_get(act, "NP") or "false") == "true"
    a.has_js = _get(sobj, "OnInstantiate") is not None
    u = res.deref(_get(sobj, "3DU") or _get(aobj, "3DU"))
    if u:
        a.units = {"TSm": _num(_get(u, "TSm"), 1.0), "TSn": _pdf_str_value(_get(u, "TSn")),
                   "TU": _pdf_str_value(_get(u, "TU")), "USm": _num(_get(u, "USm"), 1.0),
                   "UU": _pdf_str_value(_get(u, "UU")), "DSm": _num(_get(u, "DSm"), 1.0),
                   "DU": _pdf_str_value(_get(u, "DU"))}
    return a


def has_3d(doc):
    """Fast check whether a document contains any 3D annotation."""
    try:
        for pno in range(len(doc)):
            page = doc[pno]
            t, v = doc.xref_get_key(page.xref, "Annots")
            if t == "null":
                continue
            if t == "xref":
                v = doc.xref_object(_ref(v), compressed=True)
            for m in re.finditer(r"(\d+)\s+0\s+R", v or ""):
                if doc.xref_get_key(int(m.group(1)), "Subtype") == ("name", "/3D"):
                    return True
    except Exception:
        return False
    return False


def _has_poster(doc, ax):
    """True when the annotation has a non-empty normal appearance (poster image)."""
    try:
        t, v = doc.xref_get_key(ax, "AP/N")
        if t != "xref":
            return False
        x = _ref(v)
        if not x or not doc.xref_is_stream(x):
            return False
        body = re.sub(rb"[\sqQ]+", b"", doc.xref_stream(x) or b"")
        return len(body) > 0
    except Exception:
        return False


def _page_has_poster_image(page, rect):
    """Some converters (ALIEF PDF PRO among them) leave the appearance empty and
    draw the poster as an image in the page content under the 3D annotation."""
    try:
        area = max(rect.width * rect.height, 1e-6)
        for info in page.get_image_info():
            b = info.get("bbox")
            if not b:
                continue
            import pymupdf
            ib = pymupdf.Rect(b)
            inter = ib & rect
            if inter.is_empty:
                continue
            ia = inter.width * inter.height
            if ia > 0.5 * area or ia > 0.8 * max(ib.width * ib.height, 1e-6) and ia > 0.25 * area:
                return True
    except Exception:
        return False
    return False


def page_3d_rects(doc, pno):
    """[(xref, rect, has_poster)] of the 3D annotations of a page (streams not read)."""
    out = []
    try:
        page = doc[pno]
        t, v = doc.xref_get_key(page.xref, "Annots")
        if t == "null":
            return out
        if t == "xref":
            v = doc.xref_object(_ref(v), compressed=True)
        import pymupdf
        for m in re.finditer(r"(\d+)\s+0\s+R", v or ""):
            ax = int(m.group(1))
            if doc.xref_get_key(ax, "Subtype") != ("name", "/3D"):
                continue
            r = _nums(doc.xref_get_key(ax, "Rect")[1])
            if len(r) < 4:
                continue
            rect = pymupdf.Rect(min(r[0], r[2]), min(r[1], r[3]), max(r[0], r[2]), max(r[1], r[3]))
            rect = rect * page.transformation_matrix
            rect.normalize()
            poster = _has_poster(doc, ax)
            if not poster:
                poster = _page_has_poster_image(page, rect)
            out.append((ax, rect, poster))
    except Exception:
        pass
    return out
