"""Software preview of a 3D model, drawn on the page for 3D annotations that
have no poster image (many converters leave the poster out and rely on the
viewer activating the model).  Rendering does not need OpenGL: triangles are
projected with numpy and rasterised with a z-buffer in the native helper
library (u3dclod), or painted back-to-front with QPainter as a fallback for
smaller models."""

import ctypes
import math
import threading

import numpy as np

from .scene3d import look_camera

ISO_DIR = (-1.0, 1.0, -1.0)
# eye-space light directions and colours (same as the "CAD" scheme of the 3D window)
_AMB = np.array([0.25, 0.25, 0.27])
_LIGHTS = [((0.3, 0.5, 1.0), (0.65, 0.65, 0.65)), ((-0.6, -0.2, 0.6), (0.3, 0.3, 0.32)),
           ((0.0, -0.8, 0.2), (0.12, 0.12, 0.14))]
PAINTER_LIMIT = 60000


def _perspective(fovy, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy) / 2)
    M = np.zeros((4, 4))
    M[0, 0] = f / aspect
    M[1, 1] = f
    M[2, 2] = (far + near) / (near - far)
    M[2, 3] = 2 * far * near / (near - far)
    M[3, 2] = -1
    return M


def _orthographic(h, aspect, near, far):
    M = np.eye(4)
    M[0, 0] = 2.0 / (h * aspect)
    M[1, 1] = 2.0 / h
    M[2, 2] = -2.0 / (far - near)
    M[2, 3] = -(far + near) / (far - near)
    return M


def _bbox(model):
    return model.bbox(visible_only=True)


def preview_camera(model, aspect):
    lo, hi = _bbox(model)
    r = float(np.linalg.norm(hi - lo) / 2) or 1.0
    ctr = (lo + hi) / 2
    cam = None
    if model.views and 0 <= model.default_view < len(model.views):
        v = model.views[model.default_view]
        if v.camera is not None:
            cam = v.camera.copy()
            if cam.ortho and not cam.ortho_h:
                cam.ortho_h = float(np.linalg.norm(hi - lo)) * 0.6
    if cam is None:
        cam = look_camera(ISO_DIR, (0, 0, 1), ctr, 10.0)
        k = 1.0 if aspect >= 1 else 1.0 / aspect
        cam.dist = r * k / math.sin(math.radians(cam.fov) / 2) * 1.04
        cam.ortho_h = 2 * r * k * 1.04
    return cam


def _proj(cam, model, aspect):
    lo, hi = model.bbox(False)
    r = float(np.linalg.norm(hi - lo) / 2) or 1.0
    ctr = (lo + hi) / 2
    dc = float(np.dot(cam.eye - ctr, cam.R[:, 2]))
    if cam.ortho:
        return _orthographic(cam.ortho_h or 1.0, aspect, dc - r * 2 - cam.dist, dc + r * 2)
    near = max(dc - r * 1.6, r * 1e-3, cam.dist * 1e-3)
    far = dc + r * 1.6
    if far <= near:
        far = near + r * 4
    return _perspective(cam.fov, aspect, near, far)


def _bg_of(model, bg):
    if bg is not None:
        return bg
    if model.views and 0 <= model.default_view < len(model.views):
        b = model.views[model.default_view].bg
        if b:
            return tuple(float(x) for x in b[:3])
    return (1.0, 1.0, 1.0)


def _gather(model):
    tris, nrms, cols = [], [], []
    for p in model.parts:
        if not p.visible or p.tri is None or not len(p.tri) or p.opacity <= 0.02:
            continue
        n = len(p.tri)
        tris.append(np.asarray(p.tri, np.float32))
        nrms.append(np.asarray(p.nrm, np.float32) if p.nrm is not None and len(p.nrm) == n
                    else np.zeros((n, 3), np.float32))
        if p.col is not None and len(p.col) == n:
            cols.append(np.asarray(p.col, np.float32)[:, :3])
        else:
            cols.append(np.tile(np.asarray(p.color[:3], np.float32), (n, 1)))
    if not tris:
        return None
    return np.concatenate(tris), np.concatenate(nrms), np.concatenate(cols)


def _native():
    try:
        from . import u3d
        lib = u3d._native()
    except Exception:
        return None
    if lib is None or not hasattr(lib, "r3d_raster"):
        return None
    f = lib.r3d_raster
    f.restype = ctypes.c_int
    f.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_void_p,
                  ctypes.c_void_p, ctypes.c_void_p]
    return f


def render(model, width, height, bg=None, supersample=2):
    """Render *model* to an RGBA uint8 array (height, width, 4), or None."""
    width, height = max(int(width), 8), max(int(height), 8)
    g = _gather(model)
    if g is None:
        return None
    P, N, C = g
    aspect = width / height
    cam = preview_camera(model, aspect)
    M = _proj(cam, model, aspect) @ cam.view_matrix()
    bgc = _bg_of(model, bg)
    raster = _native()
    ss = supersample if raster is not None else 1
    W, H = width * ss, height * ss
    h4 = np.c_[P.astype(np.float64), np.ones(len(P))] @ M.T
    w = h4[:, 3]
    bad = w <= 1e-9
    w = np.where(bad, 1.0, w)
    ndc = h4[:, :3] / w[:, None]
    sx = (ndc[:, 0] + 1) * 0.5 * W
    sy = (1 - ndc[:, 1]) * 0.5 * H
    sz = (ndc[:, 2] + 1) * 0.5
    sz[bad] = -1.0
    # lighting in eye space, two-sided
    Rt = cam.R.T
    ne = N.astype(np.float64) @ Rt.T
    ln = np.linalg.norm(ne, axis=1)
    zero = ln < 1e-12
    if zero.any():
        # flat normal of the triangle for missing normals
        t = P.reshape(-1, 3, 3).astype(np.float64)
        fn = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]) @ Rt.T
        fn = np.repeat(fn, 3, axis=0)
        ne[zero] = fn[zero]
        ln = np.linalg.norm(ne, axis=1)
    ne /= np.where(ln < 1e-12, 1.0, ln)[:, None]
    # view vector (eye space): towards the camera
    if cam.ortho:
        vv = np.tile([0.0, 0.0, 1.0], (len(P), 1))
    else:
        pe = (np.c_[P.astype(np.float64), np.ones(len(P))] @ cam.view_matrix().T)[:, :3]
        vv = -pe / (np.linalg.norm(pe, axis=1)[:, None] + 1e-30)
    flip = np.sum(ne * vv, axis=1) < 0
    ne[flip] *= -1
    light = np.tile(_AMB, (len(P), 1))
    for d, c in _LIGHTS:
        d = np.asarray(d, float)
        d /= np.linalg.norm(d)
        light += np.clip(ne @ d, 0, None)[:, None] * np.asarray(c)[None, :]
    # small specular highlight from the main light
    hv = np.asarray(_LIGHTS[0][0], float)
    hv /= np.linalg.norm(hv)
    spec = np.clip(ne @ hv, 0, None) ** 32 * 0.25
    rgb = np.clip(C.astype(np.float64) * light + spec[:, None], 0, 1)
    if raster is not None:
        img = np.empty((H, W, 4), np.uint8)
        img[:, :, 0] = int(bgc[0] * 255)
        img[:, :, 1] = int(bgc[1] * 255)
        img[:, :, 2] = int(bgc[2] * 255)
        img[:, :, 3] = 255
        zb = np.ones((H, W), np.float32)
        v = np.ascontiguousarray(np.c_[sx, sy, sz].astype(np.float32))
        col = np.empty((len(P), 4), np.uint8)
        col[:, :3] = (rgb * 255 + 0.5).astype(np.uint8)
        col[:, 3] = 255
        col = np.ascontiguousarray(col)
        if raster(W, H, len(P) // 3, v.ctypes.data, col.ctypes.data, img.ctypes.data, zb.ctypes.data) != 0:
            return None
        if ss > 1:
            img = img.reshape(height, ss, width, ss, 4).astype(np.uint16).mean(axis=(1, 3)).astype(np.uint8)
        return np.ascontiguousarray(img)
    return _painter(width, height, sx, sy, sz, rgb, bgc)


def _painter(width, height, sx, sy, sz, rgb, bgc):
    """QPainter fallback: painter's algorithm with flat colours."""
    ntri = len(sx) // 3
    if ntri > PAINTER_LIMIT:
        return None
    from PySide6.QtGui import QImage, QPainter, QColor, QPolygonF
    from PySide6.QtCore import QPointF, Qt
    img = QImage(width, height, QImage.Format_RGBA8888)
    img.fill(QColor(int(bgc[0] * 255), int(bgc[1] * 255), int(bgc[2] * 255)))
    z = sz.reshape(-1, 3)
    ok = (z >= 0).all(axis=1) & (z <= 1).all(axis=1)
    order = np.argsort(-z.mean(axis=1))
    xs, ys = sx.reshape(-1, 3), sy.reshape(-1, 3)
    cc = (rgb.reshape(-1, 3, 3).mean(axis=1) * 255).astype(int)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing, True)
    for t in order:
        if not ok[t]:
            continue
        c = QColor(int(cc[t, 0]), int(cc[t, 1]), int(cc[t, 2]))
        p.setPen(c)
        p.setBrush(c)
        p.drawPolygon(QPolygonF([QPointF(float(xs[t, k]), float(ys[t, k])) for k in range(3)]))
    p.end()
    ptr = img.constBits()
    arr = np.frombuffer(ptr, np.uint8, count=img.sizeInBytes()).reshape(height, img.bytesPerLine())
    return arr[:, :width * 4].reshape(height, width, 4).copy()


def to_qimage(arr):
    from PySide6.QtGui import QImage
    h, w = arr.shape[:2]
    return QImage(arr.tobytes(), w, h, w * 4, QImage.Format_RGBA8888).copy()


class PreviewCache:
    """Background preview generation for the page view.

    get(doc, page, xref, rect) returns a QImage or None; when the image is
    not ready yet a worker thread is started (one at a time) and
    *notify()* is invoked through the Qt event loop when it finishes."""

    MAX_BYTES = 400 * 1024 * 1024
    LONG_SIDE = 900

    def __init__(self, notify):
        from PySide6.QtCore import QObject, Signal

        class _Sig(QObject):
            done = Signal()

        self._sig = _Sig()
        self._sig.done.connect(notify)
        self._img = {}
        self._failed = set()
        self._queue = []
        self._busy = False
        self._lock = threading.Lock()

    def clear(self):
        with self._lock:
            self._img.clear()
            self._failed.clear()
            self._queue.clear()

    def get(self, doc, page, xref, rect):
        key = (xref, round(rect.width, 1), round(rect.height, 1))
        with self._lock:
            if key in self._img:
                return self._img[key]
            if key in self._failed or any(q[0] == key for q in self._queue):
                return None
        try:
            from . import pdf3d
            lst = [a for a in pdf3d.find_3d(doc, [page]) if a.xref == xref]
        except Exception:
            lst = []
        if not lst or len(lst[0].data or b"") > self.MAX_BYTES:
            with self._lock:
                self._failed.add(key)
            return None
        rw, rh = max(rect.width, 1.0), max(rect.height, 1.0)
        s = self.LONG_SIDE / max(rw, rh)
        size = (max(16, int(rw * s)), max(16, int(rh * s)))
        with self._lock:
            self._queue.append((key, lst[0], size))
        self._kick()
        return None

    def _kick(self):
        with self._lock:
            if self._busy or not self._queue:
                return
            self._busy = True
            key, annot, size = self._queue.pop(0)
        threading.Thread(target=self._work, args=(key, annot, size), daemon=True).start()

    def _work(self, key, annot, size):
        img = None
        try:
            from .scene3d import load_annotation
            model = load_annotation(annot)
            if model.parts:
                arr = render(model, size[0], size[1])
                if arr is not None:
                    img = to_qimage(arr)
        except Exception:
            img = None
        with self._lock:
            if img is None:
                self._failed.add(key)
            else:
                self._img[key] = img
            self._busy = False
        try:
            self._sig.done.emit()
        except RuntimeError:
            return
        self._kick()
