"""Automatic update without reinstalling the program.

The installed launcher (ALIEF_PDFEDITPRO.exe) and the Python runtime never change during an update. An update
is a small signed package:

    app-<ver>.zip   the 'aliefpdf' package, assets and the user guide of the new version

It is downloaded to %LOCALAPPDATA%\\AliefEnergy\\ALIEF_PDFEDITPRO\\app\\<ver> (no admin rights needed), checked
(Ed25519 signature of the notice + SHA-256 of the package) and used from the next start. The start-up script
(app\\ALIEF_PDFEDITPRO.py next to the launcher) picks the newest healthy version and falls back to the previous
one when a new version fails to start.

When a release needs a newer runtime (new Python libraries), the notice says so with "min_runtime" and the user
is asked to download the full installer instead.
"""
import base64
import hashlib
import io
import json
import os
import shutil
import sys
import threading
import time
import zipfile

from . import VERSION

PRODUCT = "ALIEF_PDFEDITPRO"
REPO = "aliefen/alief-pdfeditpro-update"
NOTICE = "alief_pdfeditpro_update.json"
URLS = ["https://raw.githubusercontent.com/%s/main/%s" % (REPO, NOTICE),
        "https://cdn.jsdelivr.net/gh/%s@main/%s" % (REPO, NOTICE)]
PAGE_URL = "https://github.com/%s" % REPO
PUBLIC_KEY_HEX = "5a61dc0780af9cc0b8d7cb491ff20da50bfe2bb6e313ff6d3d6db0b03c7d2685"
OFFLINE_EXT = ".pdfeditpro-update"
KEEP_VERSIONS = 3


def local_root():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "AliefEnergy", PRODUCT)


def vtuple(v):
    out = []
    for p in str(v).split("."):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def runtime_id():
    """Version of the installed runtime (written by the installer build). 1 when unknown / running from source."""
    for d in (sys.prefix, os.path.dirname(sys.executable)):
        try:
            with open(os.path.join(d, "RUNTIME_ID"), "r") as f:
                return int(f.read().strip())
        except Exception:
            pass
    return 1


def running_dir():
    """Folder of the running program version (contains 'aliefpdf')."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def running_from_update():
    return os.path.normcase(local_root()) in os.path.normcase(running_dir())


def updates_supported():
    """Automatic update only for the installed Windows program (not when running from source)."""
    if os.environ.get("ALIEF_FORCE_UPDATER"):
        return True
    return sys.platform == "win32" and os.path.exists(os.path.join(sys.prefix, "RUNTIME_ID"))


# ------------------------------------------------------------------------------------------- Ed25519 (RFC 8032)
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _inv(x):
    return pow(x, _p - 2, _p)


def _xrec(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p:
        x = x * _I % _p
    if x % 2:
        x = _p - x
    return x


_By = 4 * _inv(5) % _p
_Bx = _xrec(_By)
_B = (_Bx, _By, 1, _Bx * _By % _p)


def _add(P, Q):
    x1, y1, z1, t1 = P
    x2, y2, z2, t2 = Q
    A = (y1 - x1) * (y2 - x2) % _p
    B = (y1 + x1) * (y2 + x2) % _p
    C = t1 * 2 * _d * t2 % _p
    D = z1 * 2 * z2 % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _enc(P):
    x, y, z, t = P
    zi = _inv(z)
    x = x * zi % _p
    y = y * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _dec(s):
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _xrec(y)
    if (x & 1) != sign:
        x = _p - x
    P = (x, y, 1, x * y % _p)
    if (-x * x + y * y - 1 - _d * x * x * y * y) % _p:
        raise ValueError("invalid point")
    return P


def _h(m):
    return int.from_bytes(hashlib.sha512(m).digest(), "little")


def keypair(seed=None):
    seed = seed or os.urandom(32)
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return seed, _enc(_mul(a, _B))


def sign(seed, msg):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    A = _enc(_mul(a, _B))
    r = _h(h[32:] + msg) % _q
    R = _enc(_mul(r, _B))
    S = (r + _h(R + A + msg) * a) % _q
    return R + int.to_bytes(S, 32, "little")


def verify(pub, msg, sig):
    try:
        if len(sig) != 64:
            return False
        R = _dec(sig[:32])
        A = _dec(pub)
        S = int.from_bytes(sig[32:], "little")
        if S >= _q:
            return False
        h = _h(sig[:32] + pub + msg) % _q
        return _enc(_mul(S, _B)) == _enc(_add(R, _mul(h, A)))
    except Exception:
        return False


def canonical(notice):
    d = {k: v for k, v in notice.items() if k != "sig"}
    return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()


def notice_valid(notice, pub_hex=None):
    pub = bytes.fromhex(pub_hex or PUBLIC_KEY_HEX)
    try:
        return notice.get("product") == PRODUCT and verify(pub, canonical(notice), base64.b64decode(notice.get("sig", "")))
    except Exception:
        return False


# ------------------------------------------------------------------------------------------- state
def _state_path():
    return os.path.join(local_root(), "update_state.json")


def load_state():
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            s = json.load(f)
            return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def save_state(**kw):
    s = load_state()
    s.update(kw)
    try:
        os.makedirs(local_root(), exist_ok=True)
        with open(_state_path(), "w", encoding="utf-8") as f:
            json.dump(s, f, indent=1)
    except Exception:
        pass
    return s


def _boot_path():
    return os.path.join(local_root(), "boot.json")


def mark_healthy():
    """Called once the program has started properly: the running version is good."""
    if not running_from_update():
        return
    ver = os.path.basename(running_dir())
    try:
        with open(_boot_path(), "r", encoding="utf-8") as f:
            b = json.load(f)
    except Exception:
        b = {}
    b[ver] = {"fails": 0, "good": True, "last": time.strftime("%Y-%m-%d %H:%M")}
    try:
        with open(_boot_path(), "w", encoding="utf-8") as f:
            json.dump(b, f, indent=1)
    except Exception:
        pass


# ------------------------------------------------------------------------------------------- network
def _get(url, timeout=20, progress=None, cancel=None):
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "%s-updater/%s" % (PRODUCT, VERSION),
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        total = int(r.headers.get("Content-Length") or 0)
        buf = bytearray()
        while True:
            if cancel and cancel():
                raise RuntimeError("cancelled")
            chunk = r.read(65536)
            if not chunk:
                break
            buf += chunk
            if progress:
                progress(len(buf), total)
        return bytes(buf)


def fetch_notice():
    last = None
    for u in URLS:
        try:
            data = _get(u + ("?t=%d" % int(time.time()) if "raw.githubusercontent" in u else ""), 15)
            return json.loads(data.decode("utf-8"))
        except Exception as ex:
            last = ex
    raise RuntimeError("update server not reachable (%s)" % last)


def installed_versions():
    root = os.path.join(local_root(), "app")
    out = []
    if os.path.isdir(root):
        for v in os.listdir(root):
            if os.path.exists(os.path.join(root, v, "ok.flag")):
                out.append(v)
    return sorted(out, key=vtuple)


def needs_installer(notice):
    return int(notice.get("min_runtime", 1)) > runtime_id()


def _safe_extract(z, dst):
    base = os.path.abspath(dst)
    for m in z.infolist():
        target = os.path.abspath(os.path.join(dst, m.filename))
        if not (target == base or target.startswith(base + os.sep)):
            raise RuntimeError("invalid file name in update package: %s" % m.filename)
    z.extractall(dst)


def install_packages(notice, blobs):
    """blobs: {name: bytes}. Extracts the app package; returns the target folder."""
    ver = notice["version"]
    root = local_root()
    appdir = os.path.join(root, "app", ver)
    tmp = appdir + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    for pk in notice["packages"]:
        data = blobs[pk["name"]]
        if len(data) != pk["size"] or hashlib.sha256(data).hexdigest() != pk["sha256"]:
            shutil.rmtree(tmp, ignore_errors=True)
            raise RuntimeError("package %s is damaged (download again)" % pk["name"])
        _safe_extract(zipfile.ZipFile(io.BytesIO(data)), tmp)
    if not os.path.isfile(os.path.join(tmp, "aliefpdf", "__init__.py")):
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("update package is incomplete")
    with open(os.path.join(tmp, "version.json"), "w", encoding="utf-8") as f:
        json.dump({"version": ver, "min_runtime": int(notice.get("min_runtime", 1)), "date": notice.get("date", ""),
                   "installed": time.strftime("%Y-%m-%d %H:%M")}, f)
    shutil.rmtree(appdir, ignore_errors=True)
    os.replace(tmp, appdir)
    with open(os.path.join(appdir, "ok.flag"), "w") as f:
        f.write(ver)
    cleanup()
    return appdir


def cleanup():
    """Keep the newest versions only (never the running one)."""
    root = os.path.join(local_root(), "app")
    running = os.path.normcase(running_dir())
    for old in installed_versions()[:-KEEP_VERSIONS]:
        d = os.path.join(root, old)
        if os.path.normcase(d) != running:
            shutil.rmtree(d, ignore_errors=True)
    if os.path.isdir(root):
        for v in os.listdir(root):
            if v.endswith(".tmp"):
                shutil.rmtree(os.path.join(root, v), ignore_errors=True)


def _cache_dir():
    return os.path.join(local_root(), "cache")


def _cached(pk):
    """Shared packages (everything except 'app', e.g. the Qt OpenGL files of the 3D review) are kept after
    an update, so a later update that lists the same package does not download it again."""
    p = os.path.join(_cache_dir(), "%s.zip" % pk["sha256"])
    try:
        if os.path.getsize(p) != pk["size"]:
            return None
        with open(p, "rb") as f:
            data = f.read()
        return data if hashlib.sha256(data).hexdigest() == pk["sha256"] else None
    except OSError:
        return None


def _store_cache(notice, blobs):
    d = _cache_dir()
    keep = set()
    try:
        for pk in notice["packages"]:
            if pk["name"] == "app" or pk["name"] not in blobs:
                continue
            fn = "%s.zip" % pk["sha256"]
            keep.add(fn)
            p = os.path.join(d, fn)
            if not os.path.exists(p):
                os.makedirs(d, exist_ok=True)
                with open(p + ".tmp", "wb") as f:
                    f.write(blobs[pk["name"]])
                os.replace(p + ".tmp", p)
        if os.path.isdir(d):
            for fn in os.listdir(d):
                if fn not in keep:
                    try:
                        os.remove(os.path.join(d, fn))
                    except OSError:
                        pass
    except OSError:
        pass


def download_and_install(notice, progress=None, cancel=None):
    blobs = {}
    total = sum(p["size"] for p in notice["packages"])
    done = 0
    for pk in notice["packages"]:
        base = done
        data = _cached(pk) if pk["name"] != "app" else None
        if data is None:
            cb = (lambda a, b, base=base: progress(base + a, total)) if progress else None
            data = _get(pk["url"], 120, cb, cancel)
        blobs[pk["name"]] = data
        done += pk["size"]
        if progress:
            progress(done, total)
    target = install_packages(notice, blobs)
    _store_cache(notice, blobs)
    return target


def install_offline(path):
    """Offline update file (*.pdfeditpro-update = zip with the notice and the packages)."""
    with zipfile.ZipFile(path) as z:
        notice = json.loads(z.read(NOTICE))
        if not notice_valid(notice):
            raise RuntimeError("the signature of this update file is not valid")
        if needs_installer(notice):
            raise RuntimeError("version %s needs the full installer (new program runtime)" % notice.get("version"))
        blobs = {pk["name"]: z.read(pk["file"]) for pk in notice["packages"]}
    save_state(last_notice=notice)
    target = install_packages(notice, blobs)
    _store_cache(notice, blobs)
    return notice, target


def pending_version():
    """Newest downloaded version that is newer than the running one (used after the next start), or None."""
    vers = [v for v in installed_versions() if vtuple(v) > vtuple(VERSION)]
    return vers[-1] if vers else None


class Checker:
    """Background check. on_result(status, notice, info) is called in the worker thread.

    status: offline | badsig | latest | installer | available | ready | failed
    """

    def __init__(self, on_result, auto_install=True, progress=None):
        self.on_result = on_result
        self.auto = auto_install
        self.progress = progress
        self.cancelled = False

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            n = fetch_notice()
        except Exception as ex:
            self.on_result("offline", None, str(ex))
            return
        save_state(last_check=time.strftime("%Y-%m-%d %H:%M"), latest=n.get("version"))
        if not notice_valid(n):
            self.on_result("badsig", n, "signature check failed")
            return
        save_state(last_notice=n)
        if vtuple(n.get("version")) <= vtuple(VERSION):
            self.on_result("latest", n, "")
            return
        if needs_installer(n):
            self.on_result("installer", n, "")
            return
        if n.get("version") in installed_versions():
            self.on_result("ready", n, "already downloaded")
            return
        if not self.auto:
            self.on_result("available", n, "")
            return
        try:
            d = download_and_install(n, self.progress, lambda: self.cancelled)
            self.on_result("ready", n, d)
        except Exception as ex:
            self.on_result("failed", n, str(ex))
