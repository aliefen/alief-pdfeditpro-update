"""Navigation pane (Pages, Bookmarks, Comments, Measure, Search, Layers, Attachments).

A narrow button strip always stays on the left of the document area. By default
the pane is in *auto-hide* mode: clicking (or resting the mouse on) a button slides
the panel out over the document, and it hides again when the mouse leaves it,
when the document is clicked, or with Esc. The pin button docks the panel
permanently beside the document (the previous behaviour)."""

import time

from PySide6.QtCore import Qt, QTimer, QEvent, QObject, QPoint, QRect, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QCursor, QColor
from PySide6.QtWidgets import (QApplication, QFrame, QWidget, QVBoxLayout, QHBoxLayout, QToolButton, QLabel,
                               QGraphicsDropShadowEffect, QSizePolicy, QSplitter)

from . import theme
from .settings import settings

STRIP_W = 36
MIN_W, DEF_W = 200, 270
HOVER_OPEN_MS = 450
HOVER_SWITCH_MS = 250
LEAVE_HIDE_MS = 650

STYLE = """
QFrame#NavStrip { background: #E9EEF5; border-right: 1px solid %(border)s; }
QFrame#NavStrip QToolButton { border: none; border-left: 3px solid transparent; padding: 6px 4px; margin: 0; }
QFrame#NavStrip QToolButton:hover { background: #DCE5F1; }
QFrame#NavStrip QToolButton:checked { background: white; border-left: 3px solid %(blue)s; }
QFrame#NavPanel { background: white; border-right: 1px solid %(border)s; }
QWidget#NavHeader { background: #E4EAF2; border-bottom: 1px solid %(border)s; }
QWidget#NavHeader QLabel { font-weight: 600; color: %(navy)s; }
QWidget#NavHeader QToolButton { border: none; padding: 2px; border-radius: 3px; }
QWidget#NavHeader QToolButton:hover { background: #D2DCEA; }
QWidget#NavGrip:hover { background: #C9D6E8; }
"""


class _Grip(QWidget):
    """Right-edge handle for resizing the panel in auto-hide mode."""

    def __init__(self, ctl, parent):
        super().__init__(parent)
        self.setObjectName("NavGrip")
        self.ctl = ctl
        self.setCursor(Qt.SizeHorCursor)
        self.setFixedWidth(5)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._x = None
        self._w = 0

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._x = e.globalPosition().x()
            self._w = self.ctl.width

    def mouseMoveEvent(self, e):
        if self._x is not None:
            self.ctl.set_width(self._w + e.globalPosition().x() - self._x)

    def mouseReleaseEvent(self, e):
        self._x = None
        self.ctl.save()


class NavPanel(QFrame):
    def __init__(self, ctl, side):
        super().__init__()
        self.setObjectName("NavPanel")
        self.ctl = ctl
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        col = QWidget()
        v = QVBoxLayout(col)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        head = QWidget()
        head.setObjectName("NavHeader")
        head.setAttribute(Qt.WA_StyledBackground, True)
        h = QHBoxLayout(head)
        h.setContentsMargins(8, 3, 3, 3)
        h.setSpacing(2)
        self.title = QLabel("Pages")
        h.addWidget(self.title, 1)
        self.pin_btn = QToolButton()
        self.pin_btn.setCheckable(True)
        self.pin_btn.clicked.connect(lambda on: ctl.set_pinned(on))
        h.addWidget(self.pin_btn)
        self.close_btn = QToolButton()
        self.close_btn.setIcon(theme.icon("close"))
        self.close_btn.setToolTip("Hide the panel")
        self.close_btn.clicked.connect(ctl.hide)
        h.addWidget(self.close_btn)
        v.addWidget(head)
        v.addWidget(side, 1)
        lay.addWidget(col, 1)
        self.grip = _Grip(ctl, self)
        lay.addWidget(self.grip)
        self.update_pin(False)

    def update_pin(self, pinned):
        self.pin_btn.blockSignals(True)
        self.pin_btn.setChecked(pinned)
        self.pin_btn.blockSignals(False)
        self.pin_btn.setIcon(theme.icon("pin" if pinned else "pin-outline", accent=theme.BLUE if pinned else None))
        self.pin_btn.setToolTip("Unpin: hide the panel automatically" if pinned else
                                "Pin: keep the panel open beside the document")
        self.grip.setVisible(not pinned)


class NavController(QObject):
    """Owns the strip, the panel and the auto-hide logic.

    host: the widget that holds strip + document area (the panel floats over it in auto-hide mode)
    splitter: QSplitter [panel (pinned only), document area]"""

    def __init__(self, main, side, items, host, host_layout, splitter):
        super().__init__(main)
        self.main = main
        self.side = side
        self.items = items                 # [(key, title, icon, widget)]
        self.host = host
        self.splitter = splitter
        self.pinned = bool(settings().get("nav_pinned", False))
        self.width = int(settings().get("nav_width", DEF_W) or DEF_W)
        self._open = False
        self._entered = False
        self._outside_ms = 0
        self._closed_at = {}
        self._hover_key = None
        host.setStyleSheet(STYLE % {"border": theme.BORDER, "blue": theme.BLUE, "navy": theme.NAVY})
        side.tabBar().hide()
        # ---- strip
        self.strip = QFrame()
        self.strip.setObjectName("NavStrip")
        self.strip.setFixedWidth(STRIP_W)
        sv = QVBoxLayout(self.strip)
        sv.setContentsMargins(0, 4, 0, 4)
        sv.setSpacing(1)
        self.buttons = {}
        for key, title, icon, w in items:
            b = QToolButton()
            b.setIcon(theme.icon(icon))
            b.setCheckable(True)
            b.setToolTip(title)
            b.setFixedSize(STRIP_W, 34)
            b.clicked.connect(lambda c=False, k=key: self._clicked(k))
            b.installEventFilter(self)
            sv.addWidget(b)
            self.buttons[key] = b
        sv.addStretch(1)
        self.strip_pin = QToolButton()
        self.strip_pin.setFixedSize(STRIP_W, 30)
        self.strip_pin.setCheckable(True)
        self.strip_pin.clicked.connect(lambda on: self.set_pinned(on))
        sv.addWidget(self.strip_pin)
        host_layout.insertWidget(0, self.strip)
        # ---- panel
        self.panel = NavPanel(self, side)
        self.panel.setMinimumWidth(MIN_W)
        self._shadow = None
        self._anim = QPropertyAnimation(self.panel, b"pos", self)
        self._anim.setDuration(140)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.finished.connect(self._anim_done)
        self._hiding = False
        side.currentChanged.connect(self._tab_changed)
        self.splitter.splitterMoved.connect(self._splitter_moved)
        self._timer = QTimer(self)
        self._timer.setInterval(120)
        self._timer.timeout.connect(self._tick)
        self._hover_timer = QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.timeout.connect(self._hover_fire)
        host.installEventFilter(self)
        QApplication.instance().installEventFilter(self)
        self._apply_mode(initial=True)

    # ------------------------------------------------------------ state
    def current_key(self):
        w = self.side.currentWidget()
        for key, title, icon, ww in self.items:
            if ww is w:
                return key
        return None

    def is_shown(self, key=None):
        vis = self._open if not self.pinned else self.panel.isVisible()
        return vis and (key is None or key == self.current_key())

    def recently_visible(self, key, secs=30.0):
        """True when the panel *key* is shown now or was hidden less than *secs* ago
        (e.g. pages selected in the auto-hidden thumbnails, then a ribbon command)."""
        if self.is_shown(key):
            return True
        t = self._closed_at.get(key)
        return t is not None and time.monotonic() - t < secs

    def save(self):
        settings().set("nav_pinned", self.pinned)
        settings().set("nav_width", int(self.width))

    def set_width(self, w):
        hw = max(self.host.width(), MIN_W + STRIP_W + 100)
        self.width = int(max(MIN_W, min(w, hw * 0.7)))
        if not self.pinned and self._open:
            self._place()

    # ------------------------------------------------------------ public actions
    def show(self, key=None):
        if key is not None:
            self.side.setCurrentWidget(dict((k, w) for k, t, i, w in self.items)[key])
        if self.pinned:
            self.panel.show()
            self._sync_buttons()
            sizes = self.splitter.sizes()
            if sizes and sizes[0] < MIN_W:
                self.splitter.setSizes([self.width, max(100, sum(sizes) - self.width)])
        else:
            self._slide_in()
        w = self.side.currentWidget()
        if w is not None and hasattr(w, "refresh"):
            w.refresh()

    def hide(self):
        key = self.current_key()
        if self.pinned:
            if self.panel.isVisible():
                self._closed_at[key] = time.monotonic()
            self.panel.hide()
            self._sync_buttons()
            return
        self._slide_out()

    def toggle(self):
        if self.is_shown():
            self.hide()
        else:
            self.show()

    def set_pinned(self, on):
        on = bool(on)
        if on == self.pinned:
            self._sync_pin()
            return
        was_open = self.is_shown()
        if not on:
            sizes = self.splitter.sizes()
            if sizes and sizes[0] >= MIN_W:
                self.width = sizes[0]
        self._anim.stop()
        self._open = False
        self._timer.stop()
        self.pinned = on
        self._apply_mode()
        if on:
            self.show()
        elif was_open:
            self._slide_in(animate=False)
        self.save()

    # ------------------------------------------------------------ modes
    def _apply_mode(self, initial=False):
        if self.pinned:
            self.panel.setGraphicsEffect(None)
            self.panel.setParent(None)
            self.splitter.insertWidget(0, self.panel)
            self.splitter.setCollapsible(0, False)
            self.panel.show()
            QTimer.singleShot(0, lambda: self.splitter.setSizes(
                [self.width, max(100, sum(self.splitter.sizes()) - self.width)]))
        else:
            self.panel.hide()
            self.panel.setParent(self.host)
            sh = QGraphicsDropShadowEffect(self.panel)
            sh.setBlurRadius(18)
            sh.setOffset(3, 0)
            sh.setColor(QColor(0, 0, 0, 70))
            self.panel.setGraphicsEffect(sh)
            self.panel.hide()
        self._sync_pin()
        self._sync_buttons()

    def _sync_pin(self):
        self.panel.update_pin(self.pinned)
        self.strip_pin.blockSignals(True)
        self.strip_pin.setChecked(self.pinned)
        self.strip_pin.blockSignals(False)
        self.strip_pin.setIcon(theme.icon("pin" if self.pinned else "pin-outline",
                                          accent=theme.BLUE if self.pinned else None))
        self.strip_pin.setToolTip("Navigation pane is pinned (click: auto-hide)" if self.pinned else
                                  "Navigation pane hides automatically (click: pin it open)")

    def _sync_buttons(self):
        cur = self.current_key() if self.is_shown() else None
        for k, b in self.buttons.items():
            b.blockSignals(True)
            b.setChecked(k == cur)
            b.blockSignals(False)
        for k, t, i, w in self.items:
            if k == self.current_key():
                self.panel.title.setText(t)

    def _tab_changed(self, i):
        self._sync_buttons()

    def _splitter_moved(self, pos, index):
        if self.pinned:
            sizes = self.splitter.sizes()
            if sizes and sizes[0] >= MIN_W:
                self.width = sizes[0]
                settings().set("nav_width", int(self.width))

    # ------------------------------------------------------------ auto-hide panel
    def _target_rect(self):
        h = self.host.height()
        return QRect(self.strip.width(), 0, self.width, h)

    def _place(self):
        r = self._target_rect()
        self.panel.setGeometry(r)
        self.strip.raise_()

    def _slide_in(self, animate=True):
        self._hiding = False
        r = self._target_rect()
        already = self._open and self.panel.isVisible()
        self._open = True
        self._entered = self._cursor_inside()
        self._outside_ms = 0
        self.panel.resize(r.size())
        if not already:
            self._anim.stop()
            start = QPoint(r.x() - min(r.width(), 120), 0)
            self.panel.move(start if animate else r.topLeft())
            self.panel.show()
            self.panel.raise_()
            self.strip.raise_()
            if animate:
                self._anim.setStartValue(start)
                self._anim.setEndValue(r.topLeft())
                self._anim.start()
        else:
            self._place()
        self._timer.start()
        self._sync_buttons()

    def _slide_out(self):
        if not self._open:
            return
        key = self.current_key()
        self._closed_at[key] = time.monotonic()
        self._open = False
        self._timer.stop()
        fw = QApplication.focusWidget()
        if fw is not None and self.panel.isAncestorOf(fw):
            v = self.main.view() if hasattr(self.main, "view") else None
            if v is not None:
                v.setFocus()
        self._anim.stop()
        self._hiding = True
        r = self._target_rect()
        self._anim.setStartValue(self.panel.pos())
        self._anim.setEndValue(QPoint(r.x() - min(r.width(), 120), 0))
        self._anim.start()
        self._sync_buttons()

    def _anim_done(self):
        if self._hiding:
            self._hiding = False
            self.panel.hide()

    def _cursor_inside(self):
        g = QCursor.pos()
        for w in (self.panel, self.strip):
            if w.isVisible() and w.rect().contains(w.mapFromGlobal(g)):
                return True
        return False

    def _busy(self):
        app = QApplication.instance()
        return (QApplication.mouseButtons() != Qt.NoButton or app.activePopupWidget() is not None
                or app.activeModalWidget() is not None)

    def _tick(self):
        if self.pinned or not self._open:
            self._timer.stop()
            return
        if self._busy():
            self._outside_ms = 0
            return
        if self._cursor_inside():
            self._entered = True
            self._outside_ms = 0
            return
        fw = QApplication.focusWidget()
        if fw is not None and self.panel.isAncestorOf(fw) and fw.inherits("QLineEdit"):
            return          # typing in a panel field (search, page label...)
        if self._entered:
            self._outside_ms += self._timer.interval()
            if self._outside_ms >= LEAVE_HIDE_MS:
                self._slide_out()

    # ------------------------------------------------------------ events
    def _clicked(self, key):
        self._hover_timer.stop()
        if self.is_shown(key):
            self.hide()
        else:
            self.show(key)
            self._entered = True

    def _hover_fire(self):
        k = self._hover_key
        if k is None or self.pinned or self._busy():
            return
        b = self.buttons.get(k)
        if b is None or not b.rect().contains(b.mapFromGlobal(QCursor.pos())):
            return
        if not self._open:
            self.show(k)
            self._entered = True
        elif k != self.current_key():
            self.show(k)

    def eventFilter(self, obj, ev):
        t = ev.type()
        if t == QEvent.Enter and obj in self.buttons.values():
            if not self.pinned:
                self._hover_key = next(k for k, b in self.buttons.items() if b is obj)
                self._hover_timer.start(HOVER_SWITCH_MS if self._open else HOVER_OPEN_MS)
        elif t == QEvent.Leave and obj in self.buttons.values():
            self._hover_timer.stop()
        elif obj is self.host and t == QEvent.Resize:
            if not self.pinned and self._open:
                self._place()
        elif t == QEvent.MouseButtonPress and self._open and not self.pinned:
            if isinstance(obj, QWidget) and obj.window() is self.main:
                if not (obj is self.panel or self.panel.isAncestorOf(obj) or obj is self.strip
                        or self.strip.isAncestorOf(obj)):
                    self._slide_out()
        elif t == QEvent.KeyPress and self._open and not self.pinned and ev.key() == Qt.Key_Escape:
            fw = QApplication.focusWidget()
            if fw is None or self.panel.isAncestorOf(fw) or fw is self.main.view():
                self._slide_out()
        return False
