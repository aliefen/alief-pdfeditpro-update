"""PDF conversion engines (no Qt): Word, Excel, images, DXF, SVG, text, HTML, PowerPoint, CSV, images->PDF.

Every function takes a pymupdf.Document, a list of 0-based page indices, an output path
and an optional progress(i, n, message) callback that returns False to cancel.
"""
import io
import math
import os
import re
import tempfile

import pymupdf

PT_TO_MM = 25.4 / 72.0


class Cancelled(Exception):
    pass


def _prog(progress, i, n, msg=""):
    if progress is not None and progress(i, n, msg) is False:
        raise Cancelled()


def _out_name(out_path, page, multi, ext=None):
    base, e = os.path.splitext(out_path)
    ext = ext or e
    return "%s_p%d%s" % (base, page + 1, ext) if multi else base + ext


# ===================================================================== Word
def to_word(doc, pages, out_path, progress=None, mode="flow", dpi=200):
    """mode 'flow': editable Word (pdf2docx layout analysis); 'exact': each page as an image (looks identical)."""
    if mode == "exact":
        from docx import Document
        from docx.shared import Mm
        from docx.enum.section import WD_ORIENT
        d = Document()
        first = True
        for k, i in enumerate(pages):
            _prog(progress, k, len(pages), "Page %d" % (i + 1))
            page = doc.load_page(i)
            w_mm, h_mm = page.rect.width * PT_TO_MM, page.rect.height * PT_TO_MM
            sec = d.sections[0] if first else d.add_section()
            first = False
            sec.page_width, sec.page_height = Mm(w_mm), Mm(h_mm)
            sec.orientation = WD_ORIENT.LANDSCAPE if w_mm > h_mm else WD_ORIENT.PORTRAIT
            for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
                setattr(sec, side, Mm(0))
            sec.header_distance = sec.footer_distance = Mm(0)
            pix = page.get_pixmap(dpi=dpi, alpha=False)
            bio = io.BytesIO(pix.tobytes("png"))
            par = d.add_paragraph() if k else (d.paragraphs[0] if d.paragraphs else d.add_paragraph())
            par.paragraph_format.space_before = par.paragraph_format.space_after = 0
            par.add_run().add_picture(bio, width=Mm(w_mm - 0.5))
        d.save(out_path)
        _prog(progress, len(pages), len(pages), "Done")
        return [out_path]
    from pdf2docx import Converter
    tmp = None
    src = doc.name if doc.name and os.path.exists(doc.name) and not doc.is_encrypted else None
    if src is None:
        fd, tmp = tempfile.mkstemp(suffix=".pdf")
        os.close(fd)
        doc.save(tmp, encryption=pymupdf.PDF_ENCRYPT_NONE)
        src = tmp
    _prog(progress, 0, len(pages), "Analysing page layout…")
    try:
        cv = Converter(src)
        try:
            cv.convert(out_path, pages=list(pages))
        finally:
            cv.close()
    finally:
        if tmp:
            try:
                os.remove(tmp)
            except Exception:
                pass
    _prog(progress, len(pages), len(pages), "Done")
    return [out_path]


# ==================================================================== Excel
def _num(s):
    t = (s or "").strip()
    if not t:
        return None
    if re.search(r"\d\s+\d", t):
        return None
    t2 = t.replace("\u00a0", "").replace(" ", "")
    if re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?", t2):
        t2 = t2.replace(",", "")
    elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+(,\d+)?", t2):
        t2 = t2.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"-?\d+,\d+", t2):
        t2 = t2.replace(",", ".")
    try:
        if re.fullmatch(r"-?\d+", t2):
            return int(t2)
        if re.fullmatch(r"-?\d*\.\d+([eE][-+]?\d+)?", t2):
            return float(t2)
    except Exception:
        pass
    return None


def _layout_rows(page):
    """Fallback table: group words into rows / columns by position."""
    words = page.get_text("words", sort=True)
    if not words:
        return []
    words.sort(key=lambda w: (round((w[1] + w[3]) / 2 / 3), w[0]))
    rows, cur, cy = [], [], None
    for w in words:
        y = (w[1] + w[3]) / 2
        h = w[3] - w[1]
        if cy is None or abs(y - cy) <= max(2.0, h * 0.45):
            cur.append(w)
            cy = y if cy is None else (cy + y) / 2
        else:
            rows.append(sorted(cur, key=lambda q: q[0]))
            cur, cy = [w], y
    if cur:
        rows.append(sorted(cur, key=lambda q: q[0]))
    # merge words into phrases when the gap is small
    phr_rows = []
    for r in rows:
        phr = []
        for w in r:
            if phr and w[0] - phr[-1][2] < (w[3] - w[1]) * 0.38:
                p = phr[-1]
                phr[-1] = [p[0], min(p[1], w[1]), w[2], max(p[3], w[3]), p[4] + " " + w[4]]
            else:
                phr.append([w[0], w[1], w[2], w[3], w[4]])
        phr_rows.append(phr)
    # column boundaries from x-starts
    xs = sorted(p[0] for r in phr_rows for p in r)
    cols = []
    for x in xs:
        if not cols or x - cols[-1][-1] > 8:
            cols.append([x])
        else:
            cols[-1].append(x)
    starts = [sum(c) / len(c) for c in cols]
    out = []
    for r in phr_rows:
        line = [""] * len(starts)
        for p in r:
            k = min(range(len(starts)), key=lambda j: abs(starts[j] - p[0]))
            line[k] = (line[k] + " " + p[4]).strip()
        out.append(line)
    return out


def _cell_text(words, bbox):
    """Text of a table cell from page words (keeps spaces and punctuation, multi-line)."""
    x0, y0, x1, y1 = bbox
    inside = [w for w in words if x0 - 0.5 <= (w[0] + w[2]) / 2 <= x1 + 0.5 and y0 - 0.5 <= (w[1] + w[3]) / 2 <= y1 + 0.5]
    if not inside:
        return ""
    inside.sort(key=lambda w: (round((w[1] + w[3]) / 2 / 2.5), w[0]))
    lines, cur, cy = [], [], None
    for w in inside:
        y = (w[1] + w[3]) / 2
        if cy is None or abs(y - cy) <= max(1.5, (w[3] - w[1]) * 0.5):
            cur.append(w[4])
            cy = y if cy is None else cy
        else:
            lines.append(" ".join(cur))
            cur, cy = [w[4]], y
    if cur:
        lines.append(" ".join(cur))
    return "\n".join(lines)


def _table_grid(page, t, words):
    """List of rows; each row a list of (text, span) using the detected cell boxes."""
    grid = []
    for row in t.rows:
        cells = row.cells
        out = []
        ci = 0
        while ci < len(cells):
            c = cells[ci]
            if c is None:
                out.append((None, 0))
                ci += 1
                continue
            span = 1
            while ci + span < len(cells) and cells[ci + span] is None:
                span += 1
            out.append((_cell_text(words, c), span))
            out.extend([(None, 0)] * (span - 1))
            ci += span
        if any(txt for txt, _ in out if txt):
            grid.append(out)
    return grid


def to_excel(doc, pages, out_path, progress=None, layout="sheet_per_page", detect="auto"):
    """Tables found on each page become cells (merged cells kept). Pages without ruled tables use text layout."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    wb.remove(wb.active)
    thin = Side(style="thin", color="9AA5B1")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_fill = PatternFill("solid", fgColor="DCE6F2")
    one = None
    if layout == "one_sheet":
        one = wb.create_sheet("PDF Data")
        one_row = [1]
    n = len(pages)
    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d" % (i + 1))
        page = doc.load_page(i)
        tables = []
        strat = None
        if detect in ("auto", "lines"):
            try:
                n_draw = len(page.get_cdrawings()) if hasattr(page, "get_cdrawings") else 1
            except Exception:
                n_draw = 1
            if 0 < n_draw < 15000:
                try:
                    tables = page.find_tables(strategy="lines").tables
                    strat = "lines"
                except Exception:
                    tables = []
        if not tables and detect in ("auto", "text"):
            try:
                tt = page.find_tables(strategy="text").tables
                tables = [t for t in tt if t.row_count >= 2 and t.col_count >= 2]
                strat = "text"
            except Exception:
                tables = []
        if tables and all(t.col_count <= 2 for t in tables):
            # weak detection: keep it only if the word layout does not show more columns
            lr = _layout_rows(page)
            if lr and max(len(r) for r in lr) >= 3:
                tables = []
        if layout == "sheet_per_table" and tables:
            sheets = [(wb.create_sheet(("P%d T%d" % (i + 1, j + 1))[:31]), [t]) for j, t in enumerate(tables)]
        elif layout == "one_sheet":
            sheets = [(one, tables)]
        else:
            sheets = [(wb.create_sheet(("Page %d" % (i + 1))[:31]), tables)]
        for ws, tlist in sheets:
            r0 = one_row[0] if ws is one else 1
            if ws is one:
                ws.cell(r0, 1, "Page %d" % (i + 1)).font = Font(bold=True, color="1F5BD8", size=12)
                r0 += 1
            if not tlist:
                rows = _layout_rows(page)
                for ri, row in enumerate(rows):
                    for ci, val in enumerate(row):
                        if val == "":
                            continue
                        v = _num(val)
                        ws.cell(r0 + ri, ci + 1, v if v is not None else val)
                r0 += len(rows) + 1
            words = page.get_text("words")
            for t in tlist:
                grid = _table_grid(page, t, words)
                for ri, row in enumerate(grid):
                    for ci, (txt, span) in enumerate(row):
                        c = ws.cell(r0 + ri, ci + 1)
                        c.border = border
                        if txt:
                            v = _num(txt)
                            c.value = v if v is not None else txt
                            if "\n" in txt:
                                c.alignment = Alignment(wrap_text=True, vertical="top")
                            if isinstance(v, float):
                                c.number_format = "#,##0.0##"
                            elif isinstance(v, int) and abs(v) >= 1000:
                                c.number_format = "#,##0"
                        if ri == 0 and getattr(t, "header", None) is not None and not t.header.external:
                            c.font = Font(bold=True)
                            c.fill = head_fill
                        if span > 1:
                            try:
                                ws.merge_cells(start_row=r0 + ri, start_column=ci + 1, end_row=r0 + ri, end_column=ci + span)
                            except Exception:
                                pass
                r0 += len(grid) + 2
            if ws is one:
                one_row[0] = r0 + 1
            # column widths
            widths = {}
            for row in ws.iter_rows():
                for c in row:
                    if c.value is not None:
                        L = max(len(s) for s in str(c.value).split("\n"))
                        widths[c.column] = max(widths.get(c.column, 0), min(60, L + 2))
            for col, wdt in widths.items():
                ws.column_dimensions[get_column_letter(col)].width = max(8, wdt)
    if not wb.sheetnames:
        wb.create_sheet("Empty")
    wb.save(out_path)
    _prog(progress, n, n, "Done")
    return [out_path]


def to_csv(doc, pages, out_path, progress=None):
    import csv
    outs = []
    n = len(pages)
    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d" % (i + 1))
        page = doc.load_page(i)
        try:
            tables = page.find_tables().tables
        except Exception:
            tables = []
        rows = []
        if tables:
            for t in tables:
                rows += [[("" if v is None else str(v)) for v in r] for r in t.extract()] + [[]]
        else:
            rows = _layout_rows(page)
        fn = _out_name(out_path, i, len(pages) > 1)
        with open(fn, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerows(rows)
        outs.append(fn)
    _prog(progress, n, n, "Done")
    return outs


# =================================================================== images
def to_images(doc, pages, out_path, progress=None, fmt="jpg", dpi=200, quality=92, gray=False, multipage_tiff=True):
    fmt = fmt.lower()
    n = len(pages)
    outs = []
    cs = pymupdf.csGRAY if gray else pymupdf.csRGB
    if fmt in ("tif", "tiff") and multipage_tiff and n > 1:
        from PIL import Image
        frames = []
        for k, i in enumerate(pages):
            _prog(progress, k, n, "Page %d" % (i + 1))
            pix = doc.load_page(i).get_pixmap(dpi=dpi, colorspace=cs, alpha=False)
            frames.append(Image.open(io.BytesIO(pix.tobytes("png"))))
        frames[0].save(out_path, save_all=True, append_images=frames[1:], compression="tiff_lzw", dpi=(dpi, dpi))
        _prog(progress, n, n, "Done")
        return [out_path]
    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d" % (i + 1))
        pix = doc.load_page(i).get_pixmap(dpi=dpi, colorspace=cs, alpha=False)
        fn = _out_name(out_path, i, n > 1)
        if fmt in ("jpg", "jpeg"):
            pix.save(fn, jpg_quality=quality)
        elif fmt in ("png", "pnm", "pam", "psd"):
            pix.save(fn)
        else:
            from PIL import Image
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            img.save(fn, dpi=(dpi, dpi))
        outs.append(fn)
    _prog(progress, n, n, "Done")
    return outs


# ====================================================================== DXF
_LW = [0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211]
_INSUNITS = {"mm": 4, "cm": 5, "m": 6, "in": 1, "ft": 2}


def _lineweight(width_pt):
    mm100 = width_pt * PT_TO_MM * 100
    return min(_LW, key=lambda v: abs(v - mm100))


def _rgb_int(c):
    if not c:
        return 0
    return (int(round(c[0] * 255)) << 16) | (int(round(c[1] * 255)) << 8) | int(round(c[2] * 255))


def is_scanned_page(page):
    """True when the page is essentially a picture (scan, photo, JPEG opened as PDF) without vector drawing."""
    try:
        area = abs(page.rect)
        cover = 0.0
        for inf in page.get_image_info():
            r = pymupdf.Rect(inf["bbox"]) & page.rect
            if not r.is_empty:
                cover += abs(r)
        if area <= 0 or cover / area < 0.5:
            return False
        try:
            n = len(page.get_cdrawings())
        except Exception:
            n = len(page.get_drawings())
        return n < 400
    except Exception:
        return False


def page_image_dpi(page):
    """resolution (pixels per inch of the page) of the largest picture on the page, 0 if none"""
    best, dpi = 0.0, 0.0
    try:
        for inf in page.get_image_info():
            r = pymupdf.Rect(inf["bbox"]) & page.rect
            if r.is_empty or abs(r) <= best:
                continue
            bb = pymupdf.Rect(inf["bbox"])
            if bb.width <= 0:
                continue
            best = abs(r)
            wpx, hpx = inf.get("width", 0), inf.get("height", 0)
            dpi = max(wpx / (bb.width / 72.0), hpx / (bb.height / 72.0)) if bb.height > 0 else wpx / (bb.width / 72.0)
            # page rotated 90 / 270: width and height swap
            if page.rotation % 180:
                dpi = max(hpx / (bb.width / 72.0), wpx / (bb.height / 72.0))
    except Exception:
        return 0.0
    return dpi


RASTER_LAYERS = {"LINES": ("SCAN_LINES", 7), "THICK": ("SCAN_THICK", 7), "TEXT": ("SCAN_TEXT", 3),
                 "CIRCLES": ("SCAN_CIRCLES", 4), "FILL": ("SCAN_FILL", 8), "SHADING": ("SCAN_SHADING", 9),
                 "IMAGE": ("SCAN_IMAGE", 7)}
RASTER_MAX_PX = 90e6


def _named_color(rgb):
    """saturated scan colour -> (name, (r, g, b)) or None for black / grey ink"""
    if rgb is None:
        return None
    import colorsys
    r, g, b = [c / 255.0 for c in rgb]
    h, sat, v = colorsys.rgb_to_hsv(r, g, b)
    if sat < 0.35 or v < 0.25:
        return None
    names = [(0.0, "RED"), (0.08, "ORANGE"), (0.16, "YELLOW"), (0.33, "GREEN"), (0.5, "CYAN"), (0.66, "BLUE"),
             (0.83, "MAGENTA"), (1.0, "RED")]
    name = min(names, key=lambda t: abs(t[0] - h))[1]
    return name, tuple(int(c) for c in rgb)


def raster_page_to_dxf(doc_page, dxf_doc, msp, T, f, dpi=300, opts=None, progress=None, out_path=None, page_no=0):
    """Centre-line raster to vector of one page into msp. T(x_pt, y_pt) maps display points to DXF.

    Returns a small info dict (entities, skew, dpi used)."""
    import numpy as np
    from . import vectorize as V
    o = dict(tol=1.0, threshold=0, speck_mm=0.2, circles=True, fills=True, text_layer=True, deskew=True, ortho=True,
             shading=False, colors=False, underlay=False)
    o.update(opts or {})
    r = doc_page.rect
    native = page_image_dpi(doc_page)
    if native >= 100 and native < dpi:
        dpi = int(round(native))                 # never trace finer than the scan itself
    if r.width * r.height * (dpi / 72.0) ** 2 > RASTER_MAX_PX:
        dpi = int(72.0 * math.sqrt(RASTER_MAX_PX / (r.width * r.height)))
    cs = pymupdf.csRGB if (o["colors"] or o["underlay"]) else pymupdf.csGRAY
    pix = doc_page.get_pixmap(dpi=dpi, colorspace=cs, annots=False, alpha=False)
    arr = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, pix.n)
    rgb = arr if pix.n == 3 else None
    gray = arr[:, :, 0].copy() if pix.n == 1 else (arr[:, :, 0] * 0.299 + arr[:, :, 1] * 0.587 + arr[:, :, 2] * 0.114).astype(np.uint8)
    res = V.vectorize(gray, dpi, rgb=rgb if o["colors"] else None, tol=o["tol"], threshold=o["threshold"],
                      speck_mm=o["speck_mm"], circles=o["circles"], fills=o["fills"], text_layer=o["text_layer"],
                      deskew=o["deskew"], ortho=o["ortho"], shading=o["shading"], progress=progress)
    k = 72.0 / dpi

    def D(p):
        return T(float(p[0]) * k, float(p[1]) * k)

    made = {}

    def layer(key, color_name=None):
        name, aci = RASTER_LAYERS[key]
        if color_name:
            name = "%s_%s" % (name, color_name)
        if name not in made:
            if name not in dxf_doc.layers:
                ly = dxf_doc.layers.add(name)
                ly.color = aci
            made[name] = True
        return name

    count = 0
    for e in res["entities"]:
        nc = _named_color(e.get("color")) if o["colors"] else None
        attrs = {"layer": layer(e["layer"], nc[0] if nc else None),
                 "lineweight": _lineweight(e["width"] * k) if e["layer"] != "TEXT" else 0}
        if nc:
            attrs["true_color"] = (nc[1][0] << 16) | (nc[1][1] << 8) | nc[1][2]
        kind = e["kind"]
        try:
            if kind == "line":
                a, b = D(e["p0"]), D(e["p1"])
                if a != b:
                    msp.add_line(a, b, dxfattribs=attrs)
            elif kind == "poly":
                pts = [D(p) for p in e["pts"]]
                if len(pts) >= 2:
                    msp.add_lwpolyline(pts, close=bool(e.get("closed")), dxfattribs=attrs)
            elif kind == "circle":
                c = D(e["c"])
                msp.add_circle(c, e["r"] * k * f, dxfattribs=attrs)
            elif kind == "arc":
                c = D(e["c"])
                rad = e["r"] * k * f
                angs = []
                for key in ("p0", "pm", "p1"):
                    q = D(e[key])
                    angs.append(math.degrees(math.atan2(q[1] - c[1], q[0] - c[0])) % 360.0)
                a0, am, a1 = angs
                if (am - a0) % 360.0 <= (a1 - a0) % 360.0:
                    msp.add_arc(c, rad, a0, a1, dxfattribs=attrs)
                else:
                    msp.add_arc(c, rad, a1, a0, dxfattribs=attrs)
            count += 1
        except Exception:
            pass
    for key, groups in (("FILL", res["fills"]), ("SHADING", res["shading"])):
        for outer, holes in groups:
            try:
                ly = layer(key)
                h = msp.add_hatch(color=RASTER_LAYERS[key][1], dxfattribs={"layer": ly})
                h.paths.add_polyline_path([D(p) for p in outer], is_closed=True)
                for hole in holes:
                    h.paths.add_polyline_path([D(p) for p in hole], is_closed=True)
                if key == "FILL":
                    msp.add_lwpolyline([D(p) for p in outer], close=True, dxfattribs={"layer": ly})
                count += 1
            except Exception:
                pass
    if o["underlay"] and out_path:
        try:
            img_fn = os.path.splitext(out_path)[0] + "_p%d_scan.png" % (page_no + 1)
            pix.save(img_fn)
            W, H = res["size"]
            corners = [np.array([0.0, H]), np.array([W, H]), np.array([0.0, 0.0])]
            if res["skew"]:
                c0 = np.array([W / 2.0, H / 2.0])
                corners = [V._rotate(p, c0, -math.radians(res["skew"])) for p in corners]
            bl, br, tl = [D(p) for p in corners]
            rot = math.degrees(math.atan2(br[1] - bl[1], br[0] - bl[0]))
            wu = math.hypot(br[0] - bl[0], br[1] - bl[1])
            hu = math.hypot(tl[0] - bl[0], tl[1] - bl[1])
            idef = dxf_doc.add_image_def(filename=os.path.basename(img_fn), size_in_pixel=(pix.width, pix.height))
            msp.add_image(idef, insert=bl, size_in_units=(wu, hu), rotation=rot, dxfattribs={"layer": layer("IMAGE")})
        except Exception:
            pass
    return {"entities": count, "skew": res["skew"], "dpi": dpi}


def to_dxf(doc, pages, out_path, progress=None, scale_m_per_pt=None, unit="mm", text=True, join=True,
           circles=True, fills="hatch", layers="color", images=False, one_file=True, version="R2010",
           raster="auto", raster_dpi=300, raster_opts=None):
    """PDF -> DXF in real units.

    scale_m_per_pt: metres represented by one PDF point (None = paper size 1:1).
    The y axis is flipped so the drawing reads the same way as on screen.
    raster: 'auto' traces pages that are scans / pictures (centre-line raster to vector),
            'always' traces every page as a picture, 'off' exports the vector content only.
    """
    import ezdxf
    from ezdxf import colors as dxfcolors
    from ezdxf.enums import TextEntityAlignment
    unit_m = {"mm": 0.001, "cm": 0.01, "m": 1.0, "in": 0.0254, "ft": 0.3048}[unit]
    mpp = scale_m_per_pt or (0.0254 / 72.0)
    f = mpp / unit_m          # drawing units per point
    outs = []
    n = len(pages)
    dxf_doc = None
    x_offset = 0.0

    def new_doc():
        d = ezdxf.new(version, setup=True)
        d.header["$INSUNITS"] = _INSUNITS.get(unit, 4)
        d.header["$MEASUREMENT"] = 1 if unit in ("mm", "cm", "m") else 0
        d.header["$LWDISPLAY"] = 1
        try:
            d.styles.get("Standard").dxf.font = "arial.ttf"
        except Exception:
            pass
        return d

    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d - reading vectors" % (i + 1))
        if dxf_doc is None or not one_file:
            dxf_doc = new_doc()
            x_offset = 0.0
        msp = dxf_doc.modelspace()
        page = doc.load_page(i)
        rot = page.rotation_matrix
        H = page.rect.height
        layer_cache = {}
        if raster == "always" or (raster == "auto" and is_scanned_page(page)):
            # a picture without (or with a wrong) resolution: the real scan dpi gives the true paper size
            gscale = 1.0
            pd = float((raster_opts or {}).get("paper_dpi") or 0)
            if pd > 0:
                nat = page_image_dpi(page)
                if nat > 0:
                    gscale = nat / pd

            def TD(x, y, H=H, g=gscale):
                return (x_offset + x * g * f, (H - y) * g * f)

            def vp(frac, msg, k=k, i=i):
                _prog(progress, k, n, "Page %d - %s" % (i + 1, msg))
            info = raster_page_to_dxf(page, dxf_doc, msp, TD, f * gscale, dpi=raster_dpi, opts=raster_opts, progress=vp,
                                      out_path=out_path if one_file else _out_name(out_path, i, n > 1), page_no=i)
            if raster_opts is not None:
                raster_opts.setdefault("_info", []).append((i, info))
            if one_file:
                x_offset += (page.rect.width * gscale + 40) * f
            else:
                fn = _out_name(out_path, i, n > 1)
                dxf_doc.saveas(fn)
                outs.append(fn)
            continue

        def T(p):
            q = pymupdf.Point(p) * rot
            return (x_offset + q.x * f, (H - q.y) * f)

        def layer_for(color, kind="LINES", ocg=None):
            if layers == "single":
                name = "PDF_P%d" % (i + 1) if not one_file else "PDF"
            elif layers == "ocg" and ocg:
                name = re.sub(r"[^A-Za-z0-9_\-]", "_", str(ocg))[:60] or "PDF"
            else:
                name = "PDF_%s_%06X" % (kind, _rgb_int(color))
            if name not in layer_cache:
                if name not in dxf_doc.layers:
                    ly = dxf_doc.layers.add(name)
                    if color:
                        ly.rgb = (int(color[0] * 255), int(color[1] * 255), int(color[2] * 255))
                layer_cache[name] = True
            return name

        paths = page.get_drawings()
        np_ = len(paths)
        for pi, path in enumerate(paths):
            if pi % 4000 == 0:
                _prog(progress, k, n, "Page %d - %d/%d paths" % (i + 1, pi, np_))
            items = path.get("items", [])
            if not items:
                continue
            stroke = path.get("color")
            fill = path.get("fill")
            width = path.get("width") or 0.0
            ptype = path.get("type", "s")
            col = stroke if stroke else fill
            attrs = {"layer": layer_for(col, "FILL" if (ptype == "f") else "LINES", path.get("layer")),
                     "lineweight": _lineweight(width) if width else 0}
            if col:
                attrs["true_color"] = _rgb_int(col)
            # --- circles
            if circles and all(it[0] == "c" for it in items) and len(items) >= 2:
                bb = path.get("rect")
                first, last = items[0][1], items[-1][4]
                if bb is not None and abs(first.x - last.x) < 0.5 and abs(first.y - last.y) < 0.5 and \
                        abs(bb.width - bb.height) <= 0.04 * max(bb.width, bb.height) + 0.3 and bb.width > 0.3:
                    c = T(((bb.x0 + bb.x1) / 2, (bb.y0 + bb.y1) / 2))
                    r = (bb.width + bb.height) / 4 * f
                    if ptype in ("f", "fs") and fill and fills == "hatch":
                        h = msp.add_hatch(dxfattribs=dict(attrs, true_color=_rgb_int(fill)))
                        h.set_solid_fill(rgb=(int(fill[0] * 255), int(fill[1] * 255), int(fill[2] * 255)))
                        ep = h.paths.add_edge_path()
                        ep.add_arc(c, r, 0, 360)
                    if ptype != "f" or not fill or fills != "hatch":
                        msp.add_circle(c, r, dxfattribs=attrs)
                    continue
            # --- build sub-paths of points (lines) and splines (curves)
            poly = []      # current polyline points
            closed_flag = bool(path.get("closePath"))
            outline = []   # for hatch boundaries

            def flush(closed=False):
                nonlocal poly
                if len(poly) >= 2:
                    if join or len(poly) > 2:
                        msp.add_lwpolyline(poly, close=closed, dxfattribs=attrs)
                    else:
                        msp.add_line(poly[0], poly[1], dxfattribs=attrs)
                    outline.append(list(poly))
                poly = []

            for it in items:
                kind = it[0]
                if kind == "l":
                    a, b = T(it[1]), T(it[2])
                    if join and poly and abs(poly[-1][0] - a[0]) < 1e-9 and abs(poly[-1][1] - a[1]) < 1e-9:
                        poly.append(b)
                    else:
                        flush()
                        poly = [a, b]
                        if not join:
                            flush()
                elif kind == "re":
                    flush()
                    r = it[1]
                    pts = [T((r.x0, r.y0)), T((r.x1, r.y0)), T((r.x1, r.y1)), T((r.x0, r.y1))]
                    msp.add_lwpolyline(pts, close=True, dxfattribs=attrs)
                    outline.append(pts + [pts[0]])
                elif kind == "qu":
                    flush()
                    q = it[1]
                    pts = [T(q.ul), T(q.ur), T(q.lr), T(q.ll)]
                    msp.add_lwpolyline(pts, close=True, dxfattribs=attrs)
                    outline.append(pts + [pts[0]])
                elif kind == "c":
                    flush()
                    cps = [T(it[1]), T(it[2]), T(it[3]), T(it[4])]
                    msp.add_open_spline(cps, degree=3, dxfattribs=attrs)
                    # approximate for hatch outline
                    seg = []
                    for t in [j / 8 for j in range(9)]:
                        mt = 1 - t
                        seg.append(tuple(mt ** 3 * cps[0][d] + 3 * mt * mt * t * cps[1][d] + 3 * mt * t * t * cps[2][d] + t ** 3 * cps[3][d] for d in (0, 1)))
                    outline.append(seg)
            flush(closed_flag and join)
            if fills == "hatch" and fill and ptype in ("f", "fs") and outline:
                try:
                    ring = [p for seg in outline for p in seg]
                    if len(ring) >= 3:
                        h = msp.add_hatch(dxfattribs={"layer": layer_for(fill, "FILL", path.get("layer")), "true_color": _rgb_int(fill)})
                        h.set_solid_fill(rgb=(int(fill[0] * 255), int(fill[1] * 255), int(fill[2] * 255)))
                        h.paths.add_polyline_path(ring, is_closed=True)
                        if path.get("fill_opacity", 1) < 1:
                            h.transparency = 1 - float(path.get("fill_opacity", 1))
                except Exception:
                    pass
        # --- text
        if text:
            _prog(progress, k, n, "Page %d - text" % (i + 1))
            try:
                d = page.get_text("dict")
            except Exception:
                d = {"blocks": []}
            for b in d.get("blocks", []):
                if b.get("type") != 0:
                    continue
                for ln in b.get("lines", []):
                    dx, dy = ln.get("dir", (1, 0))
                    for sp in ln.get("spans", []):
                        s = sp.get("text", "")
                        if not s.strip():
                            continue
                        c = sp.get("color", 0)
                        rgb = ((c >> 16) & 255) / 255, ((c >> 8) & 255) / 255, (c & 255) / 255
                        o = T(sp["origin"])
                        # direction after page rotation, y flipped
                        v = pymupdf.Point(dx, dy) * pymupdf.Matrix(rot.a, rot.b, rot.c, rot.d, 0, 0)
                        ang = math.degrees(math.atan2(-v.y, v.x))
                        hgt = sp.get("size", 10) * f * 0.72
                        try:
                            t = msp.add_text(s, height=hgt, rotation=ang,
                                             dxfattribs={"layer": layer_for(rgb, "TEXT"), "true_color": _rgb_int(rgb)})
                            t.set_placement(o, align=TextEntityAlignment.LEFT)
                        except Exception:
                            pass
        # --- raster images
        if images:
            try:
                infos = page.get_image_info(xrefs=True)
            except Exception:
                infos = []
            for j, inf in enumerate(infos):
                xref = inf.get("xref")
                if not xref:
                    continue
                try:
                    pix = pymupdf.Pixmap(doc, xref)
                    if pix.n - pix.alpha >= 4:
                        pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
                    img_fn = os.path.splitext(out_path)[0] + "_p%d_img%d.png" % (i + 1, j + 1)
                    pix.save(img_fn)
                    bb = pymupdf.Rect(inf["bbox"]) * rot
                    ins = (x_offset + bb.x0 * f, (H - bb.y1) * f)
                    idef = dxf_doc.add_image_def(filename=os.path.basename(img_fn), size_in_pixel=(pix.width, pix.height))
                    msp.add_image(idef, insert=ins, size_in_units=(bb.width * f, bb.height * f))
                except Exception:
                    pass
        if one_file:
            x_offset += (page.rect.width + 40) * f
        else:
            fn = _out_name(out_path, i, n > 1)
            dxf_doc.saveas(fn)
            outs.append(fn)
    if one_file and dxf_doc is not None:
        _prog(progress, n, n, "Writing DXF…")
        dxf_doc.saveas(out_path)
        outs.append(out_path)
    _prog(progress, n, n, "Done")
    return outs


# ======================================================= SVG / text / html
def to_svg(doc, pages, out_path, progress=None, text_as_path=False):
    outs = []
    n = len(pages)
    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d" % (i + 1))
        svg = doc.load_page(i).get_svg_image(text_as_path=text_as_path)
        fn = _out_name(out_path, i, n > 1)
        with open(fn, "w", encoding="utf-8") as f:
            f.write(svg)
        outs.append(fn)
    _prog(progress, n, n, "Done")
    return outs


def to_text(doc, pages, out_path, progress=None, keep_layout=True):
    n = len(pages)
    with open(out_path, "w", encoding="utf-8") as f:
        for k, i in enumerate(pages):
            _prog(progress, k, n, "Page %d" % (i + 1))
            page = doc.load_page(i)
            if keep_layout:
                rows = _layout_rows(page)
                txt = "\n".join("\t".join(r).rstrip() for r in rows)
            else:
                txt = page.get_text("text", sort=True)
            f.write("===== Page %d =====\n%s\n\n" % (i + 1, txt))
    _prog(progress, n, n, "Done")
    return [out_path]


def to_html(doc, pages, out_path, progress=None):
    n = len(pages)
    parts = ["<!doctype html><html><head><meta charset='utf-8'><title>%s</title>"
             "<style>body{background:#eef2f7;font-family:Segoe UI,Arial} .pg{background:white;margin:16px auto;"
             "box-shadow:0 2px 8px #0003;position:relative}</style></head><body>" % os.path.basename(out_path)]
    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d" % (i + 1))
        parts.append("<div class='pg'>%s</div>" % doc.load_page(i).get_text("html"))
    parts.append("</body></html>")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))
    _prog(progress, n, n, "Done")
    return [out_path]


def to_pptx(doc, pages, out_path, progress=None, dpi=200):
    from pptx import Presentation
    from pptx.util import Emu
    prs = Presentation()
    first = doc.load_page(pages[0])
    prs.slide_width = Emu(int(first.rect.width * 12700))
    prs.slide_height = Emu(int(first.rect.height * 12700))
    blank = prs.slide_layouts[6]
    n = len(pages)
    for k, i in enumerate(pages):
        _prog(progress, k, n, "Page %d" % (i + 1))
        page = doc.load_page(i)
        pix = page.get_pixmap(dpi=dpi, alpha=False)
        slide = prs.slides.add_slide(blank)
        bio = io.BytesIO(pix.tobytes("png"))
        slide.shapes.add_picture(bio, 0, 0, width=prs.slide_width, height=prs.slide_height)
        notes = page.get_text("text").strip()
        if notes:
            try:
                slide.notes_slide.notes_text_frame.text = notes[:5000]
            except Exception:
                pass
    prs.save(out_path)
    _prog(progress, n, n, "Done")
    return [out_path]


def images_to_pdf(image_paths, out_path, progress=None, page_size="fit", margin_mm=0):
    out = pymupdf.open()
    n = len(image_paths)
    sizes = {"A4": pymupdf.paper_size("a4"), "A3": pymupdf.paper_size("a3"), "Letter": pymupdf.paper_size("letter")}
    for k, fn in enumerate(image_paths):
        _prog(progress, k, n, os.path.basename(fn))
        img = pymupdf.open(fn)
        r = img[0].rect
        img.close()
        if page_size == "fit":
            page = out.new_page(width=r.width, height=r.height)
            target = page.rect
        else:
            w, h = sizes.get(page_size, sizes["A4"])
            if r.width > r.height:
                w, h = h, w
            page = out.new_page(width=w, height=h)
            m = margin_mm * 72 / 25.4
            target = pymupdf.Rect(m, m, w - m, h - m)
        page.insert_image(target, filename=fn, keep_proportion=True)
    out.save(out_path, garbage=3, deflate=True)
    _prog(progress, n, n, "Done")
    return [out_path]


FORMATS = {
    "word": ("Word document", "docx", "Word (*.docx)"),
    "excel": ("Excel workbook", "xlsx", "Excel (*.xlsx)"),
    "csv": ("CSV tables", "csv", "CSV (*.csv)"),
    "jpg": ("JPEG images", "jpg", "JPEG (*.jpg)"),
    "png": ("PNG images", "png", "PNG (*.png)"),
    "tiff": ("TIFF image", "tif", "TIFF (*.tif)"),
    "bmp": ("BMP images", "bmp", "BMP (*.bmp)"),
    "dxf": ("AutoCAD DXF", "dxf", "DXF (*.dxf)"),
    "svg": ("SVG vector", "svg", "SVG (*.svg)"),
    "txt": ("Plain text", "txt", "Text (*.txt)"),
    "html": ("HTML page", "html", "HTML (*.html)"),
    "pptx": ("PowerPoint", "pptx", "PowerPoint (*.pptx)"),
}
