"""Interactive tools: navigation, selection, comment creation and content editing."""
import math

import pymupdf
from PySide6.QtCore import Qt, QPointF, QRectF, QTimer
from PySide6.QtGui import QPen, QColor, QBrush, QPainterPath, QCursor, QGuiApplication, QImage, QFont, QPolygonF
from PySide6.QtWidgets import QApplication, QToolTip, QMessageBox, QFileDialog, QInputDialog, QLineEdit

from . import annots as A
from . import theme
from .settings import settings

SNAP_GLYPH_COLOR = QColor(255, 196, 0)


class Pick:
    __slots__ = ("page", "xd", "yd", "xu", "yu", "kind")

    def __init__(self, page, xd, yd, xu, yu, kind=None):
        self.page, self.xd, self.yd, self.xu, self.yu, self.kind = page, xd, yd, xu, yu, kind

    @property
    def unrot(self):
        return (self.xu, self.yu)


def qcolor(rgb, alpha=255):
    if rgb is None:
        return QColor(0, 0, 0, 0)
    return QColor(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), alpha)


def draw_snap_glyph(p, pt, kind):
    if not kind:
        return
    s = 6
    p.save()
    p.setRenderHint(p.RenderHint.Antialiasing, True)
    p.setBrush(Qt.NoBrush)
    for w, c in ((4, QColor(0, 0, 0, 150)), (2, SNAP_GLYPH_COLOR)):
        p.setPen(QPen(c, w))
        x, y = pt.x(), pt.y()
        if kind == "end":
            p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s))
        elif kind == "mid":
            p.drawPolygon(QPolygonF([QPointF(x, y - s - 1), QPointF(x + s + 1, y + s), QPointF(x - s - 1, y + s)]))
        elif kind == "center":
            p.drawEllipse(pt, s, s)
        elif kind == "quadrant":
            p.drawPolygon(QPolygonF([QPointF(x, y - s - 1), QPointF(x + s + 1, y), QPointF(x, y + s + 1), QPointF(x - s - 1, y)]))
        elif kind == "intersection":
            p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y + s))
            p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y - s))
        elif kind == "perpendicular":
            p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y + s))
            p.drawLine(QPointF(x - s, y + s), QPointF(x - s, y - s))
            p.drawLine(QPointF(x - s, y), QPointF(x, y))
            p.drawLine(QPointF(x, y), QPointF(x, y + s))
        elif kind == "nearest":
            p.drawPolygon(QPolygonF([QPointF(x - s, y - s), QPointF(x + s, y - s), QPointF(x - s, y + s), QPointF(x + s, y + s)]))
    p.setPen(QColor(0, 0, 0))
    f = QFont("Segoe UI", 7, QFont.Bold)
    p.setFont(f)
    label = {"end": "Endpoint", "mid": "Midpoint", "center": "Center", "quadrant": "Quadrant",
             "intersection": "Intersection", "perpendicular": "Perpendicular", "nearest": "Nearest"}.get(kind, kind)
    r = QRectF(pt.x() + 10, pt.y() + 8, len(label) * 5.6 + 8, 15)
    p.fillRect(r, QColor(255, 253, 220, 235))
    p.setPen(QPen(QColor(120, 100, 20), 1))
    p.drawRect(r)
    p.setPen(QColor(40, 40, 40))
    p.drawText(r, Qt.AlignCenter, label)
    p.restore()


class Tool:
    name = "tool"
    snaps = False      # uses OSnap
    sticky = True

    def __init__(self, main=None, style=None):
        self.main = main
        self.style = dict(style or {})
        self.view = None
        self.hover = None    # current Pick for snap glyph

    # ---------------------------------------------------------- framework
    @property
    def doc(self):
        return self.view.pdfdoc

    def cursor(self):
        return Qt.CrossCursor

    def activate(self):
        if self.snaps:
            self.prepare_snap()

    def deactivate(self):
        pass

    def prepare_snap(self):
        """Start building OSnap indexes of the visible pages in the background."""
        v = self.view
        if not v or not v.pdfdoc or not self.main or not self.main.snap_on:
            return
        try:
            cur = v.current_page()
            pending = False
            for i in sorted(set([cur, min(cur + 1, v.pdfdoc.page_count - 1)])):
                if v.pdfdoc.snap_index(i) is None:
                    pending = True
            if pending:
                self.main.status("Preparing OSnap for this page… (measuring already works, snapping starts in a moment)", 6000)
        except Exception:
            pass

    def on_snap_ready(self, i):
        if self.main and self.view and i == self.view.current_page():
            self.main.status("OSnap ready.", 2500)
        # refresh the hover glyph at the current mouse position
        try:
            from PySide6.QtGui import QCursor
            pos = self.view.viewport().mapFromGlobal(QCursor.pos())
            if self.view.viewport().rect().contains(pos):
                self.hover = self.pick(QPointF(pos))
        except Exception:
            pass

    def press(self, e):
        pass

    def move(self, e):
        if self.snaps:
            self.hover = self.pick(e.position())
            self.view.viewport().update()

    def release(self, e):
        pass

    def double_click(self, e):
        pass

    def key(self, e):
        if e.key() == Qt.Key_Escape:
            self.cancel()
            if self.main:
                self.main.set_tool("select")
            return True
        return False

    def context(self, e):
        return False

    def paint(self, p):
        if self.snaps and self.hover and self.hover.kind:
            draw_snap_glyph(p, self.view.disp_to_view(self.hover.page, self.hover.xd, self.hover.yd), self.hover.kind)

    def cancel(self):
        self.view.viewport().update()

    def author(self):
        return settings().get("author") or "Reviewer"

    def done(self):
        if self.view:
            self.view.tool_finished.emit()

    # ------------------------------------------------------------- picking
    def pick(self, pos, page=None, last=None, ortho=None):
        v = self.view
        h = v.hit(pos, clamp_page=page)
        if not h:
            return None
        i, xd, yd = h
        xu, yu = v.to_unrot(i, xd, yd)
        kind = None
        main = self.main
        snap_on = self.snaps and main is not None and main.snap_on
        if snap_on and not (QGuiApplication.keyboardModifiers() & Qt.ControlModifier):
            try:
                idx = v.pdfdoc.snap_index(i)
                tol = v.view_tol_pt(i)
                extra = self._extra_snap_points(i)
                lastu = (last.xu, last.yu) if last is not None and last.page == i else None
                if idx is not None:
                    r = idx.query(xu, yu, tol, main.snap_modes(), lastu, extra)
                else:
                    r = None
                    if extra and main.snap_modes().get("end"):
                        import numpy as np
                        ep = np.asarray(extra, dtype=float).reshape(-1, 2)
                        dd = np.hypot(ep[:, 0] - xu, ep[:, 1] - yu)
                        j = int(dd.argmin())
                        if dd[j] <= tol:
                            r = ("end", (float(ep[j, 0]), float(ep[j, 1])))
                if r:
                    kind, (xu, yu) = r
                    xd, yd = v.to_disp(i, xu, yu)
            except Exception:
                kind = None
        if ortho is None:
            ortho = main is not None and (main.ortho_on or bool(QGuiApplication.keyboardModifiers() & Qt.ShiftModifier))
        if ortho and last is not None and last.page == i and kind is None:
            if abs(xd - last.xd) >= abs(yd - last.yd):
                yd = last.yd
            else:
                xd = last.xd
            xu, yu = v.to_unrot(i, xd, yd)
        return Pick(i, xd, yd, xu, yu, kind)

    def _extra_snap_points(self, i):
        pts = []
        for a in self.doc.annot_list(i):
            vs = a.get("vertices")
            if not vs:
                continue
            if a["type"] == "Ink":
                continue
            pts.extend(vs)
        return pts

    def vpt(self, pk):
        return self.view.disp_to_view(pk.page, pk.xd, pk.yd)

    def style_pen(self, alpha=255, width=None):
        c = qcolor(self.style.get("stroke") or [0.1, 0.4, 0.9], alpha)
        w = width if width is not None else max(1.0, float(self.style.get("width", 1.5)) * self.view.page_scale(self.view.current_page()))
        pen = QPen(c, w)
        d = self.style.get("dash", "solid")
        if d == "dash":
            pen.setStyle(Qt.DashLine)
        elif d == "dot":
            pen.setStyle(Qt.DotLine)
        return pen

    def commit_page(self, i):
        self.doc.commit([i], content=False)


# ======================================================================= hand
class HandTool(Tool):
    name = "hand"

    def cursor(self):
        return Qt.OpenHandCursor

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        v = self.view
        # links
        h = v.hit_unrot(e.position())
        if h:
            i, x, y = h
            # form fields first
            if self.main and self.main.try_form_click(v, i, x, y):
                return
            # 3D models open in the 3D review window
            if self.main and hasattr(self.main, "try_3d_click") and self.main.try_3d_click(v, i, x, y):
                return
            try:
                for ln in v.pdfdoc.page(i).get_links():
                    r = ln["from"]
                    if r.x0 <= x <= r.x1 and r.y0 <= y <= r.y1:
                        self._follow(ln)
                        return
            except Exception:
                pass
        v._pan = (e.position(), v.offset())
        v.viewport().setCursor(Qt.ClosedHandCursor)

    def _follow(self, ln):
        v = self.view
        kind = ln.get("kind")
        if kind == pymupdf.LINK_GOTO:
            to = ln.get("to")
            v.go_to_page(ln.get("page", 0), to.y if to else None)
        elif kind == pymupdf.LINK_URI:
            uri = ln.get("uri", "")
            if self.main and QMessageBox.question(self.main, "Open link", "Open this link in the browser?\n\n" + uri) == QMessageBox.Yes:
                from PySide6.QtGui import QDesktopServices
                from PySide6.QtCore import QUrl
                QDesktopServices.openUrl(QUrl(uri))
        elif kind == pymupdf.LINK_NAMED:
            pg = ln.get("page")
            if pg is not None:
                v.go_to_page(pg)

    def move(self, e):
        v = self.view
        a = v.annot_at(e.position())
        if a and (a[1].get("content") or a[1].get("subject")):
            txt = a[1].get("content") or ""
            head = "%s — %s" % (a[1].get("author") or "", a[1].get("subject") or a[1]["type"])
            QToolTip.showText(e.globalPosition().toPoint(), "<b>%s</b><br>%s" % (head, txt.replace("\n", "<br>")), v)

    def double_click(self, e):
        a = self.view.annot_at(e.position())
        if a and self.main:
            self.main.activate_annot(self.view, a[0], a[1])


# ===================================================================== select
class SelectTool(Tool):
    """Select / move / resize comments; drag on empty area selects text."""
    name = "select"

    def __init__(self, main=None, style=None, text_only=False):
        super().__init__(main, style)
        self.text_only = text_only
        self.drag = None

    def cursor(self):
        return Qt.IBeamCursor if self.text_only else Qt.ArrowCursor

    def press(self, e):
        v = self.view
        if e.button() != Qt.LeftButton:
            return
        pos = e.position()
        if not self.text_only:
            # handles of selected annotation
            a = v.selected_annot_info()
            if a:
                for hid, hp in v.annot_handles(a):
                    if (hp - pos).manhattanLength() <= 8:
                        self.drag = ("resize", v.selected[0], a, hid, pos)
                        return
            hit = v.annot_at(pos)
            if hit:
                i, a = hit
                v.set_selected((i, a["xref"]))
                v.text_sel = None
                self.drag = ("move", i, a, None, pos)
                return
            if self.main and self.main.try_form_click(v, *(v.hit_unrot(pos) or (None, 0, 0))):
                return
        v.set_selected(None)
        h = v.hit_unrot(pos)
        if h:
            self.drag = ("text", h[0], None, None, pos)
            v.text_sel = None
        v.viewport().update()

    def move(self, e):
        v = self.view
        if not self.drag:
            if not self.text_only:
                a = v.selected_annot_info()
                cur = Qt.ArrowCursor
                if a:
                    for hid, hp in v.annot_handles(a):
                        if (hp - e.position()).manhattanLength() <= 8:
                            cur = Qt.SizeAllCursor if hid.startswith("v") else (Qt.SizeFDiagCursor if hid in ("tl", "br") else Qt.SizeBDiagCursor if hid in ("tr", "bl") else Qt.SizeHorCursor if hid in ("l", "r") else Qt.SizeVerCursor)
                            break
                if cur == Qt.ArrowCursor and v.annot_at(e.position()):
                    cur = Qt.PointingHandCursor
                v.viewport().setCursor(cur)
            return
        kind, i, a, hid, start = self.drag[:5]
        if kind == "text":
            h1 = v.hit_unrot(start, clamp_page=i)
            h2 = v.hit_unrot(e.position(), clamp_page=i)
            if h1 and h2:
                self._select_text(i, (h1[1], h1[2]), (h2[1], h2[2]), bool(e.modifiers() & Qt.AltModifier))
        self.drag = self.drag[:5] + (e.position(),)
        v.viewport().update()

    def _select_text(self, i, p1, p2, box=False):
        words = self.doc.words(i)
        if not words:
            self.view.text_sel = None
            return
        if box:
            x0, x1 = sorted((p1[0], p2[0]))
            y0, y1 = sorted((p1[1], p2[1]))
            sel = [w for w in words if w[0] < x1 and w[2] > x0 and w[1] < y1 and w[3] > y0]
        else:
            def nearest(pt):
                best, bd = 0, None
                for k, w in enumerate(words):
                    dx = max(w[0] - pt[0], 0, pt[0] - w[2])
                    dy = max(w[1] - pt[1], 0, pt[1] - w[3])
                    d = dx * dx + dy * dy * 4
                    if bd is None or d < bd:
                        best, bd = k, d
                return best
            a, b = nearest(p1), nearest(p2)
            if a > b:
                a, b = b, a
            sel = words[a:b + 1]
        rects = [tuple(w[:4]) for w in sel]
        lines = []
        last = None
        for w in sel:
            key = (w[5], w[6])
            if last is not None and key != last:
                lines.append("\n")
            elif last is not None:
                lines.append(" ")
            lines.append(w[4])
            last = key
        self.view.text_sel = (i, rects, "".join(lines), sel)

    def release(self, e):
        v = self.view
        if not self.drag:
            return
        kind, i, a, hid, start = self.drag[:5]
        end = e.position()
        self.drag = None
        if kind == "text":
            if (end - start).manhattanLength() < 3:
                v.text_sel = None
            v.viewport().update()
            if self.main:
                self.main.on_text_selection(v)
            return
        if (end - start).manhattanLength() < 2:
            return
        h1 = v.hit_unrot(start, clamp_page=i)
        h2 = v.hit_unrot(end, clamp_page=i)
        if not (h1 and h2):
            return
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        try:
            if kind == "move":
                dx, dy = h2[1] - h1[1], h2[2] - h1[2]
                xrefs = [a["xref"]]
                if a.get("group"):
                    xrefs = A.group_members(doc, i, a["group"]) or xrefs
                lst = {x["xref"]: x for x in doc.annot_list(i)}
                for x in xrefs:
                    if x in lst:
                        page = A.move_annot(doc.doc, page, lst[x], dx, dy)
            elif kind == "resize":
                page = A.resize_annot(doc.doc, page, a, hid, (h2[1], h2[2]))
        except Exception as ex:
            QMessageBox.warning(self.main, "Edit comment", str(ex))
        doc.commit([i], content=False)
        v.set_selected((i, a["xref"]))

    def paint(self, p):
        v = self.view
        if self.drag and len(self.drag) > 5 and self.drag[0] in ("move", "resize"):
            kind, i, a, hid, start, cur = self.drag
            d = cur - start
            p.setPen(QPen(QColor(theme.BLUE), 1.2, Qt.DashLine))
            p.setBrush(QColor(31, 91, 216, 25))
            if kind == "move":
                rr = v.unrot_rect_to_view(i, a["rect"]).translated(d)
                p.drawRect(rr)
            else:
                if hid.startswith("v") and a.get("vertices"):
                    vs = [v.unrot_to_view(i, *pt) for pt in a["vertices"]]
                    k = int(hid[1:])
                    vs[k] = cur
                    if a["type"] == "Polygon":
                        p.drawPolygon(QPolygonF(vs))
                    else:
                        p.drawPolyline(QPolygonF(vs))
                else:
                    rr = v.unrot_rect_to_view(i, a["rect"])
                    if "l" in hid:
                        rr.setLeft(cur.x())
                    if "r" in hid:
                        rr.setRight(cur.x())
                    if "t" in hid:
                        rr.setTop(cur.y())
                    if "b" in hid:
                        rr.setBottom(cur.y())
                    p.drawRect(rr.normalized())

    def key(self, e):
        if e.key() == Qt.Key_Escape:
            self.view.set_selected(None)
            self.view.text_sel = None
            self.view.viewport().update()
            return True
        if e.key() in (Qt.Key_Left, Qt.Key_Right, Qt.Key_Up, Qt.Key_Down) and self.view.selected:
            a = self.view.selected_annot_info()
            if a:
                step = 5.0 if e.modifiers() & Qt.ShiftModifier else 0.5
                i = self.view.selected[0]
                ddx = {Qt.Key_Left: (-step, 0), Qt.Key_Right: (step, 0), Qt.Key_Up: (0, -step), Qt.Key_Down: (0, step)}[e.key()]
                rot = self.view.derot(i)
                v0 = pymupdf.Point(0, 0) * rot
                v1 = pymupdf.Point(*ddx) * rot
                self.doc.checkpoint()
                A.move_annot(self.doc.doc, self.doc.page(i), a, v1.x - v0.x, v1.y - v0.y)
                self.doc.commit([i], content=False)
                return True
        return False

    def double_click(self, e):
        a = self.view.annot_at(e.position())
        if a and self.main:
            self.main.activate_annot(self.view, a[0], a[1])


# ======================================================================= zoom
class ZoomTool(Tool):
    name = "zoom"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.start = self.cur = None

    def cursor(self):
        return Qt.CrossCursor

    def press(self, e):
        if e.button() == Qt.LeftButton:
            self.start = self.cur = e.position()

    def move(self, e):
        if self.start is not None:
            self.cur = e.position()
            self.view.viewport().update()

    def release(self, e):
        if self.start is None:
            return
        s, c = self.start, e.position()
        self.start = None
        v = self.view
        if (c - s).manhattanLength() < 6:
            v.zoom_by(1 / 1.6 if e.modifiers() & (Qt.ShiftModifier | Qt.AltModifier) else 1.6, c)
            return
        h1 = v.hit(s)
        if not h1:
            return
        h2 = v.hit(c, clamp_page=h1[0])
        r = pymupdf.Rect(min(h1[1], h2[1]), min(h1[2], h2[2]), max(h1[1], h2[1]), max(h1[2], h2[2]))
        v.zoom_to_rect(h1[0], r)

    def paint(self, p):
        if self.start is not None and self.cur is not None:
            p.setPen(QPen(QColor(theme.BLUE), 1, Qt.DashLine))
            p.setBrush(QColor(31, 91, 216, 30))
            p.drawRect(QRectF(self.start, self.cur).normalized())


# ======================================================= rectangle drag tools
class RectDragTool(Tool):
    """Base: drag a rectangle on one page -> on_rect(page, disp_rect, unrot_rect)."""
    name = "rectdrag"
    fill_preview = QColor(31, 91, 216, 30)

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.p0 = self.p1 = None

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        self.p0 = self.pick(e.position())
        self.p1 = self.p0

    def move(self, e):
        if self.p0 is not None:
            self.p1 = self.pick(e.position(), page=self.p0.page)
        super().move(e)
        self.view.viewport().update()

    def release(self, e):
        if self.p0 is None:
            return
        p0, p1 = self.p0, self.pick(e.position(), page=self.p0.page) or self.p1
        self.p0 = self.p1 = None
        self.view.viewport().update()
        if p1 is None:
            return
        dr = pymupdf.Rect(min(p0.xd, p1.xd), min(p0.yd, p1.yd), max(p0.xd, p1.xd), max(p0.yd, p1.yd))
        small = dr.width * self.view.page_scale(p0.page) < 4 and dr.height * self.view.page_scale(p0.page) < 4
        a = pymupdf.Point(p0.xu, p0.yu)
        b = pymupdf.Point(p1.xu, p1.yu)
        ur = pymupdf.Rect(min(a.x, b.x), min(a.y, b.y), max(a.x, b.x), max(a.y, b.y))
        self.on_rect(p0.page, dr, ur, small)

    def on_rect(self, page, disp_rect, unrot_rect, small):
        pass

    def paint(self, p):
        super().paint(p)
        if self.p0 is not None and self.p1 is not None:
            a, b = self.vpt(self.p0), self.vpt(self.p1)
            p.setPen(self.preview_pen())
            p.setBrush(self.fill_preview)
            r = QRectF(a, b).normalized()
            if self.style.get("kind") == "ellipse":
                p.drawEllipse(r)
            else:
                p.drawRect(r)

    def preview_pen(self):
        if self.style.get("stroke"):
            return self.style_pen(220, 1.5)
        return QPen(QColor(theme.BLUE), 1.2, Qt.DashLine)


class ShapeRectTool(RectDragTool):
    """Rectangle, ellipse, rectangular cloud, area highlight, text box."""
    name = "shape"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        if self.style.get("kind") == "area":
            self.fill_preview = qcolor(self.style.get("fill") or [1, 1, 0], 90)
        elif self.style.get("fill"):
            self.fill_preview = qcolor(self.style["fill"], 60)
        else:
            self.fill_preview = QColor(0, 0, 0, 0)

    def on_rect(self, i, dr, ur, small):
        kind = self.style.get("kind", "rect")
        doc = self.doc
        if kind == "textbox":
            from .dialogs import CommentTextDialog
            text = self.style.get("text", "")
            dlg = CommentTextDialog(self.main, "Text box", text, self.style.get("fontsize", 10))
            if not dlg.exec():
                return
            text, fs = dlg.result_text()
            st = dict(self.style, fontsize=fs)
            page = doc.page(i)
            if small:
                w, h = A.freetext_size(text, fs, st.get("font", "Helvetica"))
                xd, yd = dr.x0, dr.y0
                r = pymupdf.Rect(xd, yd, xd + w, yd + h) * self.view.derot(i)
                ur = pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))
            doc.checkpoint()
            a = A.create_freetext(page, ur, text, st, self.author(), rotate=self.view.total_rot(i))
            xref = a.xref
            doc.commit([i], content=False)
            self.view.set_selected((i, xref))
            self.done()
            return
        if small:
            return
        doc.checkpoint()
        page = doc.page(i)
        a = A.create_shape(page, kind if kind in ("rect", "ellipse", "cloud", "area") else "rect", self.style,
                           self.author(), rect=ur, content=self.style.get("text") or None)
        xref = a.xref
        doc.commit([i], content=False)
        self.view.set_selected((i, xref))
        self.done()


# ================================================================ line tools
class TwoPointTool(Tool):
    name = "twopoint"
    snaps = True

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.a = None
        self.b = None

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        pk = self.pick(e.position(), page=self.a.page if self.a else None, last=self.a)
        if pk is None:
            return
        if self.a is None:
            self.a = pk
            self.b = pk
        else:
            a, self.a, self.b = self.a, None, None
            if math.hypot(pk.xd - a.xd, pk.yd - a.yd) * self.view.page_scale(a.page) > 2:
                self.finish(a, pk)
        self.view.viewport().update()

    def release(self, e):
        # support press-drag-release as well as click-click
        if self.a is not None and self.b is not None:
            pk = self.pick(e.position(), page=self.a.page, last=self.a)
            if pk and math.hypot(pk.xd - self.a.xd, pk.yd - self.a.yd) * self.view.page_scale(self.a.page) > 8:
                a, self.a, self.b = self.a, None, None
                self.finish(a, pk)
                self.view.viewport().update()

    def move(self, e):
        if self.a is not None:
            self.b = self.pick(e.position(), page=self.a.page, last=self.a)
            self.hover = self.b
        else:
            self.hover = self.pick(e.position())
        self.view.viewport().update()

    def cancel(self):
        self.a = self.b = None
        super().cancel()

    def finish(self, a, b):
        pass

    def paint(self, p):
        if self.a is not None and self.b is not None:
            p.setPen(self.preview_pen())
            p.drawLine(self.vpt(self.a), self.vpt(self.b))
            self.paint_extra(p)
        super().paint(p)

    def preview_pen(self):
        return self.style_pen(230)

    def paint_extra(self, p):
        pass


class LineTool(TwoPointTool):
    name = "line"

    def finish(self, a, b):
        doc = self.doc
        doc.checkpoint()
        page = doc.page(a.page)
        an = A.create_shape(page, self.style.get("kind", "line"), self.style, self.author(), points=[a.unrot, b.unrot],
                            content=self.style.get("text") or None)
        xref = an.xref
        doc.commit([a.page], content=False)
        self.view.set_selected((a.page, xref))
        self.done()


class MultiPointTool(Tool):
    name = "multipoint"
    snaps = True
    closed = False
    min_points = 2

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.pts = []
        self.cur = None

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        last = self.pts[-1] if self.pts else None
        pk = self.pick(e.position(), page=self.pts[0].page if self.pts else None, last=last)
        if pk is None:
            return
        if self.pts and len(self.pts) >= 3 and self.closed:
            # click near first point closes
            f = self.vpt(self.pts[0])
            if (f - e.position()).manhattanLength() < 8:
                self._finish()
                return
        self.pts.append(pk)
        self.cur = pk
        self.view.viewport().update()

    def move(self, e):
        last = self.pts[-1] if self.pts else None
        self.cur = self.pick(e.position(), page=self.pts[0].page if self.pts else None, last=last)
        self.hover = self.cur
        self.view.viewport().update()

    def double_click(self, e):
        # the double click already added a point on press; drop duplicates
        if len(self.pts) >= 2:
            a, b = self.pts[-1], self.pts[-2]
            if abs(a.xd - b.xd) < 1e-6 and abs(a.yd - b.yd) < 1e-6:
                self.pts.pop()
        self._finish()

    def key(self, e):
        if e.key() in (Qt.Key_Return, Qt.Key_Enter):
            self._finish()
            return True
        if e.key() == Qt.Key_Backspace and self.pts:
            self.pts.pop()
            self.view.viewport().update()
            return True
        return super().key(e)

    def context(self, e):
        if self.pts:
            self._finish()
            return True
        return False

    def _finish(self):
        pts = self.pts
        self.pts = []
        self.view.viewport().update()
        # remove consecutive duplicates
        clean = []
        for q in pts:
            if not clean or abs(clean[-1].xd - q.xd) > 1e-6 or abs(clean[-1].yd - q.yd) > 1e-6:
                clean.append(q)
        if len(clean) >= self.min_points:
            self.finish(clean)

    def cancel(self):
        self.pts = []
        super().cancel()

    def finish(self, pts):
        pass

    def preview_pen(self):
        return self.style_pen(230)

    def paint(self, p):
        if self.pts:
            path = [self.vpt(q) for q in self.pts]
            if self.cur is not None:
                path.append(self.vpt(self.cur))
            p.setPen(self.preview_pen())
            fill = self.style.get("fill")
            if self.closed and fill:
                p.setBrush(qcolor(fill, 60))
            else:
                p.setBrush(Qt.NoBrush)
            if self.closed and len(path) > 2:
                p.drawPolygon(QPolygonF(path))
            else:
                p.drawPolyline(QPolygonF(path))
            p.setPen(QPen(QColor(theme.BLUE), 1))
            p.setBrush(Qt.white)
            for q in path[:-1]:
                p.drawRect(QRectF(q.x() - 2.5, q.y() - 2.5, 5, 5))
            self.paint_extra(p, path)
        super().paint(p)

    def paint_extra(self, p, path):
        pass


class PolyTool(MultiPointTool):
    name = "poly"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.closed = self.style.get("kind") in ("polygon", "cloudpoly")
        self.min_points = 3 if self.closed else 2

    def finish(self, pts):
        doc = self.doc
        i = pts[0].page
        doc.checkpoint()
        page = doc.page(i)
        an = A.create_shape(page, self.style.get("kind", "polyline"), self.style, self.author(),
                            points=[q.unrot for q in pts], content=self.style.get("text") or None)
        xref = an.xref
        doc.commit([i], content=False)
        self.view.set_selected((i, xref))
        self.done()


class InkTool(Tool):
    name = "ink"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.stroke = None
        self.page = None

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit(e.position())
        if not h:
            return
        self.page = h[0]
        self.stroke = [e.position()]

    def move(self, e):
        if self.stroke is not None:
            if (e.position() - self.stroke[-1]).manhattanLength() >= 2:
                self.stroke.append(e.position())
                self.view.viewport().update()

    def release(self, e):
        if self.stroke is None:
            return
        pts = self.stroke
        self.stroke = None
        if len(pts) < 2:
            return
        v = self.view
        i = self.page
        un = []
        for q in pts:
            h = v.hit_unrot(q, clamp_page=i)
            if h:
                un.append((h[1], h[2]))
        doc = self.doc
        doc.checkpoint()
        an = A.create_shape(doc.page(i), "ink", self.style, self.author(), strokes=[un])
        doc.commit([i], content=False)
        self.done()

    def paint(self, p):
        if self.stroke:
            p.setPen(self.style_pen(230))
            p.drawPolyline(QPolygonF(self.stroke))


# ============================================================= text markups
class MarkupTool(Tool):
    """Highlight / underline / strikeout / squiggly by dragging over text."""
    name = "markup"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.sel = SelectTool(main, style, text_only=True)

    def cursor(self):
        return Qt.IBeamCursor

    def activate(self):
        self.sel.view = self.view

    def press(self, e):
        self.sel.view = self.view
        self.sel.press(e)

    def move(self, e):
        self.sel.move(e)

    def release(self, e):
        start = self.sel.drag[4] if self.sel.drag else None
        page = self.sel.drag[1] if self.sel.drag else None
        self.sel.drag = None
        v = self.view
        ts = v.text_sel
        if ts and ts[1]:
            self.apply_to_selection(v)
        elif start is not None and self.style.get("kind") == "highlight":
            # no text: make an area highlight rectangle
            h1 = v.hit_unrot(start, clamp_page=page)
            h2 = v.hit_unrot(e.position(), clamp_page=page)
            if h1 and h2 and abs(h1[1] - h2[1]) > 2 and abs(h1[2] - h2[2]) > 2:
                r = pymupdf.Rect(min(h1[1], h2[1]), min(h1[2], h2[2]), max(h1[1], h2[1]), max(h1[2], h2[2]))
                st = dict(self.style, fill=self.style.get("stroke") or [1, 1, 0], stroke=None, opacity=0.35, width=0)
                self.doc.checkpoint()
                A.create_shape(self.doc.page(page), "area", st, self.author(), rect=r)
                self.doc.commit([page], content=False)
        v.text_sel = None
        v.viewport().update()

    def apply_to_selection(self, v, kind=None):
        ts = v.text_sel
        if not ts:
            return
        i, rects, text = ts[0], ts[1], ts[2]
        # one quad per line
        words = ts[3] if len(ts) > 3 else None
        quads = []
        if words:
            lines = {}
            for w in words:
                key = (w[5], w[6])
                r = lines.get(key)
                lines[key] = pymupdf.Rect(w[:4]) if r is None else r | pymupdf.Rect(w[:4])
            quads = [r.quad for r in lines.values()]
        else:
            quads = [pymupdf.Rect(r).quad for r in rects]
        doc = self.doc
        doc.checkpoint()
        A.create_markup(doc.page(i), kind or self.style.get("kind", "highlight"), quads, self.style, self.author(), content=text)
        doc.commit([i], content=False)

    def paint(self, p):
        pass


class FreeHighlightTool(InkTool):
    """Marker pen: wide translucent stroke mixed with Multiply (text underneath stays black)."""
    name = "freehighlight"

    def paint(self, p):
        if self.stroke:
            pen = self.style_pen(110)
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
            p.setPen(pen)
            p.drawPolyline(QPolygonF(self.stroke))


def _caret_place(doc, i, x, y):
    """Snap a click to the nearest word boundary: returns (x, y_baseline, line_height)."""
    words = doc.words(i) or []
    best, bd = None, None
    for w in words:
        dx = max(w[0] - x, 0, x - w[2])
        dy = max(w[1] - y, 0, y - w[3])
        d = dx * dx + 4 * dy * dy
        if bd is None or d < bd:
            best, bd = w, d
    if best is None or bd > 40 * 40:
        return x, y, 10.0
    hgt = max(4.0, best[3] - best[1])
    bx = best[0] if abs(x - best[0]) < abs(x - best[2]) else best[2]
    return bx, best[3], hgt


class TextEditMarkTool(MarkupTool):
    """Insert Text (caret), Replace Text (strikeout + caret) and Text Correction (both, by gesture)."""
    name = "textmark"

    def release(self, e):
        start = self.sel.drag[4] if self.sel.drag else None
        page = self.sel.drag[1] if self.sel.drag else None
        self.sel.drag = None
        v = self.view
        kind = self.style.get("kind", "inserttext")
        ts = v.text_sel
        v.text_sel = None
        v.viewport().update()
        dragged = start is not None and (e.position() - start).manhattanLength() >= 3
        if dragged and ts and ts[1]:
            if kind == "inserttext":
                i = ts[0]
                last = ts[3][-1] if len(ts) > 3 and ts[3] else ts[1][-1]
                self._insert(i, last[2], last[3], max(4.0, last[3] - last[1]))
            else:
                self._replace(ts)
            return
        if start is None or page is None:
            return
        h = v.hit_unrot(e.position(), clamp_page=page)
        if not h:
            return
        if kind == "replacetext":
            self.main.status("Replace Text: drag over the words to replace.", 6000)
            return
        x, y, lh = _caret_place(self.doc, page, h[1], h[2])
        self._insert(page, x, y, lh)

    def _ask(self, title, default=""):
        from .dialogs import CommentTextDialog
        dlg = CommentTextDialog(self.main, title, default, None)
        if not dlg.exec():
            return None
        return dlg.result_text()[0]

    def _insert(self, i, x, y, lh):
        text = self._ask("Insert text")
        if text is None:
            return
        doc = self.doc
        doc.checkpoint()
        a = A.create_caret(doc.page(i), (x, y), lh, text, self.author(), subject=self.style.get("subject") or "Inserted Text",
                           color=tuple(self.style.get("stroke") or (0.1, 0.35, 0.8)), rot=self.view.total_rot(i))
        doc.commit([i], content=False)
        self.view.set_selected((i, a.xref))
        self.done()

    def _line_end(self, r, i):
        """End of the selection at baseline height (unrotated coords)."""
        return (r.x1, r.y1)

    def _replace(self, ts):
        i, rects, old = ts[0], ts[1], ts[2]
        words = ts[3] if len(ts) > 3 else None
        kind = self.style.get("kind")
        title = "Replace \u201c%s\u201d with" % (old if len(old) < 40 else old[:37] + "...")
        if kind == "textcorrection":
            title += "  (leave empty = delete)"
        new = self._ask(title)
        if new is None:
            return
        if kind == "replacetext" and not new.strip():
            return
        lines = {}
        for w in (words or [(r[0], r[1], r[2], r[3], "", 0, k) for k, r in enumerate(rects)]):
            key = (w[5], w[6])
            r = lines.get(key)
            lines[key] = pymupdf.Rect(w[:4]) if r is None else r | pymupdf.Rect(w[:4])
        quads = [r.quad for r in lines.values()]
        lastr = list(lines.values())[-1]
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        color = tuple(self.style.get("stroke") or (0.85, 0.08, 0.08))
        st = dict(self.style, stroke=list(color))
        so = A.create_markup(page, "strikeout", quads, st, self.author(), content=old)
        sel_x = so.xref
        if new.strip():
            lh = max(4.0, min(lastr.height, lastr.width) if self.view.total_rot(i) % 180 else lastr.height)
            tip = self._line_end(lastr, i)
            ca = A.create_caret(page, tip, lh, new, self.author(), subject="Replace Text", color=color,
                                rot=self.view.total_rot(i))
            gid = "rep%d" % ca.xref
            dd = doc.doc
            dd.xref_set_key(so.xref, "IRT", "%d 0 R" % ca.xref)
            dd.xref_set_key(so.xref, "RT", "/Group")
            dd.xref_set_key(so.xref, "Subj", pymupdf.get_pdf_str("Replace Text"))
            for x in (so.xref, ca.xref):
                dd.xref_set_key(x, "AliefGroup", pymupdf.get_pdf_str(gid))
            sel_x = ca.xref
        else:
            doc.doc.xref_set_key(so.xref, "Subj", pymupdf.get_pdf_str("Delete Text"))
        doc.commit([i], content=False)
        self.view.set_selected((i, sel_x))
        self.done()


class AttachFileTool(Tool):
    name = "attach"

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit_unrot(e.position())
        if not h:
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self.main, "Attach file to the page", "", "All files (*.*)")
        if not path:
            return
        i, x, y = h
        doc = self.doc
        doc.checkpoint()
        try:
            a = A.create_file_attachment(doc.page(i), (x, y), path, self.author(), self.style.get("text", ""),
                                         icon=self.style.get("icon", "Paperclip"),
                                         color=tuple(self.style.get("stroke") or (0.1, 0.35, 0.8)))
        except Exception as ex:
            QMessageBox.warning(self.main, "Attach file", str(ex))
            return
        doc.commit([i], content=False)
        self.view.set_selected((i, a.xref))
        self.done()


class SoundTool(Tool):
    name = "sound"

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit_unrot(e.position())
        if not h:
            return
        from .dialogs import SoundDialog
        dlg = SoundDialog(self.main)
        if not dlg.exec() or not dlg.wav_path:
            return
        i, x, y = h
        doc = self.doc
        doc.checkpoint()
        try:
            _, xref = A.create_sound(doc.page(i), (x, y), dlg.wav_path, self.author(), dlg.note(),
                                     color=tuple(self.style.get("stroke") or (0.1, 0.35, 0.8)))
        except Exception as ex:
            QMessageBox.warning(self.main, "Sound", str(ex))
            return
        doc.commit([i], content=False)
        self.view.set_selected((i, xref))
        self.done()


# ================================================================ click tools
class NoteTool(Tool):
    name = "note"

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit_unrot(e.position())
        if not h:
            return
        from .dialogs import CommentTextDialog
        dlg = CommentTextDialog(self.main, "Sticky note", self.style.get("text", ""), None)
        if not dlg.exec():
            return
        text, _ = dlg.result_text()
        i, x, y = h
        doc = self.doc
        doc.checkpoint()
        a = A.create_note(doc.page(i), (x, y), text, self.style, self.author())
        doc.commit([i], content=False)
        self.view.set_selected((i, a.xref))
        self.done()


class TypewriterTool(Tool):
    name = "typewriter"

    def cursor(self):
        return Qt.IBeamCursor

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit(e.position())
        if not h:
            return
        from .dialogs import CommentTextDialog
        dlg = CommentTextDialog(self.main, "Typewriter", self.style.get("text", ""), self.style.get("fontsize", 10))
        if not dlg.exec():
            return
        text, fs = dlg.result_text()
        if not text.strip():
            return
        i, xd, yd = h
        st = dict(self.style, fontsize=fs, border=False)
        w, hh = A.freetext_size(text, fs, st.get("font", "Helvetica"), min_w=20)
        doc = self.doc
        r = pymupdf.Rect(xd, yd - fs * 0.9, xd + w, yd - fs * 0.9 + hh) * self.view.derot(i)
        ur = pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))
        doc.checkpoint()
        page = doc.page(i)
        a = A.create_freetext(page, ur, text, st, self.author(), rotate=self.view.total_rot(i))
        doc.commit([i], content=False)
        self.view.set_selected((i, a.xref))
        self.done()


class CalloutTool(Tool):
    name = "callout"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.tip = None
        self.cur = None

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit(e.position())
        if not h:
            return
        if self.tip is None:
            self.tip = h
            self.cur = e.position()
        else:
            self._make(e.position())

    def move(self, e):
        if self.tip is not None:
            self.cur = e.position()
            self.view.viewport().update()

    def release(self, e):
        if self.tip is not None and self.cur is not None:
            tipv = self.view.disp_to_view(self.tip[0], self.tip[1], self.tip[2])
            if (e.position() - tipv).manhattanLength() > 25:
                self._make(e.position())

    def _make(self, pos):
        tip = self.tip
        self.tip = None
        self.view.viewport().update()
        i, txd, tyd = tip
        h = self.view.hit(pos, clamp_page=i)
        if not h:
            return
        from .dialogs import CommentTextDialog
        dlg = CommentTextDialog(self.main, "Callout", self.style.get("text", ""), self.style.get("fontsize", 10))
        if not dlg.exec():
            return
        text, fs = dlg.result_text()
        st = dict(self.style, fontsize=fs)
        w, hh = A.freetext_size(text, fs, st.get("font", "Helvetica"))
        _, bxd, byd = h
        doc = self.doc
        derot = self.view.derot(i)
        x0 = bxd if bxd >= txd else bxd - w
        rd = pymupdf.Rect(x0, byd - hh / 2, x0 + w, byd + hh / 2)
        r = rd * derot
        ur = pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))
        tipu = pymupdf.Point(txd, tyd) * derot
        pts_d = A.callout_knee((txd, tyd), tuple(rd))
        pts_u = [tuple(pymupdf.Point(q) * derot) for q in pts_d]
        doc.checkpoint()
        page = doc.page(i)
        a = A.create_freetext(page, ur, text, st, self.author(), callout=pts_u, rotate=self.view.total_rot(i))
        doc.commit([i], content=False)
        self.view.set_selected((i, a.xref))
        self.done()

    def paint(self, p):
        if self.tip is not None and self.cur is not None:
            t = self.view.disp_to_view(*self.tip)
            p.setPen(self.style_pen(230, 1.5))
            p.drawLine(t, self.cur)
            p.drawRect(QRectF(self.cur.x(), self.cur.y() - 12, 110, 24))

    def cancel(self):
        self.tip = None
        super().cancel()


class StampTool(Tool):
    name = "stamp"

    def __init__(self, main=None, style=None, stamp=None):
        super().__init__(main, style)
        self.stamp = stamp
        self.ghost = None
        self.pos = None

    def activate(self):
        from .annots import render_stamp_image
        try:
            self.ghost = render_stamp_image(self.stamp, dpi=96)
        except Exception:
            self.ghost = None

    def move(self, e):
        self.pos = e.position()
        self.view.viewport().update()

    def paint(self, p):
        if self.ghost is not None and self.pos is not None:
            h = self.view.hit(self.pos)
            if not h:
                return
            s = self.view.page_scale(h[0])
            wpt = float(self.stamp.get("width_mm", 62)) * 72 / 25.4
            w = wpt * s
            hh = w * self.ghost.height() / max(1, self.ghost.width())
            p.setOpacity(0.55)
            p.drawImage(QRectF(self.pos.x() - w / 2, self.pos.y() - hh / 2, w, hh), self.ghost)
            p.setOpacity(1.0)

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit_unrot(e.position())
        if not h:
            return
        from .templates import StampValuesDialog, store
        st = store()
        n = st.next_number(self.stamp)
        dlg = StampValuesDialog(self.stamp, n, self.main)
        if not dlg.exec():
            return
        vals = dlg.values()
        note = dlg.e_note.text()
        from .annots import render_stamp_image, image_rect_at, insert_image_stamp
        img = render_stamp_image(self.stamp, vals, dpi=500)
        i, x, y = h
        doc = self.doc
        page = doc.page(i)
        wpt = float(self.stamp.get("width_mm", 62)) * 72 / 25.4
        rect = image_rect_at(page, (x, y), img, wpt, self.view.total_rot(i))
        doc.checkpoint()
        content = "%s %s %s" % (self.stamp.get("title", ""), vals.get("number", ""), vals.get("date", ""))
        if note:
            content += "\n" + note
        blend = "Normal" if self.stamp.get("background", False) else "Multiply"
        a = insert_image_stamp(page, rect, img, self.author(), "Stamp: " + self.stamp.get("name", ""), content.strip(),
                               float(self.stamp.get("opacity", 1.0)), rot=self.view.total_rot(i), blend=blend)
        doc.commit([i], content=False)
        if self.stamp.get("auto_number", True) and "number" in self.stamp.get("fields", []):
            digits = "".join(ch for ch in vals.get("number", "") if ch.isdigit())
            if digits:
                st.commit_number(self.stamp, int(digits[-6:]))
        self.view.set_selected((i, a.xref))
        self.done()


class BalloonTool(Tool):
    """Numbered balloon (1, 2, 3 ...) with the remark stored as its comment text."""
    name = "balloon"

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit_unrot(e.position())
        if not h:
            return
        doc = self.doc
        n = A.next_balloon_number(doc)
        from .dialogs import BalloonDialog
        dlg = BalloonDialog(self.main, n, self.style.get("text", ""))
        if not dlg.exec():
            return
        n, text = dlg.values()
        i, x, y = h
        page = doc.page(i)
        color = self.style.get("stroke") or [0.85, 0.08, 0.08]
        img = A.render_balloon_image(n, color, self.style.get("shape", "circle"), dpi=500,
                                     size_mm=float(self.style.get("size_mm", 6.0)), fill=self.style.get("fill"))
        wpt = float(self.style.get("size_mm", 6.0)) * 72 / 25.4 * img.width() / max(1, img.height())
        rect = A.image_rect_at(page, (x, y), img, wpt, self.view.total_rot(i))
        doc.checkpoint()
        a = A.insert_image_stamp(page, rect, img, self.author(), "Balloon #%s" % n, text, rot=self.view.total_rot(i))
        doc.commit([i], content=False)
        self.view.set_selected((i, a.xref))
        self.done()


class LoupeTool(Tool):
    name = "loupe"

    def cursor(self):
        return Qt.BlankCursor

    def activate(self):
        self.view.set_loupe(True)

    def deactivate(self):
        self.view.set_loupe(False)

    def key(self, e):
        if e.key() in (Qt.Key_Plus, Qt.Key_Equal):
            self.view.loupe_zoom = min(128, self.view.loupe_zoom * 1.25)
            self.view._loupe_timer.start(0)
            return True
        if e.key() == Qt.Key_Minus:
            self.view.loupe_zoom = max(1.25, self.view.loupe_zoom / 1.25)
            self.view._loupe_timer.start(0)
            return True
        return super().key(e)


class SnapshotTool(RectDragTool):
    """Click a page = snapshot of that whole page (high resolution + vector); drag = snapshot of an area."""
    name = "snapshot"

    def __init__(self, main=None, style=None):
        super().__init__(main, style)
        self.hover = None
        self.hpos = None

    def cursor(self):
        return Qt.CrossCursor

    def activate(self):
        if self.main:
            from .settings import settings
            self.main.status("Snapshot: click a page to copy the whole page in high resolution (%d dpi + vector) · "
                             "drag a rectangle for an area · Esc = finish" % int(settings().get("snapshot_dpi", 600)), 0)

    def deactivate(self):
        self.hover = None
        if self.main:
            self.main.status("", 1)

    def move(self, e):
        super().move(e)
        h = self.view.hit_unrot(e.position())
        hv = h[0] if h else None
        self.hpos = e.position()
        if hv != self.hover or self.p0 is None:
            self.hover = hv
            self.view.viewport().update()

    def paint(self, p):
        super().paint(p)
        if self.p0 is not None or self.hover is None:
            return
        v = self.view
        r = v.page_view_rect(self.hover)
        if r is None:
            return
        p.setPen(QPen(QColor(theme.BLUE), 2))
        p.setBrush(QColor(31, 91, 216, 26))
        p.drawRect(r.adjusted(1, 1, -1, -1))
        import math
        from .settings import settings
        dpi = int(settings().get("snapshot_dpi", 600))
        try:
            pw, ph = v.vsizes()[self.hover]
            cap = float(settings().get("snapshot_max_mpx", 64)) * 1e6
            dpi = int(min(dpi, math.sqrt(cap / max(1.0, pw * ph)) * 72))
        except Exception:
            pass
        txt = "  Page %d  -  click = copy whole page (%d dpi + vector)   drag = area  " % (self.hover + 1, dpi)
        f = p.font()
        f.setBold(True)
        p.setFont(f)
        fm = p.fontMetrics()
        w, hgt = fm.horizontalAdvance(txt) + 8, fm.height() + 8
        pos = self.hpos or r.center()
        x = min(max(pos.x() + 16, 4), v.viewport().width() - w - 4)
        y = min(max(pos.y() + 18, 4), v.viewport().height() - hgt - 4)
        box = QRectF(x, y, w, hgt)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(15, 43, 89, 230))
        p.drawRoundedRect(box, 4, 4)
        p.setPen(QColor("white"))
        p.drawText(box, Qt.AlignCenter, txt)

    def key(self, e):
        if e.key() == Qt.Key_Escape and self.main:
            self.main.set_tool("hand")
            return True
        return super().key(e)

    def on_rect(self, i, dr, ur, small):
        if not self.main:
            return
        self.main._snapshot_to_clipboard(self.view, i, None if small else dr, "Page" if small else "Area of page")


# ============================================================= edit content
class RedactTool(RectDragTool):
    name = "redact"
    fill_preview = QColor(0, 0, 0, 90)

    def on_rect(self, i, dr, ur, small):
        if small:
            return
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        a = page.add_redact_annot(ur, fill=(0, 0, 0))
        a.set_info({"title": self.author(), "subject": "Redaction (not applied)"})
        a.update()
        doc.commit([i], content=False)
        if self.main:
            self.main.status("Area marked for redaction. Use Protect ▸ Apply Redactions to remove the content permanently.")


class WhiteoutTool(RectDragTool):
    name = "whiteout"
    fill_preview = QColor(255, 255, 255, 220)

    def on_rect(self, i, dr, ur, small):
        if small:
            return
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        page.draw_rect(ur, color=None, fill=(1, 1, 1), overlay=True)
        doc.commit([i])


class CropTool(RectDragTool):
    name = "crop"
    fill_preview = QColor(31, 91, 216, 25)

    def on_rect(self, i, dr, ur, small):
        if small:
            return
        from .dialogs import ask_crop_scope
        scope = ask_crop_scope(self.main, self.doc.page_count)
        if scope is None:
            return
        doc = self.doc
        doc.checkpoint()
        pages = range(doc.page_count) if scope == "all" else [i]
        for k in pages:
            pg = doc.page(k)
            mb = pg.mediabox
            r = pymupdf.Rect(ur)
            # cropbox is expressed in unrotated, mediabox-relative coordinates
            cb = pg.cropbox
            r = pymupdf.Rect(r.x0 + cb.x0, r.y0 + cb.y0, r.x1 + cb.x0, r.y1 + cb.y0) & mb
            if not r.is_empty:
                try:
                    pg.set_cropbox(r)
                except Exception:
                    pass
        doc.commit(structure=True)


class ImageTool(RectDragTool):
    name = "image"

    def activate(self):
        path, _ = QFileDialog.getOpenFileName(self.main, "Choose image", settings().get("last_dir", ""),
                                              "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.gif)")
        self.path = path or None
        if not path and self.main:
            QTimer.singleShot(0, lambda: self.main.set_tool("select"))
        elif self.main:
            self.main.status("Drag a rectangle where the image should be placed (or click to place at original size).")

    def on_rect(self, i, dr, ur, small):
        if not getattr(self, "path", None):
            return
        doc = self.doc
        page = doc.page(i)
        if small:
            img = QImage(self.path)
            w = img.width() * 72 / max(1, img.dotsPerMeterX() * 0.0254 or 96)
            h = img.height() * 72 / max(1, img.dotsPerMeterY() * 0.0254 or 96)
            ur = pymupdf.Rect(ur.x0, ur.y0, ur.x0 + w, ur.y0 + h)
        doc.checkpoint()
        page.insert_image(ur, filename=self.path, keep_proportion=True, rotate=0)
        doc.commit([i])


class AddTextTool(Tool):
    """Adds real page text (not a comment)."""
    name = "addtext"

    def cursor(self):
        return Qt.IBeamCursor

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        h = self.view.hit(e.position())
        if not h:
            return
        from .dialogs import AddTextDialog
        dlg = AddTextDialog(self.main)
        if not dlg.exec():
            return
        text, font, size, color = dlg.values()
        if not text:
            return
        i, xd, yd = h
        doc = self.doc
        page = doc.page(i)
        pt = pymupdf.Point(xd, yd + size * 0.8) * self.view.derot(i)
        doc.checkpoint()
        page.insert_text(pt, text, fontname=font, fontsize=size, color=color, rotate=self.view.total_rot(i))
        doc.commit([i])


class EditTextTool(Tool):
    """Click a text line to replace its text (redaction + re-insert with matching size / colour)."""
    name = "edittext"

    def cursor(self):
        return Qt.IBeamCursor

    def move(self, e):
        self._hover = self._span_at(e.position())
        self.view.viewport().update()

    def _span_at(self, pos):
        h = self.view.hit_unrot(pos)
        if not h:
            return None
        i, x, y = h
        page = self.doc.page(i)
        try:
            d = page.get_text("dict", clip=pymupdf.Rect(x - 2, y - 2, x + 2, y + 2))
        except Exception:
            return None
        for b in d.get("blocks", []):
            for ln in b.get("lines", []):
                for sp in ln.get("spans", []):
                    r = pymupdf.Rect(sp["bbox"])
                    if r.x0 - 1 <= x <= r.x1 + 1 and r.y0 - 1 <= y <= r.y1 + 1 and sp["text"].strip():
                        return i, sp, ln.get("dir", (1, 0))
        return None

    def paint(self, p):
        hv = getattr(self, "_hover", None)
        if hv:
            i, sp, _ = hv
            p.setPen(QPen(QColor(theme.RED), 1, Qt.DashLine))
            p.setBrush(QColor(255, 120, 0, 30))
            p.drawRect(self.view.unrot_rect_to_view(i, sp["bbox"]))

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        hit = self._span_at(e.position())
        if not hit:
            return
        i, sp, ldir = hit
        text, ok = QInputDialog.getText(self.main, "Edit text", "Replace text (font %s, %.1f pt):" % (sp["font"], sp["size"]),
                                        QLineEdit.Normal, sp["text"])
        if not ok or text == sp["text"]:
            return
        doc = self.doc
        page = doc.page(i)
        doc.checkpoint()
        r = pymupdf.Rect(sp["bbox"])
        shrink = pymupdf.Rect(r.x0 + 0.3, r.y0 + r.height * 0.18, r.x1 - 0.3, r.y1 - r.height * 0.18)
        page.add_redact_annot(shrink, fill=False)
        try:
            page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)
        except TypeError:
            page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE)
        c = sp.get("color", 0)
        color = ((c >> 16) & 255) / 255, ((c >> 8) & 255) / 255, (c & 255) / 255
        flags = sp.get("flags", 0)
        bold = bool(flags & 16) or "bold" in sp["font"].lower()
        serif = bool(flags & 4) or any(k in sp["font"].lower() for k in ("times", "serif", "roman", "cambria", "georgia"))
        mono = bool(flags & 8) or "cour" in sp["font"].lower()
        fn = ("cobo" if bold else "cour") if mono else ("tibo" if bold else "tiro") if serif else ("hebo" if bold else "helv")
        rot = 0
        dx, dy = ldir
        if abs(dx) < 0.5:
            rot = 90 if dy < 0 else 270
        elif dx < 0:
            rot = 180
        page.insert_text(pymupdf.Point(sp["origin"]), text, fontname=fn, fontsize=sp["size"], color=color, rotate=rot)
        doc.commit([i])


class FieldTool(RectDragTool):
    """Add a form field (text box / check box / combo box)."""
    name = "field"

    def on_rect(self, i, dr, ur, small):
        kind = self.style.get("field", "text")
        if small:
            ur = pymupdf.Rect(ur.x0, ur.y0, ur.x0 + (12 if kind == "check" else 140), ur.y0 + (12 if kind == "check" else 18))
        name, ok = QInputDialog.getText(self.main, "Form field", "Field name:", QLineEdit.Normal,
                                        "%s_%d" % (kind, int(ur.x0)))
        if not ok or not name:
            return
        w = pymupdf.Widget()
        w.rect = ur
        w.field_name = name
        if kind == "check":
            w.field_type = pymupdf.PDF_WIDGET_TYPE_CHECKBOX
        elif kind == "combo":
            w.field_type = pymupdf.PDF_WIDGET_TYPE_COMBOBOX
            items, ok = QInputDialog.getText(self.main, "Combo box", "Choices (separate with ;):", QLineEdit.Normal, "Yes;No;N/A")
            w.choice_values = [s.strip() for s in items.split(";") if s.strip()] or ["Yes", "No"]
            w.field_value = w.choice_values[0]
        else:
            w.field_type = pymupdf.PDF_WIDGET_TYPE_TEXT
            w.text_fontsize = 0
        w.border_color = (0.2, 0.3, 0.6)
        w.border_width = 0.8
        w.fill_color = (0.93, 0.96, 1.0)
        doc = self.doc
        doc.checkpoint()
        doc.page(i).add_widget(w)
        doc.commit([i], content=False)


class LinkTool(RectDragTool):
    name = "link"

    def on_rect(self, i, dr, ur, small):
        if small:
            return
        target, ok = QInputDialog.getText(self.main, "Add link", "Page number or web address (https://…):")
        if not ok or not target.strip():
            return
        doc = self.doc
        page = doc.page(i)
        t = target.strip()
        doc.checkpoint()
        if t.isdigit():
            page.insert_link({"kind": pymupdf.LINK_GOTO, "from": ur, "page": max(0, min(doc.page_count - 1, int(t) - 1)),
                              "to": pymupdf.Point(0, 0)})
        else:
            page.insert_link({"kind": pymupdf.LINK_URI, "from": ur, "uri": t})
        doc.commit([i], content=False)
