"""OpenGL support for the 3D review window.

The Qt OpenGL modules (PySide6.QtOpenGL / QtOpenGLWidgets) and the software
OpenGL fallback (opengl32sw.dll, used automatically by Qt on PCs whose graphics
driver has no OpenGL 2.x, e.g. Remote Desktop sessions and virtual machines)
are shipped in the 'qtgl' folder next to this file, so they also reach PCs
that receive the 3D review through an automatic update."""
import os
import sys

_done = [False]


def _dirs():
    here = os.path.dirname(os.path.abspath(__file__))
    out = [os.path.join(here, "qtgl")]
    # the program installed by the setup (when running from a downloaded update)
    exe = os.path.dirname(os.path.abspath(sys.executable))
    out.append(os.path.normpath(os.path.join(exe, "..", "app", "aliefpdf", "qtgl")))
    return [d for d in out if os.path.isdir(d)]


def ensure():
    """Make PySide6.QtOpenGL / QtOpenGLWidgets importable. Returns True when available."""
    if _done[0]:
        return True
    import PySide6
    dirs = _dirs()
    if sys.platform == "win32":
        pdir = os.path.dirname(os.path.abspath(PySide6.__file__))
        for d in [pdir] + dirs:
            if os.path.isfile(os.path.join(d, "opengl32sw.dll")):
                path = os.environ.get("PATH", "")
                if d.lower() not in path.lower().split(os.pathsep):
                    os.environ["PATH"] = d + os.pathsep + path
                break
    try:
        import PySide6.QtOpenGL  # noqa: F401
        import PySide6.QtOpenGLWidgets  # noqa: F401
        _done[0] = True
        return True
    except ImportError:
        pass
    for d in dirs:
        if not (os.path.isfile(os.path.join(d, "QtOpenGL.pyd")) or os.path.isfile(os.path.join(d, "QtOpenGL.abi3.so"))):
            continue
        if d not in PySide6.__path__:
            PySide6.__path__.append(d)
        if sys.platform == "win32" and hasattr(os, "add_dll_directory"):
            try:
                os.add_dll_directory(d)
            except OSError:
                pass
        try:
            import PySide6.QtOpenGL  # noqa: F401,F811
            import PySide6.QtOpenGLWidgets  # noqa: F401,F811
            _done[0] = True
            return True
        except ImportError:
            continue
    return False
