"""Microphone recording (Windows MCI, no extra libraries) and WAV playback."""
import os
import sys
import tempfile

ALIAS = "aliefrec"


def can_record():
    return sys.platform == "win32"


def _mci(cmd):
    import ctypes
    buf = ctypes.create_unicode_buffer(512)
    err = ctypes.windll.winmm.mciSendStringW(cmd, buf, 511, 0)
    if err:
        ebuf = ctypes.create_unicode_buffer(512)
        ctypes.windll.winmm.mciGetErrorStringW(err, ebuf, 511)
        raise RuntimeError(ebuf.value or ("MCI error %d" % err))
    return buf.value


class Recorder:
    def __init__(self):
        self.active = False

    def start(self):
        try:
            _mci("close " + ALIAS)
        except Exception:
            pass
        _mci("open new type waveaudio alias " + ALIAS)
        try:
            _mci("set %s bitspersample 16 channels 1 samplespersec 22050 bytespersec 44100 alignment 2" % ALIAS)
        except Exception:
            pass
        _mci("record " + ALIAS)
        self.active = True

    def stop(self, path):
        try:
            _mci("stop " + ALIAS)
            _mci('save %s "%s"' % (ALIAS, path))
        finally:
            try:
                _mci("close " + ALIAS)
            except Exception:
                pass
            self.active = False
        return path


def temp_wav(prefix="alief_sound_"):
    fd, path = tempfile.mkstemp(prefix=prefix, suffix=".wav")
    os.close(fd)
    return path


def play(path):
    if sys.platform == "win32":
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
    else:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))


def stop():
    if sys.platform == "win32":
        try:
            import winsound
            winsound.PlaySound(None, 0)
        except Exception:
            pass


def play_shutter():
    """Camera shutter click (assets/shutter.wav), asynchronous."""
    from .settings import resource_path
    path = resource_path("assets", "shutter.wav")
    if not os.path.exists(path):
        return
    if sys.platform == "win32":
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
    else:
        try:
            from PySide6.QtWidgets import QApplication
            QApplication.beep()
        except Exception:
            pass
