"""Watermarks: text (any installed font, outline / filled), image or logo (PNG, JPG, SVG, PDF), on chosen pages.

The watermark is drawn once into a small template page and placed on every target page as one shared
Form XObject (small files). Each placement is marked as a PDF watermark artifact
(/Artifact <</Subtype /Watermark>>) and put on the optional content layer "Watermark", so it can be
switched off in the Layers panel or removed again later (Acrobat watermarks can be removed too).
"""
import copy
import io
import json
import math
import os
import re
import sys

import pymupdf

from .settings import app_data_dir

OCG_NAME = "Watermark"
MARK = "AliefWatermark"

DEFAULT = {
    "name": "",
    "kind": "text",                    # text | image
    "text": "See ABS Singapore Letter Ref T1491217 Dated 18-MAR-2016",
    "font": "Arial",                   # family name or a font file path
    "bold": False,
    "italic": False,
    "style": "outline",                # outline | fill | fill_outline
    "color": [0.55, 0.55, 0.55],       # fill colour
    "outline_color": [0.45, 0.45, 0.45],
    "outline_width": 2.5,              # outline thickness in % of the font size
    "opacity": 0.45,
    "image": "",
    "image_gray": False,
    "size_mode": "fit",                # fit | fixed
    "fit_pct": 92.0,                   # % of the page diagonal (diagonal) or width
    "fontsize": 60.0,                  # pt when size_mode == fixed (text)
    "image_width_mm": 120.0,           # mm when size_mode == fixed (image)
    "angle_mode": "diag_up",           # diag_up | diag_down | horizontal | vertical | custom
    "angle": 45.0,
    "position": "center",              # center, top, bottom, left, right, top-left, top-right, bottom-left, bottom-right
    "dx_mm": 0.0,
    "dy_mm": 0.0,
    "margin_mm": 10.0,
    "tile": False,
    "tile_gap_mm": 40.0,
    "layer": "front",                  # front | back
}


# ------------------------------------------------------------------ fonts
_FONT_INDEX = None


def font_index():
    """{family lower: {"regular"/"bold"/"italic"/"bolditalic": path}} of the installed TrueType / OpenType fonts."""
    global _FONT_INDEX
    if _FONT_INDEX is not None:
        return _FONT_INDEX
    idx = {}

    def add(name, path):
        if not path or not os.path.exists(path):
            return
        n = re.sub(r"\s*\((TrueType|OpenType|All res)\)\s*$", "", name, flags=re.I).strip()
        first = n.split("&")[0].strip()
        low = first.lower()
        style = "regular"
        b = bool(re.search(r"\bbold\b", low))
        it = bool(re.search(r"\b(italic|oblique)\b", low))
        fam = re.sub(r"\b(bold|italic|oblique|regular)\b", "", first, flags=re.I).strip()
        if b and it:
            style = "bolditalic"
        elif b:
            style = "bold"
        elif it:
            style = "italic"
        d = idx.setdefault(fam.lower(), {"family": fam})
        d.setdefault(style, path)

    if sys.platform == "win32":
        try:
            import winreg
            windir = os.environ.get("WINDIR", r"C:\Windows")
            for hive, base in ((winreg.HKEY_LOCAL_MACHINE, os.path.join(windir, "Fonts")),
                               (winreg.HKEY_CURRENT_USER,
                                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"))):
                try:
                    k = winreg.OpenKey(hive, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts")
                except OSError:
                    continue
                i = 0
                while True:
                    try:
                        name, val, _ = winreg.EnumValue(k, i)
                    except OSError:
                        break
                    i += 1
                    if not str(val).lower().endswith((".ttf", ".otf", ".ttc")):
                        continue
                    p = val if os.path.isabs(val) else os.path.join(base, val)
                    add(name, p)
        except Exception:
            pass
    else:
        try:
            import subprocess
            out = subprocess.run(["fc-list", "--format", "%{family[0]}|%{style[0]}|%{file}\n"],
                                 capture_output=True, text=True, timeout=10).stdout
            for line in out.splitlines():
                parts = line.split("|")
                if len(parts) == 3 and parts[2].lower().endswith((".ttf", ".otf")):
                    fam, sty, path = parts
                    sty = sty.lower()
                    if sty in ("book", "regular", "normal", "roman"):
                        add(fam, path)
                    else:
                        add(fam + " " + sty, path)
        except Exception:
            pass
    _FONT_INDEX = idx
    return idx


def font_file(family, bold=False, italic=False):
    """Path of the font file for a family / style, or None (base-14 fallback)."""
    if family and os.path.isfile(family):
        return family
    d = font_index().get((family or "").lower())
    if not d:
        return None
    key = "bolditalic" if bold and italic else "bold" if bold else "italic" if italic else "regular"
    for k in (key, "bold" if bold else "regular", "regular", "bold", "italic", "bolditalic"):
        if d.get(k):
            return d[k]
    return None


def _base14(bold, italic):
    return "hebi" if bold and italic else "hebo" if bold else "heit" if italic else "helv"


# ------------------------------------------------------------------ template
def build_template(cfg, ref_size=200.0):
    """One-page PDF holding the watermark artwork at its natural size. Returns (doc, w, h)."""
    cfg = dict(DEFAULT, **(cfg or {}))
    src = pymupdf.open()
    op = max(0.02, min(1.0, float(cfg.get("opacity", 0.45))))
    if cfg["kind"] == "image":
        path = cfg.get("image") or ""
        if not path or not os.path.exists(path):
            raise ValueError("Choose the image / logo file of the watermark.")
        ext = os.path.splitext(path)[1].lower()
        if ext in (".pdf", ".svg"):
            vd = pymupdf.open(path)
            if ext == ".svg":
                vd = pymupdf.open("pdf", vd.convert_to_pdf())
            vp = vd[0]
            w, h = vp.rect.width, vp.rect.height
            page = src.new_page(width=w, height=h)
            page.show_pdf_page(page.rect, vd, 0)
            _wrap_opacity(src, page, op, gray=cfg.get("image_gray"))
            return src, w, h
        from PIL import Image, ImageOps
        img = Image.open(path)
        img = ImageOps.exif_transpose(img).convert("RGBA")
        if cfg.get("image_gray"):
            a = img.getchannel("A")
            img = ImageOps.grayscale(img.convert("RGB")).convert("RGBA")
            img.putalpha(a)
        if op < 0.999:
            img.putalpha(img.getchannel("A").point(lambda v: int(v * op)))
        bio = io.BytesIO()
        img.save(bio, "PNG")
        w = 72.0 * img.width / max(1.0, float((img.info.get("dpi") or (150, 150))[0] or 150))
        w = max(w, 50.0)
        h = w * img.height / img.width
        page = src.new_page(width=w, height=h)
        page.insert_image(page.rect, stream=bio.getvalue())
        return src, w, h
    # ---- text
    text = (cfg.get("text") or "").replace("\r\n", "\n").strip("\n")
    if not text.strip():
        raise ValueError("Type the watermark text.")
    lines = text.split("\n")
    fs = float(ref_size)
    ffile = font_file(cfg.get("font"), cfg.get("bold"), cfg.get("italic"))
    if ffile:
        try:
            font = pymupdf.Font(fontfile=ffile)
        except Exception:
            ffile = None
    if not ffile:
        font = pymupdf.Font(_base14(cfg.get("bold"), cfg.get("italic")))
    widths = [font.text_length(ln, fs) for ln in lines]
    asc, desc = font.ascender, font.descender
    if not asc or asc <= 0:
        asc, desc = 0.9, -0.22
    lh = fs * 1.18
    sw = fs * float(cfg.get("outline_width", 2.5)) / 100.0
    pad = fs * 0.05 + sw
    w = max(widths) + 2 * pad
    h = lh * (len(lines) - 1) + fs * (asc - desc) + 2 * pad
    page = src.new_page(width=w, height=h)
    style = cfg.get("style", "outline")
    mode = {"fill": 0, "outline": 1, "fill_outline": 2}.get(style, 1)
    fill = tuple(cfg.get("color") or (0.5, 0.5, 0.5))
    stroke = tuple(cfg.get("outline_color") or fill)
    kw = dict(fontsize=fs, render_mode=mode, fill_opacity=op, stroke_opacity=op)
    if ffile:
        kw.update(fontfile=ffile, fontname="AWMF")
    else:
        kw.update(fontname=_base14(cfg.get("bold"), cfg.get("italic")))
    if mode == 0:
        kw.update(color=fill)
    elif mode == 1:
        kw.update(color=stroke, border_width=max(0.001, sw / fs))
    else:
        kw.update(color=stroke, fill=fill, border_width=max(0.001, sw / fs))
    as_paths = cfg.get("text_as_paths", True)
    if as_paths:
        kw.update(fill_opacity=1.0, stroke_opacity=1.0)
    for k, ln in enumerate(lines):
        x = pad + (max(widths) - widths[k]) / 2
        y = pad + fs * asc + k * lh
        page.insert_text((x, y), ln, **kw)
    if as_paths:
        # letters become vector outlines: the watermark is not picked up by Select Text / table copy / search,
        # and looks the same on every PC (no font needed)
        try:
            svg = page.get_svg_image(text_as_path=True)
            vd = pymupdf.open("svg", svg.encode("utf-8"))
            pd = pymupdf.open("pdf", vd.convert_to_pdf())
            out = pymupdf.open()
            op_page = out.new_page(width=w, height=h)
            op_page.show_pdf_page(op_page.rect, pd, 0)
            _wrap_opacity(out, op_page, op)
            return out, w, h
        except Exception:
            cfg = dict(cfg, text_as_paths=False)
            return build_template(cfg, ref_size)
    return src, w, h


def _wrap_opacity(doc, page, op, gray=False):
    """Give a vector template a constant opacity (ExtGState around its content)."""
    if op >= 0.999 and not gray:
        return
    xr = page.get_contents()
    data = b"".join(doc.xref_stream(x) or b"" for x in xr)
    gs = "<</Type/ExtGState/CA %.3f/ca %.3f>>" % (op, op)
    tgt, prefix = page.xref, "Resources/"
    t, v = doc.xref_get_key(page.xref, "Resources")
    if t == "xref":
        tgt, prefix = int(v.split()[0]), ""
    elif t == "null":
        doc.xref_set_key(page.xref, "Resources", "<<>>")
    t, v = doc.xref_get_key(tgt, prefix + "ExtGState")
    if t == "xref":
        doc.xref_set_key(int(v.split()[0]), "AWop", gs)
    else:
        if t == "null":
            doc.xref_set_key(tgt, prefix + "ExtGState", "<<>>")
        doc.xref_set_key(tgt, prefix + "ExtGState/AWop", gs)
    new = b"q /AWop gs\n" + data + b"\nQ"
    doc.update_stream(xr[0], new)
    if len(xr) > 1:
        doc.xref_set_key(page.xref, "Contents", "%d 0 R" % xr[0])


# ------------------------------------------------------------------ placement
def _angle(cfg, w, h):
    m = cfg.get("angle_mode", "diag_up")
    if m == "diag_up":
        return math.degrees(math.atan2(h, w))
    if m == "diag_down":
        return -math.degrees(math.atan2(h, w))
    if m == "vertical":
        return 90.0
    if m == "horizontal":
        return 0.0
    return float(cfg.get("angle", 45.0))


def _rot_bbox(w, h, ang):
    a = math.radians(ang)
    c, s = abs(math.cos(a)), abs(math.sin(a))
    return w * c + h * s, w * s + h * c


def placements(cfg, tw, th, pw, ph, ref_size=200.0):
    """List of display-space rects (x0, y0, x1, y1) and the angle for one page of size pw x ph (points)."""
    cfg = dict(DEFAULT, **(cfg or {}))
    ang = _angle(cfg, pw, ph)
    mm = 72.0 / 25.4
    # natural (scale 1) size of the artwork
    if cfg["size_mode"] == "fit":
        bw, bh = _rot_bbox(tw, th, ang)
        frac = max(0.05, float(cfg.get("fit_pct", 85.0)) / 100.0)
        if cfg.get("tile"):
            frac = min(frac, 0.45)
        diag = math.hypot(pw, ph)
        if cfg.get("angle_mode") in ("diag_up", "diag_down"):
            k = frac * diag / max(tw, 1e-6)
        else:
            k = frac * pw / max(bw, 1e-6)
        bw, bh = bw * k, bh * k
        # never larger than the page
        f = min(1.0, pw / max(bw, 1e-6), ph / max(bh, 1e-6))
        k *= f
    else:
        if cfg["kind"] == "text":
            k = float(cfg.get("fontsize", 60.0)) / ref_size
        else:
            k = float(cfg.get("image_width_mm", 120.0)) * mm / max(tw, 1e-6)
    bw, bh = _rot_bbox(tw * k, th * k, ang)
    margin = float(cfg.get("margin_mm", 10.0)) * mm
    dx, dy = float(cfg.get("dx_mm", 0.0)) * mm, float(cfg.get("dy_mm", 0.0)) * mm
    out = []
    if cfg.get("tile"):
        gap = max(2.0, float(cfg.get("tile_gap_mm", 40.0)) * mm)
        stepx, stepy = bw + gap, bh + gap
        ny = int(ph / stepy) + 2
        nx = int(pw / stepx) + 2
        oy = (ph - (ny - 1) * stepy) / 2 + dy
        for j in range(ny):
            ox = (pw - (nx - 1) * stepx) / 2 + dx + (stepx / 2 if j % 2 else 0)
            for i in range(nx):
                cx, cy = ox + i * stepx, oy + j * stepy
                r = (cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)
                if r[2] > 0 and r[0] < pw and r[3] > 0 and r[1] < ph:
                    out.append(r)
        return out, ang
    pos = cfg.get("position", "center")
    cx = pw / 2
    cy = ph / 2
    if "left" in pos:
        cx = margin + bw / 2
    elif "right" in pos:
        cx = pw - margin - bw / 2
    if "top" in pos:
        cy = margin + bh / 2
    elif "bottom" in pos:
        cy = ph - margin - bh / 2
    cx += dx
    cy += dy
    out.append((cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2))
    return out, ang


def ensure_ocg(doc):
    try:
        for x, info in (doc.get_ocgs() or {}).items():
            if info.get("name") == OCG_NAME:
                return x
        return doc.add_ocg(OCG_NAME, on=True)
    except Exception:
        return 0


def apply(doc, pages, cfg, progress=None):
    """Put the watermark on the given page numbers. Returns the number of pages done."""
    cfg = dict(DEFAULT, **(cfg or {}))
    src, tw, th = build_template(cfg)
    oc = ensure_ocg(doc)
    overlay = cfg.get("layer", "front") != "back"
    done = 0
    for n, pno in enumerate(pages):
        if progress and progress(n, len(pages)) is False:
            break
        page = doc.load_page(pno)
        pw, ph = page.rect.width, page.rect.height          # as displayed (rotation applied)
        rects, ang = placements(cfg, tw, th, pw, ph)
        before = set(page.get_contents())
        for r in rects:
            ur = pymupdf.Rect(r) * page.derotation_matrix
            ur.normalize()
            page.show_pdf_page(ur, src, 0, rotate=ang + page.rotation, keep_proportion=True, overlay=overlay, oc=oc)
        _mark(doc, page, before, cfg)
        done += 1
    return done


def _mark(doc, page, before, cfg):
    """Wrap the new content streams as a watermark artifact and tag the form XObjects."""
    tag = pymupdf.get_pdf_str(json.dumps({"name": cfg.get("name") or "", "kind": cfg.get("kind")}))
    for x in page.get_contents():
        if x in before:
            continue
        data = doc.xref_stream(x) or b""
        if b" Do" not in data and b"\nDo" not in data:
            continue
        for m in re.finditer(rb"/([A-Za-z0-9_.#-]+)\s+Do", data):
            name = m.group(1).decode("latin-1")
            t, v = doc.xref_get_key(page.xref, "Resources/XObject/" + name)
            if t == "xref":
                doc.xref_set_key(int(v.split()[0]), MARK, tag)
        doc.update_stream(x, b"/Artifact <</Type /Pagination /Subtype /Watermark /AliefWM true>> BDC\n" + data + b"\nEMC\n")


# ------------------------------------------------------------------ removal
_ART = re.compile(rb"/Artifact\s*<<(?:(?!>>).)*?/Subtype\s*/Watermark(?:(?!>>).)*?>>\s*BDC.*?EMC", re.S)


def _is_own(m):
    head = m.group(0)[:200]
    return b"/AliefWM" in head


def watermark_kinds(doc, pno):
    """Set of 'own' / 'other' watermark artifacts on the page."""
    out = set()
    page = doc.load_page(pno)
    for x in page.get_contents():
        for m in _ART.finditer(doc.xref_stream(x) or b""):
            out.add("own" if _is_own(m) else "other")
    return out


def page_has_watermark(doc, pno):
    return bool(watermark_kinds(doc, pno))


def remove(doc, pages, include_other=True):
    """Remove watermark artifacts (own, and optionally Acrobat's) from the pages. Returns pages changed."""
    changed = 0
    for pno in pages:
        page = doc.load_page(pno)
        hit = False
        for x in page.get_contents():
            data = doc.xref_stream(x) or b""
            cnt = [0]

            def rep(m):
                if include_other or _is_own(m):
                    cnt[0] += 1
                    return b""
                return m.group(0)
            new = _ART.sub(rep, data)
            if cnt[0]:
                doc.update_stream(x, new)
                hit = True
        if hit:
            changed += 1
    return changed


# ------------------------------------------------------------------ preview / profiles
def preview_image(doc, pno, cfg, width_px=420, cache=None):
    """QImage of one page with the watermark (the document itself is not changed).

    The page itself is rendered once and kept in 'cache' (a dict); only the watermark layer is drawn again,
    so the preview follows the settings instantly even on heavy drawings.
    """
    from PySide6.QtGui import QImage, QPainter
    page = doc.load_page(pno)
    pw, ph = page.rect.width, page.rect.height
    z = width_px / max(1.0, pw)
    key = (pno, int(width_px))
    base = cache.get(key) if cache is not None else None
    if base is None:
        pix = page.get_pixmap(matrix=pymupdf.Matrix(z, z), alpha=False)
        base = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
        if cache is not None:
            if len(cache) > 6:
                cache.clear()
            cache[key] = base
    tmp = pymupdf.open()
    tmp.new_page(width=pw, height=ph)
    apply(tmp, [0], cfg)
    wp = tmp[0].get_pixmap(matrix=pymupdf.Matrix(z, z), alpha=True)
    wimg = QImage(wp.samples, wp.width, wp.height, wp.stride, QImage.Format_RGBA8888_Premultiplied).copy()
    out = base.convertToFormat(QImage.Format_RGB32)
    qp = QPainter(out)
    if (cfg or {}).get("layer") == "back":
        qp.setCompositionMode(QPainter.CompositionMode_Multiply)   # looks like "behind the lines" on white paper
    qp.drawImage(0, 0, wimg)
    qp.end()
    return out


def _store_path():
    return os.path.join(app_data_dir(), "watermarks.json")


def load_profiles():
    try:
        with open(_store_path(), "r", encoding="utf-8") as f:
            lst = json.load(f)
        if isinstance(lst, list):
            return [dict(DEFAULT, **p) for p in lst if isinstance(p, dict)]
    except Exception:
        pass
    abs_ = copy.deepcopy(DEFAULT)
    abs_["name"] = "Class approval reference (example)"
    conf = copy.deepcopy(DEFAULT)
    conf.update(name="CONFIDENTIAL (red)", text="CONFIDENTIAL", font="Arial", bold=True, style="fill",
                color=[0.85, 0.1, 0.1], opacity=0.18, fit_pct=70.0)
    draft = copy.deepcopy(DEFAULT)
    draft.update(name="FOR APPROVAL (blue, top)", text="FOR APPROVAL", bold=True, style="fill_outline",
                 color=[0.75, 0.85, 1.0], outline_color=[0.12, 0.36, 0.85], opacity=0.6, angle_mode="horizontal",
                 size_mode="fixed", fontsize=36.0, position="top")
    return [abs_, conf, draft]


def save_profiles(lst):
    try:
        with open(_store_path(), "w", encoding="utf-8") as f:
            json.dump(lst, f, indent=1)
        return True
    except Exception:
        return False


def _last_path():
    return os.path.join(app_data_dir(), "watermark_last.json")


def save_last(cfg):
    try:
        with open(_last_path(), "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=1)
    except Exception:
        pass


def load_last():
    try:
        with open(_last_path(), "r", encoding="utf-8") as f:
            c = json.load(f)
        return dict(DEFAULT, **c) if isinstance(c, dict) else None
    except Exception:
        return None
