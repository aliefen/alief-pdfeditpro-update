"""Colours, style sheet and icon helper (Alief corporate look)."""
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QIcon, QPixmap, QPainter, QColor, QPen, QFont

try:
    import qtawesome as qta
except Exception:  # pragma: no cover
    qta = None

NAVY = "#0E2A47"
NAVY2 = "#163B63"
BLUE = "#1F5BD8"      # Alief royal blue
GREEN = "#2BB24C"     # Alief bright green
RED = "#D3302F"       # product colour (PDF)
GOLD = "#C9A227"
BG = "#EEF2F7"
PANEL = "#FFFFFF"
BORDER = "#D5DCE6"
TEXT = "#1B2430"
MUTED = "#5B6675"
VIEW_BG = "#5F6B78"

ICON_COLOR = "#24476F"
ICON_ACCENT = {"comment": "#C62828", "measure": "#1565C0", "convert": "#2E7D32",
               "protect": "#6A1B9A", "edit": "#E65100", "organize": "#00838F"}

_cache = {}


def icon(name, color=ICON_COLOR, accent=None):
    key = (name, color, accent)
    if key in _cache:
        return _cache[key]
    ic = QIcon()
    if qta is not None:
        try:
            ic = qta.icon("mdi6." + name, color=accent or color,
                          color_disabled="#AAB3BF")
        except Exception:
            try:
                ic = qta.icon("mdi6.help-circle-outline", color=color)
            except Exception:
                ic = QIcon()
    _cache[key] = ic
    return ic


def color_icon(rgb, size=16, shape="square"):
    """Small swatch icon for colour pickers / template lists."""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    c = QColor.fromRgbF(*rgb) if rgb is not None else QColor(0, 0, 0, 0)
    p.setPen(QPen(QColor("#555"), 1))
    p.setBrush(c)
    if shape == "circle":
        p.drawEllipse(1, 1, size - 2, size - 2)
    else:
        p.drawRect(1, 1, size - 3, size - 3)
    p.end()
    return QIcon(pm)


STYLE = f"""
* {{ font-family: 'Segoe UI', 'Noto Sans', Arial; font-size: 9pt; color: {TEXT}; }}
QMainWindow {{ background: {BG}; }}
QMenuBar {{ background: {NAVY}; color: white; }}
QMenuBar::item {{ color: white; padding: 4px 10px; background: transparent; }}
QMenuBar::item:selected {{ background: {NAVY2}; }}
QMenu {{ background: white; border: 1px solid {BORDER}; }}
QMenu::item {{ padding: 5px 26px 5px 26px; }}
QMenu::item:selected {{ background: #E3ECFB; color: {TEXT}; }}
QMenu::separator {{ height: 1px; background: {BORDER}; margin: 3px 6px; }}

#TitleBand {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {NAVY}, stop:0.7 {NAVY2}, stop:1 #1D4F86); }}
#TitleBand QLabel {{ color: white; }}
#AppTitle {{ font-family: 'Century Gothic','Segoe UI'; font-size: 11pt; font-weight: bold; letter-spacing: 1px; }}
#AppSub {{ color: #9FC3F0; font-size: 8pt; }}
#QuickBar QToolButton {{ background: transparent; border: none; padding: 3px; border-radius: 3px; }}
#QuickBar QToolButton:hover {{ background: rgba(255,255,255,0.18); }}

QTabWidget#Ribbon::pane {{ border: none; border-top: 1px solid {BORDER}; background: #FBFCFE; }}
QTabWidget#Ribbon > QTabBar {{ background: {NAVY2}; }}
QTabWidget#Ribbon > QTabBar::tab {{ background: transparent; color: #DCE8F7; padding: 5px 16px; margin-right: 1px;
    font-weight: 600; letter-spacing: 0.5px; border: none; }}
QTabWidget#Ribbon > QTabBar::tab:selected {{ background: #FBFCFE; color: {NAVY}; border-top: 3px solid {GREEN}; }}
QTabWidget#Ribbon > QTabBar::tab:hover:!selected {{ background: rgba(255,255,255,0.12); color: white; }}
#RibbonPage {{ background: #FBFCFE; }}
#RibbonGroup {{ background: transparent; border-right: 1px solid #E1E6EE; }}
#RibbonGroupTitle {{ color: {MUTED}; font-size: 7.5pt; }}
#RibbonPage QToolButton {{ background: transparent; border: 1px solid transparent; border-radius: 4px; padding: 2px 3px; }}
#RibbonPage QToolButton:hover {{ background: #E6EEFB; border: 1px solid #C8D8F4; }}
#RibbonPage QToolButton:checked {{ background: #D4E3FA; border: 1px solid #8DB0EA; }}
#RibbonPage QToolButton:pressed {{ background: #C3D6F5; }}
#RibbonPage QComboBox, #RibbonPage QSpinBox, #RibbonPage QDoubleSpinBox {{ padding: 1px 4px; min-height: 20px; }}

QTabWidget#DocTabs::pane {{ border: none; }}
QTabWidget#DocTabs > QTabBar::tab {{ background: #DCE3EC; border: 1px solid {BORDER}; border-bottom: none; padding: 4px 10px;
    margin-right: 2px; border-top-left-radius: 4px; border-top-right-radius: 4px; max-width: 280px; }}
QTabWidget#DocTabs > QTabBar::tab:selected {{ background: white; border-top: 2px solid {BLUE}; }}

QDockWidget {{ font-weight: 600; }}
QDockWidget::title {{ background: #E4EAF2; padding: 4px 6px; border-bottom: 1px solid {BORDER}; }}
QTabWidget#SidePanels::pane {{ border: none; background: white; }}
QTabWidget#SidePanels > QTabBar::tab {{ padding: 6px 4px; background: #E9EEF5; border: 1px solid {BORDER}; margin-bottom: 1px; }}
QTabWidget#SidePanels > QTabBar::tab:selected {{ background: white; border-left: 3px solid {BLUE}; }}

QStatusBar {{ background: {NAVY}; color: white; }}
QStatusBar QLabel {{ color: white; padding: 0 6px; }}
QStatusBar QToolButton {{ color: #DCE8F7; background: transparent; border: 1px solid transparent; border-radius: 3px; padding: 1px 5px; font-size: 8pt; font-weight: 600; }}
QStatusBar QToolButton:hover {{ border: 1px solid rgba(255,255,255,0.35); }}
QStatusBar QToolButton:checked {{ background: {BLUE}; color: white; }}
QStatusBar QToolButton#RotBtn {{ color: white; font-size: 8.5pt; font-weight: 700; padding: 1px 4px; border: 1px solid rgba(255,255,255,0.28); margin: 0 1px; }}
QStatusBar QToolButton#LayBtn {{ padding: 1px 2px; }}
QStatusBar QToolButton#RotBtn:hover {{ background: rgba(255,255,255,0.16); border: 1px solid rgba(255,255,255,0.6); }}
QStatusBar QSpinBox, QStatusBar QComboBox {{ background: white; color: {TEXT}; min-height: 18px; }}

QPushButton {{ background: white; border: 1px solid #B9C4D3; border-radius: 4px; padding: 5px 14px; }}
QPushButton:hover {{ background: #EAF1FC; border-color: {BLUE}; }}
QPushButton:default, QPushButton#Primary {{ background: {BLUE}; color: white; border-color: {BLUE}; font-weight: 600; }}
QPushButton#Primary:hover {{ background: #184BB6; }}
QLineEdit, QPlainTextEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {{ background: white; border: 1px solid #B9C4D3; border-radius: 3px; padding: 3px; }}
QLineEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{ border: 1px solid {BLUE}; }}
QGroupBox {{ border: 1px solid {BORDER}; border-radius: 5px; margin-top: 10px; padding-top: 8px; font-weight: 600; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 8px; padding: 0 4px; color: {NAVY}; }}
QHeaderView::section {{ background: #E9EEF5; border: none; border-right: 1px solid {BORDER}; border-bottom: 1px solid {BORDER}; padding: 4px; font-weight: 600; }}
QTreeWidget, QTableWidget, QListWidget {{ background: white; border: 1px solid {BORDER}; alternate-background-color: #F6F8FB; }}
QTreeWidget::item:selected, QTableWidget::item:selected, QListWidget::item:selected {{ background: #D4E3FA; color: {TEXT}; }}
QProgressBar {{ border: 1px solid {BORDER}; border-radius: 3px; text-align: center; background: white; }}
QProgressBar::chunk {{ background: {GREEN}; }}
QToolTip {{ background: #FFFDE7; color: {TEXT}; border: 1px solid #C9B458; padding: 4px; }}
#PaneHeader {{ background: #E8EDF4; border-bottom: 1px solid {BORDER}; }}
#FindBar {{ background: #FFF8E1; border-bottom: 1px solid #E5D49B; }}
"""
