"""Comment summary (Excel / PDF with snapshots) and measurement export."""
import datetime
import json
import os

import pymupdf

from . import APP_NAME, COMPANY

HEAD_FILL = "D9EAD3"   # light green (company calculation-report style)
NAVY = "0E2A47"


def _comments(pdfdoc):
    out = []
    for i in range(pdfdoc.page_count):
        for a in pdfdoc.annot_list(i):
            t = a["type"]
            subj = a.get("subject") or ""
            if t in ("Popup", "Widget", "Link") or subj in ("Measurement label",) or subj.startswith("Measure: Centroid"):
                continue
            out.append((i, a))
    return out


def _date(s):
    s = (s or "").replace("D:", "")
    if len(s) >= 12:
        return "%s-%s-%s %s:%s" % (s[0:4], s[4:6], s[6:8], s[8:10], s[10:12])
    return s


def comments_xlsx(pdfdoc, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Comment Summary"
    thin = Side(style="thin", color="9AA5B1")
    bd = Border(left=thin, right=thin, top=thin, bottom=thin)
    f = Font(name="Cambria", size=10)
    fb = Font(name="Cambria", size=10, bold=True)
    ws["A1"] = "COMMENT SUMMARY"
    ws["A1"].font = Font(name="Cambria", size=14, bold=True, color=NAVY)
    ws["A2"] = "Document: %s" % (pdfdoc.path or pdfdoc.title)
    ws["A3"] = "Generated: %s by %s - %s" % (datetime.datetime.now().strftime("%d %b %Y %H:%M"), APP_NAME, COMPANY)
    for c in ("A2", "A3"):
        ws[c].font = Font(name="Cambria", size=9, italic=True)
    heads = ["No.", "Page", "Type", "Subject", "Comment / Remark", "Author", "Date", "Status", "Reply / Action"]
    widths = [6, 7, 12, 22, 60, 16, 17, 14, 30]
    for k, (h, w) in enumerate(zip(heads, widths), start=1):
        c = ws.cell(5, k, h)
        c.font = fb
        c.fill = PatternFill("solid", fgColor=HEAD_FILL)
        c.border = bd
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[c.column_letter].width = w
    r = 6
    for n, (i, a) in enumerate(_comments(pdfdoc), start=1):
        vals = [n, i + 1, a["type"], a.get("subject") or "", a.get("content") or "", a.get("author") or "",
                _date(a.get("date")), a.get("status") or "", ""]
        for k, v in enumerate(vals, start=1):
            c = ws.cell(r, k, v)
            c.font = f
            c.border = bd
            c.alignment = Alignment(vertical="top", wrap_text=True, horizontal="center" if k in (1, 2) else "left")
        r += 1
    ws.freeze_panes = "A6"
    ws.auto_filter.ref = "A5:I%d" % max(5, r - 1)
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = "5:5"
    wb.save(path)
    return path


def comments_pdf(pdfdoc, path):
    """A4 report: one row per comment with a snapshot of the marked area."""
    out = pymupdf.open()
    W, H = pymupdf.paper_size("a4")
    M = 36
    items = _comments(pdfdoc)
    title = pdfdoc.title
    navy = (0.055, 0.165, 0.28)
    green = (0.17, 0.70, 0.30)
    page = None
    y = 0
    pno = 0

    def new_page():
        nonlocal page, y, pno
        page = out.new_page(width=W, height=H)
        pno += 1
        page.draw_rect(pymupdf.Rect(0, 0, W, 54), color=None, fill=navy)
        page.draw_rect(pymupdf.Rect(0, 54, W, 57), color=None, fill=green)
        page.insert_text((M, 26), "COMMENT SUMMARY", fontsize=15, fontname="hebo", color=(1, 1, 1))
        page.insert_text((M, 43), title, fontsize=8.5, fontname="helv", color=(0.8, 0.88, 1))
        page.insert_text((W - M - 160, 26), COMPANY, fontsize=8, fontname="hebo", color=(1, 1, 1))
        page.insert_text((W - M - 160, 40), datetime.datetime.now().strftime("%d %b %Y %H:%M"), fontsize=8, fontname="helv", color=(0.8, 0.88, 1))
        page.insert_text((M, H - 18), "%s · page %d" % (APP_NAME, pno), fontsize=7, fontname="helv", color=(0.4, 0.4, 0.4))
        y = 72

    new_page()
    if not items:
        page.insert_text((M, y + 20), "No comments in this document.", fontsize=11)
    for n, (i, a) in enumerate(items, start=1):
        src = pdfdoc.page(i)
        r = pymupdf.Rect(a["rect"])
        # snapshot area around the comment (display orientation)
        pad = max(18, 0.25 * max(r.width, r.height))
        clip = (pymupdf.Rect(r.x0 - pad, r.y0 - pad, r.x1 + pad, r.y1 + pad) * src.rotation_matrix) & src.rect
        snap_w = 190
        if clip.is_empty or clip.width < 1:
            clip = src.rect
        z = min(snap_w / clip.width, 140 / clip.height, 4)
        hh = clip.height * z
        text = a.get("content") or ""
        lines = []
        for para in text.split("\n"):
            while len(para) > 70:
                cut = para.rfind(" ", 0, 70)
                cut = cut if cut > 20 else 70
                lines.append(para[:cut])
                para = para[cut:].lstrip()
            lines.append(para)
        row_h = max(hh + 10, 46 + 11 * len(lines))
        if y + row_h > H - 40:
            new_page()
        page.draw_rect(pymupdf.Rect(M, y, W - M, y + row_h), color=(0.82, 0.86, 0.9), width=0.6)
        page.draw_rect(pymupdf.Rect(M, y, M + 26, y + row_h), color=None, fill=(0.85, 0.92, 0.83))
        page.insert_text((M + 6, y + 16), str(n), fontsize=10, fontname="hebo", color=navy)
        try:
            dl = pdfdoc.display_list(i)
            pix = dl.get_pixmap(matrix=pymupdf.Matrix(z * 2.2, z * 2.2), clip=clip, alpha=False)
            target = pymupdf.Rect(M + 32, y + 5, M + 32 + clip.width * z, y + 5 + hh)
            page.insert_image(target, pixmap=pix)
            page.draw_rect(target, color=(0.7, 0.74, 0.8), width=0.4)
        except Exception:
            pass
        tx = M + 32 + snap_w + 12
        status = a.get("status") or ""
        page.insert_text((tx, y + 14), "Page %d  ·  %s  ·  %s" % (i + 1, a.get("subject") or a["type"], a.get("author") or ""),
                         fontsize=8.5, fontname="hebo", color=navy)
        page.insert_text((tx, y + 26), _date(a.get("date")) + (("   Status: " + status) if status else ""), fontsize=7.5,
                         fontname="helv", color=(0.35, 0.35, 0.4))
        yy = y + 40
        for ln in lines[:30]:
            page.insert_text((tx, yy), ln, fontsize=8.5, fontname="helv", color=(0.1, 0.1, 0.1))
            yy += 11
        y += row_h + 6
    out.save(path, garbage=3, deflate=True)
    out.close()
    return path


def measurements_xlsx(pdfdoc, rows, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Measurements"
    thin = Side(style="thin", color="9AA5B1")
    bd = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["A1"] = "MEASUREMENT LIST"
    ws["A1"].font = Font(name="Cambria", size=14, bold=True, color=NAVY)
    ws["A2"] = "Document: %s" % (pdfdoc.path or pdfdoc.title)
    ws["A2"].font = Font(name="Cambria", size=9, italic=True)
    heads = ["No.", "Page", "Type", "Value", "Unit", "Perimeter / Ø", "Centroid X", "Centroid Y", "Scale", "Text"]
    for k, h in enumerate(heads, start=1):
        c = ws.cell(4, k, h)
        c.font = Font(name="Cambria", size=10, bold=True)
        c.fill = PatternFill("solid", fgColor=HEAD_FILL)
        c.border = bd
        c.alignment = Alignment(horizontal="center")
    from .measure import UNIT_TO_M
    r = 5
    for n, (i, xref, t, val, per, cx, cy, sc, d) in enumerate(rows, start=1):
        u = d.get("unit", "m")
        f = UNIT_TO_M.get(u, 1.0)
        if "value_m2" in d:
            v, unit = d["value_m2"] / (f * f), u + "²"
        elif "value_deg" in d:
            v, unit = d["value_deg"], "°"
        else:
            v, unit = d.get("value_m", 0) / f, u
        p = d.get("perimeter_m", d.get("diameter_m"))
        vals = [n, i + 1, t, round(v, 6), unit, round(p / f, 6) if p is not None else None,
                round(d["cx_m"] / f, 6) if "cx_m" in d else None, round(d["cy_m"] / f, 6) if "cy_m" in d else None,
                d.get("scale", ""), d.get("text", "")]
        for k, val_ in enumerate(vals, start=1):
            c = ws.cell(r, k, val_)
            c.font = Font(name="Cambria", size=10)
            c.border = bd
        r += 1
    for col, w in zip("ABCDEFGHIJ", (6, 7, 12, 14, 7, 14, 13, 13, 20, 50)):
        ws.column_dimensions[col].width = w
    wb.save(path)
    return path
