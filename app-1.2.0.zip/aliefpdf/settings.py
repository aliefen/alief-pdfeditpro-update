"""Application settings, paths and small shared helpers."""
import json
import os
import sys
import getpass

from . import APP_CODE


def app_data_dir():
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    d = os.path.join(base, APP_CODE)
    os.makedirs(d, exist_ok=True)
    return d


def resource_path(*parts):
    """Path of a bundled resource (works both from source and PyInstaller build)."""
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


def default_author():
    try:
        return getpass.getuser()
    except Exception:
        return "Reviewer"


DEFAULTS = {
    "author": None,
    "recent_files": [],
    "last_dir": "",
    "last_save_dir": "",
    "measure_unit": "m",
    "measure_precision": 3,
    "snap": {"end": True, "mid": True, "center": True, "intersection": True,
             "quadrant": False, "perpendicular": False, "nearest": True},
    "snap_tolerance_px": 10,
    "loupe_zoom": 8.0,
    "loupe_size": 260,
    "grid_cols": 3,
    "grid_rows": 2,
    "thumb_size": 150,
    "default_zoom": "width",
    "tile_cache_mb": 384,
    "restore_tabs": False,
    "measure_color": [0.0, 0.45, 0.85],
    "window_geometry": None,
    "window_state": None,
}


class Settings:
    def __init__(self):
        self.path = os.path.join(app_data_dir(), "settings.json")
        self.data = dict(DEFAULTS)
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                self.data.update(json.load(f))
        except Exception:
            pass
        if not self.data.get("author"):
            self.data["author"] = default_author()

    def get(self, key, default=None):
        v = self.data.get(key, None)
        if v is None:
            return DEFAULTS.get(key, default) if default is None else default
        return v

    def set(self, key, value):
        self.data[key] = value

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=1)
        except Exception:
            pass

    def add_recent(self, path):
        rec = [p for p in self.data.get("recent_files", []) if os.path.normcase(p) != os.path.normcase(path)]
        rec.insert(0, path)
        self.data["recent_files"] = rec[:15]
        self.save()


SETTINGS = None


def settings():
    global SETTINGS
    if SETTINGS is None:
        SETTINGS = Settings()
    return SETTINGS


def parse_page_range(text, page_count):
    """'1-3, 5, 8-' -> sorted list of 0-based indices. Empty/'all' -> all pages."""
    text = (text or "").strip().lower()
    if not text or text in ("all", "semua", "*"):
        return list(range(page_count))
    out = set()
    for part in text.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            if "-" in part:
                a, b = part.split("-", 1)
                a = int(a) if a.strip() else 1
                b = int(b) if b.strip() else page_count
            else:
                a = b = int(part)
        except ValueError:
            continue
        if a > b:
            a, b = b, a
        for i in range(max(1, a), min(page_count, b) + 1):
            out.add(i - 1)
    return sorted(out)
