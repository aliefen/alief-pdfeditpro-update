"""Side panels: thumbnails, bookmarks, comments, measurements, search, layers, properties."""
import datetime
import json
import os

import pymupdf
from PySide6.QtCore import Qt, QSize, QTimer, Signal, QUrl
from PySide6.QtGui import QIcon, QPixmap, QColor, QImage, QPainter, QPen, QFont, QBrush, QDesktopServices
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QTreeWidget,
                               QTreeWidgetItem, QPushButton, QToolButton, QLineEdit, QComboBox, QLabel, QMenu,
                               QAbstractItemView, QTableWidget, QTableWidgetItem, QHeaderView, QSlider, QCheckBox,
                               QFormLayout, QPlainTextEdit, QDoubleSpinBox, QSpinBox, QFileDialog, QMessageBox,
                               QInputDialog, QApplication, QScrollArea, QFrame, QGroupBox)

from . import theme
from .settings import settings

STATUSES = ["None", "Accepted", "Rejected", "Completed", "Cancelled", "Open", "Closed - Revised"]
TYPE_ICON = {"Text": "note-outline", "FreeText": "text-box-outline", "Square": "rectangle-outline", "Circle": "ellipse-outline",
             "Line": "vector-line", "Polygon": "vector-polygon", "PolyLine": "vector-polyline", "Ink": "draw",
             "Highlight": "marker", "Underline": "format-underline", "StrikeOut": "format-strikethrough-variant",
             "Squiggly": "format-underline", "Stamp": "stamper", "Redact": "eraser", "Caret": "format-text",
             "FileAttachment": "paperclip", "Sound": "help-circle-outline"}


def _tool_btn(icon, tip, fn):
    b = QToolButton()
    b.setIcon(theme.icon(icon))
    b.setToolTip(tip)
    b.setAutoRaise(True)
    b.clicked.connect(fn)
    return b


def _fmt_date(s):
    if not s:
        return ""
    s = s.replace("D:", "")
    try:
        return "%s-%s-%s %s:%s" % (s[0:4], s[4:6], s[6:8], s[8:10], s[10:12])
    except Exception:
        return s


class BasePanel(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.doc = None
        self.view = None

    def set_view(self, view):
        if self.doc is not None:
            self.disconnect_doc(self.doc)
        self.view = view
        self.doc = view.pdfdoc if view else None
        if self.doc is not None:
            self.connect_doc(self.doc)
        self.refresh()

    def connect_doc(self, doc):
        pass

    def disconnect_doc(self, doc):
        pass

    def refresh(self):
        pass


# ================================================================ thumbnails
class ThumbList(QListWidget):
    """Icon list whose internal drag & drop reorders pages through a callback."""

    def __init__(self, on_move):
        super().__init__()
        self.on_move = on_move

    def dropEvent(self, e):
        if e.source() is not self:
            return super().dropEvent(e)
        pos = e.position().toPoint()
        idx = self.indexAt(pos)
        if idx.isValid():
            r = self.visualRect(idx)
            dest = idx.row() + (1 if pos.x() > r.center().x() else 0)
        else:
            dest = self.count()
        rows = sorted(self.row(it) for it in self.selectedItems())
        e.setDropAction(Qt.IgnoreAction)
        e.accept()
        if rows:
            self.on_move(rows, dest)


class ThumbnailsPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        bar = QHBoxLayout()
        bar.addWidget(_tool_btn("rotate-left", "Rotate selected pages left", lambda: self.main.pages_rotate(self.selected(), -90)))
        bar.addWidget(_tool_btn("rotate-right", "Rotate selected pages right", lambda: self.main.pages_rotate(self.selected(), 90)))
        bar.addWidget(_tool_btn("file-plus-outline", "Insert pages…", lambda: self.main.pages_insert()))
        bar.addWidget(_tool_btn("file-export-outline", "Extract selected pages…", lambda: self.main.pages_extract(self.selected())))
        bar.addWidget(_tool_btn("file-remove-outline", "Delete selected pages", lambda: self.main.pages_delete(self.selected())))
        bar.addStretch(1)
        self.size = QSlider(Qt.Horizontal)
        self.size.setRange(70, 320)
        self.size.setValue(int(settings().get("thumb_size", 150)))
        self.size.setFixedWidth(80)
        self.size.valueChanged.connect(self._resize)
        bar.addWidget(self.size)
        lay.addLayout(bar)
        self.list = ThumbList(self._move_pages)
        self.list.setViewMode(QListWidget.IconMode)
        self.list.setFlow(QListWidget.LeftToRight)
        self.list.setWrapping(True)
        self.list.setResizeMode(QListWidget.Adjust)
        self.list.setMovement(QListWidget.Static)
        self.list.setDragEnabled(True)
        self.list.setAcceptDrops(True)
        self.list.setDropIndicatorShown(True)
        self.list.setDragDropMode(QAbstractItemView.InternalMove)
        self.list.setDefaultDropAction(Qt.MoveAction)
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list.setSpacing(6)
        self.list.setUniformItemSizes(True)
        self.list.setStyleSheet("QListWidget{background:#E9EDF2;border:none;} QListWidget::item{color:#1B2430;}"
                                "QListWidget::item:selected{background:#C9DBF7;border:2px solid #1F5BD8;border-radius:3px;}")
        self.list.itemClicked.connect(self._clicked)
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._menu)
        self.list.verticalScrollBar().valueChanged.connect(lambda *_: self._timer.start(30))
        lay.addWidget(self.list)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._render_visible)
        self._placeholder = None
        self._resize(self.size.value(), rebuild=False)

    def connect_doc(self, doc):
        doc.structure_changed.connect(self.refresh)
        doc.pages_changed.connect(self._pages_changed)

    def disconnect_doc(self, doc):
        try:
            doc.structure_changed.disconnect(self.refresh)
            doc.pages_changed.disconnect(self._pages_changed)
        except Exception:
            pass

    def _resize(self, v, rebuild=True):
        self.list.setIconSize(QSize(v, int(v * 1.414)))
        self.list.setGridSize(QSize(v + 18, int(v * 1.414) + 30))
        settings().set("thumb_size", v)
        if rebuild:
            self.refresh()

    def refresh(self):
        self.list.blockSignals(True)
        self.list.clear()
        if self.doc:
            n = self.doc.page_count
            isz = self.list.iconSize()
            pm = QPixmap(isz)
            pm.fill(Qt.transparent)
            qp = QPainter(pm)
            w0, h0 = self.doc.page_sizes()[0] if n else (1, 1.414)
            sc = min(isz.width() / w0, isz.height() / h0)
            pw, ph = w0 * sc, h0 * sc
            qp.fillRect(int((isz.width() - pw) / 2), int((isz.height() - ph) / 2), int(pw), int(ph), QColor("white"))
            qp.end()
            ic = QIcon(pm)
            for i in range(n):
                it = QListWidgetItem(ic, str(i + 1))
                it.setData(Qt.UserRole, i)
                it.setData(Qt.UserRole + 1, False)
                it.setTextAlignment(Qt.AlignHCenter | Qt.AlignBottom)
                self.list.addItem(it)
        self.list.blockSignals(False)
        self._timer.start(30)

    def _pages_changed(self, pages):
        if not self.doc:
            return
        idx = range(self.list.count()) if pages is None else pages
        for i in idx:
            it = self.list.item(i)
            if it:
                it.setData(Qt.UserRole + 1, False)
        self._timer.start(60)

    def _render_visible(self):
        if not self.doc or not self.view:
            return
        vp = self.list.viewport().rect()
        done = 0
        for k in range(self.list.count()):
            it = self.list.item(k)
            if it.data(Qt.UserRole + 1):
                continue
            r = self.list.visualItemRect(it)
            if not r.intersects(vp):
                continue
            try:
                img = self.view.get_thumbnail(k)
            except Exception:
                continue
            s = self.list.iconSize()
            sm = img.scaled(s, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            pm = QPixmap(s)
            pm.fill(Qt.transparent)
            qp = QPainter(pm)
            ox, oy = (s.width() - sm.width()) // 2, (s.height() - sm.height()) // 2
            qp.fillRect(ox + 2, oy + 2, sm.width(), sm.height(), QColor(0, 0, 0, 50))
            qp.drawImage(ox, oy, sm)
            qp.setPen(QColor(150, 160, 175))
            qp.drawRect(ox, oy, sm.width() - 1, sm.height() - 1)
            qp.end()
            it.setIcon(QIcon(pm))
            it.setData(Qt.UserRole + 1, True)
            done += 1
            if done >= 3:
                self._timer.start(1)
                return

    def showEvent(self, e):
        super().showEvent(e)
        self._timer.start(30)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._timer.start(60)

    def _clicked(self, it):
        if self.view:
            self.view.go_to_page(self.list.row(it))

    def set_current(self, i):
        it = self.list.item(i)
        if it and not it.isSelected():
            self.list.blockSignals(True)
            self.list.setCurrentItem(it)
            self.list.blockSignals(False)
            self.list.scrollToItem(it)

    def selected(self):
        rows = sorted(self.list.row(it) for it in self.list.selectedItems())
        if not rows and self.view:
            rows = [self.view.current_page()]
        return rows

    def _move_pages(self, rows, dest):
        if not self.doc:
            return
        n = self.doc.page_count
        rest = [i for i in range(n) if i not in rows]
        k = sum(1 for i in rest if i < dest)
        order = rest[:k] + rows + rest[k:]
        if order == list(range(n)):
            return
        self.doc.checkpoint()
        self.doc.doc.select(order)
        self.doc.commit(structure=True)
        if self.view:
            self.view.go_to_page(k)

    def _menu(self, pos):
        sel = self.selected()
        m = QMenu(self)
        m.addAction(theme.icon("rotate-right"), "Rotate right", lambda: self.main.pages_rotate(sel, 90))
        m.addAction(theme.icon("rotate-left"), "Rotate left", lambda: self.main.pages_rotate(sel, -90))
        m.addAction("Rotate 180°", lambda: self.main.pages_rotate(sel, 180))
        m.addSeparator()
        m.addAction(theme.icon("file-plus-outline"), "Insert pages…", lambda: self.main.pages_insert())
        m.addAction("Duplicate", lambda: self.main.pages_duplicate(sel))
        m.addAction(theme.icon("file-export-outline"), "Extract to new PDF…", lambda: self.main.pages_extract(sel))
        m.addAction(theme.icon("crop"), "Crop to content", lambda: self.main.pages_crop_content(sel))
        m.addSeparator()
        if sel and self.view:
            m.addAction(theme.icon("camera-outline"), "Snapshot page %d (copy in high resolution)" % (sel[0] + 1),
                        lambda: self.main._snapshot_to_clipboard(self.view, sel[0]))
            m.addSeparator()
        m.addAction(theme.icon("file-remove-outline"), "Delete", lambda: self.main.pages_delete(sel))
        m.exec(self.list.mapToGlobal(pos))


# ================================================================ bookmarks
class BookmarksPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        bar = QHBoxLayout()
        bar.addWidget(_tool_btn("bookmark-outline", "Add bookmark for current page", self.add))
        bar.addWidget(_tool_btn("square-edit-outline", "Rename", self.rename))
        bar.addWidget(_tool_btn("delete-outline", "Delete", self.delete))
        bar.addStretch(1)
        lay.addLayout(bar)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemClicked.connect(self._go)
        lay.addWidget(self.tree)

    def connect_doc(self, doc):
        doc.structure_changed.connect(self.refresh)

    def disconnect_doc(self, doc):
        try:
            doc.structure_changed.disconnect(self.refresh)
        except Exception:
            pass

    def refresh(self):
        self.tree.clear()
        if not self.doc:
            return
        toc = self.doc.doc.get_toc(simple=False)
        stack = [(0, self.tree.invisibleRootItem())]
        for k, ent in enumerate(toc):
            lvl, title, pg = ent[0], ent[1], ent[2]
            dest = ent[3] if len(ent) > 3 else {}
            while stack and stack[-1][0] >= lvl:
                stack.pop()
            parent = stack[-1][1] if stack else self.tree.invisibleRootItem()
            it = QTreeWidgetItem(parent, [title])
            it.setIcon(0, theme.icon("bookmark-outline"))
            it.setData(0, Qt.UserRole, (k, pg, (dest.get("to").y if isinstance(dest, dict) and dest.get("to") is not None else None)))
            stack.append((lvl, it))
        self.tree.expandToDepth(0)

    def _go(self, it):
        k, pg, y = it.data(0, Qt.UserRole)
        if self.view and pg >= 1:
            self.view.go_to_page(pg - 1)

    def _toc(self):
        return self.doc.doc.get_toc(simple=True)

    def add(self):
        if not self.doc or not self.view:
            return
        pg = self.view.current_page()
        title, ok = QInputDialog.getText(self, "Add bookmark", "Bookmark title:", QLineEdit.Normal, "Page %d" % (pg + 1))
        if not ok or not title:
            return
        toc = self._toc()
        cur = self.tree.currentItem()
        lvl = 1
        pos = len(toc)
        if cur is not None:
            k = cur.data(0, Qt.UserRole)[0]
            lvl = toc[k][0]
            pos = k + 1
        toc.insert(pos, [lvl, title, pg + 1])
        self.doc.checkpoint()
        self.doc.doc.set_toc(toc)
        self.doc.set_modified(True)
        self.refresh()

    def rename(self):
        cur = self.tree.currentItem()
        if not cur:
            return
        k = cur.data(0, Qt.UserRole)[0]
        toc = self._toc()
        title, ok = QInputDialog.getText(self, "Rename bookmark", "Title:", QLineEdit.Normal, toc[k][1])
        if ok and title:
            toc[k][1] = title
            self.doc.checkpoint()
            self.doc.doc.set_toc(toc)
            self.doc.set_modified(True)
            self.refresh()

    def delete(self):
        cur = self.tree.currentItem()
        if not cur:
            return
        k = cur.data(0, Qt.UserRole)[0]
        toc = self._toc()
        lvl = toc[k][0]
        j = k + 1
        while j < len(toc) and toc[j][0] > lvl:
            j += 1
        del toc[k:j]
        self.doc.checkpoint()
        self.doc.doc.set_toc(toc)
        self.doc.set_modified(True)
        self.refresh()


# ================================================================= comments
class CommentsPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        bar = QHBoxLayout()
        self.filter = QComboBox()
        self.filter.addItems(["All comments", "Remarks / text", "Shapes & clouds", "Stamps & balloons", "Markups", "Measurements"])
        self.filter.currentIndexChanged.connect(self.refresh)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter…")
        self.search.textChanged.connect(self.refresh)
        bar.addWidget(self.filter)
        bar.addWidget(self.search, 1)
        lay.addLayout(bar)
        bar2 = QHBoxLayout()
        bar2.addWidget(_tool_btn("microsoft-excel", "Comment summary to Excel", lambda: self.main.comments_summary("xlsx")))
        bar2.addWidget(_tool_btn("file-pdf-box", "Comment summary report (PDF with snapshots)", lambda: self.main.comments_summary("pdf")))
        bar2.addWidget(_tool_btn("check-all" if False else "checkbox-marked-outline", "Set status of selected", self._status_menu))
        bar2.addWidget(_tool_btn("delete-outline", "Delete selected comments", self.delete_selected))
        bar2.addStretch(1)
        self.count = QLabel("")
        bar2.addWidget(self.count)
        lay.addLayout(bar2)
        self.tree = QTreeWidget()
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels(["Comment", "Author", "Status", "Type", "Date"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.header().setStretchLastSection(False)
        self.tree.itemDoubleClicked.connect(self._go)
        self.tree.itemClicked.connect(self._go)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(lambda p: self._status_menu(self.tree.viewport().mapToGlobal(p)))
        lay.addWidget(self.tree)
        self._t = QTimer(self)
        self._t.setSingleShot(True)
        self._t.timeout.connect(self._do_refresh)

    def connect_doc(self, doc):
        doc.annots_changed.connect(self.refresh)

    def disconnect_doc(self, doc):
        try:
            doc.annots_changed.disconnect(self.refresh)
        except Exception:
            pass

    def refresh(self):
        self._t.start(120)

    def _match(self, a):
        k = self.filter.currentIndex()
        t = a["type"]
        subj = a.get("subject") or ""
        if t in ("Popup", "Widget", "Link") or subj == "Measurement label":
            return False
        if a.get("group") and subj.startswith("Measure: Centroid"):
            return False
        if k == 1 and t not in ("FreeText", "Text"):
            return False
        if k == 2 and t not in ("Square", "Circle", "Polygon", "PolyLine", "Line", "Ink"):
            return False
        if k == 3 and t != "Stamp":
            return False
        if k == 4 and t not in ("Highlight", "Underline", "StrikeOut", "Squiggly"):
            return False
        if k == 5 and not a.get("measure"):
            return False
        q = self.search.text().strip().lower()
        if q and q not in (" ".join([a.get("content") or "", a.get("author") or "", subj, t])).lower():
            return False
        return True

    def _do_refresh(self):
        self.tree.clear()
        if not self.doc:
            self.count.setText("")
            return
        total = 0
        if not self.isVisible() and self.doc.page_count > 400:
            return
        for i in range(self.doc.page_count):
            lst = [a for a in self.doc.annot_list(i) if self._match(a)]
            if not lst:
                continue
            top = QTreeWidgetItem(self.tree, ["Page %d   (%d)" % (i + 1, len(lst))])
            f = top.font(0)
            f.setBold(True)
            top.setFont(0, f)
            top.setData(0, Qt.UserRole, (i, None))
            for a in lst:
                subj = a.get("subject") or a["type"]
                text = (a.get("content") or "").replace("\n", "  ")
                label = text if text else subj
                if text and subj and not subj.startswith(("Remark", "Note", "Typewriter")):
                    label = "[%s] %s" % (subj, text)
                it = QTreeWidgetItem(top, [label, a.get("author") or "", a.get("status") or "", a["type"], _fmt_date(a.get("date"))])
                it.setIcon(0, theme.icon(TYPE_ICON.get(a["type"], "comment-text-outline"),
                                         color=QColor.fromRgbF(*((a.get("colors") or {}).get("stroke") or [0.3, 0.3, 0.3])[:3]).name()))
                it.setToolTip(0, a.get("content") or subj)
                st = a.get("status") or ""
                if st:
                    it.setForeground(2, QColor({"Accepted": "#2E7D32", "Completed": "#2E7D32", "Rejected": "#C62828",
                                                "Cancelled": "#757575"}.get(st, "#E65100")))
                it.setData(0, Qt.UserRole, (i, a["xref"]))
                total += 1
        self.tree.expandAll()
        self.tree.resizeColumnToContents(1)
        self.tree.resizeColumnToContents(2)
        self.count.setText("%d comments" % total)

    def _go(self, it, col=0):
        i, xref = it.data(0, Qt.UserRole)
        if not self.view:
            return
        if xref is None:
            self.view.go_to_page(i)
            return
        for a in self.doc.annot_list(i):
            if a["xref"] == xref:
                x0, y0, x1, y1 = a["rect"]
                self.view.go_to_unrot(i, (x0 + x1) / 2, (y0 + y1) / 2)
                self.view.set_selected((i, xref))
                break

    def selected(self):
        out = []
        for it in self.tree.selectedItems():
            i, xref = it.data(0, Qt.UserRole)
            if xref is not None:
                out.append((i, xref))
        return out

    def _status_menu(self, gpos=None):
        sel = self.selected()
        if not sel:
            return
        m = QMenu(self)
        for s in STATUSES:
            m.addAction(s, lambda s=s: self.main.set_annot_status(sel, s))
        m.addSeparator()
        m.addAction(theme.icon("delete-outline"), "Delete", self.delete_selected)
        from PySide6.QtGui import QCursor
        m.exec(gpos if gpos is not None and not isinstance(gpos, bool) else QCursor.pos())

    def delete_selected(self):
        sel = self.selected()
        if sel:
            self.main.delete_annots(sel)


# ============================================================= measurements
class MeasurementsPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        bar = QHBoxLayout()
        bar.addWidget(_tool_btn("microsoft-excel", "Export measurements to Excel", self.export))
        bar.addWidget(_tool_btn("delete-outline", "Delete selected", self.delete))
        bar.addStretch(1)
        self.scale_lbl = QLabel("")
        bar.addWidget(self.scale_lbl)
        lay.addLayout(bar)
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["Page", "Type", "Value", "Perimeter", "Centroid X", "Centroid Y", "Scale"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.cellDoubleClicked.connect(self._go)
        lay.addWidget(self.table)
        self._t = QTimer(self)
        self._t.setSingleShot(True)
        self._t.timeout.connect(self._do)

    def connect_doc(self, doc):
        doc.annots_changed.connect(self.refresh)

    def disconnect_doc(self, doc):
        try:
            doc.annots_changed.disconnect(self.refresh)
        except Exception:
            pass

    def refresh(self):
        self._t.start(150)

    def rows(self):
        out = []
        if not self.doc:
            return out
        from .measure import fmt_len, fmt_area
        for i in range(self.doc.page_count):
            for a in self.doc.annot_list(i):
                m = a.get("measure")
                if not m:
                    continue
                try:
                    d = json.loads(m)
                except Exception:
                    continue
                u = d.get("unit", "m")
                t = d.get("type", "")
                if t == "Area" or t == "Circle":
                    val = fmt_area(d.get("value_m2", 0), u)
                elif t == "Angle":
                    val = "%.2f°" % d.get("value_deg", 0)
                else:
                    val = fmt_len(d.get("value_m", 0), u)
                per = fmt_len(d["perimeter_m"], u) if "perimeter_m" in d else (fmt_len(d["diameter_m"], u) + " Ø" if "diameter_m" in d else "")
                cx = fmt_len(d["cx_m"], u) if "cx_m" in d else ""
                cy = fmt_len(d["cy_m"], u) if "cy_m" in d else ""
                out.append((i, a["xref"], t, val, per, cx, cy, d.get("scale", ""), d))
        return out

    def _do(self):
        rows = self.rows()
        self.table.setRowCount(len(rows))
        for r, (i, xref, t, val, per, cx, cy, sc, d) in enumerate(rows):
            for c, v in enumerate([str(i + 1), t, val, per, cx, cy, sc]):
                it = QTableWidgetItem(v)
                if c == 0:
                    it.setData(Qt.UserRole, (i, xref))
                self.table.setItem(r, c, it)
        if self.view and self.doc:
            from .measure import page_label_scale
            self.scale_lbl.setText("Scale p.%d: %s" % (self.view.current_page() + 1, page_label_scale(self.doc, self.view.current_page())))

    def _go(self, r, c):
        it = self.table.item(r, 0)
        if it and self.view:
            i, xref = it.data(Qt.UserRole)
            for a in self.doc.annot_list(i):
                if a["xref"] == xref:
                    x0, y0, x1, y1 = a["rect"]
                    self.view.go_to_unrot(i, (x0 + x1) / 2, (y0 + y1) / 2)
                    self.view.set_selected((i, xref))

    def delete(self):
        sel = []
        for r in sorted({i.row() for i in self.table.selectedIndexes()}):
            it = self.table.item(r, 0)
            if it:
                sel.append(it.data(Qt.UserRole))
        if sel:
            self.main.delete_annots(sel)

    def export(self):
        rows = self.rows()
        if not rows:
            QMessageBox.information(self, "Measurements", "No measurements in this document.")
            return
        base = os.path.splitext(self.doc.path or self.doc.title)[0]
        path, _ = QFileDialog.getSaveFileName(self, "Export measurements", base + "_measurements.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        from .reports import measurements_xlsx
        measurements_xlsx(self.doc, rows, path)
        self.main.status("Measurements exported: " + path)


# =================================================================== search
class SearchPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        row = QHBoxLayout()
        self.q = QLineEdit()
        self.q.setPlaceholderText("Search text…")
        self.q.returnPressed.connect(self.run)
        b = QPushButton(theme.icon("magnify"), "")
        b.clicked.connect(self.run)
        row.addWidget(self.q)
        row.addWidget(b)
        lay.addLayout(row)
        opt = QHBoxLayout()
        self.case = QCheckBox("Match case")
        self.whole = QCheckBox("Whole words")
        opt.addWidget(self.case)
        opt.addWidget(self.whole)
        opt.addStretch(1)
        lay.addLayout(opt)
        self.info = QLabel("")
        lay.addWidget(self.info)
        self.list = QListWidget()
        self.list.itemClicked.connect(self._go)
        lay.addWidget(self.list)
        self.hits = []

    def run(self, text=None):
        if not self.doc:
            return
        q = text if isinstance(text, str) and text else self.q.text()
        self.q.setText(q)
        self.list.clear()
        self.doc.search_hits = {}
        self.hits = []
        if not q.strip():
            self.view.viewport().update()
            return
        flags = 0 if self.case.isChecked() else 0
        n = self.doc.page_count
        for i in range(n):
            page = self.doc.page(i)
            if self.case.isChecked() or self.whole.isChecked():
                words = page.get_text("words")
                found = []
                if self.whole.isChecked() and " " not in q:
                    for w in words:
                        a, b = w[4], q
                        if not self.case.isChecked():
                            a, b = a.lower(), b.lower()
                        if a.strip(".,;:()[]") == b:
                            found.append(pymupdf.Rect(w[:4]))
                else:
                    for r in page.search_for(q):
                        txt = page.get_textbox(r + (-1, -1, 1, 1))
                        if q in txt:
                            found.append(r)
                rects = found
            else:
                rects = page.search_for(q)
            if rects:
                self.doc.search_hits[i] = rects
                for k, r in enumerate(rects):
                    ctx = page.get_textbox(pymupdf.Rect(r.x0 - 120, r.y0 - 1, r.x1 + 120, r.y1 + 1)).replace("\n", " ").strip()
                    it = QListWidgetItem("p.%d   %s" % (i + 1, ctx[:90]))
                    it.setData(Qt.UserRole, (i, k))
                    self.list.addItem(it)
                    self.hits.append((i, k))
            if i % 20 == 0:
                self.info.setText("Searching… page %d / %d" % (i + 1, n))
                QApplication.processEvents()
        self.info.setText("%d result(s) on %d page(s)" % (len(self.hits), len(self.doc.search_hits)))
        if self.hits:
            self.list.setCurrentRow(0)
            self._go(self.list.item(0))
        self.view.viewport().update()

    def _go(self, it):
        i, k = it.data(Qt.UserRole)
        self.doc.search_current = (i, k)
        r = self.doc.search_hits[i][k]
        self.view.go_to_unrot(i, (r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)
        self.view.viewport().update()

    def step(self, d):
        if not self.hits:
            return
        cur = self.doc.search_current
        k = self.hits.index(cur) if cur in self.hits else -1
        k = (k + d) % len(self.hits)
        self.list.setCurrentRow(k)
        self._go(self.list.item(k))


# =================================================================== layers
class LayersPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        self.list = QListWidget()
        self.list.itemChanged.connect(self._toggle)
        lay.addWidget(self.list)
        self.info = QLabel("")
        self.info.setWordWrap(True)
        lay.addWidget(self.info)

    def refresh(self):
        self.list.blockSignals(True)
        self.list.clear()
        cfg = []
        if self.doc:
            try:
                cfg = self.doc.doc.layer_ui_configs()
            except Exception:
                cfg = []
        for c in cfg:
            it = QListWidgetItem("   " * c.get("depth", 0) + c.get("text", "?"))
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if c.get("on") else Qt.Unchecked)
            it.setData(Qt.UserRole, c.get("number"))
            self.list.addItem(it)
        self.list.blockSignals(False)
        self.info.setText("" if cfg else "This document has no layers (optional content).")

    def _toggle(self, it):
        num = it.data(Qt.UserRole)
        try:
            self.doc.doc.set_layer_ui_config(num, 0 if it.checkState() == Qt.Checked else 2)
        except Exception:
            return
        for i in range(self.doc.page_count):
            self.doc.gen[i] += 1
        self.doc._dl.clear()
        self.doc.pages_changed.emit(None)


# =============================================================== attachments
class AttachmentsPanel(BasePanel):
    """Files embedded in the document and files attached to pages (paperclip comments)."""

    def __init__(self, main):
        super().__init__(main)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        bar = QHBoxLayout()
        for icon, tip, fn in (("paperclip-plus", "Embed a file in the document", self.add),
                              ("open-in-new", "Open", self.open_sel), ("content-save-outline", "Save as…", self.save_sel),
                              ("delete-outline", "Delete", self.delete_sel)):
            b = QToolButton()
            b.setIcon(theme.icon(icon))
            b.setToolTip(tip)
            b.clicked.connect(fn)
            bar.addWidget(b)
        bar.addStretch(1)
        lay.addLayout(bar)
        self.list = QListWidget()
        self.list.itemDoubleClicked.connect(lambda it: self.open_sel())
        lay.addWidget(self.list)
        self.info = QLabel("")
        self.info.setWordWrap(True)
        lay.addWidget(self.info)

    def connect_doc(self, doc):
        doc.annots_changed.connect(self.refresh)
        doc.structure_changed.connect(self.refresh)

    def disconnect_doc(self, doc):
        for sig in (doc.annots_changed, doc.structure_changed):
            try:
                sig.disconnect(self.refresh)
            except Exception:
                pass

    def refresh(self, *a):
        self.list.clear()
        if not self.doc:
            self.info.setText("")
            return
        d = self.doc.doc
        n = 0
        try:
            for name in d.embfile_names():
                inf = d.embfile_info(name)
                it = QListWidgetItem(theme.icon("file-outline"), "%s   (%s KB)" % (inf.get("filename") or name, max(1, int(inf.get("size", 0)) // 1024)))
                it.setData(Qt.UserRole, ("doc", name))
                it.setToolTip(inf.get("desc") or "")
                self.list.addItem(it)
                n += 1
        except Exception:
            pass
        for i in range(self.doc.page_count):
            for a in self.doc.annot_list(i):
                if a["type"] == "FileAttachment":
                    it = QListWidgetItem(theme.icon("paperclip"), "%s   - page %d" % (a.get("file") or "attachment", i + 1))
                    it.setData(Qt.UserRole, ("annot", i, a["xref"]))
                    it.setToolTip(a.get("content") or "")
                    self.list.addItem(it)
                    n += 1
        self.info.setText("" if n else "No attachments. Use Comment ▸ Attach File, or the paperclip button above.")

    def _sel(self):
        it = self.list.currentItem()
        return it.data(Qt.UserRole) if it else None

    def add(self):
        if not self.doc:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Embed file", "", "All files (*.*)")
        if not path:
            return
        with open(path, "rb") as f:
            data = f.read()
        name = os.path.basename(path)
        d = self.doc.doc
        base, k = name, 2
        while name in d.embfile_names():
            name = "%s (%d)" % (base, k)
            k += 1
        self.doc.checkpoint()
        d.embfile_add(name, data, filename=os.path.basename(path), ufilename=os.path.basename(path), desc=name)
        self.doc.set_modified(True)
        self.refresh()

    def _doc_file(self, name):
        d = self.doc.doc
        return d.embfile_info(name).get("filename") or name, d.embfile_get(name)

    def open_sel(self):
        s = self._sel()
        if not s:
            return
        if s[0] == "annot":
            self.main.open_attachment(self.doc, s[1], s[2])
            return
        import tempfile
        fname, data = self._doc_file(s[1])
        path = os.path.join(tempfile.mkdtemp(prefix="alief_att_"), os.path.basename(fname))
        with open(path, "wb") as f:
            f.write(data)
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def save_sel(self):
        s = self._sel()
        if not s:
            return
        if s[0] == "annot":
            self.main.open_attachment(self.doc, s[1], s[2], save=True)
            return
        fname, data = self._doc_file(s[1])
        out, _ = QFileDialog.getSaveFileName(self, "Save attachment", fname)
        if out:
            with open(out, "wb") as f:
                f.write(data)

    def delete_sel(self):
        s = self._sel()
        if not s:
            return
        if s[0] == "annot":
            self.main.delete_annots([(s[1], s[2])])
        else:
            self.doc.checkpoint()
            self.doc.doc.embfile_del(s[1])
            self.doc.set_modified(True)
        self.refresh()


# =============================================================== properties
class PropertiesPanel(BasePanel):
    def __init__(self, main):
        super().__init__(main)
        self.sel = None
        outer = QVBoxLayout(self)
        outer.setContentsMargins(4, 4, 4, 4)
        self.title = QLabel("<i>No comment selected</i>")
        outer.addWidget(self.title)
        self.form_w = QWidget()
        f = QFormLayout(self.form_w)
        f.setContentsMargins(0, 0, 0, 0)
        self.content = QPlainTextEdit()
        self.content.setMaximumHeight(110)
        self.author = QLineEdit()
        self.subject = QLineEdit()
        self.status = QComboBox()
        self.status.addItems(STATUSES)
        from .templates import ColorButton
        self.stroke = ColorButton(allow_none=False)
        self.fill = ColorButton(allow_none=True)
        self.width = QDoubleSpinBox()
        self.width.setRange(0, 30)
        self.width.setSingleStep(0.25)
        self.dash = QComboBox()
        self.dash.addItems(["solid", "dash", "dot", "dashdot"])
        self.cloud = QSpinBox()
        self.cloud.setRange(0, 2)
        self.cloud_mm = QDoubleSpinBox()
        self.cloud_mm.setRange(0, 200)
        self.cloud_mm.setDecimals(1)
        self.cloud_mm.setSuffix(" mm")
        self.cloud_mm.setSpecialValueText("auto (by sheet size)")
        self.cloud_mm.setToolTip("Scallop size of the revision cloud. Auto grows with the sheet: A4 ≈ 3.5 mm, A2 ≈ 7 mm, A0 ≈ 14 mm")
        self.blend = QComboBox()
        self.blend.addItems(["Multiply", "Normal", "Darken"])
        self.blend.setToolTip("Multiply: the stamp / comment mixes like ink, so the drawing lines underneath stay readable.\n"
                              "Normal: the comment covers what is underneath.")
        self.opacity = QDoubleSpinBox()
        self.opacity.setRange(0.05, 1.0)
        self.opacity.setSingleStep(0.05)
        self.fontsize = QDoubleSpinBox()
        self.fontsize.setRange(4, 96)
        f.addRow("Comment", self.content)
        f.addRow("Author", self.author)
        f.addRow("Subject", self.subject)
        f.addRow("Status", self.status)
        f.addRow("Colour", self.stroke)
        f.addRow("Fill", self.fill)
        f.addRow("Line width", self.width)
        f.addRow("Line style", self.dash)
        f.addRow("Cloud", self.cloud)
        f.addRow("Cloud size", self.cloud_mm)
        f.addRow("Blend", self.blend)
        f.addRow("Opacity", self.opacity)
        f.addRow("Font size", self.fontsize)
        self.rows = {"stroke": self.stroke, "fill": self.fill, "width": self.width, "dash": self.dash, "cloud": self.cloud,
                     "fontsize": self.fontsize}
        outer.addWidget(self.form_w)
        bar = QHBoxLayout()
        ap = QPushButton("Apply")
        ap.setObjectName("Primary")
        ap.clicked.connect(self.apply)
        tp = QPushButton("Save as template")
        tp.setToolTip("Create a new comment template with this style")
        tp.clicked.connect(self.save_template)
        dl = QPushButton(theme.icon("delete-outline"), "")
        dl.setToolTip("Delete")
        dl.clicked.connect(lambda: self.main.delete_selected_annot(self.view) if self.view else None)
        bar.addWidget(ap)
        bar.addWidget(tp)
        bar.addWidget(dl)
        outer.addLayout(bar)
        outer.addStretch(1)
        self.form_w.setEnabled(False)

    def show_selection(self, view):
        self.view = view
        self.doc = view.pdfdoc if view else None
        a = view.selected_annot_info() if view else None
        self.sel = (view.selected, a) if a else None
        if not a:
            self.title.setText("<i>No comment selected</i>")
            self.form_w.setEnabled(False)
            return
        self.form_w.setEnabled(True)
        t = a["type"]
        self.title.setText("<b>%s</b>  · page %d" % (a.get("subject") or t, view.selected[0] + 1))
        self.content.setPlainText(a.get("content") or "")
        self.author.setText(a.get("author") or "")
        self.subject.setText(a.get("subject") or "")
        self.status.setCurrentText(a.get("status") or "None")
        cols = a.get("colors") or {}
        page = self.doc.page(view.selected[0])
        annot = page.load_annot(a["xref"])
        stroke = cols.get("stroke")
        if t == "FreeText":
            try:
                da = self.doc.doc.xref_get_key(a["xref"], "DA")[1]
                import re
                m = re.search(r"([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+rg", da)
                if m:
                    stroke = [float(m.group(k)) for k in (1, 2, 3)]
                fsm = re.search(r"([\d.]+)\s+Tf", da)
                self.fontsize.setValue(float(fsm.group(1)) if fsm else 10)
            except Exception:
                pass
        self.stroke.set_rgb(stroke or [0, 0, 0])
        self.fill.set_rgb(cols.get("fill") or None)
        b = annot.border or {}
        self.width.setValue(float(b.get("width", 1) if b.get("width", -1) >= 0 else 1))
        dashes = b.get("dashes") or ()
        self.dash.setCurrentText("solid" if not dashes else ("dot" if dashes[0] <= 1 else "dash"))
        self.cloud.setValue(int(b.get("clouds", 0) or 0) if b.get("clouds", -1) >= 0 else 0)
        cl = a.get("cloud")
        if cl:
            self.cloud.setValue(2 if float(cl.get("arc", 1)) > float(cl.get("base", 10)) * 1.3 else 1)
            self.cloud_mm.setValue(round(float(cl.get("arc", 10)) * 25.4 / 72.0, 1))
        else:
            self.cloud_mm.setValue(0)
        self.cloud_mm.setEnabled(bool(cl))
        self.blend.setCurrentText(a.get("blend") or "Normal")
        self.blend.setEnabled(t not in ("Text", "Popup", "FileAttachment", "Sound", "Caret"))
        self.opacity.setValue(float(annot.opacity) if annot.opacity and annot.opacity > 0 else 1.0)
        shapes = t in ("Square", "Circle", "Polygon", "PolyLine", "Line", "Ink")
        self.fill.setEnabled(t in ("Square", "Circle", "Polygon", "FreeText", "Line", "PolyLine"))
        self.width.setEnabled(shapes or t == "FreeText")
        self.dash.setEnabled(shapes)
        self.cloud.setEnabled(t in ("Square", "Circle", "Polygon"))
        self.fontsize.setEnabled(t == "FreeText")
        self.stroke.setEnabled(t not in ("Stamp",))
        self._loaded = (self.stroke.rgb, self.fill.rgb, self.width.value(), self.dash.currentText(), self.cloud.value(),
                        self.opacity.value(), self.fontsize.value(), self.cloud_mm.value(), self.blend.currentText())

    def apply(self):
        if not self.sel or not self.view:
            return
        (i, xref), a = self.sel
        props = {"content": self.content.toPlainText(), "author": self.author.text(), "subject": self.subject.text(),
                 "status": self.status.currentText(), "opacity": self.opacity.value()}
        cur = (self.stroke.rgb, self.fill.rgb, self.width.value(), self.dash.currentText(), self.cloud.value(),
               self.opacity.value(), self.fontsize.value(), self.cloud_mm.value(), self.blend.currentText())
        old = getattr(self, "_loaded", None)
        t = a["type"]
        if old is None or cur[0] != old[0]:
            props["stroke"] = self.stroke.rgb
        if old is None or cur[1] != old[1]:
            props["fill"] = self.fill.rgb
        if old is None or cur[2:5] != old[2:5]:
            props["width"] = self.width.value()
            props["dash"] = self.dash.currentText()
            props["cloud"] = self.cloud.value()
        if t == "FreeText" and (old is None or cur[6] != old[6]):
            props["fontsize"] = self.fontsize.value()
        if a.get("cloud") and old is not None and cur[7] != old[7] and cur[7] > 0:
            props["cloud_arc_mm"] = cur[7]
        if old is None or cur[8] != old[8]:
            props["blend"] = cur[8]
        self.main.apply_annot_props(self.view, i, xref, props)

    def save_template(self):
        if not self.sel:
            return
        (i, xref), a = self.sel
        kind = {"Square": "cloud" if self.cloud.value() else "rect", "Circle": "ellipse", "Polygon": "cloudpoly" if self.cloud.value() else "polygon",
                "PolyLine": "polyline", "Line": "arrow", "Ink": "ink", "FreeText": "textbox", "Text": "note",
                "Highlight": "highlight", "Underline": "underline", "StrikeOut": "strikeout", "Squiggly": "squiggly"}.get(a["type"])
        if not kind:
            QMessageBox.information(self, "Template", "This comment type cannot be saved as a template (use Stamps for images).")
            return
        name, ok = QInputDialog.getText(self, "New comment template", "Template name:", QLineEdit.Normal, (a.get("subject") or kind) + " (custom)")
        if not ok or not name:
            return
        from .templates import store, _t
        t = _t(name, kind, self.stroke.rgb, fill=self.fill.rgb, width=self.width.value(), dash=self.dash.currentText(),
               cloud=self.cloud.value(), opacity=self.opacity.value(), fontsize=self.fontsize.value(), subject=self.subject.text() or name)
        st = store()
        st.tools.append(t)
        st.save()
        self.main.refresh_templates()
        self.main.status("Template '%s' created - find it in Comment ▸ Templates." % name)
