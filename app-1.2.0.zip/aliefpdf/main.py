"""Entry point: single instance (second launch passes files to the running window), style, start-up."""
import os
import sys


def _server_name():
    from . import APP_CODE
    user = os.environ.get("USERNAME") or os.environ.get("USER") or "user"
    return "%s_%s" % (APP_CODE, user)


def _send_to_running(files):
    """If an instance is running, hand it the files and return True."""
    from PySide6.QtNetwork import QLocalSocket
    sock = QLocalSocket()
    sock.connectToServer(_server_name())
    if not sock.waitForConnected(250):
        return False
    payload = ("\n".join(os.path.abspath(f) for f in files) or "__activate__").encode("utf-8")
    sock.write(payload)
    sock.flush()
    sock.waitForBytesWritten(1000)
    sock.disconnectFromServer()
    return True


def _wait_for_old_instance(timeout=20.0):
    """After 'Restart now' the old window may still be closing: wait until it has gone."""
    import time
    from PySide6.QtNetwork import QLocalSocket
    end = time.time() + timeout
    while time.time() < end:
        sock = QLocalSocket()
        sock.connectToServer(_server_name())
        if not sock.waitForConnected(150):
            return
        sock.abort()
        time.sleep(0.3)


def cli(argv):
    """Command line:  --convert IN OUT [pages]   |   --unlock IN OUT [password]"""
    import pymupdf
    from . import convert as C, security as S
    from .settings import parse_page_range
    if argv[0] == "--unlock":
        ok, msg = S.remove_security(argv[1], argv[2], argv[3] if len(argv) > 3 else None)
        print(("OK: " if ok else "FAILED: ") + msg)
        return 0 if ok else 1
    src, out = argv[1], argv[2]
    doc = pymupdf.open(src)
    pages = parse_page_range(argv[3] if len(argv) > 3 else "", doc.page_count)
    ext = os.path.splitext(out)[1].lower()
    fn = {".docx": C.to_word, ".xlsx": C.to_excel, ".csv": C.to_csv, ".dxf": C.to_dxf, ".svg": C.to_svg,
          ".txt": C.to_text, ".html": C.to_html, ".pptx": C.to_pptx}.get(ext)
    if ext in (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"):
        res = C.to_images(doc, pages, out, fmt=ext[1:])
    elif fn:
        res = fn(doc, pages, out)
    else:
        print("Unsupported output type: " + ext)
        return 2
    print("OK: " + ", ".join(res))
    return 0


def _setup_stdio():
    """GUI builds have no console: send stray output to a log file instead of crashing."""
    try:
        from .settings import app_data_dir
        logdir = app_data_dir()
    except Exception:
        logdir = os.path.expanduser("~")
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        try:
            sys.stderr = open(os.path.join(logdir, "error.log"), "a", encoding="utf-8", buffering=1)
        except Exception:
            sys.stderr = open(os.devnull, "w", encoding="utf-8")

    def hook(etype, value, tb):
        import traceback
        import datetime
        text = "".join(traceback.format_exception(etype, value, tb))
        try:
            with open(os.path.join(logdir, "error.log"), "a", encoding="utf-8") as f:
                f.write("\n==== %s\n%s" % (datetime.datetime.now().isoformat(timespec="seconds"), text))
        except Exception:
            pass
        try:
            from PySide6.QtWidgets import QApplication, QMessageBox
            if QApplication.instance() is not None:
                QMessageBox.warning(None, "ALIEF PDF EDITOR PRO",
                                    "An unexpected error occurred and was written to:\n%s\n\n%s"
                                    % (os.path.join(logdir, "error.log"), str(value)[:400]))
        except Exception:
            pass
    sys.excepthook = hook


def main():
    _setup_stdio()
    argv = sys.argv[1:]
    if argv and argv[0] in ("--convert", "--unlock") and len(argv) >= 3:
        try:
            from .update import mark_healthy
            mark_healthy()
        except Exception:
            pass
        return cli(argv)
    files = [a for a in argv if not a.startswith("-")]
    new_instance = "--new" in argv
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    from PySide6.QtCore import Qt, QCoreApplication
    from PySide6.QtWidgets import QApplication
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    from . import APP_NAME, APP_CODE, COMPANY
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(COMPANY)
    if "--restarted" in argv:
        _wait_for_old_instance()
    if not new_instance and _send_to_running(files):
        try:
            from .update import mark_healthy
            mark_healthy()
        except Exception:
            pass
        return 0
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Alief.PdfEditorPro")
        except Exception:
            pass
    from .theme import STYLE
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)
    from .settings import settings
    from .viewer import CACHE
    CACHE.budget = int(settings().get("tile_cache_mb", 384)) * 1024 * 1024
    from .mainwindow import MainWindow
    win = MainWindow()
    # single-instance server
    from PySide6.QtNetwork import QLocalServer
    server = QLocalServer()
    QLocalServer.removeServer(_server_name())
    server.listen(_server_name())

    def on_conn():
        s = server.nextPendingConnection()
        if s is None:
            return

        def read():
            data = bytes(s.readAll()).decode("utf-8", "ignore")
            paths = [p for p in data.split("\n") if p and p != "__activate__"]
            if paths:
                win.open_files(paths)
            win.showNormal() if win.isMinimized() else None
            win.raise_()
            win.activateWindow()
        s.readyRead.connect(read)
    server.newConnection.connect(on_conn)
    app.aboutToQuit.connect(win.finalize_clipboard)
    win.show()
    if files:
        win.open_files(files)
    try:
        win.updates.start()
    except Exception:
        pass
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
