"""Main window: ribbon, document tabs, split panes, panels and all commands."""
import json
import os
import sys

import pymupdf
from PySide6.QtCore import Qt, QSize, QTimer, QPointF, QRectF, QUrl, Signal
from PySide6.QtGui import (QAction, QActionGroup, QIcon, QKeySequence, QPixmap, QColor, QDesktopServices, QPainter,
                           QGuiApplication, QImage, QFont)
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel, QToolButton,
                               QMenu, QFileDialog, QMessageBox, QDockWidget, QSplitter, QComboBox, QSpinBox,
                               QStatusBar, QApplication, QLineEdit, QInputDialog, QSizePolicy, QFrame, QPushButton,
                               QWidgetAction, QListWidget, QListWidgetItem, QDoubleSpinBox, QCheckBox,
                               QProgressDialog)

from . import APP_NAME, VERSION, COMPANY, theme
from .settings import settings, resource_path, parse_page_range
from .document import PdfDoc
from .viewer import DocumentView, CACHE, PX_PER_PT_100
from .ribbon import Ribbon
from . import tools as T
from . import measure as M
from . import annots as AN
from . import dialogs as D
from . import panels as P
from . import pageops as PO
from .templates import store, TemplateManager, KIND_ICON, tool_icon, stamp_thumbnail

PDF_FILTER = "PDF files (*.pdf);;Images / XPS / EPUB (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.xps *.oxps *.epub *.cbz *.svg);;All files (*)"


# =============================================================== doc tab
class ElidedLabel(QLabel):
    """Label that never forces the window wider: long text is shortened with '…' (full text in the tooltip)."""

    def __init__(self, text="", mode=Qt.ElideRight, min_chars=4, pref_width=None):
        super().__init__()
        self._full = ""
        self._mode = mode
        self._min_chars = min_chars
        self._pref = pref_width
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.setText(text)

    def setText(self, text):
        self._full = text or ""
        self.setToolTip(self._full if len(self._full) > 30 else "")
        super().setText(self._full)
        self.update()

    def text(self):
        return self._full

    def minimumSizeHint(self):
        fm = self.fontMetrics()
        return QSize(fm.horizontalAdvance("M") * self._min_chars, super().minimumSizeHint().height())

    def sizeHint(self):
        sh = super().sizeHint()
        if self._pref:
            return QSize(self._pref, sh.height())
        return sh

    def paintEvent(self, e):
        p = QPainter(self)
        r = self.contentsRect()
        txt = self.fontMetrics().elidedText(self._full, self._mode, max(0, r.width()))
        p.setPen(self.palette().color(self.foregroundRole()))
        p.setFont(self.font())
        p.drawText(r, int(self.alignment() | Qt.AlignVCenter) if self.alignment() else int(Qt.AlignLeft | Qt.AlignVCenter), txt)
        p.end()


class PaneHeader(QWidget):
    def __init__(self, tab, view):
        super().__init__()
        self.setObjectName("PaneHeader")
        self.tab, self.view = tab, view
        h = QHBoxLayout(self)
        h.setContentsMargins(6, 1, 6, 1)
        self.combo = QComboBox()
        self.combo.setMinimumWidth(180)
        self.combo.activated.connect(self._pick)
        self.page = QLabel("")
        h.addWidget(QLabel("Document:"))
        h.addWidget(self.combo, 1)
        h.addWidget(self.page)
        view.page_changed.connect(self._upd_page)

    def fill(self, docs):
        self.combo.blockSignals(True)
        self.combo.clear()
        cur = 0
        for k, d in enumerate(docs):
            self.combo.addItem(d.title, d)
            if d is self.view.pdfdoc:
                cur = k
        self.combo.setCurrentIndex(cur)
        self.combo.blockSignals(False)
        self._upd_page(self.view.current_page())

    def _pick(self, k):
        d = self.combo.itemData(k)
        if d is not None and d is not self.view.pdfdoc:
            self.view.set_document(d)
            self.tab.main.on_view_activated(self.view)

    def _upd_page(self, i):
        if self.view.pdfdoc:
            self.page.setText("p. %d / %d" % (i + 1, self.view.pdfdoc.page_count))


class DocTab(QWidget):
    def __init__(self, main, pdfdoc):
        super().__init__()
        self.main = main
        self.pdfdoc = pdfdoc
        self.views = []
        self.headers = []
        self.split = "single"
        self.sync = False
        self._syncing = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.holder = QVBoxLayout()
        lay.addLayout(self.holder)
        self.active = self._make_view(pdfdoc)
        self._build()

    def _make_view(self, doc):
        v = DocumentView(doc, self.main)
        s = settings()
        v.loupe_zoom = float(s.get("loupe_zoom", 8))
        v.loupe_size = int(s.get("loupe_size", 260))
        v.grid_cols, v.grid_rows = int(s.get("grid_cols", 3)), int(s.get("grid_rows", 2))
        dz = s.get("default_zoom", "width")
        if dz in ("width", "page"):
            v.fit = dz
        else:
            v.fit = None
            try:
                v.scale = float(dz) / 100 * PX_PER_PT_100
            except Exception:
                v.fit = "width"
        v.activated.connect(self.main.on_view_activated)
        v.page_changed.connect(lambda i, v=v: self.main.on_page_changed(v, i))
        v.zoom_changed.connect(lambda z, v=v: self.main.on_zoom_changed(v, z))
        v.cursor_moved.connect(lambda h, v=v: self.main.on_cursor(v, h))
        v.selection_changed.connect(lambda sel, v=v: self.main.on_selection(v, sel))
        v.verticalScrollBar().valueChanged.connect(lambda *_a, v=v: self._sync_from(v))
        if self.main.current_tool_name:
            v.set_tool(self.main.make_tool(self.main.current_tool_name, self.main.current_tool_style, self.main.current_stamp))
        return v

    def _build(self):
        while self.holder.count():
            it = self.holder.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
        for v in self.views:
            if v is not self.active:
                pass
        if self.split == "single":
            self.views = [self.active]
            self.headers = []
            self.holder.addWidget(self.active)
            return
        n = 4 if self.split == "quad" else 2
        while len(self.views) < n:
            nv = self._make_view(self.pdfdoc)
            self.views.append(nv)
        self.views = self.views[:n]
        if self.active not in self.views:
            self.views[0] = self.active
        self.headers = []
        panes = []
        for v in self.views:
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(0, 0, 0, 0)
            l.setSpacing(0)
            hd = PaneHeader(self, v)
            self.headers.append(hd)
            l.addWidget(hd)
            l.addWidget(v)
            panes.append(w)
        if self.split in ("h2", "v2"):
            sp = QSplitter(Qt.Horizontal if self.split == "v2" else Qt.Vertical)
            for w in panes:
                sp.addWidget(w)
            self.holder.addWidget(sp)
        else:
            outer = QSplitter(Qt.Vertical)
            for r in range(2):
                inner = QSplitter(Qt.Horizontal)
                inner.addWidget(panes[r * 2])
                inner.addWidget(panes[r * 2 + 1])
                outer.addWidget(inner)
            self.holder.addWidget(outer)
        self.refresh_headers()

    def refresh_headers(self):
        docs = self.main.all_docs()
        for h in self.headers:
            h.fill(docs)

    def set_split(self, mode):
        self.split = mode
        self._build()
        for v in self.views:
            v.show()
        QTimer.singleShot(0, lambda: [v.relayout(keep=True) for v in self.views])

    def _sync_from(self, src):
        if not self.sync or self._syncing or len(self.views) < 2:
            return
        self._syncing = True
        try:
            a = src._anchor_at(QPointF(src.viewport().width() / 2, 0))
            for v in self.views:
                if v is not src and v.pdfdoc and a[0] < v.pdfdoc.page_count:
                    v._restore_anchor(a, QPointF(v.viewport().width() / 2, 0))
        finally:
            self._syncing = False


# ======================================================== snapshot data
from PySide6.QtCore import QMimeData, QByteArray, QBuffer, QIODevice


class SnapshotMime(QMimeData):
    """Clipboard data of a snapshot: bitmap now, PNG / SVG / PDF produced only when an application pastes them."""
    WIN = 'application/x-qt-windows-mime;value="%s"'

    def __init__(self, img, pdf=None):
        super().__init__()
        self._img = img
        self._pdf = pdf
        self._cache = {}
        self.setImageData(img)

    @staticmethod
    def svg_from_pdf(pdf):
        d = pymupdf.open("pdf", pdf)
        try:
            return d[0].get_svg_image(text_as_path=True).encode("utf-8")
        finally:
            d.close()

    def _extra(self):
        f = ["image/png"]
        if self._pdf:
            f += ["image/svg+xml", self.WIN % "image/svg+xml", "application/pdf", self.WIN % "Portable Document Format"]
        return f

    def formats(self):
        base = list(super().formats())
        return base + [f for f in self._extra() if f not in base]

    def hasFormat(self, mime):
        return mime in self._extra() or super().hasFormat(mime)

    def retrieveData(self, mime, vtype):
        if mime in self._extra():
            if mime not in self._cache:
                if mime == "image/png":
                    ba = QByteArray()
                    buf = QBuffer(ba)
                    buf.open(QIODevice.WriteOnly)
                    self._img.save(buf, "PNG")
                    buf.close()
                    data = ba
                elif "svg" in mime:
                    data = QByteArray(self.svg_from_pdf(self._pdf))
                else:
                    data = QByteArray(self._pdf)
                self._cache[mime] = data
            return self._cache[mime]
        return super().retrieveData(mime, vtype)


# ============================================================ main window
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        ip = resource_path("assets", "icon.ico")
        if os.path.exists(ip):
            self.setWindowIcon(QIcon(ip))
        self.resize(1440, 900)
        self.snap_on = True
        self.ortho_on = False
        self.current_tool_name = "hand"
        self.current_tool_style = None
        self.current_stamp = None
        self.kind_style = {}
        self.A = {}
        self._build_actions()
        self._build_ui()
        self._build_ribbon()
        self._build_status()
        self._build_docks()
        self.set_tool("hand")
        self.update_actions()
        g = settings().get("window_geometry")
        if g:
            try:
                from PySide6.QtCore import QByteArray
                self.restoreGeometry(QByteArray.fromHex(g.encode()))
            except Exception:
                pass

    # ------------------------------------------------------------- actions
    def act(self, key, text, icon=None, fn=None, shortcut=None, checkable=False, tip=None, accent=None):
        a = QAction(theme.icon(icon, accent=accent) if icon else QIcon(), text, self)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        if checkable:
            a.setCheckable(True)
        a.setToolTip(tip or text.replace("\n", " "))
        if fn:
            a.triggered.connect(fn)
        self.A[key] = a
        self.addAction(a)
        return a

    def _build_actions(self):
        A = self.act
        A("new", "New", "file-plus-outline", self.new_doc, "Ctrl+N")
        A("open", "Open", "folder-open", self.open_dialog, "Ctrl+O")
        A("save", "Save", "content-save", self.save, "Ctrl+S")
        A("saveas", "Save As", "content-save-edit", self.save_as, "Ctrl+Shift+S")
        A("print", "Print", "printer", self.print_doc, "Ctrl+P")
        A("close", "Close", "close", self.close_current, "Ctrl+W")
        A("undo", "Undo", "undo", self.undo, "Ctrl+Z")
        A("redo", "Redo", "redo", self.redo, "Ctrl+Y")
        A("props", "Document\nProperties", "information-outline", self.doc_properties, "Ctrl+D")
        A("prefs", "Preferences", "cog-outline", self.preferences)
        A("about", "About", "information-outline", lambda: D.AboutDialog(self).exec())
        A("update", "Check for Updates…", "update", lambda: self.updates.open_dialog())
        A("guide", "User Guide", "help-circle-outline", self.open_guide, "F1")
        A("exit", "Exit", "close", self.close)
        # tools
        self.tool_group = QActionGroup(self)
        self.tool_group.setExclusive(True)
        for key, text, icon, sc in (("hand", "Hand", "hand-back-right", None), ("select", "Select\nComments", "cursor-default-click", None),
                                    ("selecttext", "Select\nText", "cursor-text", None), ("zoom", "Zoom\nTool", "magnify-plus-outline", None),
                                    ("snapshot", "Snapshot", "camera-outline", None), ("loupe", "Loupe", "magnify-scan", "Ctrl+L")):
            a = A("tool_" + key, text, icon, lambda c=False, k=key: self.set_tool(k), sc, checkable=True)
            self.tool_group.addAction(a)
        for key, text, icon, acc in (("m_distance", "Distance", "ruler", "measure"), ("m_perimeter", "Perimeter", "vector-polyline", "measure"),
                                     ("m_area", "Area &&\nCentroid", "vector-square", "measure"), ("m_angle", "Angle", "angle-acute", "measure"),
                                     ("m_circle", "Circle", "circle-outline", "measure"), ("m_calibrate", "Calibrate", "tape-measure", "measure"),
                                     ("m_origin", "Set\nOrigin", "axis-arrow", "measure"),
                                     ("edittext", "Edit\nText", "format-letter-case", "edit"), ("addtext", "Add\nText", "format-text", "edit"),
                                     ("image", "Add\nImage", "image-plus", "edit"), ("whiteout", "Whiteout", "eraser", "edit"),
                                     ("crop", "Crop\nPages", "crop", "organize"), ("redact", "Mark for\nRedaction", "select-drag", "protect"),
                                     ("field_text", "Text\nField", "form-textbox", "edit"), ("field_check", "Check\nBox", "checkbox-marked-outline", "edit"),
                                     ("field_combo", "Combo\nBox", "format-list-bulleted-square", "edit"), ("link", "Link", "ray-start-end", "edit")):
            a = A("tool_" + key, text, icon, lambda c=False, k=key: self.set_tool(k), checkable=True, accent=theme.ICON_ACCENT.get(acc))
            self.tool_group.addAction(a)
        self.editobj_mode = "all"
        a = A("tool_editobj", "Edit\nObjects", "vector-square-edit", lambda c=False: self.set_tool("editobj"), checkable=True,
              accent=theme.ICON_ACCENT.get("edit"), tip="Select, move, resize, duplicate, recolour or delete the page content")
        self.tool_group.addAction(a)
        self.editobj_menu = QMenu(self)
        self.editobj_group = QActionGroup(self)
        for key, label, icon in (("all", "All", "vector-square-edit"), ("text", "Text Elements", "format-text"),
                                 ("image", "Images", "image-edit-outline"), ("shape", "Shapes", "shape-outline")):
            act = self.editobj_menu.addAction(theme.icon(icon), label, lambda k=key: self.set_editobj_mode(k))
            act.setCheckable(True)
            act.setChecked(key == "all")
            self.editobj_group.addAction(act)
        # view
        A("zoom_in", "Zoom In", "magnify-plus-outline", lambda: self.view() and self.view().zoom_by(1.25), "Ctrl++")
        A("zoom_out", "Zoom Out", "magnify-minus-outline", lambda: self.view() and self.view().zoom_by(0.8), "Ctrl+-")
        A("fit_width", "Fit Width", "arrow-expand-horizontal", lambda: self.view() and self.view().set_fit("width"), "Ctrl+2")
        A("fit_page", "Fit Page", "fit-to-page-outline", lambda: self.view() and self.view().set_fit("page"), "Ctrl+0")
        A("actual", "Actual Size", "magnify", lambda: self.view() and self.view().set_zoom_percent(100), "Ctrl+1")
        self.layout_group = QActionGroup(self)
        for key, text, icon in (("lay_single", "Single\nPage", "file-document-outline"), ("lay_cont", "Continuous", "book-open-page-variant-outline"),
                                ("lay_facing", "Facing", "file-document-multiple-outline"), ("lay_grid", "Page\nGrid", "view-grid-outline")):
            a = A(key, text, icon, lambda c=False, k=key: self.set_layout(k), checkable=True)
            self.layout_group.addAction(a)
        self.split_group = QActionGroup(self)
        for key, text, icon in (("split_single", "One Pane", "file-document-outline"), ("split_v2", "Split\nVertical", "view-split-vertical"),
                                ("split_h2", "Split\nHorizontal", "view-split-horizontal"), ("split_quad", "Four\nPanes", "view-dashboard-outline")):
            a = A(key, text, icon, lambda c=False, k=key: self.set_split(k[6:]), checkable=True)
            self.split_group.addAction(a)
        A("sync", "Sync\nScroll", "file-compare", self.toggle_sync, checkable=True)
        A("fullscreen", "Full\nScreen", "fullscreen", self.toggle_fullscreen, "F11")
        A("rotate_view_cw", "Rotate View\nClockwise", "rotate-right", lambda: self.rotate_view(90), "Ctrl+Shift++")
        A("rotate_view_ccw", "Rotate View\nCounterclockwise", "rotate-left", lambda: self.rotate_view(-90), "Ctrl+Shift+-")
        A("rotate_view_reset", "Reset View Rotation", "restore", lambda: self.rotate_view(None))
        A("pg_rotate_dlg", "Rotate\nPages…", "file-rotate-right-outline", self.rotate_pages_dialog, "Ctrl+Shift+R",
          accent=theme.ICON_ACCENT["organize"])
        A("pg_rot_180", "Rotate 180°", "rotate-3d-variant", lambda: self.pages_rotate(None, 180))
        # snapshot (default = whole current page, very high quality, vector copy included)
        A("snap_page", "Snapshot Current Page Now", "camera-outline", self.snapshot_page, "Ctrl+Shift+C")
        A("snap_view", "Snapshot Visible View", "monitor-screenshot", self.snapshot_view)
        A("snap_save", "Save Page Snapshot As…", "content-save-outline", self.snapshot_save)
        A("find", "Find", "magnify", self.focus_find, "Ctrl+F")
        A("snap", "OSnap", "vector-point", self.toggle_snap, "F3", checkable=True)
        A("ortho", "Ortho", "axis-arrow", self.toggle_ortho, "F8", checkable=True)
        A("first", "First page", "page-first", lambda: self.view() and self.view().go_to_page(0))
        A("last", "Last page", "page-last", lambda: self.view() and self.view().go_to_page(self.view().pdfdoc.page_count - 1))
        A("prev", "Previous page", "chevron-left", lambda: self.view() and self.view().prev_page())
        A("next", "Next page", "chevron-right", lambda: self.view() and self.view().next_page())
        # comment commands
        A("templates", "Manage\nTemplates", "palette-outline", self.manage_templates, accent=theme.ICON_ACCENT["comment"])
        A("stamp_new", "Create Stamp…", "stamper", lambda: self.manage_templates(1))
        A("sum_xlsx", "Summary\n(Excel)", "microsoft-excel", lambda: self.comments_summary("xlsx"), accent=theme.ICON_ACCENT["convert"])
        A("sum_pdf", "Summary\n(PDF report)", "file-pdf-box", lambda: self.comments_summary("pdf"), accent=theme.ICON_ACCENT["comment"])
        A("flatten", "Flatten\nComments", "layers-outline", self.flatten_comments)
        A("show_comments", "Comments\nList", "view-list-outline", lambda: self.show_panel("comments"))
        A("props_panel", "Properties", "playlist-edit", self.toggle_properties)
        A("hl_sel", "Highlight selection", "marker", lambda: self.markup_selection("highlight"))
        # measure
        A("scale", "Scale\nSettings", "ruler-square", self.scale_dialog, accent=theme.ICON_ACCENT["measure"])
        A("autoscale", "Auto\nScale", "auto-fix", self.auto_scale, accent=theme.ICON_ACCENT["measure"])
        A("m_list", "Measurement\nList", "format-list-bulleted-square", lambda: self.show_panel("measure"))
        A("m_export", "Export\nto Excel", "microsoft-excel", self.export_measurements, accent=theme.ICON_ACCENT["convert"])
        # edit / organize
        A("watermark", "Watermark", "water-plus-outline", self.watermark, accent=theme.ICON_ACCENT["edit"])
        A("headfoot", "Header &&\nFooter", "format-header-pound", self.header_footer, accent=theme.ICON_ACCENT["edit"])
        A("pg_insert", "Insert\nPages", "file-plus-outline", self.pages_insert, accent=theme.ICON_ACCENT["organize"])
        A("pg_delete", "Delete\nPages", "file-remove-outline", lambda: self.pages_delete(None), accent=theme.ICON_ACCENT["organize"])
        A("pg_extract", "Extract\nPages", "file-export-outline", lambda: self.pages_extract(None), accent=theme.ICON_ACCENT["organize"])
        A("pg_rot_r", "Rotate Right", "rotate-right", lambda: self.pages_rotate(None, 90))
        A("pg_rot_l", "Rotate Left", "rotate-left", lambda: self.pages_rotate(None, -90))
        A("pg_dup", "Duplicate", "file-document-multiple-outline", lambda: self.pages_duplicate(None))
        A("pg_reverse", "Reverse Order", "swap-vertical" if False else "playlist-edit", self.pages_reverse)
        A("merge", "Combine\nFiles", "call-merge", self.merge_files, accent=theme.ICON_ACCENT["organize"])
        A("split", "Split\nDocument", "call-split", self.split_doc, accent=theme.ICON_ACCENT["organize"])
        A("optimize", "Optimize\nSize", "zip-box-outline", self.optimize, accent=theme.ICON_ACCENT["organize"])
        A("crop_content", "Crop to Content", "crop", lambda: self.pages_crop_content(None))
        # convert
        for fmt, text, icon in (("word", "To\nWord", "file-word-outline"), ("excel", "To\nExcel", "file-excel-outline"),
                                ("jpg", "To\nJPEG", "file-image-outline"), ("dxf", "To\nDXF (CAD)", "vector-curve"),
                                ("png", "PNG", "image-multiple-outline"), ("tiff", "TIFF", "image-multiple-outline"),
                                ("bmp", "BMP", "image-multiple-outline"), ("svg", "SVG", "svg"), ("txt", "Text", "text-box-outline"),
                                ("html", "HTML", "language-html5"), ("pptx", "PowerPoint", "file-powerpoint-outline"),
                                ("csv", "CSV tables", "file-delimited-outline")):
            A("conv_" + fmt, text, icon, lambda c=False, f=fmt: self.convert(f), accent=theme.ICON_ACCENT["convert"])
        A("conv_batch", "Batch\nConvert", "file-cog-outline", lambda: D.BatchConvertDialog(self).exec(), accent=theme.ICON_ACCENT["convert"])
        A("img2pdf", "Images\nto PDF", "image-multiple-outline", self.images_to_pdf, accent=theme.ICON_ACCENT["convert"])
        # protect
        A("unlock", "Remove\nSecurity", "lock-open-variant-outline", self.remove_security_current, accent=theme.ICON_ACCENT["protect"])
        A("unlock_batch", "Password\nRemover (batch)", "lock-reset", lambda: D.PasswordRemoverDialog(self).exec(), accent=theme.ICON_ACCENT["protect"])
        A("protect", "Protect\nwith Password", "lock-outline", self.protect, accent=theme.ICON_ACCENT["protect"])
        A("sec_info", "Security\nProperties", "shield-key-outline", lambda: self.doc_properties(2), accent=theme.ICON_ACCENT["protect"])
        A("apply_redact", "Apply\nRedactions", "eraser", self.apply_redactions, accent=theme.ICON_ACCENT["protect"])
        A("sanitize", "Sanitize\nDocument", "auto-fix", self.sanitize, accent=theme.ICON_ACCENT["protect"])

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        central = QWidget()
        v = QVBoxLayout(central)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        # title band
        band = QWidget()
        band.setObjectName("TitleBand")
        band.setFixedHeight(40)
        h = QHBoxLayout(band)
        h.setContentsMargins(10, 2, 8, 2)
        logo = QLabel()
        pm = QPixmap(resource_path("assets", "icon_256.png"))
        if not pm.isNull():
            logo.setPixmap(pm.scaled(30, 30, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        h.addWidget(logo)
        tl = QVBoxLayout()
        tl.setSpacing(0)
        t1 = QLabel(APP_NAME)
        t1.setObjectName("AppTitle")
        t2 = QLabel("%s · v%s" % (COMPANY, VERSION))
        t2.setObjectName("AppSub")
        self._app_sub = t2
        tl.addWidget(t1)
        tl.addWidget(t2)
        h.addLayout(tl)
        h.addSpacing(18)
        qb = QWidget()
        qb.setObjectName("QuickBar")
        qh = QHBoxLayout(qb)
        qh.setContentsMargins(0, 0, 0, 0)
        for k in ("open", "save", "print", "undo", "redo"):
            b = QToolButton()
            a = self.A[k]
            b.setIcon(theme.icon({"open": "folder-open", "save": "content-save", "print": "printer", "undo": "undo", "redo": "redo"}[k], color="white"))
            b.setToolTip(a.toolTip() + ("  (%s)" % a.shortcut().toString() if not a.shortcut().isEmpty() else ""))
            b.clicked.connect(a.trigger)
            b.setIconSize(QSize(18, 18))
            qh.addWidget(b)
        h.addWidget(qb)
        h.addSpacing(18)
        self.doc_label = ElidedLabel("", Qt.ElideMiddle, min_chars=6)
        self.doc_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.doc_label.setStyleSheet("color:#DCE8F7;font-size:9pt;")
        h.addWidget(self.doc_label, 1)
        h.addSpacing(12)
        self.find_edit = QLineEdit()
        self.find_edit.setPlaceholderText("Find text (Ctrl+F)")
        self.find_edit.setMinimumWidth(110)
        self.find_edit.setMaximumWidth(230)
        self.find_edit.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.find_edit.setStyleSheet("QLineEdit{background:#24507F;color:white;border:1px solid #3B6EA5;border-radius:10px;padding:3px 10px;}"
                                     "QLineEdit:focus{background:white;color:#1B2430;}")
        self.find_edit.returnPressed.connect(self.do_find)
        h.addWidget(self.find_edit)
        v.addWidget(band)
        self.ribbon = Ribbon()
        v.addWidget(self.ribbon)
        from .update_ui import UpdateBanner, UpdateManager
        self.update_banner = UpdateBanner()
        v.addWidget(self.update_banner)
        self.updates = UpdateManager(self, self.update_banner)
        self.tabs = QTabWidget()
        self.tabs.setObjectName("DocTabs")
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.setDocumentMode(True)
        self.tabs.setElideMode(Qt.ElideRight)
        self.tabs.setUsesScrollButtons(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.on_tab_changed)
        v.addWidget(self.tabs, 1)
        self.start = self._start_page()
        self.tabs.hide()
        v.addWidget(self.start, 1)
        self.setCentralWidget(central)
        self.setAcceptDrops(True)

    def _start_page(self):
        w = QWidget()
        w.setStyleSheet("background:%s;" % theme.BG)
        lay = QVBoxLayout(w)
        lay.addStretch(1)
        card = QFrame()
        card.setStyleSheet("QFrame{background:white;border:1px solid %s;border-radius:10px;}" % theme.BORDER)
        card.setMaximumWidth(720)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(28, 22, 28, 22)
        title = QLabel("<span style='font-family:Century Gothic;font-size:20pt;font-weight:bold;color:%s'>%s</span>"
                       "<br><span style='color:%s'>Open a PDF (or drop it here) to view, comment, measure, convert and edit.</span>" % (theme.NAVY, APP_NAME, theme.MUTED))
        title.setStyleSheet("border:none;")
        cl.addWidget(title)
        row = QHBoxLayout()
        for k, txt in (("open", "Open PDF…"), ("img2pdf", "Images to PDF…"), ("merge", "Combine files…"), ("unlock_batch", "Password remover…")):
            b = QPushButton(self.A[k].icon(), txt)
            if k == "open":
                b.setObjectName("Primary")
                b.setIcon(theme.icon("folder-open", color="white"))
            b.clicked.connect(self.A[k].trigger)
            row.addWidget(b)
        cl.addLayout(row)
        cl.addWidget(QLabel("<b style='color:%s'>Recent files</b>" % theme.NAVY))
        self.recent_list = QListWidget()
        self.recent_list.setStyleSheet("QListWidget{border:none;} QListWidget::item{padding:4px;}")
        self.recent_list.itemActivated.connect(lambda it: self.open_files([it.data(Qt.UserRole)]))
        self.recent_list.itemClicked.connect(lambda it: self.open_files([it.data(Qt.UserRole)]))
        cl.addWidget(self.recent_list)
        hl = QHBoxLayout()
        hl.addStretch(1)
        hl.addWidget(card, 4)
        hl.addStretch(1)
        lay.addLayout(hl, 6)
        lay.addStretch(1)
        self._fill_recent()
        return w

    def _fill_recent(self):
        self.recent_list.clear()
        for p in settings().get("recent_files", [])[:10]:
            it = QListWidgetItem(theme.icon("file-pdf-box", color=theme.RED), "%s     —  %s" % (os.path.basename(p), os.path.dirname(p)))
            it.setData(Qt.UserRole, p)
            self.recent_list.addItem(it)

    def _build_ribbon(self):
        A = self.A
        R = self.ribbon
        # FILE menu button
        fb = QToolButton()
        fb.setText("  FILE  ")
        fb.setStyleSheet("QToolButton{background:%s;color:white;font-weight:bold;border:none;padding:5px 12px;}"
                         "QToolButton::menu-indicator{image:none;}" % theme.GREEN)
        fm = QMenu(self)
        for k in ("new", "open"):
            fm.addAction(A[k])
        self.recent_menu = fm.addMenu(theme.icon("folder-open"), "Recent files")
        self.recent_menu.aboutToShow.connect(self._fill_recent_menu)
        fm.addSeparator()
        for k in ("save", "saveas", "print", "close"):
            fm.addAction(A[k])
        fm.addSeparator()
        fm.addAction(A["props"])
        fm.addAction(A["prefs"])
        fm.addAction(A["guide"])
        fm.addAction(A["update"])
        fm.addAction(A["about"])
        fm.addSeparator()
        fm.addAction(A["exit"])
        fb.setMenu(fm)
        fb.setPopupMode(QToolButton.InstantPopup)
        R.setCornerWidget(fb, Qt.TopLeftCorner)

        # HOME
        p = R.page("HOME")
        g = p.group("File")
        g.add_large(A["open"])
        g.add_large(A["save"])
        g.add_small(A["saveas"])
        g.add_small(A["print"])
        g.add_small(A["props"])
        g = self._tools_group(p)
        g.add_large(A["tool_snapshot"], self._snapshot_menu(), popup=True)
        g.add_large(A["tool_edittext"])
        g.add_large(A["tool_editobj"], self.editobj_menu, popup=True)
        g.add_small(A["tool_zoom"])
        g.add_small(A["tool_loupe"])
        g.add_small(A["rotate_view_cw"])
        g = p.group("Zoom")
        g.add_small(A["zoom_in"])
        g.add_small(A["zoom_out"])
        g.add_small(A["actual"])
        g.add_small(A["fit_width"])
        g.add_small(A["fit_page"])
        self.zoom_combo = QComboBox()
        self.zoom_combo.setEditable(True)
        self.zoom_combo.addItems(["Fit Width", "Fit Page", "25%", "50%", "75%", "100%", "150%", "200%", "400%", "800%", "1600%", "3200%", "6400%"])
        self.zoom_combo.setFixedWidth(92)
        self.zoom_combo.activated.connect(self._zoom_combo)
        self.zoom_combo.lineEdit().returnPressed.connect(lambda: self._zoom_combo(-1))
        g.add_widget(self.zoom_combo)
        g = p.group("Review")
        g.add_large(A["lay_grid"])
        g.add_large(A["tool_loupe"])
        g.add_large(A["split_v2"])
        g = p.group("Comment")
        self.home_comment_group = g
        g = p.group("Measure")
        g.add_large(A["tool_m_distance"])
        g.add_large(A["tool_m_area"])
        g.add_small(A["scale"])
        g.add_small(A["tool_m_calibrate"])
        g.add_small(A["snap"])
        g = p.group("Convert / Protect")
        for f in ("word", "excel", "dxf"):
            g.add_large(A["conv_" + f])
        g.add_large(A["unlock"])
        # COMMENT
        p = R.page("COMMENT")
        self.comment_page = p
        self._build_comment_page(p)
        # MEASURE
        p = R.page("MEASURE")
        self._tools_group(p)
        g = p.group("Scale")
        g.add_large(A["scale"])
        g.add_large(A["autoscale"])
        g.add_large(A["tool_m_calibrate"])
        g.add_large(A["tool_m_origin"])
        g = p.group("Measure")
        for k in ("m_distance", "m_perimeter", "m_area", "m_angle", "m_circle"):
            g.add_large(A["tool_" + k])
        g = p.group("Object Snap (F3)  /  Ortho (F8)")
        g.add_large(A["snap"])
        self.snap_checks = {}
        for k, lab in (("end", "Endpoint"), ("mid", "Midpoint"), ("center", "Center"), ("intersection", "Intersection"),
                       ("quadrant", "Quadrant"), ("perpendicular", "Perpendicular"), ("nearest", "Nearest")):
            cb = QCheckBox(lab)
            cb.setChecked(bool(settings().get("snap", {}).get(k, True)))
            cb.toggled.connect(self._snap_changed)
            self.snap_checks[k] = cb
            g.add_widget(cb)
        g.new_column()
        g.add_large(A["ortho"])
        g = p.group("Unit")
        self.unit_combo = QComboBox()
        self.unit_combo.addItems(list(M.UNIT_TO_M.keys()))
        self.unit_combo.setCurrentText(settings().get("measure_unit", "m"))
        self.unit_combo.currentTextChanged.connect(self._unit_changed)
        self.prec_spin = QSpinBox()
        self.prec_spin.setRange(0, 6)
        self.prec_spin.setValue(int(settings().get("measure_precision", 3)))
        self.prec_spin.setPrefix("Decimals ")
        self.prec_spin.valueChanged.connect(lambda v: (settings().set("measure_precision", v), settings().save()))
        g.add_widget(QLabel("Display unit"))
        g.add_widget(self.unit_combo)
        g.add_widget(self.prec_spin)
        g = p.group("Results")
        g.add_large(A["m_list"])
        g.add_large(A["m_export"])
        # VIEW / REVIEW
        p = R.page("VIEW")
        g = self._tools_group(p)
        g.add_large(A["tool_snapshot"], self._snapshot_menu(), popup=True)
        g.add_large(A["tool_edittext"])
        g.add_large(A["tool_editobj"], self.editobj_menu, popup=True)
        g = p.group("Page Display")
        for k in ("lay_single", "lay_cont", "lay_facing", "lay_grid"):
            g.add_large(A[k])
        g = p.group("Page Grid (sheets on screen)")
        self.grid_cols = QSpinBox()
        self.grid_cols.setRange(1, 12)
        self.grid_cols.setValue(int(settings().get("grid_cols", 3)))
        self.grid_cols.setPrefix("Columns ")
        self.grid_rows = QSpinBox()
        self.grid_rows.setRange(1, 8)
        self.grid_rows.setValue(int(settings().get("grid_rows", 2)))
        self.grid_rows.setPrefix("Rows ")
        self.grid_cols.valueChanged.connect(self._grid_changed)
        self.grid_rows.valueChanged.connect(self._grid_changed)
        g.add_widget(self.grid_cols)
        g.add_widget(self.grid_rows)
        pres = QComboBox()
        pres.addItems(["Preset…", "1 × 1", "2 × 1", "2 × 2", "3 × 2", "4 × 2", "4 × 3", "6 × 4", "8 × 5"])
        pres.activated.connect(lambda k: self._grid_preset(pres.currentText()))
        g.add_widget(pres)
        g = p.group("Loupe")
        g.add_large(A["tool_loupe"])
        self.loupe_spin = QDoubleSpinBox()
        self.loupe_spin.setRange(1.25, 128)
        self.loupe_spin.setDecimals(1)
        self.loupe_spin.setSingleStep(1)
        self.loupe_spin.setPrefix("Zoom ×")
        self.loupe_spin.setValue(float(settings().get("loupe_zoom", 8)))
        self.loupe_spin.valueChanged.connect(self._loupe_zoom)
        self.loupe_size = QSpinBox()
        self.loupe_size.setRange(120, 700)
        self.loupe_size.setSingleStep(20)
        self.loupe_size.setPrefix("Size ")
        self.loupe_size.setSuffix(" px")
        self.loupe_size.setValue(int(settings().get("loupe_size", 260)))
        self.loupe_size.valueChanged.connect(self._loupe_size)
        g.add_widget(self.loupe_spin)
        g.add_widget(self.loupe_size)
        g.add_widget(QLabel("<span style='color:#5B6675;font-size:7.5pt'>wheel = zoom · click = pin</span>"))
        g = p.group("Rotate View")
        g.add_large(A["rotate_view_ccw"])
        g.add_large(A["rotate_view_cw"])
        g.add_small(A["rotate_view_reset"])
        g.add_small(A["pg_rotate_dlg"])
        g = p.group("Split View / Compare")
        for k in ("split_single", "split_v2", "split_h2", "split_quad"):
            g.add_large(A[k])
        g.add_large(A["sync"])
        g = p.group("Window")
        g.add_large(A["fullscreen"])
        g.add_small(A["show_comments"])
        g.add_small(A["props_panel"])
        # EDIT
        p = R.page("EDIT")
        self._tools_group(p)
        self.edit_page = p
        g = p.group("Content")
        g.add_large(A["tool_edittext"])
        g.add_large(A["tool_editobj"], self.editobj_menu, popup=True)
        for k in ("addtext", "image", "whiteout"):
            g.add_large(A["tool_" + k])
        g = p.group("Page Marks")
        g.add_large(A["watermark"], self._watermark_menu(), popup=True)
        g.add_large(A["headfoot"])
        g.add_large(A["tool_link"])
        g = p.group("Forms")
        for k in ("field_text", "field_check", "field_combo"):
            g.add_large(A["tool_" + k])
        g = p.group("Undo")
        g.add_large(A["undo"])
        g.add_large(A["redo"])
        # ORGANIZE
        p = R.page("ORGANIZE")
        self._tools_group(p)
        g = p.group("Rotate")
        g.add_large(A["pg_rotate_dlg"])
        g.add_small(A["pg_rot_r"])
        g.add_small(A["pg_rot_l"])
        g.add_small(A["pg_rot_180"])
        g = p.group("Pages")
        for k in ("pg_insert", "pg_delete", "pg_extract"):
            g.add_large(A[k])
        g.add_small(A["pg_dup"])
        g.add_small(A["pg_reverse"])
        g.add_small(A["crop_content"])
        g.new_column()
        g.add_large(A["tool_crop"])
        g = p.group("Documents")
        g.add_large(A["merge"])
        g.add_large(A["split"])
        g.add_large(A["optimize"])
        # CONVERT
        p = R.page("CONVERT")
        self._tools_group(p)
        g = p.group("From PDF")
        for f in ("word", "excel", "jpg", "dxf"):
            g.add_large(A["conv_" + f])
        for f in ("png", "tiff", "bmp", "svg", "txt", "html", "pptx", "csv"):
            g.add_small(A["conv_" + f])
        g = p.group("Batch / Create")
        g.add_large(A["conv_batch"])
        g.add_large(A["img2pdf"])
        g.add_large(A["merge"])
        # PROTECT
        p = R.page("PROTECT")
        self._tools_group(p)
        g = p.group("Passwords")
        g.add_large(A["unlock"])
        g.add_large(A["unlock_batch"])
        g.add_large(A["protect"])
        g.add_large(A["sec_info"])
        g = p.group("Redaction")
        g.add_large(A["tool_redact"])
        g.add_large(A["apply_redact"])
        g.add_large(A["sanitize"])

    def _tools_group(self, p):
        """Hand / Select Comments / Select Text - shown on every ribbon tab."""
        g = p.group("Tools")
        for k in ("hand", "select", "selecttext"):
            g.add_large(self.A["tool_" + k])
        return g

    def _snapshot_menu(self):
        m = QMenu(self)
        m.addAction(self.A["tool_snapshot"].icon(), "Pick a page or area (click a page / drag a rectangle)",
                    lambda: self.set_tool("snapshot"))
        m.addAction(self.A["snap_page"])
        m.addAction(self.A["snap_view"])
        m.addSeparator()
        m.addAction(self.A["snap_save"])
        q = m.addMenu(theme.icon("cog-outline"), "Snapshot quality")
        grp = QActionGroup(q)
        cur = int(settings().get("snapshot_dpi", 600))
        for dpi, txt in ((300, "300 dpi (good)"), (600, "600 dpi (very high - default)"), (900, "900 dpi"), (1200, "1200 dpi (maximum)")):
            act = q.addAction(txt, lambda d=dpi: (settings().set("snapshot_dpi", d), settings().save()))
            act.setCheckable(True)
            act.setChecked(dpi == cur)
            grp.addAction(act)
        q.addSeparator()
        mx = q.addMenu("Maximum image size")
        g2 = QActionGroup(mx)
        curm = int(settings().get("snapshot_max_mpx", 64))
        for mp, txt in ((64, "64 megapixel (default - safe for the clipboard)"), (100, "100 megapixel"),
                        (150, "150 megapixel (large drawings A1 / A0 at full dpi; needs a lot of memory)")):
            act = mx.addAction(txt, lambda v=mp: (settings().set("snapshot_max_mpx", v), settings().save()))
            act.setCheckable(True)
            act.setChecked(mp == curm)
            g2.addAction(act)
        q.addSeparator()
        snd = m.addAction(theme.icon("camera-outline"), "Camera sound when a snapshot is taken")
        snd.setCheckable(True)
        snd.setChecked(bool(settings().get("snapshot_sound", True)))
        snd.toggled.connect(lambda on: (settings().set("snapshot_sound", on), settings().save()))
        vec = q.addAction("Also copy as vector (SVG + PDF) - never pixelated")
        vec.setCheckable(True)
        vec.setChecked(bool(settings().get("snapshot_vector", True)))
        vec.toggled.connect(lambda on: (settings().set("snapshot_vector", on), settings().save()))
        return m

    def _build_comment_page(self, p):
        A = self.A
        self.comment_buttons = {}
        self._tools_group(p)
        g = p.group("Comment")
        # PDF-XChange style: small buttons with a style drop-down, three per column
        for kind, label in (("typewriter", "Typewriter"), ("textbox", "Text Box"), ("callout", "Callout"),
                            ("note", "Sticky Note"), ("attach", "Attach File"), ("sound", "Sound"),
                            ("highlight", "Highlight Text"), ("area", "Highlight Area"), ("freehighlight", "Free Highlight"),
                            ("underline", "Underline"), ("strikeout", "Strikeout"), ("inserttext", "Insert Text"),
                            ("replacetext", "Replace Text"), ("textcorrection", "Text Correction"), ("squiggly", "Squiggly")):
            self._kind_button(g, kind, label, large=False)
        g = p.group("Class Review")
        for kind, label in (("cloud", "Cloud"), ("cloudpoly", "Cloud\nPolygon"), ("balloon", "Balloon\n\u2460")):
            self._kind_button(g, kind, label, large=True)
        self.stamp_btn_action = QAction(theme.icon("stamper", accent=theme.ICON_ACCENT["comment"]), "Stamp", self)
        self.stamp_btn_action.triggered.connect(lambda: self.use_stamp(None))
        self.stamp_menu = QMenu(self)
        g.add_large(self.stamp_btn_action, self.stamp_menu, popup=True)
        g = p.group("Drawing")
        for kind, label in (("rect", "Rectangle"), ("ellipse", "Ellipse"), ("arrow", "Arrow"), ("line", "Line"),
                            ("polyline", "Polyline"), ("polygon", "Polygon"), ("ink", "Pen")):
            self._kind_button(g, kind, label, large=False)
        g = p.group("Templates (my comment styles)")
        self.tpl_combo = QComboBox()
        self.tpl_combo.setMinimumWidth(200)
        self.tpl_combo.setIconSize(QSize(16, 16))
        self.tpl_combo.activated.connect(self._tpl_combo_pick)
        g.add_widget(self.tpl_combo)
        g.add_widget(QLabel("<span style='color:#5B6675;font-size:7.5pt'>Pick a style to start drawing with it</span>"))
        g.new_column()
        g.add_large(A["templates"])
        g = p.group("Manage")
        g.add_large(A["show_comments"])
        g.add_large(A["sum_xlsx"])
        g.add_large(A["sum_pdf"])
        g.add_small(A["props_panel"])
        g.add_small(A["flatten"])
        # home tab shortcuts
        hg = self.home_comment_group
        for kind, label in (("cloud", "Cloud"), ("balloon", "Balloon"), ("textbox", "Text Box")):
            self._kind_button(hg, kind, label, large=True, register=False)
        self.refresh_templates()

    def _kind_button(self, g, kind, label, large=True, register=True):
        a = QAction(theme.icon(KIND_ICON[kind], accent=theme.ICON_ACCENT["comment"]), label, self)
        a.setCheckable(True)
        a.triggered.connect(lambda c=False, k=kind: self.use_kind(k))
        self.tool_group.addAction(a)
        menu = QMenu(self)
        menu.aboutToShow.connect(lambda m=menu, k=kind: self._fill_kind_menu(m, k))
        b = g.add_large(a, menu, popup=True) if large else g.add_small(a, menu, popup=True)
        self.comment_buttons.setdefault(kind, []).append(a)
        return a

    def _fill_kind_menu(self, menu, kind):
        menu.clear()
        st = store()
        cur = self.kind_style.get(kind)
        for t in st.tools:
            if t["kind"] == kind:
                a = menu.addAction(tool_icon(t), t["name"], lambda t=t: self.use_template(t))
                a.setCheckable(True)
                a.setChecked(t["id"] == cur)
        menu.addSeparator()
        menu.addAction(theme.icon("palette-outline"), "New style / manage templates…", self.manage_templates)

    def refresh_templates(self):
        st = store()
        self.tpl_combo.clear()
        for t in st.tools:
            self.tpl_combo.addItem(tool_icon(t), t["name"], t["id"])
        self.stamp_menu.clear()
        for s in st.stamps:
            a = self.stamp_menu.addAction(QIcon(stamp_thumbnail(s, 30)), s["name"], lambda s=s: self.use_stamp(s))
        self.stamp_menu.setStyleSheet("QMenu{icon-size:72px;}")
        self.stamp_menu.addSeparator()
        self.stamp_menu.addAction(theme.icon("stamper"), "Create / edit stamps…", lambda: self.manage_templates(1))

    def _tpl_combo_pick(self, k):
        tid = self.tpl_combo.itemData(k)
        t = store().find_tool(tid)
        if t:
            self.use_template(t)

    def _fill_recent_menu(self):
        self.recent_menu.clear()
        for p in settings().get("recent_files", []):
            self.recent_menu.addAction(os.path.basename(p), lambda p=p: self.open_files([p])).setToolTip(p)

    def _build_status(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        nav = QWidget()
        h = QHBoxLayout(nav)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(1)
        for k in ("first", "prev"):
            b = QToolButton()
            b.setDefaultAction(self.A[k])
            b.setIcon(theme.icon(self.A[k].toolTip() and {"first": "page-first", "prev": "chevron-left"}[k], color="white"))
            h.addWidget(b)
        self.page_spin = QSpinBox()
        self.page_spin.setRange(1, 1)
        self.page_spin.setFixedWidth(58)
        self.page_spin.setKeyboardTracking(False)
        self.page_spin.valueChanged.connect(lambda v: self.view() and self.view().current_page() != v - 1 and self.view().go_to_page(v - 1))
        h.addWidget(self.page_spin)
        self.page_total = QLabel("/ 0")
        h.addWidget(self.page_total)
        for k in ("next", "last"):
            b = QToolButton()
            b.setDefaultAction(self.A[k])
            b.setIcon(theme.icon({"next": "chevron-right", "last": "page-last"}[k], color="white"))
            h.addWidget(b)
        sb.addWidget(nav)
        fm = sb.fontMetrics()
        self.coord_label = ElidedLabel("", Qt.ElideRight, min_chars=3,
                                       pref_width=fm.horizontalAdvance("X 000.000  Y -000.000 mm   ·   paper 0000.0, 0000.0 mm") + 16)
        sb.addWidget(self.coord_label, 0)
        self.msg_label = ElidedLabel("", Qt.ElideRight, min_chars=4)
        sb.addWidget(self.msg_label, 1)
        self.scale_label = ElidedLabel("", Qt.ElideRight, min_chars=4,
                                       pref_width=fm.horizontalAdvance("Scale: 1 : 1 (paper)  [mm]") + 16)
        sb.addPermanentWidget(self.scale_label)
        for k, txt in (("snap", "OSNAP"), ("ortho", "ORTHO")):
            b = QToolButton()
            b.setDefaultAction(self.A[k])
            b.setToolButtonStyle(Qt.ToolButtonTextOnly)
            b.setText(txt)
            sb.addPermanentWidget(b)
        rot = QWidget()
        rot.setObjectName("RotBox")
        rh = QHBoxLayout(rot)
        rh.setContentsMargins(4, 0, 4, 0)
        rh.setSpacing(0)
        for k, deg, tip in (("rotate-left", -90, "Rotate view 90° left (Ctrl+Shift+-) - the file is not changed"),
                            ("rotate-right", 90, "Rotate view 90° right (Ctrl+Shift++) - the file is not changed")):
            b = QToolButton()
            b.setObjectName("RotBtn")
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setIcon(theme.icon(k, color="#FFFFFF"))
            b.setIconSize(QSize(17, 17))
            b.setText("90°")
            b.setToolTip(tip)
            if deg > 0:
                b.setLayoutDirection(Qt.RightToLeft)
            b.clicked.connect(lambda c=False, d=deg: self.rotate_view(d))
            rh.addWidget(b)
            self._rot_btns = getattr(self, "_rot_btns", []) + [b]
        sb.addPermanentWidget(rot)
        sb.addPermanentWidget(self._build_zoom_box())
        self._lay_btns = []
        for k in ("lay_single", "lay_cont", "lay_grid"):
            b = QToolButton()
            b.setObjectName("LayBtn")
            self._lay_btns.append(b)
            b.setDefaultAction(self.A[k])
            b.setToolButtonStyle(Qt.ToolButtonIconOnly)
            b.setIcon(theme.icon({"lay_single": "file-document-outline", "lay_cont": "book-open-page-variant-outline",
                                  "lay_facing": "file-document-multiple-outline", "lay_grid": "view-grid-outline"}[k], color="white"))
            sb.addPermanentWidget(b)
        self.A["snap"].setChecked(True)

    def _adapt_status(self):
        """Keep the whole status bar on screen on small / high-DPI screens: drop extras when narrow."""
        if not hasattr(self, "_lay_btns"):
            return
        try:
            sw = self.screen().availableGeometry().width()
        except Exception:
            sw = self.width()
        w = min(self.width(), sw)
        for b in self._lay_btns:
            b.setVisible(w >= 1180)
        self.zoom_slider.setVisible(w >= 1060)
        for b in getattr(self, "_rot_btns", []):
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon if w >= 960 else Qt.ToolButtonIconOnly)
        if hasattr(self, "_app_sub"):
            self._app_sub.setVisible(w >= 1000)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._adapt_status()

    def showEvent(self, e):
        super().showEvent(e)
        self._adapt_status()

    # zoom box with slider (status bar)
    ZMIN, ZMAX = 2.0, 6400.0

    def _build_zoom_box(self):
        from PySide6.QtWidgets import QSlider
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(4, 0, 4, 0)
        h.setSpacing(2)
        self.zoom_box = QComboBox()
        self.zoom_box.setEditable(True)
        self.zoom_box.setInsertPolicy(QComboBox.NoInsert)
        self.zoom_box.addItems(["Fit Width", "Fit Page", "Actual Size", "10%", "25%", "50%", "75%", "100%", "125%", "150%",
                                "200%", "300%", "400%", "800%", "1600%", "3200%", "6400%"])
        self.zoom_box.setFixedWidth(92)
        self.zoom_box.setToolTip("Zoom - type a value (e.g. 137.5) and press Enter")
        self.zoom_box.activated.connect(lambda k: self._zoom_text(self.zoom_box.itemText(k)))
        self.zoom_box.lineEdit().returnPressed.connect(lambda: self._zoom_text(self.zoom_box.currentText()))
        h.addWidget(self.zoom_box)
        bm = QToolButton()
        bm.setIcon(theme.icon("minus-circle-outline", color="white"))
        bm.setToolTip("Zoom out")
        bm.setAutoRepeat(True)
        bm.clicked.connect(lambda: self.view() and self.view().zoom_by(1 / 1.1))
        h.addWidget(bm)
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setRange(0, 1000)
        self.zoom_slider.setFixedWidth(96)
        self.zoom_slider.setToolTip("Zoom")
        self.zoom_slider.setStyleSheet(
            "QSlider::groove:horizontal{height:3px;background:#7F93AD;border-radius:1px;}"
            "QSlider::sub-page:horizontal{background:#9FC3F0;}"
            "QSlider::handle:horizontal{background:white;border:2px solid #5B6675;width:12px;height:12px;margin:-6px 0;border-radius:7px;}")
        self.zoom_slider.valueChanged.connect(self._zoom_slider_moved)
        h.addWidget(self.zoom_slider)
        bp = QToolButton()
        bp.setIcon(theme.icon("plus-circle-outline", color="white"))
        bp.setToolTip("Zoom in")
        bp.setAutoRepeat(True)
        bp.clicked.connect(lambda: self.view() and self.view().zoom_by(1.1))
        h.addWidget(bp)
        return w

    def _zoom_to_slider(self, z):
        import math
        z = max(self.ZMIN, min(self.ZMAX, z))
        return int(round(1000 * math.log(z / self.ZMIN) / math.log(self.ZMAX / self.ZMIN)))

    def _zoom_slider_moved(self, val):
        if getattr(self, "_zoom_sync", False):
            return
        v = self.view()
        if not v:
            return
        import math
        z = self.ZMIN * math.exp(val / 1000.0 * math.log(self.ZMAX / self.ZMIN))
        v.set_zoom_percent(z)

    def _zoom_text(self, txt):
        v = self.view()
        if not v:
            return
        t = txt.strip().lower()
        if t.startswith("fit w"):
            v.set_fit("width")
        elif t.startswith("fit p"):
            v.set_fit("page")
        elif t.startswith("actual"):
            v.set_zoom_percent(100)
        else:
            try:
                v.set_zoom_percent(float(t.replace("%", "").replace(",", ".")))
            except ValueError:
                pass
        v.setFocus()

    def _build_docks(self):
        self.panels = {}
        dock = QDockWidget("Navigation", self)
        dock.setObjectName("NavDock")
        dock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetFloatable)
        self.side = QTabWidget()
        self.side.setObjectName("SidePanels")
        self.side.setTabPosition(QTabWidget.West)
        for key, title, icon, cls in (("thumbs", "Pages", "file-document-multiple-outline", P.ThumbnailsPanel),
                                      ("bookmarks", "Bookmarks", "bookmark-outline", P.BookmarksPanel),
                                      ("comments", "Comments", "comment-text-outline", P.CommentsPanel),
                                      ("measure", "Measure", "ruler", P.MeasurementsPanel),
                                      ("search", "Search", "magnify", P.SearchPanel),
                                      ("layers", "Layers", "layers-outline", P.LayersPanel),
                                      ("attach", "Attachments", "paperclip", P.AttachmentsPanel)):
            w = cls(self)
            self.panels[key] = w
            self.side.addTab(w, theme.icon(icon), "")
            self.side.setTabToolTip(self.side.count() - 1, title)
        self.side.currentChanged.connect(lambda k: self.side.widget(k).refresh() if self.side.widget(k) else None)
        dock.setWidget(self.side)
        dock.setMinimumWidth(200)
        self.addDockWidget(Qt.LeftDockWidgetArea, dock)
        self.nav_dock = dock
        pd = QDockWidget("Comment Properties", self)
        pd.setObjectName("PropDock")
        self.prop_panel = P.PropertiesPanel(self)
        pd.setWidget(self.prop_panel)
        self.addDockWidget(Qt.RightDockWidgetArea, pd)
        pd.hide()
        self.prop_dock = pd
        self.resizeDocks([dock], [270], Qt.Horizontal)

    # ------------------------------------------------------------ helpers
    def status(self, msg, ms=8000):
        self.msg_label.setText(msg)
        if ms:
            QTimer.singleShot(ms, lambda m=msg: self.msg_label.text() == m and self.msg_label.setText(""))

    def doc_tab(self):
        w = self.tabs.currentWidget()
        return w if isinstance(w, DocTab) else None

    def view(self):
        t = self.doc_tab()
        return t.active if t else None

    def doc(self):
        v = self.view()
        return v.pdfdoc if v else None

    def all_docs(self):
        out = []
        for k in range(self.tabs.count()):
            w = self.tabs.widget(k)
            if isinstance(w, DocTab):
                out.append(w.pdfdoc)
        return out

    def all_views(self):
        for k in range(self.tabs.count()):
            w = self.tabs.widget(k)
            if isinstance(w, DocTab):
                for v in w.views:
                    yield v

    def need_doc(self):
        d = self.doc()
        if d is None:
            self.status("Open a document first.")
        return d

    def update_actions(self):
        d = self.doc()
        has = d is not None
        for k, a in self.A.items():
            if k in ("new", "open", "prefs", "about", "update", "exit", "guide", "merge", "conv_batch", "img2pdf", "unlock_batch",
                     "snap", "ortho", "templates", "stamp_new", "fullscreen"):
                continue
            a.setEnabled(has)
        if has:
            self.A["undo"].setEnabled(d.can_undo())
            self.A["redo"].setEnabled(d.can_redo())
        title = APP_NAME
        if d:
            title = "%s%s - %s" % (d.title, " *" if d.modified else "", APP_NAME)
            self.doc_label.setText(d.path or d.title)
        else:
            self.doc_label.setText("")
        self.setWindowTitle(title)
        has_tabs = self.tabs.count() > 0
        self.tabs.setVisible(has_tabs)
        self.start.setVisible(not has_tabs)
        if not has_tabs:
            self._fill_recent()

    # ---------------------------------------------------------- open/save
    def new_doc(self):
        sizes = ["A4 portrait", "A4 landscape", "A3 landscape", "A2 landscape", "A1 landscape", "Letter"]
        s, ok = QInputDialog.getItem(self, "New document", "Page size:", sizes, 0, False)
        if not ok:
            return
        name = {"A4 portrait": "a4", "A4 landscape": "a4-l", "A3 landscape": "a3-l", "A2 landscape": "a2-l",
                "A1 landscape": "a1-l", "Letter": "letter"}[s]
        w, h = pymupdf.paper_size(name)
        self.add_doc(PdfDoc.new_blank(w, h))

    def open_dialog(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Open", settings().get("last_dir", ""), PDF_FILTER)
        if files:
            self.open_files(files)

    def open_files(self, files):
        for path in files:
            if not path or not os.path.exists(path):
                continue
            # already open?
            for k in range(self.tabs.count()):
                w = self.tabs.widget(k)
                if isinstance(w, DocTab) and w.pdfdoc.path and os.path.normcase(os.path.abspath(w.pdfdoc.path)) == os.path.normcase(os.path.abspath(path)):
                    self.tabs.setCurrentIndex(k)
                    break
            else:
                try:
                    QApplication.setOverrideCursor(Qt.WaitCursor)
                    try:
                        pd = PdfDoc.open_path(path, lambda att: (QApplication.restoreOverrideCursor(), D.ask_password(self, path, att))[1])
                    finally:
                        while QApplication.overrideCursor():
                            QApplication.restoreOverrideCursor()
                except Exception as e:
                    QMessageBox.warning(self, "Open", "Cannot open %s\n\n%s" % (path, e))
                    continue
                if pd is None:
                    continue
                settings().set("last_dir", os.path.dirname(path))
                settings().add_recent(path)
                self.add_doc(pd)
                si = pd.security_info()
                if si["encrypted"]:
                    restricted = [n for n, ok in si["perms"] if not ok]
                    self.status("This PDF is encrypted (%s)%s. Use PROTECT ▸ Remove Security to save an unprotected copy." % (
                        si["method"], (" with restrictions: " + ", ".join(restricted)) if restricted else ""), 15000)

    def add_doc(self, pd):
        tab = DocTab(self, pd)
        pd.modified_changed.connect(lambda m, pd=pd: self._doc_modified(pd))
        pd.structure_changed.connect(self.update_actions)
        k = self.tabs.addTab(tab, theme.icon("file-pdf-box", color=theme.RED), pd.title)
        self.tabs.setTabToolTip(k, pd.path or pd.title)
        self.tabs.setCurrentIndex(k)
        self.update_actions()
        self.on_tab_changed(k)
        for t in self._tabs():
            t.refresh_headers()

    def _tabs(self):
        return [self.tabs.widget(k) for k in range(self.tabs.count()) if isinstance(self.tabs.widget(k), DocTab)]

    def _doc_modified(self, pd):
        for k in range(self.tabs.count()):
            w = self.tabs.widget(k)
            if isinstance(w, DocTab) and w.pdfdoc is pd:
                self.tabs.setTabText(k, pd.title + (" *" if pd.modified else ""))
        self.update_actions()

    def save(self):
        d = self.need_doc()
        if not d:
            return False
        if not d.path:
            return self.save_as()
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            d.save()
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Save", "Could not save:\n%s" % e)
            return False
        QApplication.restoreOverrideCursor()
        self.status("Saved: " + d.path)
        self._doc_modified(d)
        return True

    def save_as(self):
        d = self.need_doc()
        if not d:
            return False
        start = d.path or os.path.join(settings().get("last_save_dir") or settings().get("last_dir") or os.path.expanduser("~"),
                                       os.path.splitext(d.title)[0] + ".pdf")
        path, _ = QFileDialog.getSaveFileName(self, "Save As", start, "PDF (*.pdf)")
        if not path:
            return False
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            d.save(path)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Save As", str(e))
            return False
        QApplication.restoreOverrideCursor()
        settings().set("last_save_dir", os.path.dirname(path))
        settings().add_recent(path)
        self._doc_modified(d)
        k = self.tabs.currentIndex()
        self.tabs.setTabToolTip(k, path)
        self.status("Saved: " + path)
        return True

    def maybe_save(self, pd):
        if not pd.modified:
            return True
        r = QMessageBox.question(self, "Save changes", "Save changes to %s?" % pd.title,
                                 QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
        if r == QMessageBox.Cancel:
            return False
        if r == QMessageBox.Save:
            idx = next((k for k in range(self.tabs.count()) if isinstance(self.tabs.widget(k), DocTab) and self.tabs.widget(k).pdfdoc is pd), None)
            if idx is not None:
                self.tabs.setCurrentIndex(idx)
            return self.save()
        return True

    def close_tab(self, k):
        w = self.tabs.widget(k)
        if not isinstance(w, DocTab):
            return
        if not self.maybe_save(w.pdfdoc):
            return
        self.tabs.removeTab(k)
        # other tabs may show this document in a split pane
        for t in self._tabs():
            for v in t.views:
                if v.pdfdoc is w.pdfdoc:
                    v.set_document(t.pdfdoc)
            t.refresh_headers()
        CACHE.drop_doc(w.pdfdoc.uid)
        w.pdfdoc.close()
        w.deleteLater()
        self.update_actions()
        if self.tabs.count() == 0:
            for p in self.panels.values():
                p.set_view(None)
            self.prop_panel.show_selection(None)

    def close_current(self):
        if self.tabs.currentIndex() >= 0:
            self.close_tab(self.tabs.currentIndex())

    def finalize_clipboard(self):
        """Replace a lazy snapshot on the clipboard by plain data so it survives after the program exits."""
        try:
            cb = QGuiApplication.clipboard()
            md = cb.mimeData()
            if isinstance(md, SnapshotMime):
                plain = QMimeData()
                plain.setImageData(md._img)
                for f in md._extra():
                    plain.setData(f, md.retrieveData(f, None))
                cb.setMimeData(plain)
        except Exception:
            pass

    def closeEvent(self, e):
        for t in self._tabs():
            if not self.maybe_save(t.pdfdoc):
                e.ignore()
                return
        self.finalize_clipboard()
        try:
            from .update import mark_healthy
            mark_healthy()
        except Exception:
            pass
        try:
            from .snap import BUILDER
            BUILDER.shutdown()
        except Exception:
            pass
        settings().set("window_geometry", bytes(self.saveGeometry().toHex()).decode())
        settings().set("grid_cols", self.grid_cols.value())
        settings().set("grid_rows", self.grid_rows.value())
        settings().set("loupe_zoom", self.loupe_spin.value())
        settings().save()
        e.accept()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self.open_files([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])

    def undo(self):
        d = self.doc()
        if d and d.undo():
            self.update_actions()

    def redo(self):
        d = self.doc()
        if d and d.redo():
            self.update_actions()

    # ------------------------------------------------------------- events
    def on_tab_changed(self, k):
        t = self.doc_tab()
        if t:
            self.on_view_activated(t.active)
        self.update_actions()

    def on_view_activated(self, v):
        t = self.doc_tab()
        if t and v in t.views:
            t.active = v
        for p in self.panels.values():
            if p.view is not v or p.doc is not v.pdfdoc:
                p.set_view(v)
        self.page_spin.blockSignals(True)
        self.page_spin.setRange(1, max(1, v.pdfdoc.page_count))
        self.page_spin.setValue(v.current_page() + 1)
        self.page_spin.blockSignals(False)
        self.page_total.setText("/ %d" % v.pdfdoc.page_count)
        self.on_zoom_changed(v, v.zoom_percent())
        self._sync_layout_actions(v)
        self.scale_label.setText("Scale: " + M.page_label_scale(v.pdfdoc, v.current_page()))
        self.prop_panel.show_selection(v)
        self.update_actions()

    def _upd_undo(self, *_):
        self.update_actions()

    def _sync_layout_actions(self, v):
        key = {"single": "lay_single", "continuous": "lay_cont", "facing": "lay_facing", "grid": "lay_grid"}[v.mode]
        self.A[key].setChecked(True)
        t = self.doc_tab()
        if t:
            self.A["split_" + t.split].setChecked(True)
            self.A["sync"].setChecked(t.sync)

    def on_page_changed(self, v, i):
        if v is not self.view():
            return
        self.page_spin.blockSignals(True)
        self.page_spin.setRange(1, max(1, v.pdfdoc.page_count))
        self.page_spin.setValue(i + 1)
        self.page_spin.blockSignals(False)
        self.page_total.setText("/ %d" % v.pdfdoc.page_count)
        self.panels["thumbs"].set_current(i)
        self.scale_label.setText("Scale: " + M.page_label_scale(v.pdfdoc, i))

    def on_zoom_changed(self, v, z):
        if v is not self.view():
            return
        txt = ("%.2f%%" % z).replace(".00%", "%")
        if not self.zoom_box.lineEdit().hasFocus():
            self.zoom_box.setEditText(txt)
        if not self.zoom_combo.hasFocus():
            self.zoom_combo.setEditText("%d%%" % round(z))
        self._zoom_sync = True
        self.zoom_slider.setValue(self._zoom_to_slider(z))
        self._zoom_sync = False

    def on_cursor(self, v, h):
        if not h:
            self.coord_label.setText("")
            return
        i, xu, yu = h
        doc = v.pdfdoc
        s = M.get_scale(doc, i)
        xd, yd = doc.to_disp(i, xu, yu)
        org = doc.get_origin(i)
        if org:
            ox, oy = doc.to_disp(i, *org)
        else:
            ox, oy = 0.0, doc.page_sizes()[i][1]
        f = s["m_per_pt"]
        u = s["unit"]
        prec = settings().get("measure_precision", 3)
        X = (xd - ox) * f / M.UNIT_TO_M[u]
        Y = (oy - yd) * f / M.UNIT_TO_M[u]
        self.coord_label.setText("X %.*f  Y %.*f %s   ·   paper %.1f, %.1f mm" % (prec, X, prec, Y, u, xd * 25.4 / 72, yd * 25.4 / 72))

    def on_selection(self, v, sel):
        self.prop_panel.show_selection(v)

    def on_text_selection(self, v):
        if v.text_sel:
            n = len(v.text_sel[2])
            self.status("%d characters selected - Ctrl+C to copy, right-click to highlight / underline / strike out." % n)

    def on_loupe_zoom_changed(self, z):
        self.loupe_spin.blockSignals(True)
        self.loupe_spin.setValue(z)
        self.loupe_spin.blockSignals(False)

    def on_grid_changed(self, v):
        self.grid_cols.blockSignals(True)
        self.grid_rows.blockSignals(True)
        self.grid_cols.setValue(v.grid_cols)
        self.grid_rows.setValue(v.grid_rows)
        self.grid_cols.blockSignals(False)
        self.grid_rows.blockSignals(False)
        self.A["lay_grid"].setChecked(True)

    def on_scale_changed(self):
        v = self.view()
        if v:
            self.scale_label.setText("Scale: " + M.page_label_scale(v.pdfdoc, v.current_page()))
            self.panels["measure"].refresh()

    # --------------------------------------------------------------- tools
    def make_tool(self, name, style=None, stamp=None):
        m = self
        if name == "hand":
            return T.HandTool(m)
        if name == "select":
            return T.SelectTool(m)
        if name == "selecttext":
            return T.SelectTool(m, text_only=True)
        if name == "zoom":
            return T.ZoomTool(m)
        if name == "snapshot":
            return T.SnapshotTool(m)
        if name == "loupe":
            return T.LoupeTool(m)
        if name == "stamp":
            return T.StampTool(m, stamp=stamp)
        cls = {"m_distance": M.DistanceTool, "m_perimeter": M.PerimeterTool, "m_area": M.AreaTool, "m_angle": M.AngleTool,
               "m_circle": M.CircleTool, "m_calibrate": M.CalibrateTool, "m_origin": M.OriginTool,
               "addtext": T.AddTextTool, "image": T.ImageTool, "whiteout": T.WhiteoutTool,
               "redact": T.RedactTool, "crop": T.CropTool, "link": T.LinkTool}.get(name)
        if cls:
            return cls(m)
        if name == "editobj":
            from . import objedit as OE
            return OE.EditObjectsTool(m, mode=self.editobj_mode)
        if name == "edittext":
            from . import objedit as OE
            return OE.EditObjectsTool(m, mode="text", edit_text_on_click=True)
        if name.startswith("field_"):
            return T.FieldTool(m, {"field": name[6:]})
        if name == "comment" and style:
            kind = style.get("kind")
            c = {"cloud": T.ShapeRectTool, "rect": T.ShapeRectTool, "ellipse": T.ShapeRectTool, "area": T.ShapeRectTool,
                 "textbox": T.ShapeRectTool, "line": T.LineTool, "arrow": T.LineTool, "polyline": T.PolyTool,
                 "polygon": T.PolyTool, "cloudpoly": T.PolyTool, "ink": T.InkTool, "highlight": T.MarkupTool,
                 "underline": T.MarkupTool, "strikeout": T.MarkupTool, "squiggly": T.MarkupTool, "note": T.NoteTool,
                 "typewriter": T.TypewriterTool, "callout": T.CalloutTool, "balloon": T.BalloonTool,
                 "freehighlight": T.FreeHighlightTool, "attach": T.AttachFileTool, "sound": T.SoundTool,
                 "inserttext": T.TextEditMarkTool, "replacetext": T.TextEditMarkTool,
                 "textcorrection": T.TextEditMarkTool}.get(kind, T.ShapeRectTool)
            t = c(m, style)
            if kind in ("line", "arrow", "polyline", "polygon", "cloudpoly"):
                t.snaps = True
            return t
        return T.HandTool(m)

    def set_tool(self, name, style=None, stamp=None):
        self.current_tool_name = name
        self.current_tool_style = style
        self.current_stamp = stamp
        for v in self.all_views():
            v.set_tool(self.make_tool(name, style, stamp))
        a = self.A.get("tool_" + name)
        if a:
            a.setChecked(True)
        elif name == "comment" and style:
            for act in self.comment_buttons.get(style.get("kind"), []):
                act.setChecked(True)
        hints = {"m_distance": "Pick two points. OSnap F3, Ortho F8 (or hold Shift), Ctrl = no snap.",
                 "m_perimeter": "Pick points, double-click / Enter / right-click to finish. Backspace removes the last point.",
                 "m_area": "Pick the corners of the area; double-click / Enter to finish. Centroid is measured from the origin (Set Origin).",
                 "m_calibrate": "Pick two points of a known dimension, then type its real length.",
                 "m_origin": "Click the point that is X = 0, Y = 0 (e.g. AP / base line).",
                 "loupe": "Move over the drawing. Mouse wheel = loupe zoom, click = pin / unpin, +/- keys.",
                 "selecttext": "Drag over text to select it (Alt = rectangular). Ctrl+C copies.",
                 "edittext": "Edit Text: click a text element to change it (the original font is kept when possible).",
                 "snapshot": "Drag a rectangle - it is copied to the clipboard in very high quality (Ctrl+Shift+C = whole page)."}
        if name == "comment" and style:
            hints.update({"comment": {
                "inserttext": "Insert Text: click between two words (or after a selected word) and type the text to insert.",
                "replacetext": "Replace Text: drag over the words to replace, then type the new text.",
                "textcorrection": "Text Correction: click = insert, drag over words = replace (empty = delete).",
                "freehighlight": "Free Highlight: paint over the drawing like a marker pen.",
                "attach": "Attach File: click where the paperclip should go, then choose the file.",
                "sound": "Sound: click where the speaker icon should go, then record or choose a WAV file.",
                "area": "Highlight Area: drag a rectangle.",
            }.get(style.get("kind"), "")})
        if name in hints:
            self.status(hints[name], 12000)

    def set_editobj_mode(self, mode):
        self.editobj_mode = mode
        for a in self.editobj_group.actions():
            a.setChecked(a.text().lower().startswith({"all": "all", "text": "text", "image": "image", "shape": "shape"}[mode]))
        self.set_tool("editobj")

    def use_kind(self, kind):
        st = store()
        tid = self.kind_style.get(kind)
        t = st.find_tool(tid) if tid else None
        if t is None:
            t = st.tool_by_kind(kind)
        if t:
            self.use_template(t)

    def use_template(self, t):
        self.kind_style[t["kind"]] = t["id"]
        self.set_tool("comment", dict(t))
        self.status("Comment style: %s" % t["name"])

    def use_stamp(self, s):
        if s is None:
            s = getattr(self, "_last_stamp", None) or (store().stamps[0] if store().stamps else None)
        if not s:
            return
        self._last_stamp = s
        self.set_tool("stamp", None, s)
        self.stamp_btn_action.setChecked(False)
        self.status("Click on the page to place the stamp '%s'." % s["name"])

    def snap_modes(self):
        return {k: cb.isChecked() for k, cb in self.snap_checks.items()}

    def _snap_changed(self, *_):
        settings().set("snap", self.snap_modes())
        settings().save()

    def toggle_snap(self):
        self.snap_on = self.A["snap"].isChecked()
        self.status("OSnap %s" % ("ON" if self.snap_on else "OFF"))

    def toggle_ortho(self):
        self.ortho_on = self.A["ortho"].isChecked()
        self.status("Ortho %s" % ("ON" if self.ortho_on else "OFF"))

    def _unit_changed(self, u):
        settings().set("measure_unit", u)
        settings().save()
        d = self.doc()
        v = self.view()
        if d and v:
            pages = list(range(d.page_count))
            changed = False
            for i in pages:
                s = d.get_scale(i)
                if s and s.get("unit") != u:
                    s["unit"] = u
                    d.set_scale([i], s)
                    changed = True
            if changed:
                d.commit(None, annots=False, content=False)
            self.on_scale_changed()

    # ---------------------------------------------------------------- view
    def _zoom_combo(self, k):
        v = self.view()
        if not v:
            return
        txt = self.zoom_combo.currentText().strip().lower()
        if txt.startswith("fit w"):
            v.set_fit("width")
        elif txt.startswith("fit p"):
            v.set_fit("page")
        else:
            try:
                v.set_zoom_percent(float(txt.replace("%", "")))
            except ValueError:
                pass
        v.setFocus()

    def set_layout(self, key):
        v = self.view()
        if not v:
            return
        if key == "lay_grid":
            v.set_grid(self.grid_cols.value(), self.grid_rows.value())
        else:
            v.set_mode({"lay_single": "single", "lay_cont": "continuous", "lay_facing": "facing"}[key])
            if v.fit is None and v.mode != "grid":
                pass
            if key == "lay_single" and v.fit is None:
                v.set_fit("page")

    def _grid_changed(self, *_):
        v = self.view()
        settings().set("grid_cols", self.grid_cols.value())
        settings().set("grid_rows", self.grid_rows.value())
        if v:
            v.set_grid(self.grid_cols.value(), self.grid_rows.value())
            self.A["lay_grid"].setChecked(True)

    def _grid_preset(self, txt):
        if "×" not in txt:
            return
        c, r = [int(x) for x in txt.replace(" ", "").split("×")]
        self.grid_cols.blockSignals(True)
        self.grid_rows.blockSignals(True)
        self.grid_cols.setValue(c)
        self.grid_rows.setValue(r)
        self.grid_cols.blockSignals(False)
        self.grid_rows.blockSignals(False)
        self._grid_changed()

    def _loupe_zoom(self, z):
        settings().set("loupe_zoom", z)
        for v in self.all_views():
            v.loupe_zoom = z
            if v.loupe_active:
                v._loupe_timer.start(0)

    def _loupe_size(self, s):
        settings().set("loupe_size", s)
        for v in self.all_views():
            v.loupe_size = s
            if v.loupe_active:
                v._loupe_timer.start(0)

    def set_split(self, mode):
        t = self.doc_tab()
        if t:
            t.set_split(mode)
            if t.views:
                t.views[0].setFocus()

    def toggle_sync(self):
        t = self.doc_tab()
        if t:
            t.sync = self.A["sync"].isChecked()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.ribbon.show()
            self.nav_dock.show()
        else:
            self.showFullScreen()

    def show_panel(self, key):
        self.nav_dock.show()
        self.side.setCurrentWidget(self.panels[key])
        self.panels[key].refresh()

    def toggle_properties(self):
        self.prop_dock.setVisible(not self.prop_dock.isVisible())
        if self.prop_dock.isVisible() and self.view():
            self.prop_panel.show_selection(self.view())

    def focus_find(self):
        self.find_edit.setFocus()
        self.find_edit.selectAll()

    def do_find(self):
        q = self.find_edit.text().strip()
        if not q or not self.doc():
            return
        sp = self.panels["search"]
        if sp.q.text() == q and sp.hits:
            sp.step(1)
            return
        self.show_panel("search")
        sp.run(q)

    def open_guide(self):
        for name in ("Panduan_ALIEF_PDF_EDITOR_PRO.pdf", "Panduan_ALIEF_PDF_EDITOR_PRO.html"):
            p = resource_path("docs", name)
            if os.path.exists(p):
                if p.endswith(".pdf"):
                    self.open_files([p])
                else:
                    QDesktopServices.openUrl(QUrl.fromLocalFile(p))
                return
        QMessageBox.information(self, "User guide", "The user guide file was not found next to the program.")

    # ---------------------------------------------------- context menu
    def show_view_menu(self, v, pos, gpos):
        m = QMenu(self)
        hit = v.annot_at(QPointF(pos))
        if hit:
            i, a = hit
            v.set_selected((i, a["xref"]))
            m.addAction(theme.icon("playlist-edit"), "Properties…", lambda: self.edit_annot_properties(v))
            st = m.addMenu("Set status")
            for s in P.STATUSES:
                st.addAction(s, lambda s=s: self.set_annot_status([(i, a["xref"])], s))
            m.addAction(theme.icon("delete-outline"), "Delete comment", lambda: self.delete_selected_annot(v))
            m.addSeparator()
        if v.text_sel:
            m.addAction(theme.icon("content-copy"), "Copy\tCtrl+C", lambda: self.copy_text_selection(v))
            m.addAction(theme.icon("table"), "Copy as table (Excel cells / Word table)", lambda: self.copy_text_selection(v, "table"))
            m.addAction(theme.icon("text"), "Copy as plain text", lambda: self.copy_text_selection(v, "text"))
            for k, lab in (("highlight", "Highlight"), ("underline", "Underline"), ("strikeout", "Strikeout"), ("squiggly", "Squiggly")):
                m.addAction(theme.icon(KIND_ICON[k]), lab, lambda k=k: self.markup_selection(k))
            m.addSeparator()
        for k in ("tool_hand", "tool_select", "tool_selecttext", "tool_loupe"):
            m.addAction(self.A[k])
        m.addSeparator()
        for k in ("zoom_in", "zoom_out", "fit_width", "fit_page", "actual"):
            m.addAction(self.A[k])
        m.addSeparator()
        m.addAction(self.A["tool_snapshot"])
        m.addAction(self.A["rotate_view_cw"])
        m.exec(gpos)

    def markup_selection(self, kind):
        v = self.view()
        if not v or not v.text_sel:
            return
        st = store().tool_by_kind(kind) or {"kind": kind}
        t = T.MarkupTool(self, st)
        t.view = v
        t.apply_to_selection(v, kind)
        v.text_sel = None
        v.viewport().update()

    # ------------------------------------------------------- annotations
    def activate_annot(self, v, i, a):
        """Double-click on a comment: play sounds, open attachments, otherwise edit its properties."""
        t = a.get("type")
        if t == "Sound":
            self.play_sound(v.pdfdoc, a["xref"])
            return
        if t == "FileAttachment":
            self.open_attachment(v.pdfdoc, i, a["xref"])
            return
        v.set_selected((i, a["xref"]))
        self.edit_annot_properties(v)

    def play_sound(self, d, xref):
        from . import audio
        try:
            path = audio.temp_wav("alief_play_")
            AN.sound_to_wav(d.doc, xref, path)
            audio.play(path)
            self.status("Playing sound comment…", 4000)
        except Exception as e:
            QMessageBox.warning(self, "Sound", str(e))

    def open_attachment(self, d, i, xref, save=False):
        import tempfile
        try:
            annot = d.page(i).load_annot(xref)
            info = annot.file_info
            name = info.get("filename") or "attachment"
            data = annot.get_file()
        except Exception as e:
            QMessageBox.warning(self, "Attachment", str(e))
            return
        if not save:
            box = QMessageBox(self)
            box.setWindowTitle("Attachment")
            box.setText("<b>%s</b><br>%s KB<br>%s" % (name, max(1, len(data) // 1024), info.get("description") or ""))
            b_open = box.addButton("Open", QMessageBox.AcceptRole)
            b_save = box.addButton("Save As…", QMessageBox.ActionRole)
            box.addButton(QMessageBox.Cancel)
            box.exec()
            if box.clickedButton() is b_save:
                save = True
            elif box.clickedButton() is not b_open:
                return
        if save:
            out, _ = QFileDialog.getSaveFileName(self, "Save attachment", name)
            if out:
                with open(out, "wb") as f:
                    f.write(data)
                self.status("Saved " + out, 5000)
            return
        folder = tempfile.mkdtemp(prefix="alief_att_")
        path = os.path.join(folder, os.path.basename(name))
        with open(path, "wb") as f:
            f.write(data)
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def edit_annot_properties(self, v):
        self.prop_dock.show()
        self.prop_panel.show_selection(v)
        self.prop_panel.content.setFocus()

    def apply_annot_props(self, v, i, xref, props):
        d = v.pdfdoc
        d.checkpoint()
        try:
            AN.apply_properties(d.doc, d.page(i), xref, props)
        except Exception as e:
            QMessageBox.warning(self, "Properties", str(e))
        d.commit([i], content=False)
        v.set_selected((i, xref))

    def delete_selected_annot(self, v):
        if not v or not v.selected:
            return
        i, xref = v.selected
        self.delete_annots([(i, xref)])
        v.set_selected(None)

    def delete_annots(self, sel):
        d = self.doc()
        if not d or not sel:
            return
        d.checkpoint()
        pages = set()
        bypage = {}
        for i, xref in sel:
            bypage.setdefault(i, set()).add(xref)
        for i, xrefs in bypage.items():
            lst = d.annot_list(i)
            groups = {a.get("group") for a in lst if a["xref"] in xrefs and a.get("group")}
            for a in lst:
                if a.get("group") and a["group"] in groups:
                    xrefs.add(a["xref"])
            AN.delete_annots(d.doc, d.page(i), xrefs)
            pages.add(i)
        d.commit(sorted(pages), content=False)
        for v in self.all_views():
            if v.pdfdoc is d:
                v.set_selected(None)

    def set_annot_status(self, sel, status):
        d = self.doc()
        if not d:
            return
        d.checkpoint()
        pages = set()
        for i, xref in sel:
            d.doc.xref_set_key(xref, "AliefStatus", pymupdf.get_pdf_str(status) if status != "None" else "null")
            pages.add(i)
        d.commit(sorted(pages), content=False)

    def try_form_click(self, v, i, x, y):
        if i is None:
            return False
        d = v.pdfdoc
        try:
            page = d.page(i)
            for w in page.widgets():
                r = w.rect
                if not (r.x0 <= x <= r.x1 and r.y0 <= y <= r.y1):
                    continue
                ft = w.field_type
                if ft == pymupdf.PDF_WIDGET_TYPE_TEXT:
                    multi = bool(w.field_flags & 4096)
                    if multi:
                        txt, ok = QInputDialog.getMultiLineText(self, "Fill form", w.field_label or w.field_name or "Text", w.field_value or "")
                    else:
                        txt, ok = QInputDialog.getText(self, "Fill form", w.field_label or w.field_name or "Text", QLineEdit.Normal, w.field_value or "")
                    if not ok:
                        return True
                    d.checkpoint()
                    w.field_value = txt
                elif ft == pymupdf.PDF_WIDGET_TYPE_CHECKBOX:
                    d.checkpoint()
                    on = w.on_state() if hasattr(w, "on_state") else True
                    w.field_value = False if w.field_value not in (False, "Off", "", None) else on
                elif ft == pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON:
                    d.checkpoint()
                    w.field_value = w.on_state() if hasattr(w, "on_state") else True
                elif ft in (pymupdf.PDF_WIDGET_TYPE_COMBOBOX, pymupdf.PDF_WIDGET_TYPE_LISTBOX):
                    items = [c if isinstance(c, str) else c[1] for c in (w.choice_values or [])]
                    cur = items.index(w.field_value) if w.field_value in items else 0
                    val, ok = QInputDialog.getItem(self, "Fill form", w.field_name or "Choice", items, cur, True)
                    if not ok:
                        return True
                    d.checkpoint()
                    w.field_value = val
                elif ft == pymupdf.PDF_WIDGET_TYPE_BUTTON:
                    return True
                else:
                    return False
                w.update()
                d.commit([i], content=False)
                return True
        except Exception:
            return False
        return False

    # ------------------------------------------------------ comment cmds
    def manage_templates(self, tab=0):
        dlg = TemplateManager(self, tab if isinstance(tab, int) else 0)
        if dlg.exec():
            self.refresh_templates()

    def comments_summary(self, fmt):
        d = self.need_doc()
        if not d:
            return
        from . import reports
        base = os.path.splitext(d.path or d.title)[0]
        ext = "xlsx" if fmt == "xlsx" else "pdf"
        path, _ = QFileDialog.getSaveFileName(self, "Comment summary", base + "_comments." + ext,
                                              "Excel (*.xlsx)" if ext == "xlsx" else "PDF (*.pdf)")
        if not path:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            (reports.comments_xlsx if ext == "xlsx" else reports.comments_pdf)(d, path)
        finally:
            QApplication.restoreOverrideCursor()
        if ext == "pdf":
            self.open_files([path])
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def flatten_comments(self):
        d = self.need_doc()
        if not d:
            return
        if QMessageBox.question(self, "Flatten", "Make all comments and form fields a permanent part of the pages?\n"
                                "They can no longer be edited (Undo is available).") != QMessageBox.Yes:
            return
        d.checkpoint()
        if not PO.flatten(d.doc):
            QMessageBox.warning(self, "Flatten", "Flatten is not supported by this PDF engine version.")
        d.commit(None)

    # ---------------------------------------------------------- measure
    def scale_dialog(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        dlg = M.ScaleDialog(self, d, v.current_page())
        if dlg.exec() and dlg.result_scale:
            d.checkpoint()
            d.set_scale(dlg.result_pages, dlg.result_scale)
            d.commit(dlg.result_pages, annots=False, content=False)
            self.unit_combo.blockSignals(True)
            self.unit_combo.setCurrentText(dlg.result_scale["unit"])
            self.unit_combo.blockSignals(False)
            self.prec_spin.setValue(settings().get("measure_precision", 3))
            self.on_scale_changed()
            self.status("Scale %s applied to %d page(s)." % (dlg.result_scale["label"], len(dlg.result_pages)))
        elif dlg.calibrate_requested:
            self.set_tool("m_calibrate")

    def auto_scale(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        s, msg = M.detect_scale(d, v.current_page())
        if s:
            r = QMessageBox.question(self, "Auto scale", msg + "\n\nApply %s to all pages?" % s["label"],
                                     QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
            if r == QMessageBox.Cancel:
                return
            pages = list(range(d.page_count)) if r == QMessageBox.Yes else [v.current_page()]
            d.checkpoint()
            d.set_scale(pages, s)
            d.commit(pages, annots=False, content=False)
            self.on_scale_changed()
        else:
            box = QMessageBox(self)
            box.setWindowTitle("Auto scale")
            box.setText(msg)
            b1 = box.addButton("Enter ratio…", QMessageBox.AcceptRole)
            b2 = box.addButton("Calibrate…", QMessageBox.AcceptRole)
            box.addButton(QMessageBox.Close)
            box.exec()
            if box.clickedButton() == b1:
                self.scale_dialog()
            elif box.clickedButton() == b2:
                self.set_tool("m_calibrate")

    def export_measurements(self):
        self.show_panel("measure")
        self.panels["measure"].export()

    # ------------------------------------------------------------- pages
    def _sel_pages(self, pages):
        if pages:
            return pages
        th = self.panels["thumbs"]
        sel = th.selected() if th.isVisible() else []
        if not sel and self.view():
            sel = [self.view().current_page()]
        return sel

    def pages_rotate(self, pages, angle):
        d = self.need_doc()
        if not d:
            return
        pages = self._sel_pages(pages)
        d.checkpoint()
        PO.rotate_pages(d.doc, pages, angle)
        d.commit(structure=True)

    def pages_delete(self, pages):
        d = self.need_doc()
        if not d:
            return
        pages = self._sel_pages(pages)
        if len(pages) >= d.page_count:
            QMessageBox.warning(self, "Delete pages", "A document must keep at least one page.")
            return
        if QMessageBox.question(self, "Delete pages", "Delete %d page(s): %s ?" % (len(pages), ", ".join(str(p + 1) for p in pages[:20]))) != QMessageBox.Yes:
            return
        d.checkpoint()
        PO.delete_pages(d.doc, pages)
        d.commit(structure=True)

    def pages_extract(self, pages):
        d = self.need_doc()
        if not d:
            return
        pages = self._sel_pages(pages)
        txt, ok = QInputDialog.getText(self, "Extract pages", "Pages to extract:", QLineEdit.Normal,
                                       ",".join(str(p + 1) for p in pages))
        if not ok:
            return
        pages = parse_page_range(txt, d.page_count)
        if not pages:
            return
        base = os.path.splitext(d.path or d.title)[0]
        path, _ = QFileDialog.getSaveFileName(self, "Save extracted pages", "%s_p%s.pdf" % (base, txt.replace(",", "_").replace(" ", "")), "PDF (*.pdf)")
        if path:
            PO.extract_pages(d.doc, pages, path)
            if QMessageBox.question(self, "Extract pages", "Saved %s\n\nOpen it now?" % path) == QMessageBox.Yes:
                self.open_files([path])

    def pages_insert(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        dlg = D.InsertPagesDialog(self, d.page_count, v.current_page())
        if not dlg.exec():
            return
        at = dlg.position()
        d.checkpoint()
        try:
            if dlg.src.currentIndex() == 0:
                w, h = dlg.page_size()
                PO.insert_blank(d.doc, at, w, h, dlg.count.value())
            else:
                path = dlg.file.text()
                rng = None
                if dlg.frange.text().strip():
                    src = pymupdf.open(path)
                    rng = parse_page_range(dlg.frange.text(), src.page_count)
                    src.close()
                pw = None
                if pymupdf.open(path).needs_pass:
                    pw = D.ask_password(self, path)
                PO.insert_file(d.doc, at, path, rng, pw)
        except Exception as e:
            QMessageBox.warning(self, "Insert pages", str(e))
        d.commit(structure=True)
        v.go_to_page(min(at, d.page_count - 1))

    def pages_duplicate(self, pages):
        d = self.need_doc()
        if not d:
            return
        d.checkpoint()
        PO.duplicate_pages(d.doc, self._sel_pages(pages))
        d.commit(structure=True)

    def pages_reverse(self):
        d = self.need_doc()
        if not d:
            return
        d.checkpoint()
        PO.reverse_pages(d.doc)
        d.commit(structure=True)

    def pages_crop_content(self, pages):
        d = self.need_doc()
        if not d:
            return
        pages = self._sel_pages(pages)
        d.checkpoint()
        for i in pages:
            pg = d.page(i)
            bb = pymupdf.Rect()
            for b in pg.get_bboxlog():
                bb |= pymupdf.Rect(b[1])
            if bb.is_empty:
                continue
            bb = (bb + (-6, -6, 6, 6)) & pg.rect
            r = bb * pg.derotation_matrix
            r = pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))
            cb = pg.cropbox
            r = pymupdf.Rect(r.x0 + cb.x0, r.y0 + cb.y0, r.x1 + cb.x0, r.y1 + cb.y0) & pg.mediabox
            try:
                pg.set_cropbox(r)
            except Exception:
                pass
        d.commit(structure=True)

    def merge_files(self):
        files = [self.doc().path] if self.doc() and self.doc().path else []
        dlg = D.MergeDialog(self, files)
        if not dlg.exec() or not dlg.files():
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save combined PDF", os.path.join(settings().get("last_save_dir") or "", "Combined.pdf"), "PDF (*.pdf)")
        if not path:
            return
        res = D.run_with_progress(self, "Combining files…", lambda progress=None: PO.merge_files(dlg.files(), path, progress, dlg.bm.isChecked()))
        if res:
            self.open_files([path])

    def split_doc(self):
        d = self.need_doc()
        if not d:
            return
        dlg = D.SplitDialog(self, d)
        if not dlg.exec():
            return
        mode = ["every", "ranges", "bookmarks"][dlg.mode.currentIndex()]
        outs = PO.split(d.doc, dlg.out.text(), os.path.splitext(d.title)[0], mode, dlg.n.value(), dlg.ranges.text())
        QMessageBox.information(self, "Split", "%d file(s) written to\n%s" % (len(outs), dlg.out.text()))
        if outs:
            QDesktopServices.openUrl(QUrl.fromLocalFile(dlg.out.text()))

    def optimize(self):
        d = self.need_doc()
        if not d:
            return
        dlg = D.OptimizeDialog(self)
        if not dlg.exec():
            return
        base = os.path.splitext(d.path or d.title)[0]
        path, _ = QFileDialog.getSaveFileName(self, "Save optimized PDF", base + "_optimized.pdf", "PDF (*.pdf)")
        if not path:
            return
        copy = D.detached_copy(d)
        res = D.run_with_progress(self, "Optimizing…", PO.optimize, copy, path, dlg.dpi.value(), dlg.q.value(), dlg.fonts.isChecked(), dlg.meta.isChecked())
        copy.close()
        if res:
            before = os.path.getsize(d.path) if d.path and os.path.exists(d.path) else len(d.doc.tobytes())
            after = os.path.getsize(path)
            QMessageBox.information(self, "Optimize", "Saved %s\n\n%.2f MB  →  %.2f MB  (%.0f%%)" % (
                path, before / 1048576, after / 1048576, after * 100.0 / max(1, before)))

    # -------------------------------------------------------------- edit
    def watermark(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        from .watermark_ui import WatermarkDialog
        from . import watermark as WM
        dlg = WatermarkDialog(self, d, v.current_page())
        if not dlg.exec():
            return
        cfg, pages = dlg.config(), dlg.pages()
        d.checkpoint()
        prog = None
        if len(pages) > 25:
            prog = QProgressDialog("Applying watermark…", "Cancel", 0, len(pages), self)
            prog.setWindowModality(Qt.WindowModal)
            prog.setMinimumDuration(300)
        QApplication.setOverrideCursor(Qt.WaitCursor)

        def cb(i, n):
            if prog:
                prog.setValue(i)
                if prog.wasCanceled():
                    return False
            return True
        try:
            done = WM.apply(d.doc, pages, cfg, progress=cb)
        except Exception as e:
            done = 0
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Watermark", str(e))
        else:
            QApplication.restoreOverrideCursor()
        if prog:
            prog.close()
        try:
            names = [c.get("text") for c in d.doc.layer_ui_configs()]
            if done and WM.OCG_NAME not in names:
                d._reload_bytes(d._snapshot())      # MuPDF reads the layer list only when a file is opened
        except Exception:
            pass
        d.commit(pages)
        try:
            self.panels["layers"].refresh()
        except Exception:
            pass
        self.statusBar().showMessage("Watermark put on %d page(s)" % done, 6000)

    def watermark_remove(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        from .watermark_ui import RemoveWatermarkDialog
        from . import watermark as WM
        dlg = RemoveWatermarkDialog(self, d, v.current_page())
        if not dlg.exec():
            return
        other = dlg.incl_other.isChecked()
        hits = set(dlg.own) | (set(dlg.other) if other else set())
        pages = [p for p in dlg.pages_get() if p in hits]
        if not pages:
            return
        d.checkpoint()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            n = WM.remove(d.doc, pages, include_other=other)
        finally:
            QApplication.restoreOverrideCursor()
        d.commit(pages)
        self.statusBar().showMessage("Watermark removed from %d page(s)" % n, 6000)

    def _watermark_menu(self):
        m = QMenu(self)
        m.addAction(theme.icon("water-plus-outline"), "Add / Create Watermark…", self.watermark)
        m.addAction(theme.icon("water-remove-outline"), "Remove Watermarks…", self.watermark_remove)
        return m

    def header_footer(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        dlg = D.HeaderFooterDialog(self, d.page_count, v.current_page())
        if not dlg.exec():
            return
        pages = dlg.pages_get()
        d.checkpoint()
        PO.header_footer(d.doc, pages, {k: e.text() for k, e in dlg.slots.items()}, dlg.size.value(),
                         tuple(dlg.color.rgb or (0, 0, 0)), dlg.margin.value(), filename=d.title, start_number=dlg.start.value())
        d.commit(pages)

    # ----------------------------------------------------------- convert
    def convert(self, fmt):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        D.ConvertDialog(self, d, fmt, v.current_page()).exec()

    def images_to_pdf(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Images", settings().get("last_dir", ""),
                                                "Images (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.gif)")
        if not files:
            return
        size, ok = QInputDialog.getItem(self, "Images to PDF", "Page size:", ["Fit each image", "A4", "A3", "Letter"], 0, False)
        if not ok:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save PDF", os.path.join(os.path.dirname(files[0]), "Images.pdf"), "PDF (*.pdf)")
        if not path:
            return
        from . import convert as C
        res = D.run_with_progress(self, "Creating PDF…", C.images_to_pdf, files, path,
                                  page_size="fit" if size.startswith("Fit") else size, margin_mm=0 if size.startswith("Fit") else 10)
        if res:
            self.open_files([path])

    # ----------------------------------------------------------- protect
    def remove_security_current(self):
        d = self.need_doc()
        if not d:
            return
        si = d.security_info()
        if not si["encrypted"]:
            QMessageBox.information(self, "Remove security", "This document has no password or restrictions.")
            return
        msg = "Encryption: %s\nRestrictions: %s\n\nSave an unprotected copy of this document?" % (
            si["method"], ", ".join(n for n, ok in si["perms"] if not ok) or "none")
        if si["signed"]:
            msg += "\n\nNote: this file contains digital signature(s); they will no longer be valid in the unprotected copy."
        if QMessageBox.question(self, "Remove security", msg) != QMessageBox.Yes:
            return
        base = os.path.splitext(d.path or d.title)[0]
        path, _ = QFileDialog.getSaveFileName(self, "Save unprotected copy", base + "_unlocked.pdf", "PDF (*.pdf)")
        if not path:
            return
        try:
            d.save(path, encryption=pymupdf.PDF_ENCRYPT_NONE)
        except Exception as e:
            QMessageBox.warning(self, "Remove security", str(e))
            return
        self.tabs.setTabText(self.tabs.currentIndex(), d.title)
        self.status("Unprotected copy saved and opened: " + path)
        self.update_actions()

    def protect(self):
        d = self.need_doc()
        if not d:
            return
        dlg = D.ProtectDialog(self)
        if not dlg.exec():
            return
        user, owner, perms, method = dlg.values()
        base = os.path.splitext(d.path or d.title)[0]
        path, _ = QFileDialog.getSaveFileName(self, "Save protected PDF", base + "_protected.pdf", "PDF (*.pdf)")
        if not path:
            return
        from .security import protect
        copy = D.detached_copy(d)
        try:
            protect(copy, path, user, owner, perms, method)
        except Exception as e:
            QMessageBox.warning(self, "Protect", str(e))
            return
        finally:
            copy.close()
        QMessageBox.information(self, "Protect", "Protected copy saved:\n%s" % path)

    def apply_redactions(self):
        d = self.need_doc()
        if not d:
            return
        if QMessageBox.question(self, "Apply redactions", "Permanently remove all content under the areas marked for redaction?") != QMessageBox.Yes:
            return
        d.checkpoint()
        n = PO.apply_redactions(d.doc)
        d.commit(None)
        self.status("Redactions applied on %d page(s)." % n)

    def sanitize(self):
        d = self.need_doc()
        if not d:
            return
        d.checkpoint()
        PO.sanitize(d.doc)
        d.commit(None)
        self.status("Metadata, JavaScript and thumbnails removed.")

    def doc_properties(self, tab=0):
        d = self.need_doc()
        if not d:
            return
        dlg = D.DocPropertiesDialog(self, d)
        if isinstance(tab, int):
            dlg.findChild(QTabWidget).setCurrentIndex(tab)
        dlg.exec()
        self.update_actions()

    def preferences(self):
        if D.PreferencesDialog(self).exec():
            s = settings()
            for v in self.all_views():
                v.loupe_size = int(s.get("loupe_size", 260))
            self.loupe_size.setValue(int(s.get("loupe_size", 260)))

    # -------------------------------------------------------------- print
    def print_doc(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        from PySide6.QtPrintSupport import QPrinter, QPrintDialog
        printer = QPrinter(QPrinter.HighResolution)
        printer.setDocName(d.title)
        printer.setFromTo(1, d.page_count)
        dlg = QPrintDialog(printer, self)
        dlg.setOption(QPrintDialog.PrintPageRange, True)
        dlg.setOption(QPrintDialog.PrintCurrentPage, True)
        dlg.setMinMax(1, d.page_count)
        if not dlg.exec():
            return
        rng = dlg.printRange()
        if rng == QPrintDialog.PageRange:
            pages = list(range(printer.fromPage() - 1, printer.toPage()))
        elif rng == QPrintDialog.CurrentPage:
            pages = [v.current_page()]
        else:
            pages = list(range(d.page_count))
        n = self.print_pages(d, printer, pages)
        if n is None:
            QMessageBox.warning(self, "Print", "Cannot start the printer.")
            return
        self.status("Sent %d page(s) to the printer." % len(pages))

    def print_pages(self, d, printer, pages, show_progress=True):
        """Render pages to a QPrinter (fit to the printable area). Returns pages printed or None."""
        dpi = min(600, max(150, printer.resolution()))
        painter = QPainter()
        if not painter.begin(printer):
            return None
        prog = D.QProgressDialog("Printing…", "Cancel", 0, len(pages), self) if show_progress else None
        if prog:
            prog.setWindowModality(Qt.WindowModal)
        from .viewer import pix_to_qimage
        done = 0
        for k, i in enumerate(pages):
            if prog and prog.wasCanceled():
                break
            if prog:
                prog.setValue(k)
                QApplication.processEvents()
            if k:
                printer.newPage()
            pix = d.page(i).get_pixmap(dpi=dpi, alpha=False)
            img = pix_to_qimage(pix)
            area = painter.viewport()
            sz = img.size()
            sz.scale(area.size(), Qt.KeepAspectRatio)
            painter.save()
            painter.setViewport(area.x() + (area.width() - sz.width()) // 2, area.y() + (area.height() - sz.height()) // 2, sz.width(), sz.height())
            painter.setWindow(img.rect())
            painter.drawImage(0, 0, img)
            painter.restore()
            done += 1
        painter.end()
        if prog:
            prog.close()
        return done

    # ----------------------------------------------------------- rotation
    def rotate_view(self, delta):
        v = self.view()
        if not v:
            return
        v.rotate_view(-v.view_rot if delta is None else delta)
        self.status("View rotated to %d° (the document itself is not changed - use ORGANIZE ▸ Rotate Pages to save a rotation)." % v.view_rot
                    if v.view_rot else "View rotation reset.")

    def rotate_pages_dialog(self):
        d, v = self.need_doc(), self.view()
        if not d:
            return
        sel = self.panels["thumbs"].selected() if self.panels["thumbs"].isVisible() else [v.current_page()]
        dlg = D.RotatePagesDialog(self, d.page_count, v.current_page(), sel)
        if not dlg.exec():
            return
        angle, pages = dlg.values(d)
        if not pages:
            QMessageBox.information(self, "Rotate pages", "No pages match the selection.")
            return
        d.checkpoint()
        PO.rotate_pages(d.doc, pages, angle)
        d.commit(structure=True)
        self.status("Rotated %d page(s)%s." % (len(pages), " to upright" if angle == "upright" else " by %d°" % angle))

    # ----------------------------------------------------------- snapshot
    def _snapshot_data(self, v, i, rect=None, dpi=None, vector=None):
        """Render page i (or rect in view display points) -> (QImage, vector_pdf_bytes|None, dpi)."""
        import math
        from .viewer import pix_to_qimage
        d = v.pdfdoc
        dpi = int(dpi or settings().get("snapshot_dpi", 600))
        vector = bool(settings().get("snapshot_vector", True)) if vector is None else vector
        pw, ph = v.vsizes()[i]
        rect = pymupdf.Rect(rect) if rect is not None else pymupdf.Rect(0, 0, pw, ph)
        rect &= pymupdf.Rect(0, 0, pw, ph)
        z = dpi / 72.0
        max_px = float(settings().get("snapshot_max_mpx", 64)) * 1e6
        if rect.width * rect.height * z * z > max_px:
            z = math.sqrt(max_px / max(1.0, rect.width * rect.height))
        pix = d.render(i, v.render_matrix(i, z), clip=v.disp_rect_to_dl(i, rect))
        img = pix_to_qimage(pix)
        dpm = int(round(z * 72 / 0.0254))
        img.setDotsPerMeterX(dpm)
        img.setDotsPerMeterY(dpm)
        pdf = None
        if vector:
            try:
                tmp = pymupdf.open()
                tmp.insert_pdf(d.doc, from_page=i, to_page=i, annots=True, widgets=True)
                try:
                    tmp.bake(annots=True, widgets=True)
                except Exception:
                    pass
                tp = tmp[0]
                ur = rect * v.derot(i)
                ur = pymupdf.Rect(min(ur.x0, ur.x1), min(ur.y0, ur.y1), max(ur.x0, ur.x1), max(ur.y0, ur.y1))
                cb = tp.cropbox
                r = pymupdf.Rect(ur.x0 + cb.x0, ur.y0 + cb.y0, ur.x1 + cb.x0, ur.y1 + cb.y0) & tp.mediabox
                if not r.is_empty and abs(r.width * r.height - cb.width * cb.height) > 1:
                    tp.set_cropbox(r)
                tp.set_rotation(v.total_rot(i))
                pdf = tmp.tobytes(garbage=3, deflate=True)
                tmp.close()
            except Exception:
                pdf = None
        return img, pdf, int(round(z * 72))

    def _snapshot_to_clipboard(self, v, i, rect=None, what="Page"):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            img, pdf, dpi = self._snapshot_data(v, i, rect)
            QGuiApplication.clipboard().setMimeData(SnapshotMime(img, pdf))
        finally:
            QApplication.restoreOverrideCursor()
        self._snapshot_feedback(v, i, rect)
        self.status("%s %d copied: %d × %d px at %d dpi%s - paste into Word, Excel, PowerPoint, CAD, e-mail…" % (
            what, i + 1, img.width(), img.height(), dpi, " + vector (SVG/PDF)" if pdf else ""), 12000)

    def _snapshot_feedback(self, v, i, rect=None):
        """Camera shutter sound + a short white flash over the captured area."""
        if settings().get("snapshot_sound", True):
            try:
                from . import audio
                audio.play_shutter()
            except Exception:
                pass
        try:
            vr = v.page_view_rect(i)
            if rect is not None and vr is not None:
                s = v.page_scale(i)
                vr = QRectF(vr.left() + rect[0] * s, vr.top() + rect[1] * s, (rect[2] - rect[0]) * s, (rect[3] - rect[1]) * s)
            v.flash(vr)
        except Exception:
            pass

    def copy_text_selection(self, v, mode="auto"):
        """Copy selected text; tables go to the clipboard as TSV + HTML table (Excel cells / Word table)."""
        ts = v.text_sel if v else None
        if not ts:
            return
        from . import clipcopy
        i, rects, text = ts[0], ts[1], ts[2]
        sel = ts[3] if len(ts) > 3 else []
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            page = v.pdfdoc.page(i)
            if mode == "text":
                md, n = clipcopy.make_mime(page, sel, v.pdfdoc.words(i), text, "text")
            else:
                md, n = clipcopy.make_mime(page, sel, v.pdfdoc.words(i), text, "auto")
                if not n and mode == "table" and sel:
                    rows = [[(w[4], 1)] for w in sel]
                    md = clipcopy.QMimeData()
                    md.setText(text)
                    md.setHtml(clipcopy.to_html(rows))
        finally:
            QApplication.restoreOverrideCursor()
        QGuiApplication.clipboard().setMimeData(md)
        if n:
            cols = 0
            try:
                cols = max(len(r) for r in md.text().split("\r\n")[0:1] for r in [r.split("\t")])
            except Exception:
                pass
            self.status("Table copied: %d rows%s - paste into Excel (fills rows and columns) or Word (creates a table)."
                        % (n, " × %d columns" % cols if cols else ""), 8000)
        else:
            self.status("Text copied (%d characters)." % len(text), 4000)

    def snapshot_page(self):
        v = self.view()
        if not v:
            return
        self._snapshot_to_clipboard(v, v.current_page())

    def snapshot_view(self):
        v = self.view()
        if not v:
            return
        i = v.current_page()
        r = v.page_view_rect(i)
        if r is None:
            return
        vis = r.intersected(QRectF(v.viewport().rect()))
        s = v.page_scale(i)
        rect = pymupdf.Rect((vis.left() - r.left()) / s, (vis.top() - r.top()) / s, (vis.right() - r.left()) / s, (vis.bottom() - r.top()) / s)
        self._snapshot_to_clipboard(v, i, rect, "Visible part of page")

    def snapshot_save(self):
        v = self.view()
        if not v:
            return
        i = v.current_page()
        d = v.pdfdoc
        base = os.path.splitext(d.path or d.title)[0] + "_p%d" % (i + 1)
        path, flt = QFileDialog.getSaveFileName(self, "Save page snapshot", base + ".png",
                                                "PNG image (*.png);;JPEG image (*.jpg);;TIFF image (*.tif);;SVG vector (*.svg);;PDF vector (*.pdf)")
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            img, pdf, dpi = self._snapshot_data(v, i, vector=ext in (".svg", ".pdf"))
            if ext == ".svg" and pdf:
                open(path, "wb").write(SnapshotMime.svg_from_pdf(pdf))
            elif ext == ".pdf" and pdf:
                open(path, "wb").write(pdf)
            else:
                img.save(path, None, 95)
        finally:
            QApplication.restoreOverrideCursor()
        self.status("Snapshot saved: %s" % path)
