"""Create, move, resize and restyle PDF annotations; render stamp / balloon images."""
import datetime
import os
import json
import math

import pymupdf
from PySide6.QtCore import Qt, QRectF, QBuffer, QByteArray, QIODevice, QPointF
from PySide6.QtGui import QImage, QPainter, QColor, QPen, QFont, QFontMetricsF, QTransform, QPainterPath

DASHES = {"solid": None, "dash": [4, 3], "dot": [1, 2], "dashdot": [6, 2, 1, 2]}
LINE_ENDS = {"none": pymupdf.PDF_ANNOT_LE_NONE, "open": pymupdf.PDF_ANNOT_LE_OPEN_ARROW,
             "closed": pymupdf.PDF_ANNOT_LE_CLOSED_ARROW, "circle": pymupdf.PDF_ANNOT_LE_CIRCLE,
             "square": pymupdf.PDF_ANNOT_LE_SQUARE, "slash": pymupdf.PDF_ANNOT_LE_SLASH,
             "diamond": pymupdf.PDF_ANNOT_LE_DIAMOND, "butt": pymupdf.PDF_ANNOT_LE_BUTT}

FONT_MAP = {"Helvetica": "helv", "Times": "tiro", "Courier": "cour"}


def _rgb(c):
    if c is None:
        return None
    return tuple(float(v) for v in c[:3])


def finish(annot, style, author, subject=None, content=None):
    """Apply colours / border / opacity / info from a template style and regenerate."""
    t = annot.type[1]
    stroke = _rgb(style.get("stroke"))
    fill = _rgb(style.get("fill"))
    try:
        if t not in ("FreeText", "Stamp"):
            cols = {}
            if stroke is not None:
                cols["stroke"] = stroke
            if fill is not None and t in ("Square", "Circle", "Polygon", "Line", "PolyLine"):
                cols["fill"] = fill
            if cols:
                annot.set_colors(**cols)
        if t not in ("Text", "Stamp", "Highlight", "Underline", "StrikeOut", "Squiggly", "FreeText"):
            w = float(style.get("width", 1.0))
            dashes = DASHES.get(style.get("dash", "solid"))
            kw = {"width": w}
            if dashes:
                kw["dashes"] = dashes
            if style.get("cloud") and t in ("Square", "Circle", "Polygon"):
                kw["clouds"] = int(style.get("cloud", 1))
            annot.set_border(**kw)
        op = float(style.get("opacity", 1.0))
        if op < 0.999:
            annot.set_opacity(op)
    except Exception:
        pass
    info = {"title": author or ""}
    info["subject"] = subject if subject is not None else style.get("subject") or style.get("name", "")
    if content is not None:
        info["content"] = content
    try:
        annot.set_info(info)
    except Exception:
        pass
    try:
        annot.update()
    except Exception:
        pass
    return annot


DEFAULT_BLEND = {"area": "Multiply", "freehighlight": "Multiply"}


def create_shape(page, kind, style, author, rect=None, points=None, strokes=None, content=None):
    """Create a graphic annotation (unrotated coordinates)."""
    a = _create_shape(page, kind, style, author, rect, points, strokes, content)
    blend = style.get("blend") or DEFAULT_BLEND.get(style.get("kind") or kind)
    if a is not None and blend and blend != "Normal":
        set_ap_blend(page.parent, a.xref, blend)
    return a


def _create_shape(page, kind, style, author, rect=None, points=None, strokes=None, content=None):
    if kind == "cloud":
        return create_cloud(page, kind, style, author, rect=rect, content=content)
    if kind == "cloudpoly":
        return create_cloud(page, kind, style, author, points=points, content=content)
    if kind in ("rect", "area"):
        a = page.add_rect_annot(pymupdf.Rect(rect))
        return finish(a, dict(style), author, content=content)
    if kind == "ellipse":
        return finish(page.add_circle_annot(pymupdf.Rect(rect)), style, author, content=content)
    if kind in ("line", "arrow"):
        a = page.add_line_annot(pymupdf.Point(points[0]), pymupdf.Point(points[1]))
        le_s = LINE_ENDS.get(style.get("line_start", "none"), 0)
        le_e = LINE_ENDS.get(style.get("line_end", "open" if kind == "arrow" else "none"), 0)
        if le_s or le_e:
            a.set_line_ends(le_s, le_e)
        return finish(a, style, author, content=content)
    if kind == "polyline":
        a = page.add_polyline_annot([pymupdf.Point(p) for p in points])
        le_e = LINE_ENDS.get(style.get("line_end", "none"), 0)
        if le_e:
            a.set_line_ends(0, le_e)
        return finish(a, style, author, content=content)
    if kind in ("polygon", "cloudpoly"):
        pts = [pymupdf.Point(p) for p in points]
        if len(pts) > 2 and abs(pts[0].x - pts[-1].x) < 0.01 and abs(pts[0].y - pts[-1].y) < 0.01:
            pts = pts[:-1]
        a = page.add_polygon_annot(pts)
        st = dict(style)
        if kind == "cloudpoly":
            st["cloud"] = st.get("cloud") or 1
        return finish(a, st, author, content=content)
    if kind == "ink":
        a = page.add_ink_annot([[tuple(p) for p in s] for s in strokes])
        return finish(a, style, author, content=content)
    raise ValueError(kind)


def create_markup(page, kind, quads, style, author, content=None):
    fn = {"highlight": page.add_highlight_annot, "underline": page.add_underline_annot,
          "strikeout": page.add_strikeout_annot, "squiggly": page.add_squiggly_annot}[kind]
    a = fn(quads=quads)
    if style.get("stroke"):
        a.set_colors(stroke=_rgb(style["stroke"]))
    return finish(a, style, author, content=content)


def create_note(page, point, text, style, author):
    a = page.add_text_annot(pymupdf.Point(point), text or "", icon=style.get("icon", "Comment"))
    if style.get("stroke"):
        a.set_colors(stroke=_rgb(style["stroke"]))
    return finish(a, style, author, content=text)


def create_freetext(page, rect, text, style, author, callout=None, rotate=0):
    color = _rgb(style.get("text_color") or style.get("stroke") or (0, 0, 0))
    fill = _rgb(style.get("fill"))
    border = float(style.get("width", 1.0)) if style.get("border", True) else 0
    kw = dict(fontsize=float(style.get("fontsize", 10)), fontname=FONT_MAP.get(style.get("font", "Helvetica"), "helv"),
              text_color=color, border_width=border, rotate=rotate, align=int(style.get("align", 0)))
    if fill is not None:
        kw["fill_color"] = fill
    if callout:
        kw["callout"] = [pymupdf.Point(p) for p in callout]
        kw["line_end"] = LINE_ENDS.get(style.get("line_end", "open"), pymupdf.PDF_ANNOT_LE_OPEN_ARROW)
    op = float(style.get("opacity", 1.0))
    if op < 0.999:
        kw["opacity"] = op
    a = page.add_freetext_annot(pymupdf.Rect(rect), text, **kw)
    try:
        a.set_info({"title": author or "", "subject": style.get("subject") or style.get("name", ""), "content": text})
        a.update()
    except Exception:
        pass
    return a


def freetext_size(text, fontsize, font="Helvetica", min_w=60):
    """Rough box size (points) for a FreeText annotation holding text."""
    fn = FONT_MAP.get(font, "helv")
    lines = (text or " ").split("\n")
    w = max(pymupdf.get_text_length(ln or " ", fontname=fn, fontsize=fontsize) for ln in lines)
    return max(min_w, w * 1.1 + fontsize * 1.4), len(lines) * fontsize * 1.28 + fontsize * 1.0


def callout_knee(tip, rect):
    """Return the 3-point callout line: tip -> knee -> nearest point on the box edge."""
    x0, y0, x1, y1 = rect
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    tx, ty = tip
    if tx < x0:
        end = (x0, cy)
    elif tx > x1:
        end = (x1, cy)
    elif ty < y0:
        end = (cx, y0)
    else:
        end = (cx, y1)
    if end[0] in (x0, x1):
        knee = (end[0] - 12 if end[0] == x0 else end[0] + 12, end[1])
    else:
        knee = (end[0], end[1] - 12 if end[1] == y0 else end[1] + 12)
    return [tip, knee, end]


# --------------------------------------------------------------- images
def _qimage_png(img):
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.WriteOnly)
    img.save(buf, "PNG")
    buf.close()
    return bytes(ba)


def _qc(rgb, alpha=255):
    return QColor(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), alpha)


def stamp_values_default(st):
    return {"number": "", "date": datetime.date.today().strftime(st.get("date_format", "%d %b %Y")).upper(),
            "place": st.get("place", ""), "by": st.get("by", "")}


def render_stamp_image(st, values=None, dpi=400):
    """Render a stamp template to a QImage (transparent background)."""
    values = values or stamp_values_default(st)
    mm = dpi / 25.4
    W = float(st.get("width_mm", 62)) * mm
    col = _qc(st.get("color", (0.85, 0.1, 0.1)))
    pad = 2.6 * mm
    f_head = QFont("Segoe UI", 1)
    f_head.setPixelSize(int(2.6 * mm))
    f_head.setBold(True)
    f_title = QFont("Arial", 1)
    f_title.setBold(True)
    f_sub = QFont("Arial", 1)
    f_sub.setItalic(True)
    f_sub.setPixelSize(int(2.7 * mm))
    f_field = QFont("Segoe UI", 1)
    f_field.setPixelSize(int(2.75 * mm))
    f_small = QFont("Segoe UI", 1)
    f_small.setItalic(True)
    f_small.setPixelSize(int(2.1 * mm))
    title = st.get("title", "APPROVED")
    # fit title size into the width
    tsize = 7.2 * mm
    while tsize > 2.5 * mm:
        f_title.setPixelSize(int(tsize))
        if QFontMetricsF(f_title).horizontalAdvance(title) <= W - 2 * pad:
            break
        tsize -= 0.2 * mm
    rows = []
    if st.get("header"):
        rows.append(("head", st["header"], f_head, 4.2 * mm))
    rows.append(("title", title, f_title, tsize * 1.15))
    if st.get("subtitle"):
        rows.append(("sub", st["subtitle"], f_sub, 3.6 * mm))
    fields = st.get("fields", ["number", "date"])
    if "number" in fields:
        rows.append(("field", (st.get("number_label", "Number :"), values.get("number", ""), st.get("number_sublabel", "Nomor")), f_field, 6.0 * mm))
    if "by" in fields:
        rows.append(("field", (st.get("by_label", "By :"), values.get("by", ""), st.get("by_sublabel", "Oleh")), f_field, 6.0 * mm))
    if "date" in fields or "place" in fields:
        txt = ", ".join([v for v in ((values.get("place", "") if "place" in fields else ""), (values.get("date", "") if "date" in fields else "")) if v])
        rows.append(("date", txt, f_field, 4.8 * mm))
    H = pad * 2 + sum(r[3] for r in rows) + (1.5 * mm if st.get("header") else 0)
    style = st.get("style", "box")
    img = QImage(int(W) + 8, int(H) + 8, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.TextAntialiasing, True)
    box = QRectF(4, 4, W, H)
    if st.get("background", False):
        p.fillRect(box, QColor(255, 255, 255, 235)) if style not in ("rounded", "oval") else None
    pen = QPen(col, max(2.0, 0.55 * mm))
    p.setPen(pen)
    if style == "rounded":
        path = QPainterPath()
        path.addRoundedRect(box, 3 * mm, 3 * mm)
        if st.get("background", False):
            p.fillPath(path, QColor(255, 255, 255, 235))
        p.drawPath(path)
    elif style == "oval":
        path = QPainterPath()
        path.addEllipse(box)
        if st.get("background", False):
            p.fillPath(path, QColor(255, 255, 255, 235))
        p.drawPath(path)
    else:
        p.drawRect(box)
        if style == "double":
            p.setPen(QPen(col, max(1.0, 0.25 * mm)))
            p.drawRect(box.adjusted(0.9 * mm, 0.9 * mm, -0.9 * mm, -0.9 * mm))
            p.setPen(pen)
    y = 4 + pad
    for kind, txt, font, h in rows:
        p.setFont(font)
        r = QRectF(4 + pad, y, W - 2 * pad, h)
        if kind == "head":
            p.setPen(col)
            p.drawText(r, Qt.AlignHCenter | Qt.AlignVCenter, txt)
            y += h
            p.setPen(QPen(col, max(1.0, 0.25 * mm)))
            p.drawLine(QPointF(4 + pad * 0.5, y + 0.5 * mm), QPointF(4 + W - pad * 0.5, y + 0.5 * mm))
            y += 1.5 * mm
            continue
        p.setPen(col)
        if kind in ("title", "sub"):
            p.drawText(r, Qt.AlignHCenter | Qt.AlignVCenter, txt)
        elif kind == "field":
            lab, val, sub = txt
            p.drawText(QRectF(r.left(), r.top(), r.width(), h * 0.62), Qt.AlignLeft | Qt.AlignVCenter, lab)
            lw = QFontMetricsF(font).horizontalAdvance(lab + "  ")
            fb = QFont(font)
            fb.setBold(True)
            fb.setLetterSpacing(QFont.AbsoluteSpacing, 0.25 * mm)
            p.setFont(fb)
            p.drawText(QRectF(r.left() + lw, r.top(), r.width() - lw, h * 0.62), Qt.AlignLeft | Qt.AlignVCenter, val or "")
            p.setFont(f_small)
            p.drawText(QRectF(r.left(), r.top() + h * 0.55, r.width(), h * 0.42), Qt.AlignLeft | Qt.AlignVCenter, sub or "")
        elif kind == "date":
            fb = QFont(font)
            fb.setBold(True)
            p.setFont(fb)
            p.drawText(r, Qt.AlignHCenter | Qt.AlignVCenter, txt)
        y += h
    p.end()
    return img


def render_balloon_image(number, color=(0.85, 0.1, 0.1), shape="circle", dpi=400, size_mm=6.0, fill=None):
    mm = dpi / 25.4
    D = size_mm * mm
    txt = str(number)
    W = D if len(txt) <= 2 else D * (0.55 + 0.25 * len(txt))
    img = QImage(int(W) + 6, int(D) + 6, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing, True)
    c = _qc(color)
    r = QRectF(3, 3, W, D)
    p.setPen(QPen(c, max(2.0, 0.45 * mm)))
    p.setBrush(_qc(fill) if fill else QColor(255, 255, 255, 230))
    if shape == "square":
        p.drawRect(r)
    elif shape == "hexagon":
        path = QPainterPath()
        cx, cy = r.center().x(), r.center().y()
        rx, ry = r.width() / 2, r.height() / 2
        pts = [QPointF(cx + rx * math.cos(math.radians(a)), cy + ry * math.sin(math.radians(a))) for a in range(0, 360, 60)]
        path.moveTo(pts[0])
        for q in pts[1:]:
            path.lineTo(q)
        path.closeSubpath()
        p.drawPath(path)
    elif len(txt) <= 2:
        p.drawEllipse(r)
    else:
        p.drawRoundedRect(r, D / 2, D / 2)
    f = QFont("Arial", 1)
    f.setBold(True)
    f.setPixelSize(int(D * (0.62 if len(txt) == 1 else 0.52)))
    p.setFont(f)
    p.setPen(c)
    p.drawText(r, Qt.AlignCenter, txt)
    p.end()
    return img


def insert_image_stamp(page, rect, qimg, author, subject, content="", opacity=1.0, rot=None, blend="Multiply"):
    """Image stamp. blend='Multiply' mixes the stamp like ink: the document underneath stays readable."""
    rot = page.rotation if rot is None else rot
    if rot:
        qimg = qimg.transformed(QTransform().rotate(-rot), Qt.SmoothTransformation)
    a = page.add_stamp_annot(pymupdf.Rect(rect), stamp=_qimage_png(qimg))
    try:
        if opacity < 0.999:
            a.set_opacity(opacity)
        if blend and blend != "Normal":
            a.set_blendmode(blend)
        a.set_info({"title": author or "", "subject": subject or "", "content": content or ""})
        a.update()
    except Exception:
        pass
    return a


def set_ap_blend(doc, xref, mode):
    """Blend mode written into the annotation's own appearance stream (no regeneration, so
    stamps from any program keep their look). 'Multiply' keeps the drawing underneath readable."""
    mode = mode or "Normal"
    try:
        t, v = doc.xref_get_key(xref, "AP/N")
        if t != "xref":
            return False
        apx = int(v.split()[0])
        data = doc.xref_stream(apx) or b""
        marker = b"q /ABM gs\n"
        if data.startswith(marker):
            body = data[len(marker):]
            if body.endswith(b"\nQ"):
                body = body[:-2]
        else:
            body = data
        if mode == "Normal":
            doc.update_stream(apx, body)
        else:
            doc.update_stream(apx, marker + body + b"\nQ")
            rt, rv = doc.xref_get_key(apx, "Resources")
            if rt == "xref":
                rx = int(rv.split()[0])
                target, prefix = rx, ""
            else:
                if rt != "dict":
                    doc.xref_set_key(apx, "Resources", "<<>>")
                target, prefix = apx, "Resources/"
            et, ev = doc.xref_get_key(target, prefix + "ExtGState")
            if et == "xref":
                target, prefix = int(ev.split()[0]), ""
                doc.xref_set_key(target, "ABM", "<</Type/ExtGState/BM/%s>>" % mode)
            else:
                if et != "dict":
                    doc.xref_set_key(target, prefix + "ExtGState", "<<>>")
                doc.xref_set_key(target, prefix + "ExtGState/ABM", "<</Type/ExtGState/BM/%s>>" % mode)
        doc.xref_set_key(xref, "BM", "null" if mode == "Normal" else "/" + mode)
        return True
    except Exception:
        return False


# ------------------------------------------------------------ page-size scaling
def page_scale_factor(page):
    """1.0 for A4 / Letter and smaller, 2.0 for A2, 4.0 for A0 ... (longest side / A4 height)."""
    r = page.rect
    return max(1.0, max(r.width, r.height) / 842.0)


# ----------------------------------------------------------------- clouds
CLOUD_SWEEP = math.radians(150.0)


def _cloud_geometry(pts, arc):
    """pts: polygon in PDF space (y up). Returns (start, [bezier (c1, c2, p) ...], bbox)."""
    n = len(pts)
    area = 0.0
    for k in range(n):
        x0, y0 = pts[k]
        x1, y1 = pts[(k + 1) % n]
        area += x0 * y1 - x1 * y0
    sign = 1.0 if area >= 0 else -1.0           # CCW in y-up space -> outward normal on the right side
    th = CLOUD_SWEEP
    beziers = []
    xs, ys = [], []
    for k in range(n):
        ax, ay = pts[k]
        bx, by = pts[(k + 1) % n]
        L = math.hypot(bx - ax, by - ay)
        if L < 1e-6:
            continue
        m = max(1, int(round(L / max(arc, 0.5))))
        dx, dy = (bx - ax) / L, (by - ay) / L
        nx, ny = dy * sign, -dx * sign
        c = L / m
        r = c / (2 * math.sin(th / 2))
        h = r * math.cos(th / 2)
        for j in range(m):
            px, py = ax + dx * c * j, ay + dy * c * j
            qx, qy = ax + dx * c * (j + 1), ay + dy * c * (j + 1)
            mx, my = (px + qx) / 2, (py + qy) / 2
            cx, cy = mx - nx * h, my - ny * h
            a0 = math.atan2(py - cy, px - cx)
            a1 = math.atan2(qy - cy, qx - cx)
            delta = a1 - a0
            while delta <= -math.pi:
                delta += 2 * math.pi
            while delta > math.pi:
                delta -= 2 * math.pi
            for part in range(2):
                s0 = a0 + delta * part / 2
                s1 = a0 + delta * (part + 1) / 2
                kk = 4.0 / 3.0 * math.tan((s1 - s0) / 4)
                p0 = (cx + r * math.cos(s0), cy + r * math.sin(s0))
                p3 = (cx + r * math.cos(s1), cy + r * math.sin(s1))
                c1 = (p0[0] - kk * r * math.sin(s0), p0[1] + kk * r * math.cos(s0))
                c2 = (p3[0] + kk * r * math.sin(s1), p3[1] - kk * r * math.cos(s1))
                beziers.append((c1, c2, p3))
                xs += [c1[0], c2[0], p3[0]]
                ys += [c1[1], c2[1], p3[1]]
    start = beziers[-1][2] if beziers else pts[0]
    if not xs:
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
    return start, beziers, (min(xs), min(ys), max(xs), max(ys))


def cloud_info(doc, xref):
    try:
        t, v = doc.xref_get_key(xref, "AliefCloud")
        if t == "string" and v:
            return json.loads(v)
    except Exception:
        pass
    return None


def apply_cloud_ap(doc, page, xref):
    """Write our own cloud appearance (arc size proportional to the sheet) for a Polygon cloud."""
    info = cloud_info(doc, xref)
    if not info:
        return False
    annot = page.load_annot(xref)
    if annot is None or annot.type[1] != "Polygon":
        return False
    verts = annot.vertices or []
    if len(verts) < 3:
        return False
    M = ~page.transformation_matrix
    pts = [tuple(pymupdf.Point(p) * M) for p in verts]
    cols = annot.colors or {}
    stroke = cols.get("stroke") or (0.85, 0.08, 0.08)
    fill = cols.get("fill") or None
    b = annot.border or {}
    w = b.get("width", 1.5)
    w = 1.5 if w is None or w < 0 else w
    op = annot.opacity
    op = 1.0 if op is None or op < 0 or op > 1 else op
    arc = float(info.get("arc", 10.0))
    start, bez, bb = _cloud_geometry(pts, arc)
    pad = w / 2 + 0.5
    bbox = (bb[0] - pad, bb[1] - pad, bb[2] + pad, bb[3] + pad)
    ops = ["q"]
    res = "<<>>"
    if op < 0.999:
        ops.append("/AGS gs")
        res = "<</ExtGState<</AGS<</Type/ExtGState/CA %.3f/ca %.3f>>>>>>" % (op, op)
    ops.append("%.4f %.4f %.4f RG" % tuple(stroke[:3]))
    if fill:
        ops.append("%.4f %.4f %.4f rg" % tuple(fill[:3]))
    ops.append("%.3f w 1 J 1 j" % w)
    ops.append("%.3f %.3f m" % start)
    for c1, c2, p3 in bez:
        ops.append("%.3f %.3f %.3f %.3f %.3f %.3f c" % (c1[0], c1[1], c2[0], c2[1], p3[0], p3[1]))
    ops.append("h B" if fill else "h S")
    ops.append("Q")
    stream = ("\n".join(ops)).encode()
    t, v = doc.xref_get_key(xref, "AP/N")
    if t != "xref":
        annot.update()
        t, v = doc.xref_get_key(xref, "AP/N")
        if t != "xref":
            return False
    apx = int(v.split()[0])
    doc.update_stream(apx, stream)
    doc.xref_set_key(apx, "BBox", "[%.3f %.3f %.3f %.3f]" % bbox)
    doc.xref_set_key(apx, "Matrix", "[1 0 0 1 0 0]")
    doc.xref_set_key(apx, "Resources", res)
    doc.xref_set_key(xref, "Rect", "[%.3f %.3f %.3f %.3f]" % bbox)
    doc.xref_set_key(xref, "RD", "null")
    bt, bv = doc.xref_get_key(xref, "BM")
    if bt == "name" and bv.lstrip("/") not in ("Normal", ""):
        set_ap_blend(doc, xref, bv.lstrip("/"))
    return True


def cloud_arc_for(page, style):
    mm = float(style.get("cloud_arc_mm", 0) or 0)
    if mm > 0:
        return mm * 72.0 / 25.4
    inten = int(style.get("cloud", 1) or 1)
    return 10.0 * page_scale_factor(page) * (1.0 if inten <= 1 else 1.6)


def create_cloud(page, kind, style, author, rect=None, points=None, content=None):
    """Revision cloud whose scallops and line width grow with the sheet size (A4 -> A0)."""
    doc = page.parent
    k = page_scale_factor(page)
    st = dict(style)
    if st.get("scale_with_page", True):
        st["width"] = float(st.get("width", 1.5)) * (k ** 0.75)
    st["cloud"] = int(st.get("cloud") or 1)
    if rect is not None:
        r = pymupdf.Rect(rect)
        pts = [r.tl, r.tr, r.br, r.bl]
    else:
        pts = [pymupdf.Point(p) for p in points]
        if len(pts) > 2 and abs(pts[0].x - pts[-1].x) < 0.01 and abs(pts[0].y - pts[-1].y) < 0.01:
            pts = pts[:-1]
    a = page.add_polygon_annot(pts)
    finish(a, st, author, content=content)
    xref = a.xref
    info = {"arc": round(cloud_arc_for(page, st), 3), "base": round(10.0 * k, 3), "rect": rect is not None}
    doc.xref_set_key(xref, "AliefCloud", pymupdf.get_pdf_str(json.dumps(info)))
    apply_cloud_ap(doc, page, xref)
    return page.load_annot(xref)


# ------------------------------------------------------- attachments / sound
def create_file_attachment(page, point, path, author, content="", icon="Paperclip", color=(0.1, 0.35, 0.8)):
    with open(path, "rb") as f:
        data = f.read()
    name = os.path.basename(path)
    a = page.add_file_annot(pymupdf.Point(point), data, name, ufilename=name, desc=content or name, icon=icon)
    try:
        a.set_colors(stroke=color)
        a.set_info({"title": author or "", "subject": "Attachment: " + name, "content": content or name})
        a.update()
    except Exception:
        pass
    return a


def wav_info(path):
    import wave
    with wave.open(path, "rb") as w:
        return w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()


def create_sound(page, point, wav_path, author, content="", color=(0.1, 0.35, 0.8)):
    """PDF Sound annotation from a WAV file (PCM 8 / 16 bit)."""
    import wave
    import numpy as np
    doc = page.parent
    with wave.open(wav_path, "rb") as w:
        ch, sw, rate, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        frames = w.readframes(n)
    if sw == 2:
        data = np.frombuffer(frames, "<i2").astype(">i2").tobytes()   # PDF sound samples are big-endian
        enc, bits = "/Signed", 16
    elif sw == 1:
        data, enc, bits = frames, "/Raw", 8
    else:
        raise ValueError("Only 8-bit or 16-bit PCM WAV files are supported")
    sx = doc.get_new_xref()
    doc.update_object(sx, "<</Type/Sound/R %d/C %d/B %d/E%s>>" % (rate, ch, bits, enc))
    doc.update_stream(sx, data)
    x, y = point
    size = 20.0 * min(2.0, page_scale_factor(page))
    M = ~page.transformation_matrix
    r = pymupdf.Rect(x, y, x + size, y + size) * M
    r = pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))
    secs = n / float(rate or 1)
    text = content or ("Sound %.1f s" % secs)
    mu = pymupdf.mupdf
    ppage = mu.pdf_page_from_fz_page(page.this)
    pa = mu.pdf_create_annot(ppage, mu.PDF_ANNOT_SOUND)
    ax = mu.pdf_to_num(mu.pdf_annot_obj(pa))
    for key, val in (("Rect", "[%.3f %.3f %.3f %.3f]" % (r.x0, r.y0, r.x1, r.y1)), ("Sound", "%d 0 R" % sx),
                     ("Name", "/Speaker"), ("Contents", pymupdf.get_pdf_str(text)),
                     ("T", pymupdf.get_pdf_str(author or "")), ("Subj", pymupdf.get_pdf_str("Sound")),
                     ("C", "[%.3f %.3f %.3f]" % tuple(color[:3])), ("F", "4"),
                     ("M", pymupdf.get_pdf_str(pymupdf.get_pdf_now()))):
        doc.xref_set_key(ax, key, val)
    a = page.load_annot(ax)
    try:
        a.update()
    except Exception:
        pass
    return page, ax


def sound_to_wav(doc, annot_xref, out_path):
    import wave
    import numpy as np
    t, v = doc.xref_get_key(annot_xref, "Sound")
    if t != "xref":
        raise ValueError("No sound data")
    sx = int(v.split()[0])
    data = doc.xref_stream(sx)
    def num(key, default):
        tt, vv = doc.xref_get_key(sx, key)
        try:
            return int(float(vv))
        except Exception:
            return default
    rate, ch, bits = num("R", 22050), num("C", 1), num("B", 8)
    enc = doc.xref_get_key(sx, "E")[1]
    with wave.open(out_path, "wb") as w:
        w.setnchannels(ch)
        w.setframerate(rate)
        if bits == 16:
            w.setsampwidth(2)
            arr = np.frombuffer(data[: len(data) // 2 * 2], ">i2").astype("<i2")
            w.writeframes(arr.tobytes())
        else:
            w.setsampwidth(1)
            if "Signed" in (enc or ""):
                data = (np.frombuffer(data, np.int8).astype(np.int16) + 128).astype(np.uint8).tobytes()
            w.writeframes(data)
    return out_path


def apply_caret_ap(doc, page, xref):
    """Caret (^) drawn at the size of the text line it marks, upright in the reader's view."""
    t, v = doc.xref_get_key(xref, "AliefCaret")
    if t != "string":
        return False
    info = json.loads(v)
    lh = float(info.get("lh", 10.0))
    tx, ty = info["tip"]
    R = pymupdf.Matrix(-int(info.get("rot", 0)))
    M = ~page.transformation_matrix
    w = 0.38 * lh
    loc = [(0, -0.05 * lh), (-0.12 * w, 0.18 * lh), (-0.55 * w, 0.42 * lh), (-w, 0.55 * lh), (0, 0.40 * lh),
           (w, 0.55 * lh), (0.55 * w, 0.42 * lh), (0.12 * w, 0.18 * lh)]
    pts = []
    for lx, ly in loc:
        q = pymupdf.Point(lx, ly) * R
        pts.append(pymupdf.Point(tx + q.x, ty + q.y) * M)
    cols = info.get("color") or [0.1, 0.35, 0.8]
    p0, c1, c2, b1, mid, b2, c3, c4 = pts
    ops = ["q", "%.4f %.4f %.4f rg" % tuple(cols[:3]),
           "%.3f %.3f m" % (p0.x, p0.y),
           "%.3f %.3f %.3f %.3f %.3f %.3f c" % (c1.x, c1.y, c2.x, c2.y, b1.x, b1.y),
           "%.3f %.3f %.3f %.3f %.3f %.3f c" % ((b1.x + mid.x) / 2, (b1.y + mid.y) / 2, mid.x, mid.y, mid.x, mid.y),
           "%.3f %.3f %.3f %.3f %.3f %.3f c" % (mid.x, mid.y, (b2.x + mid.x) / 2, (b2.y + mid.y) / 2, b2.x, b2.y),
           "%.3f %.3f %.3f %.3f %.3f %.3f c" % (c3.x, c3.y, c4.x, c4.y, p0.x, p0.y),
           "f", "Q"]
    xs = [q.x for q in pts]
    ys = [q.y for q in pts]
    pad = 0.5
    bbox = (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)
    t, v = doc.xref_get_key(xref, "AP/N")
    if t != "xref":
        return False
    apx = int(v.split()[0])
    doc.update_stream(apx, "\n".join(ops).encode())
    doc.xref_set_key(apx, "BBox", "[%.3f %.3f %.3f %.3f]" % bbox)
    doc.xref_set_key(apx, "Matrix", "[1 0 0 1 0 0]")
    doc.xref_set_key(apx, "Resources", "<<>>")
    doc.xref_set_key(xref, "Rect", "[%.3f %.3f %.3f %.3f]" % bbox)
    doc.xref_set_key(xref, "RD", "null")
    return True


def create_caret(page, tip, line_h, text, author, subject="Inserted Text", color=(0.1, 0.35, 0.8), rot=0):
    """Caret with its point at tip (unrotated coords) sized to the text line height."""
    doc = page.parent
    a = page.add_caret_annot(pymupdf.Point(tip))
    try:
        a.set_colors(stroke=color)
        a.set_info({"title": author or "", "subject": subject, "content": text or ""})
        a.update()
    except Exception:
        pass
    info = {"lh": round(float(line_h), 3), "tip": [round(tip[0], 3), round(tip[1], 3)], "rot": int(rot) % 360,
            "color": [float(c) for c in color[:3]]}
    doc.xref_set_key(a.xref, "AliefCaret", pymupdf.get_pdf_str(json.dumps(info)))
    apply_caret_ap(doc, page, a.xref)
    return page.load_annot(a.xref)


def image_rect_at(page, center_unrot, qimg, width_pt, rot=None):
    """Unrotated rect of an image stamp centred at a point, keeping image aspect as seen on screen."""
    rot = page.rotation if rot is None else rot
    w = width_pt
    h = width_pt * qimg.height() / max(1, qimg.width())
    if rot in (90, 270):
        w, h = h, w
    cx, cy = center_unrot
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


# ---------------------------------------------------------- modifications
def _vstr(page, pts):
    M = ~page.transformation_matrix
    out = []
    for q in pts:
        v = pymupdf.Point(q) * M
        out.append("%.4f %.4f" % (v.x, v.y))
    return "[" + " ".join(out) + "]"


def set_vertices(doc, page, xref, pts):
    """Replace the geometry of a Line / Polygon / PolyLine / Ink annotation."""
    annot = page.load_annot(xref)
    t = annot.type[1]
    if t == "Line":
        doc.xref_set_key(xref, "L", _vstr(page, pts[:2]))
    elif t in ("Polygon", "PolyLine"):
        doc.xref_set_key(xref, "Vertices", _vstr(page, pts))
    elif t == "Ink":
        doc.xref_set_key(xref, "InkList", "[" + " ".join(_vstr(page, s) for s in pts) + "]")
    try:
        page = doc.reload_page(page)
    except Exception:
        pass
    a = page.load_annot(xref)
    a.update()
    apply_cloud_ap(doc, page, xref)
    return page


def set_rect_exact(annot, target):
    """set_rect without the growth MuPDF adds for cloud margins (/RD) and border widths."""
    target = pymupdf.Rect(target)
    annot.set_rect(target)
    try:
        annot.update()
    except Exception:
        pass
    r = annot.rect
    d = (r.x0 - target.x0, r.y0 - target.y0, r.x1 - target.x1, r.y1 - target.y1)
    if max(abs(v) for v in d) > 0.01:
        annot.set_rect(pymupdf.Rect(target.x0 - d[0], target.y0 - d[1], target.x1 - d[2], target.y1 - d[3]))
        try:
            annot.update()
        except Exception:
            pass


def move_annot(doc, page, a, dx, dy):
    """Translate annotation dict a (from PdfDoc.annot_list) by dx, dy (unrotated pts)."""
    t = a["type"]
    xref = a["xref"]
    if t in ("Line", "Polygon", "PolyLine") and a.get("vertices"):
        return set_vertices(doc, page, xref, [(x + dx, y + dy) for x, y in a["vertices"]])
    if t == "Ink" and a.get("vertices"):
        return set_vertices(doc, page, xref, [[(x + dx, y + dy) for x, y in s] for s in a["vertices"]])
    if t in ("Highlight", "Underline", "StrikeOut", "Squiggly"):
        return page
    if t == "Caret":
        tt, vv = doc.xref_get_key(xref, "AliefCaret")
        if tt == "string":
            info = json.loads(vv)
            info["tip"] = [info["tip"][0] + dx, info["tip"][1] + dy]
            doc.xref_set_key(xref, "AliefCaret", pymupdf.get_pdf_str(json.dumps(info)))
            apply_caret_ap(doc, page, xref)
            return page
    annot = page.load_annot(xref)
    if t == "FreeText":
        _move_callout(doc, page, annot, dx, dy)
        annot = page.load_annot(xref)
    x0, y0, x1, y1 = a["rect"]
    set_rect_exact(annot, (x0 + dx, y0 + dy, x1 + dx, y1 + dy))
    return page


def _move_callout(doc, page, annot, dx, dy):
    """FreeText callout lines (/CL) are stored separately: shift all but the arrow tip."""
    try:
        t, v = doc.xref_get_key(annot.xref, "CL")
        if t != "array":
            return
        nums = [float(x) for x in v.strip("[]").split()]
        M = page.transformation_matrix
        pts = [pymupdf.Point(nums[k], nums[k + 1]) * M for k in range(0, len(nums), 2)]
        new = [pts[0]] + [pymupdf.Point(q.x + dx, q.y + dy) for q in pts[1:]]
        doc.xref_set_key(annot.xref, "CL", _vstr(page, new))
    except Exception:
        pass


def resize_annot(doc, page, a, handle, new_pt, orig_rect=None):
    """Move a handle ('tl','br','v3', ...) of annotation a to new_pt (unrotated)."""
    t = a["type"]
    xref = a["xref"]
    if a.get("cloud") and a["cloud"].get("rect") and a.get("vertices") and not handle.startswith("v"):
        vs = a["vertices"]
        x0, y0 = min(p[0] for p in vs), min(p[1] for p in vs)
        x1, y1 = max(p[0] for p in vs), max(p[1] for p in vs)
        nx, ny = new_pt
        if "l" in handle:
            x0 = nx
        if "r" in handle:
            x1 = nx
        if "t" in handle:
            y0 = ny
        if "b" in handle:
            y1 = ny
        r = pymupdf.Rect(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))
        if r.width < 3 or r.height < 3:
            return page
        return set_vertices(doc, page, xref, [tuple(r.tl), tuple(r.tr), tuple(r.br), tuple(r.bl)])
    if handle.startswith("v") and a.get("vertices"):
        k = int(handle[1:])
        v = list(a["vertices"])
        v[k] = tuple(new_pt)
        return set_vertices(doc, page, xref, v)
    x0, y0, x1, y1 = orig_rect or a["rect"]
    nx, ny = new_pt
    if "l" in handle:
        x0 = nx
    if "r" in handle:
        x1 = nx
    if "t" in handle:
        y0 = ny
    if "b" in handle:
        y1 = ny
    r = pymupdf.Rect(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))
    if r.width < 3 or r.height < 3:
        return page
    if t == "Ink" and a.get("vertices"):
        ox0, oy0, ox1, oy1 = a["rect"]
        sx = r.width / max(1e-6, ox1 - ox0)
        sy = r.height / max(1e-6, oy1 - oy0)
        strokes = [[(r.x0 + (x - ox0) * sx, r.y0 + (y - oy0) * sy) for x, y in s] for s in a["vertices"]]
        return set_vertices(doc, page, xref, strokes)
    annot = page.load_annot(xref)
    set_rect_exact(annot, r)
    return page


def apply_properties(doc, page, xref, props):
    """props: dict of content, author, subject, stroke, fill, width, dash, opacity, fontsize, status, cloud."""
    annot = page.load_annot(xref)
    t = annot.type[1]
    info = {}
    for k_src, k_dst in (("content", "content"), ("author", "title"), ("subject", "subject")):
        if k_src in props:
            info[k_dst] = props[k_src]
    if info:
        annot.set_info(info)
    if t == "FreeText":
        kw = {}
        if "fontsize" in props:
            kw["fontsize"] = float(props["fontsize"])
        if props.get("stroke") is not None:
            kw["text_color"] = _rgb(props["stroke"])
        if "fill" in props:
            kw["fill_color"] = _rgb(props["fill"]) if props["fill"] is not None else None
        if "width" in props:
            kw["border_width"] = float(props["width"])
        if "opacity" in props:
            annot.set_opacity(float(props["opacity"]))
        try:
            annot.update(**{k: v for k, v in kw.items() if v is not None or k == "fill_color"})
        except Exception:
            annot.update()
    else:
        cols = {}
        if props.get("stroke") is not None:
            cols["stroke"] = _rgb(props["stroke"])
        if "fill" in props and t in ("Square", "Circle", "Polygon", "Line", "PolyLine"):
            cols["fill"] = _rgb(props["fill"]) if props["fill"] is not None else []
        if cols:
            try:
                annot.set_colors(**cols)
            except Exception:
                pass
        if any(k in props for k in ("width", "dash", "cloud")) and t not in ("Text", "Stamp", "Highlight", "Underline", "StrikeOut", "Squiggly"):
            b = annot.border or {}
            kw = {"width": float(props.get("width", b.get("width", 1)))}
            dash = props.get("dash")
            if dash and DASHES.get(dash):
                kw["dashes"] = DASHES[dash]
            elif dash == "solid":
                kw["dashes"] = []
            if t in ("Square", "Circle", "Polygon"):
                kw["clouds"] = int(props.get("cloud", b.get("clouds", 0) or 0))
            try:
                annot.set_border(**kw)
            except Exception:
                pass
        if "opacity" in props:
            annot.set_opacity(float(props["opacity"]))
        try:
            annot.update()
        except Exception:
            pass
    if "blend" in props:
        set_ap_blend(doc, xref, props["blend"])
    info = cloud_info(doc, xref)
    if info is not None:
        if "cloud" in props and int(props["cloud"] or 0) == 0:
            doc.xref_set_key(xref, "AliefCloud", "null")
            annot = page.load_annot(xref)
            annot.set_border(width=(annot.border or {}).get("width", 1.5), clouds=0)
            annot.update()
        else:
            if "cloud" in props:
                info["arc"] = float(info.get("base", 9.0)) * (1.0 if int(props["cloud"]) <= 1 else 1.6)
            if props.get("cloud_arc_mm"):
                info["arc"] = float(props["cloud_arc_mm"]) * 72.0 / 25.4
            doc.xref_set_key(xref, "AliefCloud", pymupdf.get_pdf_str(json.dumps(info)))
            apply_cloud_ap(doc, page, xref)
    if t == "Caret":
        tt, vv = doc.xref_get_key(xref, "AliefCaret")
        if tt == "string":
            ci = json.loads(vv)
            if props.get("stroke") is not None:
                ci["color"] = [float(c) for c in props["stroke"][:3]]
                doc.xref_set_key(xref, "AliefCaret", pymupdf.get_pdf_str(json.dumps(ci)))
            apply_caret_ap(doc, page, xref)
    if "status" in props:
        v = props["status"]
        doc.xref_set_key(xref, "AliefStatus", pymupdf.get_pdf_str(v) if v and v != "None" else "null")
    return page


def delete_annots(doc, page, xrefs):
    for x in xrefs:
        try:
            a = page.load_annot(x)
            if a:
                page.delete_annot(a)
        except Exception:
            pass


def group_members(pdfdoc, page_index, group):
    if not group:
        return []
    return [a["xref"] for a in pdfdoc.annot_list(page_index) if a.get("group") == group]


def next_balloon_number(pdfdoc):
    mx = 0
    for i in range(pdfdoc.page_count):
        for a in pdfdoc.annot_list(i):
            subj = a.get("subject") or ""
            if subj.startswith("Balloon #"):
                try:
                    mx = max(mx, int(subj.split("#", 1)[1].split()[0]))
                except Exception:
                    pass
    return mx + 1
