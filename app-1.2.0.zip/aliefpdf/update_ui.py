"""Update notifications: background check, banner under the ribbon, Windows notification, update dialog, restart."""
import os
import subprocess
import sys
import time

from PySide6.QtCore import QObject, Signal, QTimer, Qt, QUrl
from PySide6.QtGui import QDesktopServices, QIcon
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton, QDialog, QVBoxLayout, QCheckBox,
                               QDialogButtonBox, QTextBrowser, QProgressBar, QMessageBox, QFileDialog,
                               QSystemTrayIcon, QMenu, QApplication)

from . import APP_NAME, VERSION, theme
from . import update as U
from .settings import settings, resource_path

CHECK_EVERY_MS = 4 * 3600 * 1000
FIRST_CHECK_MS = 12000


def _notes_html(n):
    notes = (n or {}).get("notes") or ""
    if isinstance(notes, list):
        items = "".join("<li>%s</li>" % _esc(x) for x in notes)
        return "<ul style='margin-left:-20px'>%s</ul>" % items
    return "<p>%s</p>" % _esc(notes).replace("\n", "<br>")


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class UpdateBanner(QFrame):
    """Coloured strip under the ribbon with the update message and buttons."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("UpdateBanner")
        h = QHBoxLayout(self)
        h.setContentsMargins(12, 5, 8, 5)
        self.icon = QLabel()
        self.icon.setFixedWidth(22)
        h.addWidget(self.icon)
        self.text = QLabel()
        self.text.setTextFormat(Qt.RichText)
        self.text.setWordWrap(True)
        h.addWidget(self.text, 1)
        self.b1 = QPushButton()
        self.b2 = QPushButton()
        self.b3 = QPushButton("Later")
        for b in (self.b1, self.b2, self.b3):
            b.setCursor(Qt.PointingHandCursor)
            h.addWidget(b)
        self.b3.clicked.connect(self.hide)
        self._cb = {}
        self.b1.clicked.connect(lambda: self._cb.get(1, lambda: None)())
        self.b2.clicked.connect(lambda: self._cb.get(2, lambda: None)())
        self.hide()

    def show_message(self, kind, html, b1=None, b2=None):
        col = {"ready": ("#E6F4EA", "#1E7D3A", "check-decagram"), "available": ("#E8F0FB", "#1F5FAF", "download-circle-outline"),
               "installer": ("#FFF4E0", "#9A5B00", "package-down"), "updated": ("#E6F4EA", "#1E7D3A", "party-popper")}[kind]
        bg, fg, ic = col
        self.setStyleSheet("#UpdateBanner{background:%s;border-bottom:1px solid %s;}"
                           "#UpdateBanner QLabel{color:#1B2430;}"
                           "#UpdateBanner QPushButton{background:white;border:1px solid %s;border-radius:4px;padding:3px 12px;color:%s;}"
                           "#UpdateBanner QPushButton:hover{background:%s;color:white;}" % (bg, fg, fg, fg, fg))
        self.icon.setPixmap(theme.icon(ic, accent=fg).pixmap(20, 20))
        self.text.setText(html)
        for k, btn, spec in ((1, self.b1, b1), (2, self.b2, b2)):
            if spec:
                btn.setText(spec[0])
                self._cb[k] = spec[1]
                btn.show()
            else:
                self._cb.pop(k, None)
                btn.hide()
        self.show()


class UpdateManager(QObject):
    result = Signal(str, object, str)
    progress = Signal(int, int)

    def __init__(self, main, banner):
        super().__init__(main)
        self.main = main
        self.banner = banner
        self.notice = None
        self.status = ""
        self.info = ""
        self.busy = False
        self.manual = False
        self.dialog = None
        self.tray = None
        self.checker = None
        self.result.connect(self._on_result)
        self.timer = QTimer(self)
        self.timer.setInterval(CHECK_EVERY_MS)
        self.timer.timeout.connect(lambda: self.check(manual=False))

    # ------------------------------------------------------------ public
    def start(self):
        """Called once the main window is shown."""
        QTimer.singleShot(1500, U.mark_healthy)
        try:
            U.cleanup()
        except Exception:
            pass
        self._show_updated_note()
        if not U.updates_supported():
            return
        if settings().get("update_auto_check", True):
            QTimer.singleShot(FIRST_CHECK_MS, lambda: self.check(manual=False))
            self.timer.start()
        pend = U.pending_version()
        if pend:
            self._banner_ready(pend)

    def check(self, manual=True, download=None):
        if self.busy:
            return
        self.busy = True
        self.manual = manual
        auto = settings().get("update_auto_download", True) if download is None else download
        self.checker = U.Checker(lambda s, n, i: self.result.emit(s, n, i), auto_install=auto,
                                 progress=lambda a, b: self.progress.emit(a, b))
        self.checker.start()

    def install_now(self):
        """Download the available version (when automatic download is off)."""
        self.check(manual=True, download=True)
        self.open_dialog()

    # ------------------------------------------------------------ results
    def _on_result(self, status, notice, info):
        self.busy = False
        self.status, self.notice, self.info = status, notice, info
        settings().set("update_last_check", time.strftime("%Y-%m-%d %H:%M"))
        settings().save()
        ver = (notice or {}).get("version", "")
        if status == "ready":
            self._banner_ready(ver)
            self._notify("Update %s is ready" % ver,
                         "%s %s has been downloaded. Restart the program to use it." % (APP_NAME, ver))
        elif status == "available":
            self.banner.show_message(
                "available", "<b>%s %s is available</b> (you have %s)." % (APP_NAME, ver, VERSION),
                ("Download && install", self.install_now), ("What's new?", self.open_dialog))
            self._notify("New version %s available" % ver, "Open %s to download and install it." % APP_NAME)
        elif status == "installer":
            self.banner.show_message(
                "installer", "<b>%s %s is available.</b> This version needs the new full installer." % (APP_NAME, ver),
                ("Open download page", self.open_download_page), ("What's new?", self.open_dialog))
            self._notify("New version %s available" % ver, "This version needs the new installer.")
        if self.dialog is not None:
            self.dialog.refresh()

    def _banner_ready(self, ver):
        self.banner.show_message(
            "ready", "<b>%s %s is ready.</b> It was downloaded in the background and starts the next time you "
                     "open the program." % (APP_NAME, ver),
            ("Restart now", self.restart_now), ("What's new?", self.open_dialog))

    def _show_updated_note(self):
        st = U.load_state()
        ln = st.get("last_notice")
        if isinstance(ln, dict) and ln.get("version") == VERSION and U.notice_valid(ln):
            self.notice, self.status = ln, "latest"          # release notes of the version in use
        if st.get("seen") == VERSION:
            return
        U.save_state(seen=VERSION)
        if st.get("seen") and U.vtuple(st.get("seen")) < U.vtuple(VERSION):
            self.banner.show_message(
                "updated", "<b>%s has been updated to version %s.</b>" % (APP_NAME, VERSION),
                ("What's new?", self.open_dialog))

    def _notify(self, title, text):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        if self.tray is None:
            ic = QIcon(resource_path("assets", "icon.ico"))
            self.tray = QSystemTrayIcon(ic if not ic.isNull() else self.main.windowIcon(), self.main)
            self.tray.setToolTip(APP_NAME)
            m = QMenu()
            m.addAction("Show update…", self.open_dialog)
            self.tray.setContextMenu(m)
            self.tray.messageClicked.connect(self.open_dialog)
            self.tray.activated.connect(lambda r: self.open_dialog())
        self.tray.show()
        self.tray.showMessage(title, text, QSystemTrayIcon.Information, 12000)

    # ------------------------------------------------------------ actions
    def open_dialog(self):
        try:
            self.main.showNormal() if self.main.isMinimized() else None
            self.main.raise_()
            self.main.activateWindow()
        except Exception:
            pass
        if self.dialog is None:
            self.dialog = UpdateDialog(self)
        self.dialog.refresh()
        self.dialog.show()
        self.dialog.raise_()

    def open_download_page(self):
        n = self.notice or {}
        QDesktopServices.openUrl(QUrl(n.get("installer_url") or U.PAGE_URL))

    def install_file(self, parent=None):
        p, _ = QFileDialog.getOpenFileName(parent or self.main, "Install update from file", "",
                                           "ALIEF PDF EDITOR PRO update (*%s *.zip)" % U.OFFLINE_EXT)
        if not p:
            return
        try:
            notice, _d = U.install_offline(p)
        except Exception as ex:
            QMessageBox.warning(parent or self.main, "Update", "This update file cannot be installed:\n%s" % ex)
            return
        self.notice, self.status = notice, "ready"
        self._banner_ready(notice["version"])
        if self.dialog is not None:
            self.dialog.refresh()
        QMessageBox.information(parent or self.main, "Update",
                                "Version %s is installed and starts the next time you open the program." % notice["version"])

    def restart_now(self):
        files = []
        try:
            files = [t.pdfdoc.path for t in self.main._tabs() if getattr(t.pdfdoc, "path", None)]
        except Exception:
            pass
        if self.dialog is not None:
            self.dialog.hide()
        if not self.main.close():            # asks to save modified documents; cancel keeps the program open
            return
        exe = sys.executable
        if os.path.basename(exe).lower().startswith("python"):
            args = [exe, os.path.abspath(sys.argv[0])]
        else:
            args = [exe]
        args += ["--restarted"] + [f for f in files if os.path.exists(f)]
        try:
            flags = 0x00000008 | 0x00000200 if sys.platform == "win32" else 0   # DETACHED_PROCESS | NEW_PROCESS_GROUP
            env = dict(os.environ)
            env.pop("ALIEF_PDF_RUNNING", None)
            subprocess.Popen(args, close_fds=True, creationflags=flags, env=env)
        except Exception as ex:
            QMessageBox.warning(None, APP_NAME, "Please start the program again.\n(%s)" % ex)
        if self.tray is not None:
            self.tray.hide()
        QApplication.quit()


class UpdateDialog(QDialog):
    def __init__(self, mgr):
        super().__init__(mgr.main)
        self.mgr = mgr
        self.setWindowTitle("Check for Updates")
        self.setWindowIcon(theme.icon("update"))
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        self.head = QLabel()
        self.head.setTextFormat(Qt.RichText)
        self.head.setWordWrap(True)
        lay.addWidget(self.head)
        self.bar = QProgressBar()
        self.bar.setTextVisible(True)
        self.bar.hide()
        lay.addWidget(self.bar)
        self.notes = QTextBrowser()
        self.notes.setOpenExternalLinks(True)
        self.notes.setMinimumHeight(180)
        lay.addWidget(self.notes, 1)
        self.c_check = QCheckBox("Check for new versions automatically (at start-up and every 4 hours)")
        self.c_dl = QCheckBox("Download new versions automatically in the background")
        self.c_check.setChecked(bool(settings().get("update_auto_check", True)))
        self.c_dl.setChecked(bool(settings().get("update_auto_download", True)))
        self.c_check.toggled.connect(self._save_opts)
        self.c_dl.toggled.connect(self._save_opts)
        lay.addWidget(self.c_check)
        lay.addWidget(self.c_dl)
        row = QHBoxLayout()
        self.b_check = QPushButton(theme.icon("refresh"), "Check now")
        self.b_check.clicked.connect(lambda: (self.mgr.check(manual=True), self.refresh()))
        self.b_get = QPushButton(theme.icon("download"), "Download && install")
        self.b_get.clicked.connect(lambda: (self.mgr.check(manual=True, download=True), self.refresh()))
        self.b_restart = QPushButton(theme.icon("restart"), "Restart now")
        self.b_restart.clicked.connect(self.mgr.restart_now)
        self.b_page = QPushButton(theme.icon("open-in-new"), "Download page")
        self.b_page.clicked.connect(self.mgr.open_download_page)
        self.b_file = QPushButton(theme.icon("folder-zip-outline"), "Install from file…")
        self.b_file.setToolTip("For PCs without internet: install a %s file copied from another PC" % U.OFFLINE_EXT)
        self.b_file.clicked.connect(lambda: self.mgr.install_file(self))
        for b in (self.b_check, self.b_get, self.b_restart, self.b_page, self.b_file):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(self.hide)
        lay.addWidget(bb)
        mgr.progress.connect(self._progress)

    def _save_opts(self):
        settings().set("update_auto_check", self.c_check.isChecked())
        settings().set("update_auto_download", self.c_dl.isChecked())
        settings().save()
        if self.c_check.isChecked():
            self.mgr.timer.start()
        else:
            self.mgr.timer.stop()

    def _progress(self, a, b):
        self.bar.show()
        self.bar.setMaximum(max(1, b))
        self.bar.setValue(min(a, max(1, b)))
        self.bar.setFormat("Downloading… %.1f / %.1f MB" % (a / 1048576.0, max(1, b) / 1048576.0))

    def refresh(self):
        m = self.mgr
        n = m.notice or {}
        ver = n.get("version", "")
        where = "update folder" if U.running_from_update() else "installed program"
        last = settings().get("update_last_check", "") or "never"
        base = ("<span style='font-size:13pt;font-weight:bold;color:%s'>%s</span><br>"
                "Version in use: <b>%s</b> (%s) &nbsp;·&nbsp; last check: %s<br><br>" % (theme.NAVY, APP_NAME, VERSION, where, last))
        st = "busy" if m.busy else m.status
        msg = {
            "busy": "Checking for updates…",
            "": "Press <b>Check now</b> to look for a new version.",
            "latest": "<b style='color:#1E7D3A'>You are using the latest version.</b>",
            "available": "<b>Version %s is available.</b> Press <b>Download &amp; install</b>." % ver,
            "ready": "<b style='color:#1E7D3A'>Version %s is ready.</b> Press <b>Restart now</b> or simply start the "
                     "program again later." % ver,
            "installer": "<b>Version %s is available</b> and needs the new full installer. Press <b>Download page</b>." % ver,
            "offline": "The update server cannot be reached. Check the internet connection and try again.<br>"
                       "<span style='color:#5B6675'>%s</span>" % _esc(m.info),
            "badsig": "<b style='color:#B23A2A'>The update information is not genuine (signature check failed) and "
                      "was ignored.</b>",
            "failed": "<b style='color:#B23A2A'>The download failed:</b> %s<br>Press <b>Check now</b> to try again." % _esc(m.info),
        }.get(st, "")
        if not U.updates_supported():
            msg += ("<br><br><span style='color:#5B6675'>Automatic update works for the program installed with "
                    "ALIEF_PDFEDITPRO_Setup.exe on Windows.</span>")
        self.head.setText(base + msg)
        if n and st in ("available", "ready", "installer", "latest"):
            self.notes.setHtml("<b>What's new in version %s</b> (%s)%s" % (_esc(ver), _esc(n.get("date", "")), _notes_html(n)))
        else:
            self.notes.setHtml("<span style='color:#5B6675'>The release notes of a new version are shown here.</span>")
        self.b_check.setEnabled(not m.busy)
        self.b_get.setVisible(st == "available")
        self.b_get.setEnabled(not m.busy)
        self.b_restart.setVisible(st == "ready" or (not m.busy and U.pending_version() is not None))
        self.b_page.setVisible(st == "installer")
        if not m.busy:
            self.bar.hide()
