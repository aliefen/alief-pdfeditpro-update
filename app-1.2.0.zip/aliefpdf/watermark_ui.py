"""Watermark dialog: create text / image / logo watermarks, save them as profiles, preview, choose pages."""
import os

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox, QLabel,
                               QComboBox, QLineEdit, QPlainTextEdit, QPushButton, QCheckBox, QDoubleSpinBox,
                               QSpinBox, QSlider, QRadioButton, QButtonGroup, QFileDialog, QFontComboBox,
                               QDialogButtonBox, QInputDialog, QMessageBox, QWidget, QStackedWidget)

from . import theme
from . import watermark as W
from .settings import parse_page_range
from .templates import ColorButton

POSITIONS = [("top-left", "Top left"), ("top", "Top centre"), ("top-right", "Top right"),
             ("left", "Middle left"), ("center", "Centre"), ("right", "Middle right"),
             ("bottom-left", "Bottom left"), ("bottom", "Bottom centre"), ("bottom-right", "Bottom right")]
ANGLES = [("diag_up", "Diagonal ↗ (bottom-left to top-right)"), ("diag_down", "Diagonal ↘ (top-left to bottom-right)"),
          ("horizontal", "Horizontal"), ("vertical", "Vertical"), ("custom", "Custom angle")]
STYLES = [("outline", "Outline (hollow letters)"), ("fill", "Filled"), ("fill_outline", "Filled + outline")]


class WatermarkDialog(QDialog):
    def __init__(self, main, pdfdoc, current=0):
        super().__init__(main)
        self.setWindowTitle("Watermark")
        self.setWindowIcon(theme.icon("water-plus-outline"))
        self.main = main
        self.pdfdoc = pdfdoc
        self.n = pdfdoc.page_count
        self.current = current
        self.profiles = W.load_profiles()
        self._loading = False
        self._pv_cache = {}
        self.resize(1060, 720)
        root = QHBoxLayout(self)

        # ------------------------------------------------------------ left: settings
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 6, 0)
        prow = QHBoxLayout()
        prow.addWidget(QLabel("Saved watermark:"))
        self.prof = QComboBox()
        self.prof.addItem("(new)")
        for p in self.profiles:
            self.prof.addItem(p.get("name") or "Watermark")
        self.prof.currentIndexChanged.connect(self._profile_selected)
        prow.addWidget(self.prof, 1)
        b_save = QPushButton(theme.icon("content-save-outline"), "Save as…")
        b_save.clicked.connect(self._save_profile)
        b_del = QPushButton(theme.icon("delete-outline"), "")
        b_del.setToolTip("Delete the selected saved watermark")
        b_del.clicked.connect(self._delete_profile)
        prow.addWidget(b_save)
        prow.addWidget(b_del)
        lv.addLayout(prow)

        trow = QHBoxLayout()
        self.r_text = QRadioButton("Text")
        self.r_img = QRadioButton("Image / logo")
        self.r_text.setChecked(True)
        grp = QButtonGroup(self)
        grp.addButton(self.r_text)
        grp.addButton(self.r_img)
        trow.addWidget(QLabel("<b>Type</b>"))
        trow.addWidget(self.r_text)
        trow.addWidget(self.r_img)
        trow.addStretch(1)
        lv.addLayout(trow)

        self.stack = QStackedWidget()
        # text page
        tp = QWidget()
        tf = QFormLayout(tp)
        tf.setContentsMargins(0, 0, 0, 0)
        self.text = QPlainTextEdit()
        self.text.setPlaceholderText("Watermark text - several lines are allowed")
        self.text.setFixedHeight(64)
        tf.addRow("Text", self.text)
        frow = QHBoxLayout()
        self.font = QFontComboBox()
        self.font.setFontFilters(QFontComboBox.ScalableFonts)
        self.font_file = QLineEdit()
        self.font_file.setPlaceholderText("or a font file (.ttf / .otf)")
        b_ff = QPushButton("…")
        b_ff.setFixedWidth(28)
        b_ff.clicked.connect(self._pick_font_file)
        frow.addWidget(self.font, 2)
        frow.addWidget(self.font_file, 1)
        frow.addWidget(b_ff)
        tf.addRow("Font", frow)
        srow = QHBoxLayout()
        self.bold = QCheckBox("Bold")
        self.italic = QCheckBox("Italic")
        self.style = QComboBox()
        for k, lab in STYLES:
            self.style.addItem(lab, k)
        srow.addWidget(self.bold)
        srow.addWidget(self.italic)
        srow.addWidget(self.style, 1)
        tf.addRow("Style", srow)
        crow = QHBoxLayout()
        self.color = ColorButton([0.55, 0.55, 0.55])
        self.ocolor = ColorButton([0.45, 0.45, 0.45])
        self.owidth = QDoubleSpinBox()
        self.owidth.setRange(0.2, 15)
        self.owidth.setSingleStep(0.5)
        self.owidth.setSuffix(" %")
        self.owidth.setToolTip("Outline thickness as % of the letter size")
        crow.addWidget(QLabel("Fill"))
        crow.addWidget(self.color)
        crow.addWidget(QLabel("Outline"))
        crow.addWidget(self.ocolor)
        crow.addWidget(self.owidth)
        tf.addRow("Colours", crow)
        self.font_note = QLabel("")
        self.font_note.setStyleSheet("color:#B23A2A;")
        tf.addRow("", self.font_note)
        self.stack.addWidget(tp)
        # image page
        ip = QWidget()
        iff = QFormLayout(ip)
        iff.setContentsMargins(0, 0, 0, 0)
        irow = QHBoxLayout()
        self.image = QLineEdit()
        self.image.setPlaceholderText("PNG, JPG, BMP, TIF, SVG or PDF (logo)")
        b_img = QPushButton(theme.icon("folder-image"), "Browse…")
        b_img.clicked.connect(self._pick_image)
        irow.addWidget(self.image, 1)
        irow.addWidget(b_img)
        iff.addRow("Image / logo", irow)
        self.gray = QCheckBox("Grey scale (washed-out logo)")
        iff.addRow("", self.gray)
        self.thumb = QLabel()
        self.thumb.setFixedSize(220, 96)
        self.thumb.setAlignment(Qt.AlignCenter)
        self.thumb.setStyleSheet("background:#FFFFFF;border:1px solid #C9D1DB;color:#8792A2;")
        iff.addRow("", self.thumb)
        self.stack.addWidget(ip)
        lv.addWidget(self.stack)

        g = QGroupBox("Size, angle and transparency")
        gf = QFormLayout(g)
        zrow = QHBoxLayout()
        self.r_fit = QRadioButton("Fit to page")
        self.r_fix = QRadioButton("Fixed")
        self.r_fit.setChecked(True)
        zg = QButtonGroup(self)
        zg.addButton(self.r_fit)
        zg.addButton(self.r_fix)
        self.fit = QDoubleSpinBox()
        self.fit.setRange(5, 100)
        self.fit.setSuffix(" % of page")
        self.fsize = QDoubleSpinBox()
        self.fsize.setRange(4, 600)
        self.fsize.setSuffix(" pt")
        self.iwidth = QDoubleSpinBox()
        self.iwidth.setRange(5, 2000)
        self.iwidth.setSuffix(" mm wide")
        zrow.addWidget(self.r_fit)
        zrow.addWidget(self.fit)
        zrow.addSpacing(10)
        zrow.addWidget(self.r_fix)
        zrow.addWidget(self.fsize)
        zrow.addWidget(self.iwidth)
        gf.addRow("Size", zrow)
        arow = QHBoxLayout()
        self.angle_mode = QComboBox()
        for k, lab in ANGLES:
            self.angle_mode.addItem(lab, k)
        self.angle = QDoubleSpinBox()
        self.angle.setRange(-180, 180)
        self.angle.setSuffix(" °")
        arow.addWidget(self.angle_mode, 1)
        arow.addWidget(self.angle)
        gf.addRow("Rotation", arow)
        orow = QHBoxLayout()
        self.opacity = QSlider(Qt.Horizontal)
        self.opacity.setRange(3, 100)
        self.op_lab = QLabel("45 %")
        self.op_lab.setFixedWidth(40)
        self.opacity.valueChanged.connect(lambda v: self.op_lab.setText("%d %%" % v))
        orow.addWidget(self.opacity, 1)
        orow.addWidget(self.op_lab)
        gf.addRow("Opacity", orow)
        lv.addWidget(g)

        g2 = QGroupBox("Position and pages")
        g2f = QFormLayout(g2)
        prow2 = QHBoxLayout()
        self.position = QComboBox()
        for k, lab in POSITIONS:
            self.position.addItem(lab, k)
        self.dx = QDoubleSpinBox()
        self.dy = QDoubleSpinBox()
        for sp, lab in ((self.dx, "X "), (self.dy, "Y ")):
            sp.setRange(-2000, 2000)
            sp.setPrefix(lab)
            sp.setSuffix(" mm")
        self.margin = QDoubleSpinBox()
        self.margin.setRange(0, 200)
        self.margin.setPrefix("margin ")
        self.margin.setSuffix(" mm")
        prow2.addWidget(self.position, 1)
        prow2.addWidget(self.dx)
        prow2.addWidget(self.dy)
        prow2.addWidget(self.margin)
        g2f.addRow("Position", prow2)
        tlrow = QHBoxLayout()
        self.tile = QCheckBox("Repeat over the whole page (tile)")
        self.gap = QDoubleSpinBox()
        self.gap.setRange(0, 500)
        self.gap.setPrefix("gap ")
        self.gap.setSuffix(" mm")
        tlrow.addWidget(self.tile)
        tlrow.addWidget(self.gap)
        tlrow.addStretch(1)
        g2f.addRow("", tlrow)
        self.layer = QComboBox()
        self.layer.addItem("In front of the page content (also on scanned pages)", "front")
        self.layer.addItem("Behind the page content", "back")
        g2f.addRow("Layer", self.layer)
        pgrow = QHBoxLayout()
        self.pg_mode = QComboBox()
        self.pg_mode.addItems(["All pages (%d)" % self.n, "Current page (%d)" % (current + 1), "Pages…"])
        self.pg_range = QLineEdit()
        self.pg_range.setPlaceholderText("e.g. 1-5, 8, 10-12, 20-")
        self.pg_range.setEnabled(False)
        self.pg_mode.currentIndexChanged.connect(lambda k: self.pg_range.setEnabled(k == 2))
        self.pg_sub = QComboBox()
        self.pg_sub.addItems(["every page", "odd pages only", "even pages only"])
        pgrow.addWidget(self.pg_mode)
        pgrow.addWidget(self.pg_range, 1)
        pgrow.addWidget(self.pg_sub)
        g2f.addRow("Pages", pgrow)
        lv.addWidget(g2)
        lv.addStretch(1)
        root.addWidget(left, 11)

        # ------------------------------------------------------------ right: preview
        right = QVBoxLayout()
        hrow = QHBoxLayout()
        hrow.addWidget(QLabel("<b>Preview</b>"))
        hrow.addStretch(1)
        hrow.addWidget(QLabel("page"))
        self.pv_page = QSpinBox()
        self.pv_page.setRange(1, max(1, self.n))
        self.pv_page.setValue(current + 1)
        hrow.addWidget(self.pv_page)
        right.addLayout(hrow)
        self.pv = QLabel()
        self.pv.setAlignment(Qt.AlignCenter)
        self.pv.setMinimumSize(380, 520)
        self.pv.setStyleSheet("background:#5E6B7D;border:1px solid #3B4656;")
        right.addWidget(self.pv, 1)
        self.pv_note = QLabel("")
        self.pv_note.setWordWrap(True)
        self.pv_note.setStyleSheet("color:#5B6675;")
        right.addWidget(self.pv_note)
        bb = QDialogButtonBox()
        self.b_apply = bb.addButton("Apply watermark", QDialogButtonBox.AcceptRole)
        self.b_apply.setIcon(theme.icon("water-plus-outline"))
        bb.addButton(QDialogButtonBox.Cancel)
        bb.accepted.connect(self._accept)
        bb.rejected.connect(self.reject)
        right.addWidget(bb)
        root.addLayout(right, 9)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(280)
        self._timer.timeout.connect(self._update_preview)
        for w in (self.text,):
            w.textChanged.connect(self._changed)
        for w in (self.font_file, self.image, self.pg_range):
            w.textChanged.connect(self._changed)
        for w in (self.font, self.style, self.angle_mode, self.position, self.layer, self.pg_mode, self.pg_sub):
            w.currentIndexChanged.connect(self._changed)
        for w in (self.bold, self.italic, self.gray, self.tile, self.r_text, self.r_img, self.r_fit, self.r_fix):
            w.toggled.connect(self._changed)
        for w in (self.owidth, self.fit, self.fsize, self.iwidth, self.angle, self.dx, self.dy, self.margin, self.gap):
            w.valueChanged.connect(self._changed)
        self.opacity.valueChanged.connect(self._changed)
        self.pv_page.valueChanged.connect(self._changed)
        for b in (self.color, self.ocolor):
            b.clicked.connect(self._changed)
        last = W.load_last()
        start = last or (self.profiles[0] if self.profiles else W.DEFAULT)
        self.set_config(start)
        names = [p.get("name") for p in self.profiles]
        if start.get("name") in names:
            self.prof.blockSignals(True)
            self.prof.setCurrentIndex(names.index(start.get("name")) + 1)
            self.prof.blockSignals(False)

    # ------------------------------------------------------------ config <-> widgets
    def set_config(self, cfg):
        c = dict(W.DEFAULT, **(cfg or {}))
        self._loading = True
        try:
            (self.r_img if c["kind"] == "image" else self.r_text).setChecked(True)
            self.text.setPlainText(c["text"])
            fam = c.get("font") or "Arial"
            if os.path.isfile(fam):
                self.font_file.setText(fam)
            else:
                self.font_file.setText("")
                self.font.setCurrentFont(QFont(fam))
            self.bold.setChecked(bool(c["bold"]))
            self.italic.setChecked(bool(c["italic"]))
            self.style.setCurrentIndex(max(0, [k for k, _ in STYLES].index(c["style"]) if c["style"] in [k for k, _ in STYLES] else 0))
            self.color.set_rgb(c["color"])
            self.ocolor.set_rgb(c["outline_color"])
            self.owidth.setValue(float(c["outline_width"]))
            self.image.setText(c.get("image") or "")
            self.gray.setChecked(bool(c.get("image_gray")))
            (self.r_fit if c["size_mode"] == "fit" else self.r_fix).setChecked(True)
            self.fit.setValue(float(c["fit_pct"]))
            self.fsize.setValue(float(c["fontsize"]))
            self.iwidth.setValue(float(c["image_width_mm"]))
            keys = [k for k, _ in ANGLES]
            self.angle_mode.setCurrentIndex(keys.index(c["angle_mode"]) if c["angle_mode"] in keys else 0)
            self.angle.setValue(float(c["angle"]))
            self.opacity.setValue(int(round(float(c["opacity"]) * 100)))
            pk = [k for k, _ in POSITIONS]
            self.position.setCurrentIndex(pk.index(c["position"]) if c["position"] in pk else 4)
            self.dx.setValue(float(c["dx_mm"]))
            self.dy.setValue(float(c["dy_mm"]))
            self.margin.setValue(float(c["margin_mm"]))
            self.tile.setChecked(bool(c["tile"]))
            self.gap.setValue(float(c["tile_gap_mm"]))
            self.layer.setCurrentIndex(1 if c["layer"] == "back" else 0)
        finally:
            self._loading = False
        self._changed()

    def config(self):
        ff = self.font_file.text().strip()
        return {
            "name": self.prof.currentText() if self.prof.currentIndex() > 0 else "",
            "kind": "image" if self.r_img.isChecked() else "text",
            "text": self.text.toPlainText(),
            "font": ff if ff else self.font.currentFont().family(),
            "bold": self.bold.isChecked(),
            "italic": self.italic.isChecked(),
            "style": self.style.currentData(),
            "color": self.color.rgb or [0.5, 0.5, 0.5],
            "outline_color": self.ocolor.rgb or [0.4, 0.4, 0.4],
            "outline_width": self.owidth.value(),
            "opacity": self.opacity.value() / 100.0,
            "image": self.image.text().strip(),
            "image_gray": self.gray.isChecked(),
            "size_mode": "fit" if self.r_fit.isChecked() else "fixed",
            "fit_pct": self.fit.value(),
            "fontsize": self.fsize.value(),
            "image_width_mm": self.iwidth.value(),
            "angle_mode": self.angle_mode.currentData(),
            "angle": self.angle.value(),
            "position": self.position.currentData(),
            "dx_mm": self.dx.value(),
            "dy_mm": self.dy.value(),
            "margin_mm": self.margin.value(),
            "tile": self.tile.isChecked(),
            "tile_gap_mm": self.gap.value(),
            "layer": self.layer.currentData(),
        }

    def pages(self):
        k = self.pg_mode.currentIndex()
        if k == 0:
            lst = list(range(self.n))
        elif k == 1:
            lst = [self.current]
        else:
            lst = parse_page_range(self.pg_range.text(), self.n)
        sub = self.pg_sub.currentIndex()
        if sub == 1:
            lst = [p for p in lst if p % 2 == 0]
        elif sub == 2:
            lst = [p for p in lst if p % 2 == 1]
        return lst

    # ------------------------------------------------------------ events
    def _changed(self, *a):
        if self._loading:
            return
        text = self.r_text.isChecked()
        self.stack.setCurrentIndex(0 if text else 1)
        self.fsize.setVisible(text)
        self.iwidth.setVisible(not text)
        self.angle.setEnabled(self.angle_mode.currentData() == "custom")
        st = self.style.currentData()
        self.color.setEnabled(st != "outline")
        self.ocolor.setEnabled(st != "fill")
        self.owidth.setEnabled(st != "fill")
        self.gap.setEnabled(self.tile.isChecked())
        self.position.setEnabled(not self.tile.isChecked())
        if not text:
            self._update_thumb()
        if text:
            ff = self.font_file.text().strip()
            fam = ff or self.font.currentFont().family()
            found = W.font_file(fam, self.bold.isChecked(), self.italic.isChecked())
            self.font_note.setText("" if found else
                                   "Font file of \u201c%s\u201d not found - Helvetica is used. Choose a .ttf/.otf file." % fam)
        self._timer.start()

    def _update_thumb(self):
        p = self.image.text().strip()
        if getattr(self, "_thumb_for", None) == p:
            return
        self._thumb_for = p
        pm = QPixmap()
        if p and os.path.isfile(p):
            ext = os.path.splitext(p)[1].lower()
            try:
                if ext in (".svg", ".pdf"):
                    import pymupdf
                    with pymupdf.open(p) as d:
                        pg = d[0]
                        z = min(200 / max(1, pg.rect.width), 88 / max(1, pg.rect.height))
                        pix = pg.get_pixmap(matrix=pymupdf.Matrix(z, z), alpha=True)
                        pm.loadFromData(pix.tobytes("png"))
                else:
                    pm = QPixmap(p)
            except Exception:
                pm = QPixmap()
        if pm.isNull():
            self.thumb.setPixmap(QPixmap())
            self.thumb.setText("no image chosen" if not p else "cannot read this file")
        else:
            self.thumb.setPixmap(pm.scaled(210, 88, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _update_preview(self):
        cfg = self.config()
        pno = self.pv_page.value() - 1
        try:
            img = W.preview_image(self.pdfdoc.doc, pno, cfg, width_px=max(300, self.pv.width() - 20), cache=self._pv_cache)
            pm = QPixmap.fromImage(img)
            if pm.height() > self.pv.height() - 10:
                pm = pm.scaledToHeight(self.pv.height() - 10, Qt.SmoothTransformation)
            self.pv.setPixmap(pm)
            n = len(self.pages())
            self.pv_note.setText("Will be applied to %d page(s). The watermark goes on its own layer "
                                 "\u201cWatermark\u201d (Layers panel) and can be removed again with "
                                 "Watermark \u25b8 Remove." % n)
        except Exception as e:
            self.pv.setText(str(e))
            self.pv_note.setText("")

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "_timer"):
            self._timer.start()

    def _pick_font_file(self):
        p, _ = QFileDialog.getOpenFileName(self, "Font file", os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Fonts"),
                                           "Fonts (*.ttf *.otf *.ttc)")
        if p:
            self.font_file.setText(p)

    def _pick_image(self):
        p, _ = QFileDialog.getOpenFileName(self, "Image or logo", "",
                                           "Images and logos (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.gif *.svg *.pdf)")
        if p:
            self.image.setText(p)
            self.r_img.setChecked(True)

    def _profile_selected(self, k):
        if k <= 0:
            return
        self.set_config(self.profiles[k - 1])

    def _save_profile(self):
        cur = self.prof.currentText() if self.prof.currentIndex() > 0 else ""
        name, ok = QInputDialog.getText(self, "Save watermark", "Name of this watermark:", text=cur or "My watermark")
        if not ok or not name.strip():
            return
        cfg = self.config()
        cfg["name"] = name.strip()
        for i, p in enumerate(self.profiles):
            if p.get("name") == cfg["name"]:
                self.profiles[i] = cfg
                break
        else:
            self.profiles.append(cfg)
            self.prof.addItem(cfg["name"])
        W.save_profiles(self.profiles)
        self.prof.blockSignals(True)
        self.prof.setCurrentText(cfg["name"])
        self.prof.blockSignals(False)

    def _delete_profile(self):
        k = self.prof.currentIndex()
        if k <= 0:
            return
        if QMessageBox.question(self, "Watermark", "Delete the saved watermark \u201c%s\u201d?" % self.prof.currentText()) \
                != QMessageBox.Yes:
            return
        del self.profiles[k - 1]
        W.save_profiles(self.profiles)
        self.prof.removeItem(k)

    def _accept(self):
        cfg = self.config()
        if cfg["kind"] == "text" and not cfg["text"].strip():
            QMessageBox.warning(self, "Watermark", "Type the watermark text.")
            return
        if cfg["kind"] == "image" and not os.path.exists(cfg["image"]):
            QMessageBox.warning(self, "Watermark", "Choose the image / logo file.")
            return
        if not self.pages():
            QMessageBox.warning(self, "Watermark", "No pages selected.")
            return
        # remember the last settings as the starting point next time
        W.save_last(cfg)
        self.accept()


class RemoveWatermarkDialog(QDialog):
    def __init__(self, main, pdfdoc, current=0):
        super().__init__(main)
        self.setWindowTitle("Remove watermarks")
        self.setMinimumWidth(460)
        self.n = pdfdoc.page_count
        self.doc = pdfdoc.doc
        lay = QVBoxLayout(self)
        own, other = [], []
        if self.n <= 3000:
            for i in range(self.n):
                k = W.watermark_kinds(self.doc, i)
                if "own" in k:
                    own.append(i)
                if "other" in k:
                    other.append(i)
        self.own, self.other = own, other
        if own or other:
            txt = "Watermarks found:\n  \u2022 made with ALIEF PDF EDITOR PRO: %d page(s)" % len(own)
            txt += "\n  \u2022 made with other programs (e.g. Adobe Acrobat): %d page(s)" % len(other)
        else:
            txt = ("No removable watermark was found in this document.\n(Watermarks that are part of the drawing "
                   "itself, e.g. a scanned or printed stamp, cannot be removed here - use Edit Objects.)")
        lab = QLabel(txt)
        lab.setWordWrap(True)
        lay.addWidget(lab)
        self.incl_other = QCheckBox("Also remove watermarks made by other programs")
        self.incl_other.setEnabled(bool(other))
        self.incl_other.setChecked(bool(other) and not own)
        lay.addWidget(self.incl_other)
        f = QFormLayout()
        from .dialogs import pages_row
        self.pages_w, self.pages_get = pages_row(self.n, current)
        f.addRow("Pages", self.pages_w)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Remove")
        bb.button(QDialogButtonBox.Ok).setEnabled(bool(own or other))
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
