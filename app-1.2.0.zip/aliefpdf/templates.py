"""Comment templates (tool presets) and stamp templates, plus their manager dialogs."""
import copy
import json
import os
import uuid

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QColor, QImage, QIcon
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QFormLayout,
                               QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox, QPushButton, QLabel, QTabWidget,
                               QWidget, QColorDialog, QCheckBox, QFileDialog, QMessageBox, QPlainTextEdit,
                               QDialogButtonBox, QGroupBox, QGridLayout)

from .settings import app_data_dir
from . import theme, COMPANY, COMPANY_CITY

RED = [0.85, 0.08, 0.08]
BLUE = [0.05, 0.3, 0.85]
GREEN = [0.0, 0.55, 0.2]
YELLOW = [1.0, 0.92, 0.0]
ORANGE = [0.95, 0.5, 0.0]
NAVY = [0.06, 0.17, 0.35]
BLACK = [0.0, 0.0, 0.0]

TOOL_KINDS = [
    ("cloud", "Revision cloud (rectangle)"), ("cloudpoly", "Revision cloud (polygon)"),
    ("balloon", "Numbered balloon"), ("textbox", "Text box"), ("callout", "Callout"),
    ("typewriter", "Typewriter"), ("note", "Sticky note"), ("rect", "Rectangle"), ("ellipse", "Ellipse"),
    ("line", "Line"), ("arrow", "Arrow"), ("polyline", "Polyline"), ("polygon", "Polygon"),
    ("ink", "Pen (freehand)"), ("highlight", "Highlight text"), ("underline", "Underline text"),
    ("strikeout", "Strikeout text"), ("squiggly", "Squiggly underline"), ("area", "Area highlight"),
    ("freehighlight", "Free highlight (marker pen)"), ("attach", "Attach file"), ("sound", "Sound"),
    ("inserttext", "Insert text (caret)"), ("replacetext", "Replace text"), ("textcorrection", "Text correction"),
]
KIND_ICON = {"cloud": "weather-cloudy", "cloudpoly": "weather-cloudy", "balloon": "numeric-1-circle-outline",
             "textbox": "text-box-outline", "callout": "message-arrow-left-outline", "typewriter": "format-text",
             "note": "note-outline", "rect": "rectangle-outline", "ellipse": "ellipse-outline",
             "line": "vector-line", "arrow": "arrow-top-right", "polyline": "vector-polyline",
             "polygon": "vector-polygon", "ink": "draw", "highlight": "marker", "underline": "format-underline",
             "strikeout": "format-strikethrough-variant", "squiggly": "format-underline", "area": "select-drag",
             "freehighlight": "brush", "attach": "paperclip", "sound": "volume-high", "inserttext": "chevron-up",
             "replacetext": "find-replace", "textcorrection": "spellcheck"}


def _t(name, kind, stroke, **kw):
    d = {"id": uuid.uuid4().hex[:10], "name": name, "kind": kind, "stroke": stroke, "fill": None, "width": 1.5,
         "dash": "solid", "opacity": 1.0, "fontsize": 10.0, "font": "Helvetica", "text": "", "subject": name}
    d.update(kw)
    return d


def default_tools():
    return [
        _t("Class Remark Cloud (Red)", "cloud", RED, width=1.5, cloud=1, subject="Remark"),
        _t("Class Remark Cloud Polygon (Red)", "cloudpoly", RED, width=1.5, cloud=1, subject="Remark"),
        _t("Remark Balloon (Red)", "balloon", RED, shape="circle", size_mm=6.0, subject="Balloon"),
        _t("Remark Text (Red)", "textbox", RED, width=1.0, fontsize=9.0, fill=[1, 1, 1], subject="Remark"),
        _t("Remark Callout (Red)", "callout", RED, width=1.0, fontsize=9.0, fill=[1, 1, 1], line_end="open", subject="Remark"),
        _t("Typewriter (Red)", "typewriter", RED, fontsize=10.0, border=False, subject="Typewriter"),
        _t("Typewriter (Blue)", "typewriter", BLUE, fontsize=10.0, border=False, subject="Typewriter"),
        _t("Sticky Note", "note", YELLOW, subject="Note", icon="Comment"),
        _t("Rectangle (Red)", "rect", RED, width=1.5),
        _t("Ellipse (Red)", "ellipse", RED, width=1.5),
        _t("Arrow (Red)", "arrow", RED, width=1.5, line_end="open"),
        _t("Line (Blue)", "line", BLUE, width=1.2),
        _t("Polyline (Green)", "polyline", GREEN, width=1.5),
        _t("Polygon (Blue 20%)", "polygon", BLUE, fill=[0.75, 0.85, 1.0], opacity=0.6, width=1.0),
        _t("Pen (Red)", "ink", RED, width=1.5),
        _t("Highlight (Yellow)", "highlight", YELLOW, opacity=1.0),
        _t("Underline (Green)", "underline", GREEN),
        _t("Strikeout (Red)", "strikeout", RED),
        _t("Squiggly (Blue)", "squiggly", BLUE),
        _t("Area Highlight (Yellow)", "area", None, fill=YELLOW, opacity=0.35, width=0.0),
        _t("Hold / Check Cloud (Orange)", "cloud", ORANGE, width=1.5, cloud=1, dash="solid", subject="Hold point"),
        _t("Information Cloud (Blue)", "cloud", BLUE, width=1.2, cloud=1, subject="Information"),
        _t("Free Highlight (Yellow)", "freehighlight", YELLOW, width=10.0, opacity=0.45, subject="Free Highlight"),
        _t("Free Highlight (Green)", "freehighlight", [0.3, 0.95, 0.3], width=10.0, opacity=0.45, subject="Free Highlight"),
        _t("Attach File", "attach", BLUE, icon="Paperclip", subject="Attachment"),
        _t("Sound", "sound", BLUE, subject="Sound"),
        _t("Insert Text (Blue)", "inserttext", BLUE, subject="Inserted Text"),
        _t("Replace Text (Red)", "replacetext", RED, subject="Replace Text"),
        _t("Text Correction (Red)", "textcorrection", RED, subject="Text Correction"),
    ]


def _s(name, title, sub, color, **kw):
    d = {"id": uuid.uuid4().hex[:10], "name": name, "title": title, "subtitle": sub, "color": color,
         "header": COMPANY, "style": "box", "fields": ["number", "date", "place"], "place": COMPANY_CITY.upper(),
         "date_format": "%d %b %Y", "number_label": "Number :", "number_sublabel": "Nomor", "by": "",
         "by_label": "Checked by :", "by_sublabel": "Diperiksa oleh", "width_mm": 62.0, "opacity": 1.0,
         "background": False, "auto_number": True, "number_prefix": ""}
    d.update(kw)
    return d


def default_stamps():
    return [
        _s("Approved", "APPROVED", "DISETUJUI", GREEN),
        _s("Approved with Comments", "APPROVED WITH COMMENTS", "DISETUJUI DENGAN CATATAN", BLUE),
        _s("Not Approved", "NOT APPROVED", "TIDAK DISETUJUI", RED),
        _s("Reviewed", "REVIEWED", "TELAH DIPERIKSA", BLUE, fields=["number", "by", "date", "place"]),
        _s("Checked", "CHECKED", "DIPERIKSA", GREEN, fields=["by", "date", "place"]),
        _s("For Information", "FOR INFORMATION", "UNTUK INFORMASI", NAVY, fields=["date", "place"]),
        _s("For Construction", "FOR CONSTRUCTION", "UNTUK PRODUKSI", GREEN, style="double", fields=["number", "date", "place"]),
        _s("Rejected", "REJECTED", "DITOLAK", RED, fields=["date", "place"]),
        _s("Preliminary", "PRELIMINARY", "AWAL / BELUM FINAL", ORANGE, fields=["date"]),
        _s("As Built", "AS BUILT", "SESUAI TERPASANG", NAVY, style="double", fields=["date", "place"]),
        _s("Void", "VOID", "TIDAK BERLAKU", RED, fields=["date"], style="rounded"),
        _s("Confidential", "CONFIDENTIAL", "RAHASIA", RED, fields=[], style="rounded"),
    ]


class TemplateStore:
    def __init__(self):
        self.path = os.path.join(app_data_dir(), "templates.json")
        self.tools = default_tools()
        self.stamps = default_stamps()
        self.counters = {}
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            self.tools = d.get("tools") or self.tools
            self.stamps = d.get("stamps") or self.stamps
            self.counters = d.get("counters", {})
            if int(d.get("schema", 1)) < 2:
                self._upgrade_v11()
                self.save()
        except Exception:
            self.save()

    def _upgrade_v11(self):
        """v1.1: stamps no longer hide the drawing (transparent + Multiply); add the new comment kinds."""
        for s in self.stamps:
            s["background"] = False
        have = {t.get("kind") for t in self.tools}
        for t in default_tools():
            if t["kind"] not in have:
                self.tools.append(t)
                have.add(t["kind"])

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({"schema": 2, "tools": self.tools, "stamps": self.stamps, "counters": self.counters}, f, indent=1)
        except Exception:
            pass

    def tool_by_kind(self, kind):
        for t in self.tools:
            if t["kind"] == kind:
                return t
        return next((t for t in default_tools() if t["kind"] == kind), None)

    def find_tool(self, tid):
        return next((t for t in self.tools if t["id"] == tid), None)

    def find_stamp(self, sid):
        return next((s for s in self.stamps if s["id"] == sid), None)

    def next_number(self, stamp):
        key = stamp.get("id")
        n = int(self.counters.get(key, 0)) + 1
        return n

    def commit_number(self, stamp, n):
        self.counters[stamp.get("id")] = int(n)
        self.save()

    def export(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"tools": self.tools, "stamps": self.stamps}, f, indent=1)

    def import_(self, path, replace=False):
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        tools, stamps = d.get("tools", []), d.get("stamps", [])
        if replace:
            self.tools, self.stamps = tools or self.tools, stamps or self.stamps
        else:
            ids = {t["id"] for t in self.tools}
            self.tools += [t for t in tools if t.get("id") not in ids]
            ids = {s["id"] for s in self.stamps}
            self.stamps += [s for s in stamps if s.get("id") not in ids]
        self.save()


STORE = None


def store():
    global STORE
    if STORE is None:
        STORE = TemplateStore()
    return STORE


def tool_icon(t):
    return theme.icon(KIND_ICON.get(t.get("kind"), "comment-text-outline"),
                      color=QColor.fromRgbF(*(t.get("stroke") or t.get("fill") or [0.2, 0.2, 0.2])).name())


def stamp_thumbnail(st, h=36):
    from .annots import render_stamp_image
    img = render_stamp_image(st, dpi=110)
    return QPixmap.fromImage(img.scaledToHeight(h, Qt.SmoothTransformation))


# ======================================================================= UI
class ColorButton(QPushButton):
    def __init__(self, rgb=None, allow_none=False):
        super().__init__()
        self.allow_none = allow_none
        self.setFixedWidth(90)
        self.set_rgb(rgb)
        self.clicked.connect(self.pick)

    def set_rgb(self, rgb):
        self.rgb = list(rgb) if rgb is not None else None
        self.setIcon(theme.color_icon(self.rgb))
        self.setText(QColor.fromRgbF(*self.rgb).name().upper() if self.rgb else "None")

    def pick(self):
        start = QColor.fromRgbF(*self.rgb) if self.rgb else QColor("white")
        dlg = QColorDialog(start, self)
        dlg.setOption(QColorDialog.ShowAlphaChannel, False)
        if self.allow_none:
            btn = QPushButton("No colour")
            btn.clicked.connect(lambda: (self.set_rgb(None), dlg.reject()))
            dlg.layout().addWidget(btn)
        if dlg.exec():
            c = dlg.selectedColor()
            self.set_rgb([round(c.redF(), 4), round(c.greenF(), 4), round(c.blueF(), 4)])


class TemplateManager(QDialog):
    """Create / edit comment styles and stamps."""

    def __init__(self, parent=None, start_tab=0):
        super().__init__(parent)
        self.setWindowTitle("Comment Templates & Stamps")
        self.resize(900, 600)
        self.st = store()
        self.tools = copy.deepcopy(self.st.tools)
        self.stamps = copy.deepcopy(self.st.stamps)
        lay = QVBoxLayout(self)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs)
        self.tabs.addTab(self._build_tools_tab(), theme.icon("comment-text-outline"), "Comment Styles")
        self.tabs.addTab(self._build_stamps_tab(), theme.icon("stamper"), "Stamps")
        self.tabs.setCurrentIndex(start_tab)
        bb = QHBoxLayout()
        b_imp = QPushButton(theme.icon("folder-open"), "Import…")
        b_exp = QPushButton(theme.icon("file-export-outline"), "Export…")
        b_def = QPushButton("Restore defaults")
        b_imp.clicked.connect(self.do_import)
        b_exp.clicked.connect(self.do_export)
        b_def.clicked.connect(self.restore_defaults)
        bb.addWidget(b_imp)
        bb.addWidget(b_exp)
        bb.addWidget(b_def)
        bb.addStretch(1)
        ok = QPushButton("Save && Close")
        ok.setObjectName("Primary")
        cancel = QPushButton("Cancel")
        ok.clicked.connect(self.accept_save)
        cancel.clicked.connect(self.reject)
        bb.addWidget(ok)
        bb.addWidget(cancel)
        lay.addLayout(bb)
        self._fill_tool_list()
        self._fill_stamp_list()

    # ------------------------------------------------------------ tools tab
    def _build_tools_tab(self):
        w = QWidget()
        h = QHBoxLayout(w)
        left = QVBoxLayout()
        self.tool_list = QListWidget()
        self.tool_list.setIconSize(QSize(20, 20))
        self.tool_list.currentRowChanged.connect(self._load_tool)
        left.addWidget(self.tool_list)
        row = QHBoxLayout()
        for txt, fn in (("New", self.new_tool), ("Duplicate", self.dup_tool), ("Delete", self.del_tool),
                        ("▲", lambda: self.move_tool(-1)), ("▼", lambda: self.move_tool(1))):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            row.addWidget(b)
        left.addLayout(row)
        h.addLayout(left, 2)
        box = QGroupBox("Style")
        f = QFormLayout(box)
        self.t_name = QLineEdit()
        self.t_kind = QComboBox()
        for k, label in TOOL_KINDS:
            self.t_kind.addItem(theme.icon(KIND_ICON[k]), label, k)
        self.t_stroke = ColorButton(allow_none=True)
        self.t_fill = ColorButton(allow_none=True)
        self.t_width = QDoubleSpinBox()
        self.t_width.setRange(0, 20)
        self.t_width.setSingleStep(0.25)
        self.t_dash = QComboBox()
        self.t_dash.addItems(["solid", "dash", "dot", "dashdot"])
        self.t_cloud = QSpinBox()
        self.t_cloud.setRange(0, 2)
        self.t_cloud.setToolTip("Cloud intensity for rectangle / ellipse / polygon (0 = none)")
        self.t_opacity = QDoubleSpinBox()
        self.t_opacity.setRange(0.05, 1.0)
        self.t_opacity.setSingleStep(0.05)
        self.t_font = QComboBox()
        self.t_font.addItems(["Helvetica", "Times", "Courier"])
        self.t_fontsize = QDoubleSpinBox()
        self.t_fontsize.setRange(4, 72)
        self.t_lineend = QComboBox()
        self.t_lineend.addItems(["none", "open", "closed", "circle", "square", "slash", "diamond", "butt"])
        self.t_shape = QComboBox()
        self.t_shape.addItems(["circle", "square", "hexagon"])
        self.t_size = QDoubleSpinBox()
        self.t_size.setRange(3, 30)
        self.t_size.setSuffix(" mm")
        self.t_subject = QLineEdit()
        self.t_text = QPlainTextEdit()
        self.t_text.setMaximumHeight(70)
        self.t_text.setPlaceholderText("Default text (optional), e.g. 'To be submitted for approval'")
        self.t_border = QCheckBox("Draw border around text")
        f.addRow("Name", self.t_name)
        f.addRow("Comment type", self.t_kind)
        f.addRow("Line / text colour", self.t_stroke)
        f.addRow("Fill colour", self.t_fill)
        f.addRow("Line width (pt)", self.t_width)
        f.addRow("Line style", self.t_dash)
        f.addRow("Cloud effect", self.t_cloud)
        f.addRow("Opacity", self.t_opacity)
        f.addRow("Font", self.t_font)
        f.addRow("Font size", self.t_fontsize)
        f.addRow("Arrow / line end", self.t_lineend)
        f.addRow("Balloon shape", self.t_shape)
        f.addRow("Balloon size", self.t_size)
        f.addRow("Subject", self.t_subject)
        f.addRow("Default text", self.t_text)
        f.addRow("", self.t_border)
        h.addWidget(box, 3)
        return w

    def _fill_tool_list(self):
        self._cur_tool = -1
        self.tool_list.blockSignals(True)
        self.tool_list.clear()
        for t in self.tools:
            it = QListWidgetItem(tool_icon(t), t["name"])
            self.tool_list.addItem(it)
        self.tool_list.blockSignals(False)
        if self.tools:
            self.tool_list.setCurrentRow(0)
            self._load_tool(0)

    def _load_tool(self, row):
        self._store_tool()
        if row < 0 or row >= len(self.tools):
            return
        self._cur_tool = row
        t = self.tools[row]
        self.t_name.setText(t.get("name", ""))
        self.t_kind.setCurrentIndex(max(0, self.t_kind.findData(t.get("kind"))))
        self.t_stroke.set_rgb(t.get("stroke"))
        self.t_fill.set_rgb(t.get("fill"))
        self.t_width.setValue(float(t.get("width", 1.5)))
        self.t_dash.setCurrentText(t.get("dash", "solid"))
        self.t_cloud.setValue(int(t.get("cloud", 0) or 0))
        self.t_opacity.setValue(float(t.get("opacity", 1.0)))
        self.t_font.setCurrentText(t.get("font", "Helvetica"))
        self.t_fontsize.setValue(float(t.get("fontsize", 10)))
        self.t_lineend.setCurrentText(t.get("line_end", "open" if t.get("kind") in ("arrow", "callout") else "none"))
        self.t_shape.setCurrentText(t.get("shape", "circle"))
        self.t_size.setValue(float(t.get("size_mm", 6.0)))
        self.t_subject.setText(t.get("subject", ""))
        self.t_text.setPlainText(t.get("text", ""))
        self.t_border.setChecked(bool(t.get("border", True)))

    def _store_tool(self):
        row = getattr(self, "_cur_tool", -1)
        if row < 0 or row >= len(self.tools):
            return
        t = self.tools[row]
        t.update({"name": self.t_name.text().strip() or "Untitled", "kind": self.t_kind.currentData(),
                  "stroke": self.t_stroke.rgb, "fill": self.t_fill.rgb, "width": self.t_width.value(),
                  "dash": self.t_dash.currentText(), "cloud": self.t_cloud.value(), "opacity": self.t_opacity.value(),
                  "font": self.t_font.currentText(), "fontsize": self.t_fontsize.value(),
                  "line_end": self.t_lineend.currentText(), "shape": self.t_shape.currentText(),
                  "size_mm": self.t_size.value(), "subject": self.t_subject.text(),
                  "text": self.t_text.toPlainText(), "border": self.t_border.isChecked()})
        it = self.tool_list.item(row)
        if it:
            it.setText(t["name"])
            it.setIcon(tool_icon(t))

    def new_tool(self):
        self._store_tool()
        self.tools.append(_t("New style", "cloud", RED, cloud=1))
        self._fill_tool_list()
        self.tool_list.setCurrentRow(len(self.tools) - 1)

    def dup_tool(self):
        self._store_tool()
        row = self.tool_list.currentRow()
        if row < 0:
            return
        t = copy.deepcopy(self.tools[row])
        t["id"] = uuid.uuid4().hex[:10]
        t["name"] += " (copy)"
        self.tools.insert(row + 1, t)
        self._fill_tool_list()
        self.tool_list.setCurrentRow(row + 1)

    def del_tool(self):
        row = self.tool_list.currentRow()
        if row >= 0:
            self.tools.pop(row)
            self._cur_tool = -1
            self._fill_tool_list()

    def move_tool(self, d):
        self._store_tool()
        row = self.tool_list.currentRow()
        j = row + d
        if 0 <= row < len(self.tools) and 0 <= j < len(self.tools):
            self.tools[row], self.tools[j] = self.tools[j], self.tools[row]
            self._fill_tool_list()
            self.tool_list.setCurrentRow(j)

    # ----------------------------------------------------------- stamps tab
    def _build_stamps_tab(self):
        w = QWidget()
        h = QHBoxLayout(w)
        left = QVBoxLayout()
        self.stamp_list = QListWidget()
        self.stamp_list.setIconSize(QSize(80, 34))
        self.stamp_list.currentRowChanged.connect(self._load_stamp)
        left.addWidget(self.stamp_list)
        row = QHBoxLayout()
        for txt, fn in (("New", self.new_stamp), ("Duplicate", self.dup_stamp), ("Delete", self.del_stamp)):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            row.addWidget(b)
        left.addLayout(row)
        h.addLayout(left, 2)
        right = QVBoxLayout()
        box = QGroupBox("Stamp design")
        f = QFormLayout(box)
        self.s_name = QLineEdit()
        self.s_header = QLineEdit()
        self.s_title = QLineEdit()
        self.s_sub = QLineEdit()
        self.s_color = ColorButton()
        self.s_style = QComboBox()
        self.s_style.addItems(["box", "double", "rounded", "oval"])
        self.s_width = QDoubleSpinBox()
        self.s_width.setRange(20, 200)
        self.s_width.setSuffix(" mm")
        self.s_place = QLineEdit()
        self.s_datefmt = QComboBox()
        self.s_datefmt.setEditable(True)
        self.s_datefmt.addItems(["%d %b %Y", "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d %B %Y"])
        self.s_by = QLineEdit()
        self.s_numlab = QLineEdit()
        self.s_numsub = QLineEdit()
        self.s_prefix = QLineEdit()
        self.s_prefix.setPlaceholderText("e.g. AEU-REV-")
        self.s_auto = QCheckBox("Auto-increment number")
        self.s_bg = QCheckBox("White background (covers the drawing underneath)")
        self.s_bg.setToolTip("Off (default): the stamp is transparent and mixed like ink (Multiply), so the\n"
                             "drawing lines underneath stay readable. On: an opaque white box hides what is under the stamp.")
        self.s_opacity = QDoubleSpinBox()
        self.s_opacity.setRange(0.1, 1.0)
        self.s_opacity.setSingleStep(0.05)
        fl = QHBoxLayout()
        self.s_f = {}
        for k, lab in (("number", "Number"), ("by", "Checked by"), ("date", "Date"), ("place", "Place")):
            cb = QCheckBox(lab)
            self.s_f[k] = cb
            fl.addWidget(cb)
        f.addRow("Name", self.s_name)
        f.addRow("Header (company)", self.s_header)
        f.addRow("Title", self.s_title)
        f.addRow("Subtitle", self.s_sub)
        f.addRow("Colour", self.s_color)
        f.addRow("Border style", self.s_style)
        f.addRow("Width", self.s_width)
        f.addRow("Fields", fl)
        f.addRow("Number label", self.s_numlab)
        f.addRow("Number sub-label", self.s_numsub)
        f.addRow("Number prefix", self.s_prefix)
        f.addRow("", self.s_auto)
        f.addRow("Default place", self.s_place)
        f.addRow("Date format", self.s_datefmt)
        f.addRow("Checked by (default)", self.s_by)
        f.addRow("Opacity", self.s_opacity)
        f.addRow("", self.s_bg)
        right.addWidget(box)
        pv = QHBoxLayout()
        b = QPushButton(theme.icon("eye-outline"), "Update preview")
        b.clicked.connect(self._preview_stamp)
        pv.addWidget(b)
        pv.addStretch(1)
        right.addLayout(pv)
        self.s_preview = QLabel()
        self.s_preview.setAlignment(Qt.AlignCenter)
        self.s_preview.setMinimumHeight(215)
        self.s_preview.setStyleSheet("background:#F4F6FA;border:1px solid #D5DCE6;")
        right.addWidget(self.s_preview)
        h.addLayout(right, 3)
        return w

    def _fill_stamp_list(self):
        self._cur_stamp = -1
        self.stamp_list.blockSignals(True)
        self.stamp_list.clear()
        for s in self.stamps:
            self.stamp_list.addItem(QListWidgetItem(QIcon(stamp_thumbnail(s, 34)), s["name"]))
        self.stamp_list.blockSignals(False)
        if self.stamps:
            self.stamp_list.setCurrentRow(0)
            self._load_stamp(0)

    def _load_stamp(self, row):
        self._store_stamp()
        if row < 0 or row >= len(self.stamps):
            return
        self._cur_stamp = row
        s = self.stamps[row]
        self.s_name.setText(s.get("name", ""))
        self.s_header.setText(s.get("header", ""))
        self.s_title.setText(s.get("title", ""))
        self.s_sub.setText(s.get("subtitle", ""))
        self.s_color.set_rgb(s.get("color", RED))
        self.s_style.setCurrentText(s.get("style", "box"))
        self.s_width.setValue(float(s.get("width_mm", 62)))
        for k, cb in self.s_f.items():
            cb.setChecked(k in s.get("fields", []))
        self.s_numlab.setText(s.get("number_label", "Number :"))
        self.s_numsub.setText(s.get("number_sublabel", "Nomor"))
        self.s_prefix.setText(s.get("number_prefix", ""))
        self.s_auto.setChecked(bool(s.get("auto_number", True)))
        self.s_place.setText(s.get("place", ""))
        self.s_datefmt.setCurrentText(s.get("date_format", "%d %b %Y"))
        self.s_by.setText(s.get("by", ""))
        self.s_opacity.setValue(float(s.get("opacity", 1.0)))
        self.s_bg.setChecked(bool(s.get("background", False)))
        self._preview_stamp()

    def _store_stamp(self):
        row = getattr(self, "_cur_stamp", -1)
        if row < 0 or row >= len(self.stamps):
            return
        s = self.stamps[row]
        s.update({"name": self.s_name.text().strip() or "Stamp", "header": self.s_header.text(),
                  "title": self.s_title.text(), "subtitle": self.s_sub.text(), "color": self.s_color.rgb or RED,
                  "style": self.s_style.currentText(), "width_mm": self.s_width.value(),
                  "fields": [k for k, cb in self.s_f.items() if cb.isChecked()],
                  "number_label": self.s_numlab.text(), "number_sublabel": self.s_numsub.text(),
                  "number_prefix": self.s_prefix.text(), "auto_number": self.s_auto.isChecked(),
                  "place": self.s_place.text(), "date_format": self.s_datefmt.currentText(), "by": self.s_by.text(),
                  "opacity": self.s_opacity.value(), "background": self.s_bg.isChecked()})
        it = self.stamp_list.item(row)
        if it:
            it.setText(s["name"])
            it.setIcon(QIcon(stamp_thumbnail(s, 34)))

    def _preview_stamp(self):
        self._store_stamp()
        row = getattr(self, "_cur_stamp", -1)
        if 0 <= row < len(self.stamps):
            from .annots import render_stamp_image, stamp_values_default
            s = self.stamps[row]
            vals = stamp_values_default(s)
            vals["number"] = (s.get("number_prefix", "") + "0001") if "number" in s.get("fields", []) else ""
            img = render_stamp_image(s, vals, dpi=150)
            self.s_preview.setPixmap(QPixmap.fromImage(img).scaled(380, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def new_stamp(self):
        self._store_stamp()
        self.stamps.append(_s("New stamp", "CHECKED", "DIPERIKSA", BLUE))
        self._cur_stamp = -1
        self._fill_stamp_list()
        self.stamp_list.setCurrentRow(len(self.stamps) - 1)

    def dup_stamp(self):
        self._store_stamp()
        row = self.stamp_list.currentRow()
        if row < 0:
            return
        s = copy.deepcopy(self.stamps[row])
        s["id"] = uuid.uuid4().hex[:10]
        s["name"] += " (copy)"
        self.stamps.insert(row + 1, s)
        self._cur_stamp = -1
        self._fill_stamp_list()
        self.stamp_list.setCurrentRow(row + 1)

    def del_stamp(self):
        row = self.stamp_list.currentRow()
        if row >= 0:
            self.stamps.pop(row)
            self._cur_stamp = -1
            self._fill_stamp_list()

    # --------------------------------------------------------------- common
    def accept_save(self):
        self._store_tool()
        self._store_stamp()
        self.st.tools = self.tools
        self.st.stamps = self.stamps
        self.st.save()
        self.accept()

    def do_export(self):
        self._store_tool()
        self._store_stamp()
        path, _ = QFileDialog.getSaveFileName(self, "Export templates", "Alief_Comment_Templates.json", "JSON (*.json)")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"tools": self.tools, "stamps": self.stamps}, f, indent=1)

    def do_import(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import templates", "", "JSON (*.json)")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception as e:
            QMessageBox.warning(self, "Import", str(e))
            return
        ids = {t["id"] for t in self.tools}
        self.tools += [t for t in d.get("tools", []) if t.get("id") not in ids]
        ids = {s["id"] for s in self.stamps}
        self.stamps += [s for s in d.get("stamps", []) if s.get("id") not in ids]
        self._cur_tool = self._cur_stamp = -1
        self._fill_tool_list()
        self._fill_stamp_list()

    def restore_defaults(self):
        if QMessageBox.question(self, "Restore defaults", "Replace all styles and stamps with the defaults?") == QMessageBox.Yes:
            self.tools, self.stamps = default_tools(), default_stamps()
            self._cur_tool = self._cur_stamp = -1
            self._fill_tool_list()
            self._fill_stamp_list()


class StampValuesDialog(QDialog):
    """Asks the dynamic fields (number / date / place / by) when placing a stamp."""

    def __init__(self, stamp, number, parent=None):
        super().__init__(parent)
        from .annots import stamp_values_default, render_stamp_image
        self.stamp = stamp
        self.setWindowTitle("Stamp - " + stamp.get("name", ""))
        lay = QVBoxLayout(self)
        f = QFormLayout()
        vals = stamp_values_default(stamp)
        fields = stamp.get("fields", [])
        self.e_num = QLineEdit(stamp.get("number_prefix", "") + (str(number).zfill(4) if stamp.get("auto_number", True) else ""))
        self.e_date = QLineEdit(vals["date"])
        self.e_place = QLineEdit(vals["place"])
        self.e_by = QLineEdit(vals["by"])
        self.e_note = QLineEdit()
        self.e_note.setPlaceholderText("Optional comment text stored with the stamp")
        if "number" in fields:
            f.addRow("Number", self.e_num)
        if "by" in fields:
            f.addRow("Checked by", self.e_by)
        if "date" in fields:
            f.addRow("Date", self.e_date)
        if "place" in fields:
            f.addRow("Place", self.e_place)
        f.addRow("Comment", self.e_note)
        lay.addLayout(f)
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.preview)
        for e in (self.e_num, self.e_date, self.e_place, self.e_by):
            e.textChanged.connect(self._upd)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self._upd()

    def values(self):
        return {"number": self.e_num.text(), "date": self.e_date.text(), "place": self.e_place.text(), "by": self.e_by.text()}

    def _upd(self):
        from .annots import render_stamp_image
        img = render_stamp_image(self.stamp, self.values(), dpi=120)
        self.preview.setPixmap(QPixmap.fromImage(img).scaled(360, 180, Qt.KeepAspectRatio, Qt.SmoothTransformation))
