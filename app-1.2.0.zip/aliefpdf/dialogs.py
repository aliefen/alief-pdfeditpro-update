"""Dialogs: text input, conversion, password remover, protection, page tools, preferences."""
import os
import traceback

import pymupdf
from PySide6.QtCore import Qt, QThread, Signal, QSize, QTimer
from PySide6.QtGui import QColor, QIcon, QPixmap, QFont
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QLabel, QLineEdit,
                               QPlainTextEdit, QDoubleSpinBox, QSpinBox, QComboBox, QCheckBox, QPushButton,
                               QDialogButtonBox, QFileDialog, QMessageBox, QProgressDialog, QTableWidget,
                               QTableWidgetItem, QHeaderView, QGroupBox, QRadioButton, QListWidget, QListWidgetItem,
                               QAbstractItemView, QApplication, QTabWidget, QWidget, QInputDialog, QButtonGroup,
                               QColorDialog, QSizePolicy)

from . import theme, APP_NAME, VERSION, COMPANY
from .settings import settings, parse_page_range


# ================================================================ helpers
class Worker(QThread):
    progressed = Signal(int, int, str)
    succeeded = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, *args, **kw):
        super().__init__()
        self.fn, self.args, self.kw = fn, args, kw
        self.cancelled = False

    def progress(self, i, n, msg=""):
        self.progressed.emit(i, n, msg)
        return not self.cancelled

    def run(self):
        try:
            res = self.fn(*self.args, progress=self.progress, **self.kw)
            self.succeeded.emit(res)
        except Exception as e:
            from .convert import Cancelled
            if isinstance(e, Cancelled):
                self.failed.emit("Cancelled")
            else:
                self.failed.emit("%s\n\n%s" % (e, traceback.format_exc(limit=3)))


def run_with_progress(parent, title, fn, *args, **kw):
    """Run fn(..., progress=cb) in a thread with a progress dialog. Returns result or None."""
    dlg = QProgressDialog(title, "Cancel", 0, 100, parent)
    dlg.setWindowTitle(APP_NAME)
    dlg.setWindowModality(Qt.WindowModal)
    dlg.setMinimumDuration(200)
    dlg.setMinimumWidth(420)
    w = Worker(fn, *args, **kw)
    out = {}

    def prog(i, n, msg):
        dlg.setMaximum(max(1, n))
        dlg.setValue(min(i, max(1, n)))
        if msg:
            dlg.setLabelText("%s\n%s" % (title, msg))

    w.progressed.connect(prog)
    w.succeeded.connect(lambda r: out.setdefault("ok", r))
    w.failed.connect(lambda m: out.setdefault("err", m))
    dlg.canceled.connect(lambda: setattr(w, "cancelled", True))
    w.start()
    while w.isRunning():
        QApplication.processEvents()
        w.wait(30)
    QApplication.processEvents()
    dlg.close()
    if "err" in out:
        if out["err"] != "Cancelled":
            QMessageBox.warning(parent, title, out["err"])
        return None
    return out.get("ok")


def detached_copy(pdfdoc):
    """Independent pymupdf.Document copy for worker threads."""
    data = pdfdoc.doc.tobytes(garbage=0)
    d = pymupdf.open("pdf", data)
    if d.needs_pass and pdfdoc.password:
        d.authenticate(pdfdoc.password)
    return d


def ask_password(parent, filename, attempt=0):
    msg = "<b>%s</b> is protected with an open password.<br>Enter the password:" % os.path.basename(filename)
    if attempt:
        msg = "<span style='color:#C62828'>Wrong password, try again.</span><br>" + msg
    dlg = QInputDialog(parent)
    dlg.setWindowTitle("Password required")
    dlg.setLabelText(msg)
    dlg.setTextEchoMode(QLineEdit.Password)
    if dlg.exec():
        return dlg.textValue()
    return None


def ask_crop_scope(parent, n):
    if n == 1:
        return "page"
    box = QMessageBox(parent)
    box.setWindowTitle("Crop pages")
    box.setText("Apply this crop box to:")
    b1 = box.addButton("This page", QMessageBox.AcceptRole)
    b2 = box.addButton("All pages", QMessageBox.AcceptRole)
    box.addButton(QMessageBox.Cancel)
    box.exec()
    if box.clickedButton() == b1:
        return "page"
    if box.clickedButton() == b2:
        return "all"
    return None


def pages_row(n, current=0):
    """(widget, getter) for an 'All / Current / Range' page selector."""
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    cb = QComboBox()
    cb.addItems(["All pages (%d)" % n, "Current page (%d)" % (current + 1), "Pages…"])
    ed = QLineEdit()
    ed.setPlaceholderText("e.g. 1-3, 6, 9-")
    ed.setEnabled(False)
    cb.currentIndexChanged.connect(lambda k: ed.setEnabled(k == 2))
    h.addWidget(cb)
    h.addWidget(ed, 1)

    def get():
        k = cb.currentIndex()
        if k == 0:
            return list(range(n))
        if k == 1:
            return [current]
        return parse_page_range(ed.text(), n)
    return w, get


# ============================================================== comments
class CommentTextDialog(QDialog):
    def __init__(self, parent, title, text="", fontsize=10):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(420, 220)
        lay = QVBoxLayout(self)
        self.ed = QPlainTextEdit(text or "")
        self.ed.setPlaceholderText("Type the comment / remark…")
        lay.addWidget(self.ed)
        self.fs = None
        if fontsize is not None:
            row = QHBoxLayout()
            row.addWidget(QLabel("Font size"))
            self.fs = QDoubleSpinBox()
            self.fs.setRange(4, 96)
            self.fs.setValue(float(fontsize))
            row.addWidget(self.fs)
            row.addStretch(1)
            lay.addLayout(row)
        lay.addWidget(QLabel("<span style='color:#5B6675'>Author: %s</span>" % settings().get("author")))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.ed.setFocus()

    def result_text(self):
        return self.ed.toPlainText(), (self.fs.value() if self.fs else None)


class BalloonDialog(QDialog):
    def __init__(self, parent, n, text=""):
        super().__init__(parent)
        self.setWindowTitle("Remark balloon")
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.num = QLineEdit(str(n))
        self.txt = QPlainTextEdit(text or "")
        self.txt.setPlaceholderText("Remark text for this balloon (shown in the comment list and summary)")
        f.addRow("Number", self.num)
        f.addRow("Remark", self.txt)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.resize(420, 220)
        self.txt.setFocus()

    def values(self):
        return self.num.text().strip() or "1", self.txt.toPlainText()


class AddTextDialog(QDialog):
    FONTS = [("Helvetica", "helv"), ("Helvetica Bold", "hebo"), ("Times", "tiro"), ("Times Bold", "tibo"),
             ("Courier", "cour"), ("Courier Bold", "cobo")]

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Add text to page")
        lay = QVBoxLayout(self)
        self.ed = QPlainTextEdit()
        lay.addWidget(self.ed)
        row = QHBoxLayout()
        self.font = QComboBox()
        for n, _ in self.FONTS:
            self.font.addItem(n)
        self.size = QDoubleSpinBox()
        self.size.setRange(4, 200)
        self.size.setValue(10)
        from .templates import ColorButton
        self.color = ColorButton([0, 0, 0])
        row.addWidget(self.font)
        row.addWidget(self.size)
        row.addWidget(self.color)
        lay.addLayout(row)
        lay.addWidget(QLabel("<span style='color:#5B6675'>The text becomes part of the page content (not a comment).</span>"))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def values(self):
        return self.ed.toPlainText(), self.FONTS[self.font.currentIndex()][1], self.size.value(), tuple(self.color.rgb or (0, 0, 0))


# ============================================================== convert
class ConvertDialog(QDialog):
    def __init__(self, main, pdfdoc, fmt, current_page=0):
        super().__init__(main)
        from .convert import FORMATS
        self.main = main
        self.pdfdoc = pdfdoc
        self.fmt = fmt
        label, ext, flt = FORMATS[fmt]
        self.setWindowTitle("Convert PDF to " + label)
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.pages_w, self.pages_get = pages_row(pdfdoc.page_count, current_page)
        f.addRow("Pages", self.pages_w)
        base = os.path.splitext(pdfdoc.path or pdfdoc.title)[0]
        folder = settings().get("last_save_dir") or (os.path.dirname(pdfdoc.path) if pdfdoc.path else os.path.expanduser("~"))
        self.out = QLineEdit(os.path.join(folder, os.path.basename(base) + "." + ext))
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self._browse(flt))
        row = QHBoxLayout()
        row.addWidget(self.out)
        row.addWidget(b)
        f.addRow("Output file", row)
        self.opts = {}
        if fmt == "word":
            cb = QComboBox()
            cb.addItems(["Editable - flowing text, tables and images (recommended)", "Exact look - each page as a picture"])
            self.opts["mode"] = cb
            f.addRow("Layout", cb)
        elif fmt == "excel":
            cb = QComboBox()
            cb.addItems(["One sheet per page", "One sheet per table", "All pages in one sheet"])
            self.opts["layout"] = cb
            d = QComboBox()
            d.addItems(["Auto (ruled tables, then text columns)", "Ruled tables only", "Text columns only"])
            self.opts["detect"] = d
            f.addRow("Sheets", cb)
            f.addRow("Table detection", d)
        elif fmt in ("jpg", "png", "tiff", "bmp", "pptx"):
            dpi = QSpinBox()
            dpi.setRange(36, 1200)
            dpi.setValue(200 if fmt != "tiff" else 300)
            dpi.setSuffix(" dpi")
            self.opts["dpi"] = dpi
            f.addRow("Resolution", dpi)
            if fmt == "jpg":
                q = QSpinBox()
                q.setRange(10, 100)
                q.setValue(92)
                self.opts["quality"] = q
                f.addRow("JPEG quality", q)
            if fmt != "pptx":
                g = QCheckBox("Grayscale")
                self.opts["gray"] = g
                f.addRow("", g)
        elif fmt == "dxf":
            from .measure import get_scale, UNIT_TO_M, PT_TO_M
            s = get_scale(pdfdoc, current_page)
            self.scale_label = QLabel()
            self.ratio = QDoubleSpinBox()
            self.ratio.setRange(0.001, 1e7)
            self.ratio.setDecimals(3)
            self.ratio.setValue(round(s["m_per_pt"] / PT_TO_M, 6))
            self.opts["ratio"] = self.ratio
            u = QComboBox()
            u.addItems(list(UNIT_TO_M.keys()))
            u.setCurrentText("mm")
            self.opts["unit"] = u
            row2 = QHBoxLayout()
            row2.addWidget(QLabel("1 :"))
            row2.addWidget(self.ratio)
            row2.addWidget(QLabel("  DXF units"))
            row2.addWidget(u)
            f.addRow("Drawing scale", row2)
            f.addRow("", QLabel("<span style='color:#5B6675'>Scale taken from the measurement scale of the page (%s). "
                                "Geometry is written in real size, e.g. 1:115 + mm → hull length in mm.</span>" % s.get("label", "")))
            for key, txt, val in (("text", "Export text as TEXT entities", True), ("join", "Join connected lines into polylines", True),
                                  ("circles", "Recognise circles", True), ("images", "Export raster images (PNG beside the DXF)", False)):
                c = QCheckBox(txt)
                c.setChecked(val)
                self.opts[key] = c
                f.addRow("", c)
            fl = QComboBox()
            fl.addItems(["Solid fills as HATCH", "Ignore fills"])
            self.opts["fills"] = fl
            ly = QComboBox()
            ly.addItems(["Layer per colour", "PDF layers (OCG)", "Single layer"])
            self.opts["layers"] = ly
            one = QComboBox()
            one.addItems(["All pages in one DXF (side by side)", "One DXF per page"])
            self.opts["one_file"] = one
            f.addRow("Fills", fl)
            f.addRow("Layers", ly)
            f.addRow("Pages to files", one)
        elif fmt == "txt":
            c = QCheckBox("Keep column layout (tab separated)")
            c.setChecked(True)
            self.opts["keep_layout"] = c
            f.addRow("", c)
        elif fmt == "svg":
            c = QCheckBox("Convert text to outlines")
            self.opts["text_as_path"] = c
            f.addRow("", c)
        lay.addLayout(f)
        self.open_after = QCheckBox("Open the result when finished")
        self.open_after.setChecked(True)
        lay.addWidget(self.open_after)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Convert")
        bb.accepted.connect(self.run)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _browse(self, flt):
        p, _ = QFileDialog.getSaveFileName(self, "Save as", self.out.text(), flt)
        if p:
            self.out.setText(p)

    def run(self):
        from . import convert as C
        pages = self.pages_get()
        if not pages:
            QMessageBox.warning(self, "Convert", "No pages selected.")
            return
        out = self.out.text().strip()
        if not out:
            return
        os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
        settings().set("last_save_dir", os.path.dirname(os.path.abspath(out)))
        settings().save()
        o = self.opts
        fmt = self.fmt
        kw = {}
        if fmt == "word":
            fn, kw = C.to_word, {"mode": "flow" if o["mode"].currentIndex() == 0 else "exact"}
        elif fmt == "excel":
            fn, kw = C.to_excel, {"layout": ["sheet_per_page", "sheet_per_table", "one_sheet"][o["layout"].currentIndex()],
                                  "detect": ["auto", "lines", "text"][o["detect"].currentIndex()]}
        elif fmt == "csv":
            fn = C.to_csv
        elif fmt in ("jpg", "png", "tiff", "bmp"):
            fn, kw = C.to_images, {"fmt": {"tiff": "tif"}.get(fmt, fmt), "dpi": o["dpi"].value(), "gray": o["gray"].isChecked()}
            if fmt == "jpg":
                kw["quality"] = o["quality"].value()
        elif fmt == "pptx":
            fn, kw = C.to_pptx, {"dpi": o["dpi"].value()}
        elif fmt == "dxf":
            from .measure import PT_TO_M
            fn, kw = C.to_dxf, {"scale_m_per_pt": o["ratio"].value() * PT_TO_M, "unit": o["unit"].currentText(),
                                "text": o["text"].isChecked(), "join": o["join"].isChecked(),
                                "circles": o["circles"].isChecked(), "images": o["images"].isChecked(),
                                "fills": "hatch" if o["fills"].currentIndex() == 0 else "none",
                                "layers": ["color", "ocg", "single"][o["layers"].currentIndex()],
                                "one_file": o["one_file"].currentIndex() == 0}
        elif fmt == "svg":
            fn, kw = C.to_svg, {"text_as_path": o["text_as_path"].isChecked()}
        elif fmt == "txt":
            fn, kw = C.to_text, {"keep_layout": o["keep_layout"].isChecked()}
        elif fmt == "html":
            fn = C.to_html
        else:
            return
        doc = detached_copy(self.pdfdoc)
        if fmt == "word" and kw.get("mode") == "flow" and self.pdfdoc.path and not self.pdfdoc.modified and not self.pdfdoc.password:
            doc.close()
            doc = pymupdf.open(self.pdfdoc.path)
        res = run_with_progress(self, "Converting to %s…" % C.FORMATS[fmt][0], fn, doc, pages, out, **kw)
        doc.close()
        if res:
            self.results = res
            self.accept()
            if self.open_after.isChecked():
                from PySide6.QtGui import QDesktopServices
                from PySide6.QtCore import QUrl
                QDesktopServices.openUrl(QUrl.fromLocalFile(res[0]))
            elif self.main:
                self.main.status("Saved %d file(s): %s" % (len(res), res[0]))


class BatchConvertDialog(QDialog):
    """Convert many PDF files at once."""

    def __init__(self, main):
        super().__init__(main)
        from .convert import FORMATS
        self.setWindowTitle("Batch convert PDF files")
        self.resize(640, 460)
        lay = QVBoxLayout(self)
        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        lay.addWidget(self.list)
        row = QHBoxLayout()
        for txt, fn in (("Add files…", self.add), ("Add folder…", self.add_folder), ("Remove", self.remove)):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        f = QFormLayout()
        self.fmt = QComboBox()
        for k, (lab, ext, _) in FORMATS.items():
            self.fmt.addItem("%s (*.%s)" % (lab, ext), k)
        self.outdir = QLineEdit(settings().get("last_save_dir") or os.path.expanduser("~"))
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self.outdir.setText(QFileDialog.getExistingDirectory(self, "Output folder", self.outdir.text()) or self.outdir.text()))
        r2 = QHBoxLayout()
        r2.addWidget(self.outdir)
        r2.addWidget(b)
        self.same = QCheckBox("Save next to each source file")
        f.addRow("Convert to", self.fmt)
        f.addRow("Output folder", r2)
        f.addRow("", self.same)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Close)
        bb.button(QDialogButtonBox.Ok).setText("Convert all")
        bb.accepted.connect(self.run)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            p = u.toLocalFile()
            if p.lower().endswith(".pdf"):
                self.list.addItem(p)

    def add(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "PDF files", settings().get("last_dir", ""), "PDF (*.pdf)")
        for p in fs:
            self.list.addItem(p)

    def add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder with PDF files", settings().get("last_dir", ""))
        if d:
            for fn in sorted(os.listdir(d)):
                if fn.lower().endswith(".pdf"):
                    self.list.addItem(os.path.join(d, fn))

    def remove(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))

    def run(self):
        from . import convert as C
        files = [self.list.item(k).text() for k in range(self.list.count())]
        if not files:
            return
        fmt = self.fmt.currentData()
        ext = C.FORMATS[fmt][1]
        fnmap = {"word": C.to_word, "excel": C.to_excel, "csv": C.to_csv, "dxf": C.to_dxf, "svg": C.to_svg,
                 "txt": C.to_text, "html": C.to_html, "pptx": C.to_pptx}

        def job(progress=None):
            done = []
            for k, path in enumerate(files):
                if progress(k, len(files), os.path.basename(path)) is False:
                    break
                doc = pymupdf.open(path)
                if doc.needs_pass:
                    doc.close()
                    done.append((path, "skipped (open password)"))
                    continue
                folder = os.path.dirname(path) if self.same.isChecked() else self.outdir.text()
                out = os.path.join(folder, os.path.splitext(os.path.basename(path))[0] + "." + ext)
                pages = list(range(doc.page_count))
                try:
                    if fmt in ("jpg", "png", "tiff", "bmp"):
                        C.to_images(doc, pages, out, fmt={"tiff": "tif"}.get(fmt, fmt))
                    else:
                        fnmap[fmt](doc, pages, out)
                    done.append((path, "OK"))
                except Exception as e:
                    done.append((path, "error: %s" % e))
                doc.close()
            progress(len(files), len(files), "Done")
            return done

        res = run_with_progress(self, "Batch conversion", job)
        if res:
            ok = sum(1 for _, s in res if s == "OK")
            QMessageBox.information(self, "Batch conversion", "%d of %d files converted.\n\n%s" % (
                ok, len(res), "\n".join("%s: %s" % (os.path.basename(p), s) for p, s in res if s != "OK")[:2000]))


# =========================================================== password remover
class PasswordRemoverDialog(QDialog):
    """Batch remover for PDF restrictions (owner passwords) and known open passwords."""

    def __init__(self, main, files=None):
        super().__init__(main)
        self.setWindowTitle("PDF Password / Restriction Remover")
        self.resize(820, 480)
        lay = QVBoxLayout(self)
        head = QLabel("<b>Remove PDF security</b><br><span style='color:#5B6675'>Files that only restrict printing, copying or "
                      "editing are unlocked instantly. Files with an <i>open password</i> need that password. The original "
                      "files are kept unless you choose to overwrite them.</span>")
        head.setWordWrap(True)
        lay.addWidget(head)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["File", "Security", "Pages", "Result"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        lay.addWidget(self.table)
        row = QHBoxLayout()
        for txt, fn, ic in (("Add files…", self.add, "file-plus-outline"), ("Add folder…", self.add_folder, "folder-open"),
                            ("Remove", self.remove, "close"), ("Clear", lambda: self.table.setRowCount(0), "delete-outline")):
            b = QPushButton(theme.icon(ic), txt)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        f = QFormLayout()
        self.pw = QLineEdit()
        self.pw.setEchoMode(QLineEdit.Password)
        self.pw.setPlaceholderText("Only needed for files with an open password")
        f.addRow("Open password", self.pw)
        self.out_mode = QComboBox()
        self.out_mode.addItems(["Save as <name>_unlocked.pdf next to the original", "Save into folder…",
                                "Overwrite original (keeps <name>.pdf.bak)"])
        self.outdir = QLineEdit(settings().get("last_save_dir") or "")
        self.outdir.setEnabled(False)
        self.out_mode.currentIndexChanged.connect(lambda k: self.outdir.setEnabled(k == 1))
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self.outdir.setText(QFileDialog.getExistingDirectory(self, "Output folder", self.outdir.text()) or self.outdir.text()))
        r2 = QHBoxLayout()
        r2.addWidget(self.outdir)
        r2.addWidget(b)
        f.addRow("Output", self.out_mode)
        f.addRow("Folder", r2)
        lay.addLayout(f)
        bb = QHBoxLayout()
        bb.addStretch(1)
        go = QPushButton(theme.icon("lock-open-variant-outline", color="white"), "  Remove security")
        go.setObjectName("Primary")
        go.setDefault(True)
        go.clicked.connect(self.run)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        bb.addWidget(go)
        bb.addWidget(close)
        lay.addLayout(bb)
        self.setAcceptDrops(True)
        for p in files or []:
            self._add_path(p)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            p = u.toLocalFile()
            if os.path.isdir(p):
                for fn in sorted(os.listdir(p)):
                    if fn.lower().endswith(".pdf"):
                        self._add_path(os.path.join(p, fn))
            elif p.lower().endswith(".pdf"):
                self._add_path(p)

    def _add_path(self, p):
        from .security import inspect
        info = inspect(p)
        r = self.table.rowCount()
        self.table.insertRow(r)
        it = QTableWidgetItem(p)
        it.setData(Qt.UserRole, p)
        self.table.setItem(r, 0, it)
        st = QTableWidgetItem(info["status"] + ((" - " + info["method"]) if info.get("method") else ""))
        col = {"Not protected": "#2E7D32", "Open password required": "#C62828"}.get(info["status"], "#E65100")
        st.setForeground(QColor(col))
        self.table.setItem(r, 1, st)
        self.table.setItem(r, 2, QTableWidgetItem(str(info.get("pages") or "")))
        self.table.setItem(r, 3, QTableWidgetItem(""))

    def add(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "PDF files", settings().get("last_dir", ""), "PDF (*.pdf)")
        for p in fs:
            self._add_path(p)

    def add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder", settings().get("last_dir", ""))
        if d:
            for fn in sorted(os.listdir(d)):
                if fn.lower().endswith(".pdf"):
                    self._add_path(os.path.join(d, fn))

    def remove(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.table.removeRow(r)

    def run(self):
        from .security import remove_security
        mode = self.out_mode.currentIndex()
        pw = self.pw.text() or None
        n_ok = 0
        for r in range(self.table.rowCount()):
            p = self.table.item(r, 0).data(Qt.UserRole)
            base, ext = os.path.splitext(p)
            if mode == 0:
                out = base + "_unlocked.pdf"
            elif mode == 1:
                d = self.outdir.text() or os.path.dirname(p)
                os.makedirs(d, exist_ok=True)
                out = os.path.join(d, os.path.basename(p))
            else:
                out = p
            ok, msg = remove_security(p, out, pw)
            n_ok += ok
            it = QTableWidgetItem(("✔ " if ok else "✖ ") + msg + (("  →  " + out) if ok and out != p else ""))
            it.setForeground(QColor("#2E7D32" if ok else "#C62828"))
            self.table.setItem(r, 3, it)
            QApplication.processEvents()
        QMessageBox.information(self, "Remove security", "%d of %d file(s) processed successfully." % (n_ok, self.table.rowCount()))


class ProtectDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.setWindowTitle("Protect PDF (password & permissions)")
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.user = QLineEdit()
        self.user.setEchoMode(QLineEdit.Password)
        self.user.setPlaceholderText("leave empty = anyone can open")
        self.owner = QLineEdit()
        self.owner.setEchoMode(QLineEdit.Password)
        self.owner.setPlaceholderText("password to change permissions")
        self.method = QComboBox()
        self.method.addItems(["AES-256", "AES-128", "RC4-128"])
        f.addRow("Open password", self.user)
        f.addRow("Permissions password", self.owner)
        f.addRow("Encryption", self.method)
        lay.addLayout(f)
        box = QGroupBox("Allow")
        g = QGridLayout(box)
        self.perm = {}
        items = [("Print", pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_PRINT_HQ, True), ("Copy text / images", pymupdf.PDF_PERM_COPY, False),
                 ("Modify document", pymupdf.PDF_PERM_MODIFY, False), ("Add comments", pymupdf.PDF_PERM_ANNOTATE, False),
                 ("Fill forms", pymupdf.PDF_PERM_FORM, True), ("Assemble (insert / rotate pages)", pymupdf.PDF_PERM_ASSEMBLE, False)]
        for k, (txt, val, on) in enumerate(items):
            cb = QCheckBox(txt)
            cb.setChecked(on)
            self.perm[val] = cb
            g.addWidget(cb, k // 2, k % 2)
        lay.addWidget(box)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _ok(self):
        if not self.user.text() and not self.owner.text():
            QMessageBox.warning(self, "Protect", "Enter an open password and/or a permissions password.")
            return
        self.accept()

    def values(self):
        perms = pymupdf.PDF_PERM_ACCESSIBILITY
        for v, cb in self.perm.items():
            if cb.isChecked():
                perms |= v
        return self.user.text(), self.owner.text(), perms, self.method.currentText()


# ============================================================ page dialogs
class WatermarkDialog(QDialog):
    def __init__(self, main, n, current):
        super().__init__(main)
        self.setWindowTitle("Add watermark")
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.kind = QComboBox()
        self.kind.addItems(["Text", "Image"])
        self.text = QLineEdit("CONFIDENTIAL")
        self.img = QLineEdit()
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self.img.setText(QFileDialog.getOpenFileName(self, "Image", "", "Images (*.png *.jpg *.jpeg *.bmp)")[0] or self.img.text()))
        r = QHBoxLayout()
        r.addWidget(self.img)
        r.addWidget(b)
        self.size = QDoubleSpinBox()
        self.size.setRange(6, 400)
        self.size.setValue(72)
        from .templates import ColorButton
        self.color = ColorButton([0.85, 0.1, 0.1])
        self.opacity = QDoubleSpinBox()
        self.opacity.setRange(0.03, 1.0)
        self.opacity.setSingleStep(0.05)
        self.opacity.setValue(0.22)
        self.angle = QSpinBox()
        self.angle.setRange(-180, 180)
        self.angle.setValue(45)
        self.scale = QDoubleSpinBox()
        self.scale.setRange(0.05, 1.0)
        self.scale.setValue(0.5)
        self.front = QComboBox()
        self.front.addItems(["In front of page content", "Behind page content"])
        self.pages_w, self.pages_get = pages_row(n, current)
        f.addRow("Type", self.kind)
        f.addRow("Text", self.text)
        f.addRow("Image file", r)
        f.addRow("Font size", self.size)
        f.addRow("Colour", self.color)
        f.addRow("Opacity", self.opacity)
        f.addRow("Angle (°)", self.angle)
        f.addRow("Image width (× page)", self.scale)
        f.addRow("Position", self.front)
        f.addRow("Pages", self.pages_w)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class HeaderFooterDialog(QDialog):
    def __init__(self, main, n, current):
        super().__init__(main)
        self.setWindowTitle("Header / Footer / Page numbers")
        lay = QVBoxLayout(self)
        g = QGridLayout()
        self.slots = {}
        g.addWidget(QLabel("Left"), 0, 1)
        g.addWidget(QLabel("Centre"), 0, 2)
        g.addWidget(QLabel("Right"), 0, 3)
        for r, (lab, key) in enumerate((("Header", "t"), ("Footer", "b")), start=1):
            g.addWidget(QLabel(lab), r, 0)
            for c, pos in enumerate("lcr", start=1):
                e = QLineEdit()
                self.slots[key + pos] = e
                g.addWidget(e, r, c)
        self.slots["br"].setText("Page <<page>> of <<pages>>")
        lay.addLayout(g)
        lay.addWidget(QLabel("<span style='color:#5B6675'>Tokens: &lt;&lt;page&gt;&gt; &lt;&lt;pages&gt;&gt; &lt;&lt;date&gt;&gt; "
                             "&lt;&lt;time&gt;&gt; &lt;&lt;file&gt;&gt;</span>"))
        f = QFormLayout()
        self.size = QDoubleSpinBox()
        self.size.setRange(4, 48)
        self.size.setValue(8)
        self.margin = QDoubleSpinBox()
        self.margin.setRange(0, 100)
        self.margin.setValue(8)
        self.margin.setSuffix(" mm")
        self.start = QSpinBox()
        self.start.setRange(-9999, 99999)
        self.start.setValue(1)
        from .templates import ColorButton
        self.color = ColorButton([0, 0, 0])
        self.pages_w, self.pages_get = pages_row(n, current)
        f.addRow("Font size", self.size)
        f.addRow("Margin", self.margin)
        f.addRow("First page number", self.start)
        f.addRow("Colour", self.color)
        f.addRow("Pages", self.pages_w)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class MergeDialog(QDialog):
    def __init__(self, main, files=None):
        super().__init__(main)
        self.setWindowTitle("Combine files into one PDF")
        self.resize(560, 420)
        lay = QVBoxLayout(self)
        self.list = QListWidget()
        self.list.setDragDropMode(QAbstractItemView.InternalMove)
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        for p in files or []:
            self.list.addItem(p)
        lay.addWidget(QLabel("Drag to change the order. PDF, images, XPS and EPUB files can be combined."))
        lay.addWidget(self.list)
        row = QHBoxLayout()
        for txt, fn in (("Add files…", self.add), ("Remove", self.remove), ("Sort A–Z", self.sort)):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        self.bm = QCheckBox("Create a bookmark for each file")
        self.bm.setChecked(True)
        lay.addWidget(self.bm)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Combine…")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                self.list.addItem(u.toLocalFile())

    def add(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "Files", settings().get("last_dir", ""),
                                             "Documents (*.pdf *.png *.jpg *.jpeg *.tif *.tiff *.bmp *.xps *.epub);;All files (*)")
        for p in fs:
            self.list.addItem(p)

    def remove(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))

    def sort(self):
        self.list.sortItems()

    def files(self):
        return [self.list.item(k).text() for k in range(self.list.count())]


class SplitDialog(QDialog):
    def __init__(self, main, pdfdoc):
        super().__init__(main)
        self.setWindowTitle("Split document")
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.mode = QComboBox()
        self.mode.addItems(["Every N pages", "By page ranges", "By top-level bookmarks"])
        self.n = QSpinBox()
        self.n.setRange(1, 100000)
        self.n.setValue(1)
        self.ranges = QLineEdit()
        self.ranges.setPlaceholderText("e.g. 1-3, 4-10, 11-")
        folder = os.path.dirname(pdfdoc.path) if pdfdoc.path else os.path.expanduser("~")
        self.out = QLineEdit(os.path.join(folder, os.path.splitext(pdfdoc.title)[0] + "_split"))
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self.out.setText(QFileDialog.getExistingDirectory(self, "Output folder", self.out.text()) or self.out.text()))
        r = QHBoxLayout()
        r.addWidget(self.out)
        r.addWidget(b)
        f.addRow("Split", self.mode)
        f.addRow("Pages per file", self.n)
        f.addRow("Ranges", self.ranges)
        f.addRow("Output folder", r)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class InsertPagesDialog(QDialog):
    def __init__(self, main, n, current):
        super().__init__(main)
        self.setWindowTitle("Insert pages")
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.src = QComboBox()
        self.src.addItems(["Blank page(s)", "From file…"])
        self.count = QSpinBox()
        self.count.setRange(1, 999)
        self.size = QComboBox()
        self.size.addItems(["Same as current page", "A4 portrait", "A4 landscape", "A3 portrait", "A3 landscape", "A2 landscape", "A1 landscape"])
        self.file = QLineEdit()
        b = QPushButton("…")
        b.setFixedWidth(30)
        b.setStyleSheet("padding:2px 4px;")
        b.clicked.connect(lambda: self.file.setText(QFileDialog.getOpenFileName(self, "File", settings().get("last_dir", ""),
                                                                                "Documents (*.pdf *.png *.jpg *.jpeg *.tif *.tiff *.xps *.epub)")[0] or self.file.text()))
        r = QHBoxLayout()
        r.addWidget(self.file)
        r.addWidget(b)
        self.frange = QLineEdit()
        self.frange.setPlaceholderText("all pages")
        self.where = QComboBox()
        self.where.addItems(["After current page (%d)" % (current + 1), "Before current page", "At the end", "At the beginning"])
        f.addRow("Insert", self.src)
        f.addRow("Number of pages", self.count)
        f.addRow("Page size", self.size)
        f.addRow("File", r)
        f.addRow("Pages of file", self.frange)
        f.addRow("Position", self.where)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.n, self.current = n, current

    def position(self):
        k = self.where.currentIndex()
        return [self.current + 1, self.current, self.n, 0][k]

    def page_size(self):
        k = self.size.currentIndex()
        if k == 0:
            return None, None
        name = ["", "a4", "a4-l", "a3", "a3-l", "a2-l", "a1-l"][k]
        return pymupdf.paper_size(name)


class OptimizeDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.setWindowTitle("Optimize / reduce file size")
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.dpi = QSpinBox()
        self.dpi.setRange(0, 1200)
        self.dpi.setValue(150)
        self.dpi.setSpecialValueText("keep images")
        self.dpi.setSuffix(" dpi")
        self.q = QSpinBox()
        self.q.setRange(10, 100)
        self.q.setValue(75)
        self.fonts = QCheckBox("Subset embedded fonts")
        self.fonts.setChecked(True)
        self.meta = QCheckBox("Remove metadata")
        f.addRow("Downsample images to", self.dpi)
        f.addRow("JPEG quality", self.q)
        f.addRow("", self.fonts)
        f.addRow("", self.meta)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class PreferencesDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.setWindowTitle("Preferences")
        s = settings()
        lay = QVBoxLayout(self)
        f = QFormLayout()
        self.author = QLineEdit(s.get("author"))
        self.zoom = QComboBox()
        self.zoom.addItems(["width", "page", "100"])
        self.zoom.setCurrentText(str(s.get("default_zoom", "width")))
        self.tol = QSpinBox()
        self.tol.setRange(3, 40)
        self.tol.setValue(int(s.get("snap_tolerance_px", 10)))
        self.tol.setSuffix(" px")
        self.prec = QSpinBox()
        self.prec.setRange(0, 6)
        self.prec.setValue(int(s.get("measure_precision", 3)))
        from .templates import ColorButton
        self.mcol = ColorButton(s.get("measure_color", [0, 0.45, 0.85]))
        self.cache = QSpinBox()
        self.cache.setRange(64, 4096)
        self.cache.setValue(int(s.get("tile_cache_mb", 384)))
        self.cache.setSuffix(" MB")
        self.loupe_size = QSpinBox()
        self.loupe_size.setRange(120, 700)
        self.loupe_size.setValue(int(s.get("loupe_size", 260)))
        self.loupe_size.setSuffix(" px")
        f.addRow("Author name for comments", self.author)
        f.addRow("Default zoom", self.zoom)
        f.addRow("OSnap aperture", self.tol)
        f.addRow("Measurement decimals", self.prec)
        f.addRow("Measurement colour", self.mcol)
        f.addRow("Render cache", self.cache)
        f.addRow("Loupe size", self.loupe_size)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def save(self):
        s = settings()
        s.set("author", self.author.text().strip() or s.get("author"))
        s.set("default_zoom", self.zoom.currentText())
        s.set("snap_tolerance_px", self.tol.value())
        s.set("measure_precision", self.prec.value())
        s.set("measure_color", self.mcol.rgb)
        s.set("tile_cache_mb", self.cache.value())
        s.set("loupe_size", self.loupe_size.value())
        s.save()
        from .viewer import CACHE
        CACHE.budget = self.cache.value() * 1024 * 1024
        self.accept()


class DocPropertiesDialog(QDialog):
    def __init__(self, main, pdfdoc):
        super().__init__(main)
        self.setWindowTitle("Document properties")
        self.pdfdoc = pdfdoc
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        lay.addWidget(tabs)
        w = QWidget()
        f = QFormLayout(w)
        meta = pdfdoc.doc.metadata or {}
        self.ed = {}
        for k in ("title", "author", "subject", "keywords", "creator", "producer"):
            e = QLineEdit(meta.get(k, "") or "")
            self.ed[k] = e
            f.addRow(k.capitalize(), e)
        tabs.addTab(w, "Description")
        w2 = QWidget()
        f2 = QFormLayout(w2)
        d = pdfdoc.doc
        p0 = d.load_page(0) if d.page_count else None
        size = ""
        if p0:
            from .measure import page_paper_name
            size = "%.1f × %.1f mm %s" % (p0.rect.width * 25.4 / 72, p0.rect.height * 25.4 / 72, page_paper_name(p0) or "")
        for lab, val in (("File", pdfdoc.path or "(not saved)"), ("Pages", str(d.page_count)), ("Page 1 size", size),
                         ("PDF version", meta.get("format", "")), ("Created", meta.get("creationDate", "")),
                         ("Modified", meta.get("modDate", "")),
                         ("File size", ("%.2f MB" % (os.path.getsize(pdfdoc.path) / 1048576)) if pdfdoc.path and os.path.exists(pdfdoc.path) else "")):
            le = QLineEdit(val)
            le.setReadOnly(True)
            f2.addRow(lab, le)
        tabs.addTab(w2, "Details")
        w3 = QWidget()
        f3 = QFormLayout(w3)
        si = pdfdoc.security_info()
        f3.addRow("Encryption", QLabel(si["method"]))
        for name, allowed in si["perms"]:
            f3.addRow(name, QLabel("<span style='color:%s'>%s</span>" % ("#2E7D32" if allowed else "#C62828", "Allowed" if allowed else "Not allowed")))
        f3.addRow("Digital signatures", QLabel("Yes" if si["signed"] else "No"))
        tabs.addTab(w3, "Security")
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.resize(520, 380)

    def save(self):
        meta = dict(self.pdfdoc.doc.metadata or {})
        changed = False
        for k, e in self.ed.items():
            if (meta.get(k) or "") != e.text():
                meta[k] = e.text()
                changed = True
        if changed:
            self.pdfdoc.checkpoint()
            self.pdfdoc.doc.set_metadata({k: v for k, v in meta.items() if k in ("title", "author", "subject", "keywords", "creator", "producer")})
            self.pdfdoc.set_modified(True)
        self.accept()


class AboutDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.setWindowTitle("About " + APP_NAME)
        lay = QVBoxLayout(self)
        from .settings import resource_path
        ic = QLabel()
        pm = QPixmap(resource_path("assets", "icon_256.png"))
        if not pm.isNull():
            ic.setPixmap(pm.scaled(96, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        ic.setAlignment(Qt.AlignCenter)
        lay.addWidget(ic)
        t = QLabel("<div style='text-align:center'><span style='font-family:Century Gothic;font-size:16pt;font-weight:bold;color:%s'>%s</span>"
                   "<br>Version %s<br><br>PDF viewer &amp; editor for engineering documents<br>"
                   "Rendering engine: MuPDF (PyMuPDF) · UI: Qt<br><br><b>%s</b><br>Naval Architect &amp; Marine Engineer Consultant<br>"
                   "Batam, Indonesia</div>" % (theme.NAVY, APP_NAME, VERSION, COMPANY))
        t.setTextFormat(Qt.RichText)
        lay.addWidget(t)
        bb = QDialogButtonBox(QDialogButtonBox.Ok)
        if hasattr(main, "updates"):
            b = bb.addButton("Check for Updates…", QDialogButtonBox.ActionRole)
            b.setIcon(theme.icon("update"))
            b.clicked.connect(lambda: (self.accept(), main.updates.open_dialog()))
        bb.accepted.connect(self.accept)
        lay.addWidget(bb)


class RotatePagesDialog(QDialog):
    """Rotate pages permanently: direction, page range, even/odd subset, orientation filter."""

    def __init__(self, main, n, current, selected):
        super().__init__(main)
        self.setWindowTitle("Rotate Pages")
        self.n, self.current, self.selected = n, current, sorted(selected or [current])
        lay = QVBoxLayout(self)
        box = QGroupBox("Direction")
        g = QVBoxLayout(box)
        self.r_cw = QRadioButton("Clockwise 90°")
        self.r_ccw = QRadioButton("Counterclockwise 90°")
        self.r_180 = QRadioButton("180°")
        self.r_up = QRadioButton("Make upright (reset to 0°)")
        self.r_cw.setChecked(True)
        for w in (self.r_cw, self.r_ccw, self.r_180, self.r_up):
            g.addWidget(w)
        lay.addWidget(box)
        box2 = QGroupBox("Page range")
        f = QFormLayout(box2)
        self.scope = QComboBox()
        self.scope.addItems(["All pages (%d)" % n, "Current page (%d)" % (current + 1),
                             "Selected pages (%d)" % len(self.selected), "Pages…"])
        self.range = QLineEdit()
        self.range.setPlaceholderText("e.g. 1-3, 6, 9-")
        self.range.setEnabled(False)
        self.scope.currentIndexChanged.connect(lambda k: self.range.setEnabled(k == 3))
        self.subset = QComboBox()
        self.subset.addItems(["All pages in range", "Even pages only", "Odd pages only"])
        self.orient = QComboBox()
        self.orient.addItems(["Portrait and landscape pages", "Portrait pages only", "Landscape pages only"])
        f.addRow("Pages", self.scope)
        f.addRow("Range", self.range)
        f.addRow("Subset", self.subset)
        f.addRow("Orientation", self.orient)
        lay.addWidget(box2)
        lay.addWidget(QLabel("<span style='color:#5B6675'>The rotation is saved in the document. "
                             "To turn only the screen, use VIEW ▸ Rotate View.</span>"))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def values(self, pdfdoc):
        k = self.scope.currentIndex()
        if k == 0:
            pages = list(range(self.n))
        elif k == 1:
            pages = [self.current]
        elif k == 2:
            pages = list(self.selected)
        else:
            pages = parse_page_range(self.range.text(), self.n)
        sub = self.subset.currentIndex()
        if sub == 1:
            pages = [p for p in pages if (p + 1) % 2 == 0]
        elif sub == 2:
            pages = [p for p in pages if (p + 1) % 2 == 1]
        o = self.orient.currentIndex()
        if o:
            sizes = pdfdoc.page_sizes()
            pages = [p for p in pages if (sizes[p][1] >= sizes[p][0]) == (o == 1)]
        if self.r_cw.isChecked():
            angle = 90
        elif self.r_ccw.isChecked():
            angle = -90
        elif self.r_180.isChecked():
            angle = 180
        else:
            angle = None
        if angle is None:
            # reset: rotate each page back by its own rotation
            return "upright", pages
        return angle, pages


class SoundDialog(QDialog):
    """Record from the microphone (Windows) or choose a WAV file for a Sound comment."""

    def __init__(self, parent):
        super().__init__(parent)
        from . import audio
        self.audio = audio
        self.setWindowTitle("Sound comment")
        self.resize(420, 200)
        self.wav_path = None
        self.rec = audio.Recorder()
        lay = QVBoxLayout(self)
        self.info = QLabel("Record a voice remark or choose a WAV file.")
        self.info.setWordWrap(True)
        lay.addWidget(self.info)
        row = QHBoxLayout()
        self.b_rec = QPushButton(theme.icon("record-circle-outline", "#D32F2F"), "Record")
        self.b_rec.setCheckable(True)
        self.b_rec.toggled.connect(self._toggle_rec)
        if not audio.can_record():
            self.b_rec.setEnabled(False)
            self.b_rec.setToolTip("Recording is available on Windows")
        b_file = QPushButton(theme.icon("folder-music-outline"), "Choose WAV…")
        b_file.clicked.connect(self._choose)
        self.b_play = QPushButton(theme.icon("play-circle-outline"), "Play")
        self.b_play.setEnabled(False)
        self.b_play.clicked.connect(lambda: self.audio.play(self.wav_path))
        row.addWidget(self.b_rec)
        row.addWidget(b_file)
        row.addWidget(self.b_play)
        lay.addLayout(row)
        self.ed = QLineEdit()
        self.ed.setPlaceholderText("Comment text (optional)")
        lay.addWidget(self.ed)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.accepted.connect(self.accept)
        self.bb.rejected.connect(self.reject)
        self.bb.button(QDialogButtonBox.Ok).setEnabled(False)
        lay.addWidget(self.bb)
        self._t0 = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

    def _toggle_rec(self, on):
        import time
        try:
            if on:
                self.audio.stop()
                self.rec.start()
                self._t0 = time.time()
                self._timer.start(200)
                self.b_rec.setText("Stop")
                self.b_rec.setIcon(theme.icon("stop-circle-outline", "#D32F2F"))
            else:
                self._timer.stop()
                path = self.audio.temp_wav()
                self.rec.stop(path)
                self._set_file(path)
                self.b_rec.setText("Record again")
                self.b_rec.setIcon(theme.icon("record-circle-outline", "#D32F2F"))
        except Exception as e:
            self._timer.stop()
            self.b_rec.blockSignals(True)
            self.b_rec.setChecked(False)
            self.b_rec.blockSignals(False)
            QMessageBox.warning(self, "Record", "The microphone could not be used:\n%s" % e)

    def _tick(self):
        import time
        self.info.setText("<b style='color:#D32F2F'>● Recording… %.1f s</b>  - press Stop when finished." % (time.time() - self._t0))

    def _choose(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose sound", "", "WAV sound (*.wav)")
        if path:
            self._set_file(path)

    def _set_file(self, path):
        from .annots import wav_info
        try:
            ch, sw, rate, n = wav_info(path)
        except Exception as e:
            QMessageBox.warning(self, "Sound", "This WAV file cannot be used (PCM WAV only):\n%s" % e)
            return
        self.wav_path = path
        self.info.setText("%s  -  %.1f s, %d Hz, %s" % (os.path.basename(path), n / float(rate or 1), rate,
                                                         "mono" if ch == 1 else "stereo"))
        self.b_play.setEnabled(True)
        self.bb.button(QDialogButtonBox.Ok).setEnabled(True)

    def note(self):
        return self.ed.text().strip()

    def reject(self):
        if self.rec.active:
            try:
                self.rec.stop(self.audio.temp_wav())
            except Exception:
                pass
        self.audio.stop()
        super().reject()

    def accept(self):
        self.audio.stop()
        super().accept()
