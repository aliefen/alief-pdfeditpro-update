"""Page organisation and document-wide operations (no Qt)."""
import datetime
import os

import pymupdf


def rotate_pages(doc, pages, angle):
    """angle: +90 / -90 / 180, or 'upright' to reset the rotation to 0."""
    for i in pages:
        p = doc.load_page(i)
        p.set_rotation(0 if angle == "upright" else (p.rotation + angle) % 360)


def delete_pages(doc, pages):
    doc.delete_pages(sorted(set(pages)))


def extract_pages(doc, pages, out_path):
    new = pymupdf.open()
    for i in pages:
        new.insert_pdf(doc, from_page=i, to_page=i, annots=True)
    new.save(out_path, garbage=3, deflate=True)
    new.close()
    return out_path


def insert_blank(doc, at, width=None, height=None, count=1):
    ref = doc.load_page(min(max(0, at - 1), doc.page_count - 1)) if doc.page_count else None
    w = width or (ref.rect.width if ref else 595)
    h = height or (ref.rect.height if ref else 842)
    for k in range(count):
        doc.new_page(pno=at + k, width=w, height=h)


def insert_file(doc, at, path, page_range=None, password=None):
    src = pymupdf.open(path)
    if src.needs_pass:
        if not password or not src.authenticate(password):
            raise ValueError("%s is password protected" % os.path.basename(path))
    if not src.is_pdf:
        data = src.convert_to_pdf()
        src.close()
        src = pymupdf.open("pdf", data)
    if page_range:
        for k, i in enumerate(page_range):
            doc.insert_pdf(src, from_page=i, to_page=i, start_at=at + k, annots=True)
    else:
        doc.insert_pdf(src, start_at=at, annots=True)
    n = src.page_count if not page_range else len(page_range)
    src.close()
    return n


def duplicate_pages(doc, pages):
    for k, i in enumerate(sorted(pages)):
        src = i + k
        to = src + 1
        doc.fullcopy_page(src, to if to < doc.page_count else -1)


def reverse_pages(doc):
    n = doc.page_count
    doc.select(list(range(n - 1, -1, -1)))


def move_page(doc, src, dst):
    doc.move_page(src, dst)


def merge_files(paths, out_path, progress=None, bookmarks=True):
    out = pymupdf.open()
    toc = []
    for k, p in enumerate(paths):
        if progress and progress(k, len(paths), os.path.basename(p)) is False:
            break
        src = pymupdf.open(p)
        if not src.is_pdf:
            data = src.convert_to_pdf()
            src.close()
            src = pymupdf.open("pdf", data)
        start = out.page_count
        out.insert_pdf(src, annots=True)
        if bookmarks:
            toc.append([1, os.path.splitext(os.path.basename(p))[0], start + 1])
            for lvl, title, pg in src.get_toc(simple=True):
                toc.append([lvl + 1, title, start + pg])
        src.close()
    if bookmarks and toc:
        try:
            out.set_toc(toc)
        except Exception:
            pass
    out.save(out_path, garbage=3, deflate=True)
    out.close()
    return out_path


def split(doc, out_dir, base, mode="every", value=1, ranges=None, progress=None):
    """mode: 'every' (N pages per file), 'ranges' ('1-3,4-8'), 'bookmarks' (top-level bookmarks)."""
    os.makedirs(out_dir, exist_ok=True)
    n = doc.page_count
    groups = []
    if mode == "every":
        step = max(1, int(value))
        groups = [list(range(a, min(n, a + step))) for a in range(0, n, step)]
    elif mode == "ranges":
        for part in (ranges or "").split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                a = int(a or 1)
                b = int(b or n)
            else:
                a = b = int(part)
            groups.append(list(range(max(1, a) - 1, min(n, b))))
    elif mode == "bookmarks":
        toc = [t for t in doc.get_toc(simple=True) if t[0] == 1]
        starts = [(t[2] - 1, t[1]) for t in toc if t[2] >= 1]
        for k, (s, title) in enumerate(starts):
            e = starts[k + 1][0] if k + 1 < len(starts) else n
            if e > s:
                groups.append((list(range(s, e)), title))
    outs = []
    for k, g in enumerate(groups):
        title = None
        if isinstance(g, tuple):
            g, title = g
        if not g:
            continue
        if progress and progress(k, len(groups), "") is False:
            break
        if title:
            safe = "".join(c for c in title if c not in '\\/:*?"<>|').strip()[:80] or "part"
            fn = os.path.join(out_dir, "%s_%02d_%s.pdf" % (base, k + 1, safe))
        else:
            fn = os.path.join(out_dir, "%s_p%d-%d.pdf" % (base, g[0] + 1, g[-1] + 1))
        extract_pages(doc, g, fn)
        outs.append(fn)
    return outs


def _tokens(s, page_no, total, filename):
    now = datetime.datetime.now()
    return (s.replace("<<page>>", str(page_no)).replace("<<pages>>", str(total))
            .replace("<<date>>", now.strftime("%d %b %Y")).replace("<<time>>", now.strftime("%H:%M"))
            .replace("<<file>>", filename))


def header_footer(doc, pages, slots, fontsize=8, color=(0, 0, 0), margin_mm=8, font="helv", filename="", start_number=1):
    """slots: dict with keys tl, tc, tr, bl, bc, br -> text with tokens <<page>> <<pages>> <<date>> <<file>>."""
    total = doc.page_count
    m = margin_mm * 72 / 25.4
    for k, i in enumerate(pages):
        page = doc.load_page(i)
        W, H = page.rect.width, page.rect.height
        derot = page.derotation_matrix
        for key, txt in slots.items():
            if not txt:
                continue
            s = _tokens(txt, i + start_number, total + start_number - 1, filename)
            tw = pymupdf.get_text_length(s, fontname=font, fontsize=fontsize)
            x = {"l": m, "c": (W - tw) / 2, "r": W - m - tw}[key[1]]
            y = m + fontsize if key[0] == "t" else H - m
            pt = pymupdf.Point(x, y) * derot
            page.insert_text(pt, s, fontsize=fontsize, fontname=font, color=color, rotate=page.rotation)


def watermark_text(doc, pages, text, fontsize=60, color=(0.8, 0.1, 0.1), opacity=0.25, angle=45, font="hebo", overlay=True):
    """Diagonal text watermark centred on each page; angle is counter-clockwise as seen on screen."""
    for i in pages:
        page = doc.load_page(i)
        r = page.rect
        tw = pymupdf.get_text_length(text, fontname=font, fontsize=fontsize)
        cu = pymupdf.Point(r.width / 2, r.height / 2) * page.derotation_matrix
        start = pymupdf.Point(cu.x - tw / 2, cu.y + fontsize * 0.35)
        page.insert_text(start, text, fontsize=fontsize, fontname=font, color=color, fill_opacity=opacity,
                         stroke_opacity=opacity, morph=(cu, pymupdf.Matrix(angle + page.rotation)), overlay=overlay)


def watermark_image(doc, pages, image_path, scale=0.5, opacity=0.25, overlay=False):
    from PIL import Image
    import io
    img = Image.open(image_path).convert("RGBA")
    if opacity < 1:
        a = img.getchannel("A").point(lambda v: int(v * opacity))
        img.putalpha(a)
    bio = io.BytesIO()
    img.save(bio, "PNG")
    data = bio.getvalue()
    for i in pages:
        page = doc.load_page(i)
        r = page.rect
        w = r.width * scale
        h = w * img.height / img.width
        rect = pymupdf.Rect((r.width - w) / 2, (r.height - h) / 2, (r.width + w) / 2, (r.height + h) / 2) * page.derotation_matrix
        page.insert_image(rect, stream=data, overlay=overlay, keep_proportion=True, rotate=0)


def flatten(doc, annots=True, widgets=True):
    if hasattr(doc, "bake"):
        doc.bake(annots=annots, widgets=widgets)
        return True
    return False


def optimize(doc, out_path, image_dpi=150, jpg_quality=75, subset_fonts=True, remove_metadata=False, progress=None):
    if progress:
        progress(0, 3, "Images")
    if image_dpi and hasattr(doc, "rewrite_images"):
        try:
            doc.rewrite_images(dpi_threshold=int(image_dpi * 1.3), dpi_target=int(image_dpi), quality=int(jpg_quality),
                               lossy=True, lossless=True, bitonal=True, color=True, gray=True)
        except Exception:
            pass
    if progress:
        progress(1, 3, "Fonts")
    if subset_fonts:
        try:
            doc.subset_fonts()
        except Exception:
            pass
    if remove_metadata:
        doc.set_metadata({})
        try:
            doc.del_xml_metadata()
        except Exception:
            pass
    if progress:
        progress(2, 3, "Writing")
    doc.save(out_path, garbage=4, deflate=True, deflate_images=True, deflate_fonts=True, use_objstms=1, clean=True)
    return out_path


def apply_redactions(doc):
    n = 0
    for page in doc:
        has = any(a.type[0] == pymupdf.PDF_ANNOT_REDACT for a in page.annots())
        if has:
            page.apply_redactions()
            n += 1
    return n


def sanitize(doc):
    """Remove metadata, JavaScript and thumbnails."""
    doc.set_metadata({})
    try:
        doc.del_xml_metadata()
    except Exception:
        pass
    try:
        doc.scrub(attached_files=False, clean_pages=False, embedded_files=False, hidden_text=False, javascript=True,
                  metadata=True, redactions=False, remove_links=False, reset_fields=False, reset_responses=False,
                  thumbnails=True, xml_metadata=True)
    except Exception:
        pass
