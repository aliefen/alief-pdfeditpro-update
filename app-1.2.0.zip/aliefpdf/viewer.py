"""Fast tiled PDF view (MuPDF display lists, progressive tiles, page grid, loupe)."""
import math
import time
from collections import OrderedDict

import pymupdf
from PySide6.QtCore import QEvent, Qt, QRectF, QPointF, QTimer, Signal, QRect, QSize
from PySide6.QtGui import (QPainter, QColor, QImage, QPen, QBrush, QPainterPath, QFont,
                           QKeySequence, QGuiApplication, QCursor)
from PySide6.QtWidgets import QAbstractScrollArea, QApplication

from . import theme

PX_PER_PT_100 = 96.0 / 72.0   # 100 % zoom == real paper size on a 96-dpi screen
TILE = 512


class TileCache:
    """LRU cache of rendered tiles (QImage tuples) and content pixmaps, bounded by memory."""

    def __init__(self, budget_mb=512):
        self.d = OrderedDict()
        self.bytes = 0
        self.budget = budget_mb * 1024 * 1024
        self.latest = {}     # tile position (without generation) -> newest key, for stale display

    @staticmethod
    def _size(v):
        if isinstance(v, tuple):
            return v[0].sizeInBytes()
        try:
            return v.width * v.height * v.n
        except Exception:
            return 1024

    def get(self, key):
        v = self.d.get(key)
        if v is not None:
            self.d.move_to_end(key)
        return v

    def put(self, key, val, pos=None):
        old = self.d.pop(key, None)
        if old is not None:
            self.bytes -= self._size(old)
        self.d[key] = val
        self.bytes += self._size(val)
        if pos is not None:
            self.latest[pos] = key
        while self.bytes > self.budget and len(self.d) > 1:
            _, v = self.d.popitem(last=False)
            self.bytes -= self._size(v)

    def stale(self, pos):
        k = self.latest.get(pos)
        return self.d.get(k) if k is not None else None

    def drop_doc(self, uid):
        for k in [k for k in self.d if len(k) > 1 and k[1] == uid]:
            v = self.d.pop(k)
            self.bytes -= self._size(v)
        for p in [p for p in self.latest if len(p) > 1 and p[1] == uid]:
            self.latest.pop(p, None)


CACHE = TileCache()

_IDENT = pymupdf.Identity


def pix_to_qimage(pix):
    fmt = QImage.Format_RGB888 if pix.n == 3 else QImage.Format_RGBA8888
    img = QImage(pix.samples_mv, pix.width, pix.height, pix.stride, fmt)
    return img.copy()


class DocumentView(QAbstractScrollArea):
    page_changed = Signal(int)
    zoom_changed = Signal(float)
    cursor_moved = Signal(object)      # (page, unrot x, unrot y) or None
    selection_changed = Signal(object)  # (page, xref) or None
    activated = Signal(object)
    tool_finished = Signal()

    MARGIN = 12
    GAP = 12

    def __init__(self, pdfdoc, main=None, parent=None):
        super().__init__(parent)
        self.main = main
        self.pdfdoc = None
        self.mode = "continuous"
        self.fit = "width"
        self.scale = PX_PER_PT_100
        self.grid_cols, self.grid_rows = 3, 2
        self.items = []
        self.content_w = self.content_h = 0
        self.current = 0
        self.tool = None
        self.selected = None          # (page, xref)
        self.text_sel = None          # (page, [rects unrot], text)
        self._queue = []
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self._render_some)
        self._pan = None
        self._space_pan = False
        self.loupe_active = False
        self.loupe_zoom = 8.0
        self.loupe_size = 260
        self.loupe_pos = None
        self.loupe_pinned = False
        self.loupe_img = None
        self._loupe_timer = QTimer(self)
        self._loupe_timer.setSingleShot(True)
        self._loupe_timer.timeout.connect(self._render_loupe)
        self.show_forms = True
        self.view_rot = 0              # extra rotation of the view only (document unchanged)
        self._vm_cache = {}
        self.viewport().setMouseTracking(True)
        self.setMouseTracking(True)
        self.viewport().setAttribute(Qt.WA_OpaquePaintEvent, True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAcceptDrops(True)
        self.horizontalScrollBar().valueChanged.connect(self._on_scroll)
        self.verticalScrollBar().valueChanged.connect(self._on_scroll)
        self.set_document(pdfdoc)

    # ------------------------------------------------------------ document
    def set_document(self, pdfdoc):
        if self.pdfdoc is not None:
            try:
                self.pdfdoc.pages_changed.disconnect(self._on_pages_changed)
                self.pdfdoc.structure_changed.disconnect(self._on_structure_changed)
                self.pdfdoc.snap_ready.disconnect(self._on_snap_ready)
            except Exception:
                pass
        self.pdfdoc = pdfdoc
        self.selected = None
        self.text_sel = None
        self._vm_cache = {}
        if pdfdoc is not None:
            pdfdoc.pages_changed.connect(self._on_pages_changed)
            pdfdoc.structure_changed.connect(self._on_structure_changed)
            pdfdoc.snap_ready.connect(self._on_snap_ready)
        self.current = 0
        self.relayout()
        self.verticalScrollBar().setValue(0)
        self.viewport().update()

    def _on_pages_changed(self, pages):
        if self.selected and self.pdfdoc:
            # selection may refer to a deleted annotation
            pg, xref = self.selected
            if pg >= self.pdfdoc.page_count or not any(a["xref"] == xref for a in self.pdfdoc.annot_list(pg)):
                self.set_selected(None)
        self.relayout(keep=True)
        self.viewport().update()

    def _on_snap_ready(self, i):
        if self.tool is not None and getattr(self.tool, "snaps", False):
            try:
                self.tool.on_snap_ready(i)
            except Exception:
                pass
        self.viewport().update()

    # ------------------------------------------------------- view rotation
    def vm(self, i):
        """Matrix: page display coordinates -> view display coordinates (view rotation)."""
        r = self.view_rot
        if not r:
            return _IDENT
        w, h = self.pdfdoc.page_sizes()[i]
        key = (i, r, w, h)
        m = self._vm_cache.get(key)
        if m is None:
            m = pymupdf.Matrix(r)
            rr = pymupdf.Rect(0, 0, w, h) * m
            m = pymupdf.Matrix(m.a, m.b, m.c, m.d, -rr.x0, -rr.y0)
            self._vm_cache[key] = m
        return m

    def vsizes(self):
        sizes = self.pdfdoc.page_sizes()
        if self.view_rot in (90, 270):
            return [(h, w) for (w, h) in sizes]
        return sizes

    def to_disp(self, i, xu, yu):
        """Unrotated page coordinates -> view display points."""
        p = pymupdf.Point(xu, yu) * self.pdfdoc.rot_info(i)[0]
        if self.view_rot:
            p = p * self.vm(i)
        return p.x, p.y

    def to_unrot(self, i, xd, yd):
        p = pymupdf.Point(xd, yd)
        if self.view_rot:
            p = p * ~self.vm(i)
        p = p * self.pdfdoc.rot_info(i)[1]
        return p.x, p.y

    def derot(self, i):
        """Matrix: view display points -> unrotated page coordinates."""
        m = pymupdf.Matrix(self.pdfdoc.rot_info(i)[1])
        if self.view_rot:
            return ~self.vm(i) * m
        return m

    def total_rot(self, i):
        return (self.pdfdoc.rot_info(i)[2] + self.view_rot) % 360

    def disp_rect_to_dl(self, i, rect):
        """View display rect -> rect in the display-list (page display) space."""
        if not self.view_rot:
            return pymupdf.Rect(rect)
        r = pymupdf.Rect(rect) * ~self.vm(i)
        return pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))

    def render_matrix(self, i, scale):
        if self.view_rot:
            return self.vm(i) * pymupdf.Matrix(scale, scale)
        return pymupdf.Matrix(scale, scale)

    def rotate_view(self, delta):
        cur = self.current_page()
        self.view_rot = (self.view_rot + delta) % 360
        self._vm_cache = {}
        self.relayout()
        self.go_to_page(cur)
        self.viewport().update()

    def _on_structure_changed(self):
        self.selected = None
        self.text_sel = None
        if self.pdfdoc and self.current >= self.pdfdoc.page_count:
            self.current = max(0, self.pdfdoc.page_count - 1)
        self.relayout(keep=True)
        self.viewport().update()
        self.selection_changed.emit(None)

    # -------------------------------------------------------------- layout
    def zoom_percent(self):
        if self.mode == "grid" and self.items:
            for it in self.items:
                if it:
                    return it[1] / PX_PER_PT_100 * 100
        return self.scale / PX_PER_PT_100 * 100

    def relayout(self, keep=False):
        anchor = None
        if keep and self.items:
            anchor = self._anchor_at(QPointF(self.viewport().width() / 2, 0))
        doc = self.pdfdoc
        vw = max(50, self.viewport().width())
        vh = max(50, self.viewport().height())
        if doc is None or doc.page_count == 0:
            self.items = []
            self.content_w = self.content_h = 0
            self._update_scrollbars()
            return
        sizes = self.vsizes()
        n = len(sizes)
        M, G = self.MARGIN, self.GAP
        items = [None] * n
        if self.mode == "grid":
            cols = max(1, self.grid_cols)
            rows = max(1, self.grid_rows)
            cw = (vw - M * 2 - G * (cols - 1)) / cols
            ch = (vh - M * 2 - G * (rows - 1)) / rows
            cw, ch = max(20, cw), max(20, ch)
            y = M
            for r0 in range(0, n, cols):
                for c in range(cols):
                    i = r0 + c
                    if i >= n:
                        break
                    w, h = sizes[i]
                    s = min(cw / w, ch / h)
                    pw, ph = w * s, h * s
                    x = M + c * (cw + G) + (cw - pw) / 2
                    items[i] = (QRectF(x, y + (ch - ph) / 2, pw, ph), s)
                y += ch + G
            self.content_w = vw
            self.content_h = y - G + M
        else:
            facing = self.mode == "facing"
            if self.fit:
                if facing:
                    pair_w = max((sizes[i][0] + (sizes[i + 1][0] if i + 1 < n else sizes[i][0])) for i in range(0, n, 2))
                    sw = (vw - 2 * M - G) / pair_w
                    maxh = max(h for _, h in sizes)
                    sp = (vh - 2 * M) / maxh
                else:
                    cur = min(self.current, n - 1)
                    maxw = max(w for w, _ in sizes)
                    sw = (vw - 2 * M - (16 if self.mode == "continuous" else 0)) / maxw
                    sp = min((vw - 2 * M) / sizes[cur][0], (vh - 2 * M) / sizes[cur][1])
                self.scale = max(0.02, sw if self.fit == "width" else min(sw, sp))
            s = self.scale
            if self.mode == "single":
                i = min(self.current, n - 1)
                w, h = sizes[i]
                pw, ph = w * s, h * s
                cwid = max(vw, pw + 2 * M)
                chei = max(vh, ph + 2 * M)
                items[i] = (QRectF((cwid - pw) / 2, max(M, (chei - ph) / 2), pw, ph), s)
                self.content_w, self.content_h = cwid, chei
            elif facing:
                rows = []
                for i in range(0, n, 2):
                    pair = [i] + ([i + 1] if i + 1 < n else [])
                    rows.append(pair)
                maxroww = max(sum(sizes[j][0] * s for j in pair) + G * (len(pair) - 1) for pair in rows)
                cwid = max(vw, maxroww + 2 * M)
                y = M
                for pair in rows:
                    roww = sum(sizes[j][0] * s for j in pair) + G * (len(pair) - 1)
                    rowh = max(sizes[j][1] * s for j in pair)
                    x = (cwid - roww) / 2
                    for j in pair:
                        pw, ph = sizes[j][0] * s, sizes[j][1] * s
                        items[j] = (QRectF(x, y, pw, ph), s)
                        x += pw + G
                    y += rowh + G
                self.content_w, self.content_h = cwid, y - G + M
            else:
                maxw = max(w for w, _ in sizes) * s
                cwid = max(vw, maxw + 2 * M)
                y = M
                for i, (w, h) in enumerate(sizes):
                    pw, ph = w * s, h * s
                    items[i] = (QRectF((cwid - pw) / 2, y, pw, ph), s)
                    y += ph + G
                self.content_w, self.content_h = cwid, y - G + M
        self.items = items
        self._update_scrollbars()
        if anchor:
            self._restore_anchor(anchor, QPointF(self.viewport().width() / 2, 0))
        self.zoom_changed.emit(self.zoom_percent())

    def flash(self, rect):
        """Short white 'camera flash' over rect (view coordinates)."""
        if rect is None:
            return
        self._flash = (QRectF(rect).intersected(QRectF(self.viewport().rect())), time.perf_counter())
        if not hasattr(self, "_flash_timer"):
            self._flash_timer = QTimer(self)
            self._flash_timer.setInterval(16)
            self._flash_timer.timeout.connect(self._flash_tick)
        self._flash_timer.start()
        self.viewport().update()

    def _flash_tick(self):
        if getattr(self, "_flash", None) is None or time.perf_counter() - self._flash[1] > 0.4:
            self._flash = None
            self._flash_timer.stop()
        self.viewport().update()

    def _update_scrollbars(self):
        vw, vh = self.viewport().width(), self.viewport().height()
        hs, vs = self.horizontalScrollBar(), self.verticalScrollBar()
        hs.setRange(0, int(max(0, self.content_w - vw)))
        hs.setPageStep(vw)
        hs.setSingleStep(40)
        vs.setRange(0, int(max(0, self.content_h - vh)))
        vs.setPageStep(vh)
        vs.setSingleStep(60)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.relayout(keep=True)

    def _anchor_at(self, vpos):
        """(page, rel_x, rel_y) of the document point under viewport position vpos."""
        cx = vpos.x() + self.horizontalScrollBar().value()
        cy = vpos.y() + self.verticalScrollBar().value()
        best = None
        for i, it in enumerate(self.items):
            if not it:
                continue
            r = it[0]
            if r.top() - self.GAP <= cy <= r.bottom() + self.GAP and (best is None or abs(r.center().x() - cx) < best[3]):
                best = (i, (cx - r.left()) / r.width(), (cy - r.top()) / r.height(), abs(r.center().x() - cx))
        if best is None:
            i = self.current_page()
            return (i, 0.5, 0.0)
        return best[:3]

    def _restore_anchor(self, anchor, vpos):
        i, rx, ry = anchor
        if i >= len(self.items) or not self.items[i]:
            return
        r = self.items[i][0]
        x = r.left() + rx * r.width() - vpos.x()
        y = r.top() + ry * r.height() - vpos.y()
        self.horizontalScrollBar().setValue(int(round(x)))
        self.verticalScrollBar().setValue(int(round(y)))

    # ---------------------------------------------------------- navigation
    def current_page(self):
        if self.mode == "single":
            return self.current
        vy = self.verticalScrollBar().value()
        vh = self.viewport().height()
        mid = vy + vh * 0.35
        best, bd = self.current, None
        for i, it in enumerate(self.items):
            if not it:
                continue
            r = it[0]
            if r.top() <= mid <= r.bottom() + self.GAP:
                return i
            d = min(abs(r.top() - mid), abs(r.bottom() - mid))
            if bd is None or d < bd:
                best, bd = i, d
        return best

    def _on_scroll(self, *_):
        cp = self.current_page()
        if cp != self.current and self.mode != "single":
            self.current = cp
            self.page_changed.emit(cp)
        self.viewport().update()

    def go_to_page(self, i, y_pt=None, x_pt=None):
        if not self.pdfdoc:
            return
        i = max(0, min(self.pdfdoc.page_count - 1, i))
        if self.mode == "single":
            self.current = i
            self.relayout()
            self.verticalScrollBar().setValue(0)
            self.page_changed.emit(i)
            self.viewport().update()
            return
        it = self.items[i]
        if not it:
            return
        r, s = it
        y = r.top() - self.MARGIN
        if y_pt is not None:
            y = r.top() + y_pt * s - self.viewport().height() / 3
        self.verticalScrollBar().setValue(int(y))
        if x_pt is not None:
            self.horizontalScrollBar().setValue(int(r.left() + x_pt * s - self.viewport().width() / 2))
        self.current = i
        self.page_changed.emit(i)
        self.viewport().update()

    def go_to_unrot(self, i, xu, yu):
        xd, yd = self.to_disp(i, xu, yu)
        self.go_to_page(i, yd, xd)

    def next_page(self):
        self.go_to_page(self.current_page() + (self.grid_cols if self.mode == "grid" else 2 if self.mode == "facing" else 1))

    def prev_page(self):
        self.go_to_page(self.current_page() - (self.grid_cols if self.mode == "grid" else 2 if self.mode == "facing" else 1))

    # ---------------------------------------------------------------- zoom
    def set_mode(self, mode):
        if mode == self.mode:
            return
        cur = self.current_page()
        self.mode = mode
        if mode == "single":
            self.current = cur
        self.relayout()
        self.go_to_page(cur)

    def set_grid(self, cols, rows):
        self.grid_cols, self.grid_rows = max(1, cols), max(1, rows)
        cur = self.current_page()
        if self.mode != "grid":
            self.mode = "grid"
        self.relayout()
        self.go_to_page(cur)

    def set_fit(self, fit):
        if self.mode == "grid":
            self.mode = "continuous"
        cur = self.current_page()
        self.fit = fit
        self.relayout()
        self.go_to_page(cur)

    def set_zoom_percent(self, pct, anchor_pos=None):
        self.set_scale(pct / 100.0 * PX_PER_PT_100, anchor_pos)

    def set_scale(self, s, anchor_pos=None):
        s = max(0.02, min(64 * PX_PER_PT_100, s))
        if self.mode == "grid":
            self.mode = "continuous"
        if anchor_pos is None:
            anchor_pos = QPointF(self.viewport().width() / 2, self.viewport().height() / 2)
        anchor = self._anchor_at(anchor_pos)
        self.fit = None
        self.scale = s
        self.relayout()
        self._restore_anchor(anchor, anchor_pos)
        self.viewport().update()

    def zoom_by(self, factor, anchor_pos=None):
        base = self.scale
        if self.mode == "grid" and self.items:
            base = next((it[1] for it in self.items if it), self.scale)
        self.set_scale(base * factor, anchor_pos)

    def zoom_to_rect(self, page, disp_rect):
        """Zoom so that disp_rect (display points of page) fills the viewport."""
        vw, vh = self.viewport().width(), self.viewport().height()
        w, h = max(1.0, disp_rect.width), max(1.0, disp_rect.height)
        s = min((vw - 30) / w, (vh - 30) / h)
        self.fit = None
        if self.mode == "grid":
            self.mode = "continuous"
        self.scale = max(0.02, min(64 * PX_PER_PT_100, s))
        self.relayout()
        it = self.items[page]
        if it:
            r, sc = it
            cx = r.left() + (disp_rect.x0 + w / 2) * sc
            cy = r.top() + (disp_rect.y0 + h / 2) * sc
            self.horizontalScrollBar().setValue(int(cx - vw / 2))
            self.verticalScrollBar().setValue(int(cy - vh / 2))
        self.viewport().update()

    # ------------------------------------------------------------ geometry
    def offset(self):
        return QPointF(self.horizontalScrollBar().value(), self.verticalScrollBar().value())

    def page_view_rect(self, i):
        it = self.items[i] if 0 <= i < len(self.items) else None
        if not it:
            return None
        return it[0].translated(-self.offset())

    def page_scale(self, i):
        it = self.items[i] if 0 <= i < len(self.items) else None
        return it[1] if it else self.scale

    def hit(self, pos, clamp_page=None):
        """Viewport pos -> (page, xd, yd) in display points. clamp_page forces that page."""
        off = self.offset()
        cx, cy = pos.x() + off.x(), pos.y() + off.y()
        if clamp_page is not None:
            it = self.items[clamp_page] if clamp_page < len(self.items) else None
            if not it:
                return None
            r, s = it
            return clamp_page, (cx - r.left()) / s, (cy - r.top()) / s
        for i, it in enumerate(self.items):
            if not it:
                continue
            r, s = it
            if r.left() <= cx <= r.right() and r.top() <= cy <= r.bottom():
                return i, (cx - r.left()) / s, (cy - r.top()) / s
        return None

    def hit_unrot(self, pos, clamp_page=None):
        h = self.hit(pos, clamp_page)
        if not h:
            return None
        i, xd, yd = h
        xu, yu = self.to_unrot(i, xd, yd)
        return i, xu, yu

    def disp_to_view(self, i, xd, yd):
        it = self.items[i]
        if not it:
            return QPointF(-1000, -1000)
        r, s = it
        off = self.offset()
        return QPointF(r.left() + xd * s - off.x(), r.top() + yd * s - off.y())

    def unrot_to_view(self, i, xu, yu):
        xd, yd = self.to_disp(i, xu, yu)
        return self.disp_to_view(i, xd, yd)

    def unrot_rect_to_view(self, i, rect):
        x0, y0, x1, y1 = rect
        a = self.unrot_to_view(i, x0, y0)
        b = self.unrot_to_view(i, x1, y1)
        return QRectF(a, b).normalized()

    def view_tol_pt(self, i, px=None):
        from .settings import settings
        px = px or settings().get("snap_tolerance_px", 10)
        return px / max(1e-6, self.page_scale(i))

    # ----------------------------------------------------------- painting
    def paintEvent(self, e):
        p = QPainter(self.viewport())
        vr = self.viewport().rect()
        p.fillRect(vr, QColor(theme.VIEW_BG))
        doc = self.pdfdoc
        if not doc or not self.items:
            p.end()
            return
        dpr = self.devicePixelRatioF()
        off = self.offset()
        vis = QRectF(off.x(), off.y(), vr.width(), vr.height())
        center = vis.center()
        missing = []
        for i, it in enumerate(self.items):
            if not it:
                continue
            r, s = it
            if not r.intersects(vis):
                continue
            rv = r.translated(-off)
            # shadow + paper
            p.fillRect(rv.translated(3, 3), QColor(0, 0, 0, 60))
            p.fillRect(rv, Qt.white)
            sdev = s * dpr
            skey = int(round(sdev * 1000))
            rot = self.view_rot
            gen = doc.gen[i]
            tkey = ("t", doc.uid, doc.epoch, i, gen, rot)
            tpos = ("t", doc.uid, doc.epoch, i, rot)
            thumb = CACHE.get(tkey)
            if thumb is None:
                thumb = CACHE.stale(tpos)
                missing.append((-1, tkey, i, None, 0, 0))
            # tiles that cover the visible part of the page
            inter = r.intersected(vis)
            x0 = int(max(0, (inter.left() - r.left()) * dpr) // TILE)
            x1 = int(max(0, (inter.right() - r.left()) * dpr - 1) // TILE)
            y0 = int(max(0, (inter.top() - r.top()) * dpr) // TILE)
            y1 = int(max(0, (inter.bottom() - r.top()) * dpr - 1) // TILE)
            tiles = []
            all_ok = True
            for ty in range(y0, y1 + 1):
                for tx in range(x0, x1 + 1):
                    key = ("f", doc.uid, doc.epoch, i, gen, rot, skey, tx, ty)
                    t = CACHE.get(key)
                    if t is None:
                        tc = QPointF(r.left() + (tx + 0.5) * TILE / dpr, r.top() + (ty + 0.5) * TILE / dpr)
                        d = (tc - center).manhattanLength()
                        missing.append((d, key, i, sdev, tx, ty))
                        t = CACHE.stale(("f", doc.uid, doc.epoch, i, rot, skey, tx, ty))
                    if t is None:
                        all_ok = False
                    else:
                        tiles.append(t)
            if not all_ok and thumb is not None:
                p.setRenderHint(QPainter.SmoothPixmapTransform, True)
                p.drawImage(rv, thumb[0])
            p.setRenderHint(QPainter.SmoothPixmapTransform, False)
            for img, px, py in tiles:
                p.drawImage(QRectF(rv.left() + px / dpr, rv.top() + py / dpr, img.width() / dpr, img.height() / dpr), img)
            self._paint_page_overlays(p, i, rv, s)
        if self.tool is not None:
            p.setRenderHint(QPainter.Antialiasing, True)
            try:
                self.tool.paint(p)
            except Exception:
                pass
        if self.loupe_active and self.loupe_pos is not None:
            self._paint_loupe(p)
        fl = getattr(self, "_flash", None)
        if fl is not None:
            r, t0 = fl
            k = (time.perf_counter() - t0) / 0.35
            if k < 1.0:
                p.fillRect(r, QColor(255, 255, 255, int(235 * (1.0 - k) ** 1.5)))
                p.setPen(QColor(31, 91, 216, int(255 * (1.0 - k))))
                p.drawRect(r.adjusted(0.5, 0.5, -0.5, -0.5))
            else:
                self._flash = None
        p.end()
        if missing:
            missing.sort(key=lambda m: m[0])
            self._queue = missing
            if not self._render_timer.isActive():
                self._render_timer.start(0)

    def _render_some(self):
        doc = self.pdfdoc
        if not doc or not self._queue:
            return
        t0 = time.perf_counter()
        done = 0
        while self._queue and (time.perf_counter() - t0 < 0.03 or done == 0):
            d, key, i, sdev, tx, ty = self._queue.pop(0)
            if CACHE.get(key) is not None or i >= doc.page_count:
                continue
            try:
                if sdev is None:          # thumbnail placeholder
                    img = self._render_thumb(i, key[5])
                    CACHE.put(key, (img, 0, 0), ("t", doc.uid, doc.epoch, i, key[5]))
                else:
                    self._render_tile(key, i, sdev, tx, ty)
            except Exception:
                CACHE.put(key, (QImage(1, 1, QImage.Format_RGB888), 0, 0))
            done += 1
        self.viewport().update()

    def _render_tile(self, key, i, sdev, tx, ty):
        doc = self.pdfdoc
        rot, skey = key[5], key[6]
        pos = ("f", doc.uid, doc.epoch, i, rot, skey, tx, ty)
        T = TILE
        clip_v = pymupdf.Rect(tx * T / sdev, ty * T / sdev, (tx + 1) * T / sdev, (ty + 1) * T / sdev)
        clip = self.disp_rect_to_dl(i, clip_v)
        mat = self.render_matrix(i, sdev)
        odl = doc.overlay_dl(i)
        if odl is False:              # no low-level API: combined rendering
            dl = doc.display_list(i)
            clip = clip & dl.rect
            if clip.is_empty:
                CACHE.put(key, (QImage(1, 1, QImage.Format_RGB888), 0, 0), pos)
                return
            pix = dl.get_pixmap(matrix=mat, clip=clip, alpha=False)
            CACHE.put(key, (pix_to_qimage(pix), pix.x, pix.y), pos)
            return
        ckey = ("c", doc.uid, doc.epoch, i, doc.content_gen[i], rot, skey, tx, ty)
        cpix = CACHE.get(ckey)
        if cpix is None:
            cdl = doc.content_dl(i)
            clip = clip & cdl.rect
            if clip.is_empty:
                CACHE.put(key, (QImage(1, 1, QImage.Format_RGB888), 0, 0), pos)
                return
            cpix = cdl.get_pixmap(matrix=mat, clip=clip, alpha=False)
            CACHE.put(ckey, cpix)
        if odl:
            pix = pymupdf.Pixmap(cpix)
            doc.draw_overlay(i, pix, mat)
        else:
            pix = cpix
        CACHE.put(key, (pix_to_qimage(pix), pix.x, pix.y), pos)

    def _render_thumb(self, i, rot=0):
        doc = self.pdfdoc
        w, h = doc.page_sizes()[i]
        ts = min(420.0 / max(w, h), 1.5)
        old = self.view_rot
        self.view_rot = rot
        try:
            mat = self.render_matrix(i, ts)
        finally:
            self.view_rot = old
        return pix_to_qimage(doc.render(i, mat))

    def get_thumbnail(self, i, max_dim=420):
        """QImage thumbnail (shared cache, unrotated view) for panels."""
        doc = self.pdfdoc
        key = ("t", doc.uid, doc.epoch, i, doc.gen[i], 0)
        t = CACHE.get(key)
        if t is None:
            t = (self._render_thumb(i, 0), 0, 0)
            CACHE.put(key, t, ("t", doc.uid, doc.epoch, i, 0))
        return t[0]

    def _paint_page_overlays(self, p, i, rv, s):
        doc = self.pdfdoc
        p.setRenderHint(QPainter.Antialiasing, True)
        # search hits
        hits = doc.search_hits.get(i)
        if hits:
            for k, q in enumerate(hits):
                rr = self.unrot_rect_to_view(i, tuple(q.rect if hasattr(q, "rect") else q))
                cur = doc.search_current == (i, k)
                p.fillRect(rr, QColor(255, 120, 0, 120) if cur else QColor(255, 220, 0, 110))
                if cur:
                    p.setPen(QPen(QColor(230, 80, 0), 1.5))
                    p.drawRect(rr)
        # text selection
        if self.text_sel and self.text_sel[0] == i:
            for rect in self.text_sel[1]:
                p.fillRect(self.unrot_rect_to_view(i, rect), QColor(31, 91, 216, 70))
        # form fields
        if self.show_forms and getattr(doc, "has_forms", None) is not False:
            try:
                ws = self._widgets_cache(i)
                if ws:
                    p.setPen(Qt.NoPen)
                    for (rect, _) in ws:
                        p.fillRect(self.unrot_rect_to_view(i, rect), QColor(120, 170, 255, 45))
            except Exception:
                pass
        # origin marker
        try:
            org = doc.get_origin(i) if getattr(self, "show_origin", True) else None
        except Exception:
            org = None
        if org:
            c = self.unrot_to_view(i, *org)
            p.setPen(QPen(QColor(0, 150, 60), 1.5))
            p.drawLine(c, c + QPointF(28, 0))
            p.drawLine(c, c + QPointF(0, -28))
            p.drawEllipse(c, 4, 4)
            p.setFont(QFont("Segoe UI", 7, QFont.Bold))
            p.drawText(c + QPointF(30, 4), "X")
            p.drawText(c + QPointF(-3, -31), "Y")
        # selected annotation
        if self.selected and self.selected[0] == i:
            a = self.selected_annot_info()
            if a:
                rr = self.unrot_rect_to_view(i, a["rect"]).adjusted(-2, -2, 2, 2)
                p.setPen(QPen(QColor(theme.BLUE), 1, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(rr)
                p.setPen(QPen(QColor(theme.BLUE), 1))
                p.setBrush(Qt.white)
                for h in self.annot_handles(a):
                    p.drawRect(QRectF(h[1].x() - 3.5, h[1].y() - 3.5, 7, 7))

    def _widgets_cache(self, i):
        doc = self.pdfdoc
        key = (doc.epoch, i, doc.gen[i])
        cache = getattr(self, "_wcache", {})
        if key not in cache:
            lst = []
            try:
                page = doc.page(i)
                for w in page.widgets():
                    lst.append((tuple(w.rect), w.xref))
            except Exception:
                pass
            if len(cache) > 50:
                cache.clear()
            cache[key] = lst
            self._wcache = cache
        return cache[key]

    # --------------------------------------------------------- annotations
    def set_selected(self, sel):
        self.selected = sel
        self.viewport().update()
        self.selection_changed.emit(sel)

    def selected_annot_info(self):
        if not self.selected or not self.pdfdoc:
            return None
        pg, xref = self.selected
        if pg >= self.pdfdoc.page_count:
            return None
        for a in self.pdfdoc.annot_list(pg):
            if a["xref"] == xref:
                return a
        return None

    def annot_handles(self, a):
        """[(handle_id, QPointF view pos)] for the selected annotation."""
        i = self.selected[0]
        t = a["type"]
        if t == "Line" and a.get("vertices") and len(a["vertices"]) >= 2:
            return [("v0", self.unrot_to_view(i, *a["vertices"][0])), ("v1", self.unrot_to_view(i, *a["vertices"][1]))]
        if t == "Polygon" and a.get("cloud", {}).get("rect") and a.get("vertices"):
            vs = a["vertices"]
            r = (min(p[0] for p in vs), min(p[1] for p in vs), max(p[0] for p in vs), max(p[1] for p in vs))
            rr = self.unrot_rect_to_view(i, r)
            return [("tl", rr.topLeft()), ("tr", rr.topRight()), ("bl", rr.bottomLeft()), ("br", rr.bottomRight()),
                    ("t", QPointF(rr.center().x(), rr.top())), ("b", QPointF(rr.center().x(), rr.bottom())),
                    ("l", QPointF(rr.left(), rr.center().y())), ("r", QPointF(rr.right(), rr.center().y()))]
        if t in ("Polygon", "PolyLine") and a.get("vertices"):
            return [("v%d" % k, self.unrot_to_view(i, *v)) for k, v in enumerate(a["vertices"])]
        if t in ("Square", "Circle", "FreeText", "Stamp", "Redact", "Ink"):
            rr = self.unrot_rect_to_view(i, a["rect"])
            return [("tl", rr.topLeft()), ("tr", rr.topRight()), ("bl", rr.bottomLeft()), ("br", rr.bottomRight()),
                    ("t", QPointF(rr.center().x(), rr.top())), ("b", QPointF(rr.center().x(), rr.bottom())),
                    ("l", QPointF(rr.left(), rr.center().y())), ("r", QPointF(rr.right(), rr.center().y()))]
        return []

    def annot_at(self, pos):
        """(page, annot dict) under viewport pos (topmost), or None."""
        h = self.hit_unrot(pos)
        if not h:
            return None
        i, x, y = h
        tol = self.view_tol_pt(i, 5)
        best = None
        for a in reversed(self.pdfdoc.annot_list(i)):
            if a["type"] in ("Popup", "Widget", "Link"):
                continue
            x0, y0, x1, y1 = a["rect"]
            if not (x0 - tol <= x <= x1 + tol and y0 - tol <= y <= y1 + tol):
                continue
            t = a["type"]
            if t in ("Line", "PolyLine", "Ink") and a.get("vertices"):
                strokes = a["vertices"] if t == "Ink" else [a["vertices"]]
                ok = False
                for st in strokes:
                    for k in range(len(st) - 1):
                        if _dist_seg(x, y, st[k], st[k + 1]) <= tol * 1.6:
                            ok = True
                            break
                    if ok:
                        break
                if not ok:
                    continue
            elif t in ("Square", "Circle", "Polygon"):
                # hollow shapes: hit only near the border unless filled
                fill = (a.get("colors") or {}).get("fill")
                if not fill:
                    near_edge = min(abs(x - x0), abs(x - x1), abs(y - y0), abs(y - y1)) <= tol * 2.5
                    if t == "Polygon" and a.get("vertices"):
                        v = a["vertices"]
                        near_edge = any(_dist_seg(x, y, v[k], v[(k + 1) % len(v)]) <= tol * 2.5 for k in range(len(v)))
                    if not near_edge:
                        if best is None:
                            best = (i, a)  # remember as weak candidate
                        continue
            return i, a
        return best

    # ------------------------------------------------------------- loupe
    def _render_loupe(self):
        if not self.loupe_active or self.loupe_pos is None or not self.pdfdoc:
            return
        h = self.hit(self.loupe_pos)
        if not h:
            self.loupe_img = None
            self.viewport().update()
            return
        i, xd, yd = h
        dpr = self.devicePixelRatioF()
        L = self.loupe_size
        sl = self.page_scale(i) * self.loupe_zoom
        half = (L / 2.0) / sl
        clip_v = pymupdf.Rect(xd - half, yd - half, xd + half, yd + half)
        clip = self.disp_rect_to_dl(i, clip_v)
        page_rect = pymupdf.Rect(0, 0, *self.pdfdoc.page_sizes()[i])
        c2 = clip & page_rect
        if c2.is_empty:
            self.loupe_img = None
        else:
            m = sl * dpr
            try:
                pix = self.pdfdoc.render(i, self.render_matrix(i, m), clip=c2)
                ox = (pix.x - (xd - half) * m) / dpr
                oy = (pix.y - (yd - half) * m) / dpr
                self.loupe_img = (pix_to_qimage(pix), ox, oy, (i, xd, yd))
            except Exception:
                self.loupe_img = None
        self.viewport().update()

    def _paint_loupe(self, p):
        L = self.loupe_size
        c = self.loupe_pos
        rect = QRectF(c.x() - L / 2, c.y() - L / 2, L, L)
        path = QPainterPath()
        path.addEllipse(rect)
        p.save()
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillPath(path.translated(4, 5), QColor(0, 0, 0, 70))
        p.setClipPath(path)
        p.fillRect(rect, QColor(theme.VIEW_BG))
        if self.loupe_img:
            img, ox, oy, _ = self.loupe_img
            dpr = self.devicePixelRatioF()
            p.drawImage(QRectF(rect.left() + ox, rect.top() + oy, img.width() / dpr, img.height() / dpr), img)
        p.setPen(QPen(QColor(220, 0, 0, 160), 1))
        p.drawLine(QPointF(c.x() - 10, c.y()), QPointF(c.x() + 10, c.y()))
        p.drawLine(QPointF(c.x(), c.y() - 10), QPointF(c.x(), c.y() + 10))
        p.setClipping(False)
        p.setPen(QPen(QColor(theme.NAVY), 4))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(rect)
        p.setPen(QPen(QColor(theme.GREEN), 1.5))
        p.drawEllipse(rect.adjusted(2.5, 2.5, -2.5, -2.5))
        # zoom badge
        txt = "%d%%  x%g%s" % (round(self.zoom_percent() * self.loupe_zoom), self.loupe_zoom, "  (pinned)" if self.loupe_pinned else "")
        p.setFont(QFont("Segoe UI", 8, QFont.Bold))
        fm = p.fontMetrics()
        w = fm.horizontalAdvance(txt) + 14
        badge = QRectF(c.x() - w / 2, rect.bottom() - 6, w, 18)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(theme.NAVY))
        p.drawRoundedRect(badge, 8, 8)
        p.setPen(Qt.white)
        p.drawText(badge, Qt.AlignCenter, txt)
        p.restore()

    def set_loupe(self, active):
        self.loupe_active = active
        self.loupe_pinned = False
        if active:
            self.loupe_pos = self.viewport().mapFromGlobal(QCursor.pos())
            if not self.viewport().rect().contains(self.loupe_pos):
                self.loupe_pos = QPointF(self.viewport().width() / 2, self.viewport().height() / 2)
            self.loupe_pos = QPointF(self.loupe_pos)
            self._loupe_timer.start(0)
        else:
            self.loupe_img = None
        self.viewport().update()

    # -------------------------------------------------------------- events
    def set_tool(self, tool):
        if self.tool is not None:
            try:
                self.tool.deactivate()
            except Exception:
                pass
        self.tool = tool
        if tool is not None:
            tool.view = self
            try:
                tool.activate()
            except Exception:
                pass
            self.viewport().setCursor(tool.cursor())
        self.viewport().update()

    def mousePressEvent(self, e):
        self.activated.emit(self)
        self.setFocus()
        if e.button() == Qt.MiddleButton or (e.button() == Qt.LeftButton and self._space_pan):
            self._pan = (e.position(), self.offset())
            self.viewport().setCursor(Qt.ClosedHandCursor)
            return
        if self.loupe_active and e.button() == Qt.LeftButton and self.tool and self.tool.name == "loupe":
            self.loupe_pinned = not self.loupe_pinned
            self.loupe_pos = e.position()
            self._loupe_timer.start(0)
            return
        if self.tool:
            self.tool.press(e)

    def mouseMoveEvent(self, e):
        if self._pan is not None:
            start, off = self._pan
            d = e.position() - start
            self.horizontalScrollBar().setValue(int(off.x() - d.x()))
            self.verticalScrollBar().setValue(int(off.y() - d.y()))
            return
        if self.loupe_active and not self.loupe_pinned:
            self.loupe_pos = e.position()
            if not self._loupe_timer.isActive():
                self._loupe_timer.start(12)
            self.viewport().update()
        h = self.hit_unrot(e.position())
        self.cursor_moved.emit(h)
        if self.tool:
            self.tool.move(e)

    def mouseReleaseEvent(self, e):
        if self._pan is not None and (e.button() == Qt.MiddleButton or e.button() == Qt.LeftButton):
            self._pan = None
            self.viewport().setCursor(self.tool.cursor() if self.tool else Qt.ArrowCursor)
            return
        if self.tool:
            self.tool.release(e)

    def mouseDoubleClickEvent(self, e):
        if self.tool:
            self.tool.double_click(e)

    def wheelEvent(self, e):
        dy = e.angleDelta().y()
        if self.loupe_active:
            if dy:
                f = 2 ** (1 / 4) if dy > 0 else 2 ** (-1 / 4)
                self.loupe_zoom = max(1.25, min(128.0, round(self.loupe_zoom * f, 2)))
                self._loupe_timer.start(0)
                if self.main:
                    self.main.on_loupe_zoom_changed(self.loupe_zoom)
            return
        if e.modifiers() & Qt.ControlModifier:
            if self.mode == "grid":
                cols = self.grid_cols + (-1 if dy > 0 else 1)
                rows = max(1, round(self.grid_rows * max(1, cols) / max(1, self.grid_cols)))
                self.set_grid(max(1, min(12, cols)), max(1, min(8, rows)))
                if self.main:
                    self.main.on_grid_changed(self)
                return
            f = 1.15 if dy > 0 else 1 / 1.15
            self.zoom_by(f, e.position())
            return
        if self.mode == "single":
            vs = self.verticalScrollBar()
            if dy < 0 and vs.value() >= vs.maximum():
                if self.current < self.pdfdoc.page_count - 1:
                    self.go_to_page(self.current + 1)
                return
            if dy > 0 and vs.value() <= vs.minimum():
                if self.current > 0:
                    self.go_to_page(self.current - 1)
                    self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())
                return
        super().wheelEvent(e)

    def event(self, e):
        # let the active tool claim keys that are also application shortcuts (Ctrl+D, Ctrl+A, Del ...)
        if e.type() == QEvent.ShortcutOverride and self.tool is not None:
            wants = getattr(self.tool, "wants_key", None)
            try:
                if wants and wants(e):
                    e.accept()
                    return True
            except Exception:
                pass
        return super().event(e)

    def keyPressEvent(self, e):
        k = e.key()
        if k == Qt.Key_Space and not e.isAutoRepeat():
            self._space_pan = True
            self.viewport().setCursor(Qt.OpenHandCursor)
            return
        if self.tool and self.tool.key(e):
            return
        if k == Qt.Key_Delete and self.selected and self.main:
            self.main.delete_selected_annot(self)
            return
        if e.matches(QKeySequence.Copy) and self.text_sel:
            if self.main and hasattr(self.main, "copy_text_selection"):
                self.main.copy_text_selection(self)
            else:
                QGuiApplication.clipboard().setText(self.text_sel[2])
            return
        if k in (Qt.Key_PageDown,) or (k == Qt.Key_Right and self.mode == "single"):
            self.next_page()
            return
        if k in (Qt.Key_PageUp,) or (k == Qt.Key_Left and self.mode == "single"):
            self.prev_page()
            return
        if k == Qt.Key_Home and e.modifiers() & Qt.ControlModifier:
            self.go_to_page(0)
            return
        if k == Qt.Key_End and e.modifiers() & Qt.ControlModifier:
            self.go_to_page(self.pdfdoc.page_count - 1)
            return
        super().keyPressEvent(e)

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key_Space and not e.isAutoRepeat():
            self._space_pan = False
            self.viewport().setCursor(self.tool.cursor() if self.tool else Qt.ArrowCursor)
            return
        super().keyReleaseEvent(e)

    def contextMenuEvent(self, e):
        if self.tool and self.tool.context(e):
            return
        if self.main:
            self.main.show_view_menu(self, e.pos(), e.globalPos())

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        files = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if files and self.main:
            self.main.open_files(files)

    def leaveEvent(self, e):
        self.cursor_moved.emit(None)
        if self.loupe_active and not self.loupe_pinned:
            self.loupe_pos = None
            self.viewport().update()
        super().leaveEvent(e)


def _dist_seg(x, y, a, b):
    ax, ay = a
    bx, by = b
    vx, vy = bx - ax, by - ay
    L2 = vx * vx + vy * vy
    if L2 < 1e-12:
        return math.hypot(x - ax, y - ay)
    t = max(0.0, min(1.0, ((x - ax) * vx + (y - ay) * vy) / L2))
    return math.hypot(ax + t * vx - x, ay + t * vy - y)
