"""Measurement: scale (manual / calibrated / automatic), units, distance, perimeter, area + centroid, angle."""
import json
import math
import re
import uuid

import pymupdf
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QPen, QColor, QFont, QPolygonF
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QComboBox, QDoubleSpinBox, QSpinBox,
                               QRadioButton, QButtonGroup, QLabel, QPushButton, QLineEdit, QGroupBox, QMessageBox,
                               QDialogButtonBox, QGridLayout)

from .tools import TwoPointTool, MultiPointTool, Tool, qcolor, draw_snap_glyph
from .settings import settings, parse_page_range
from . import annots as A
from . import theme

UNIT_TO_M = {"mm": 0.001, "cm": 0.01, "m": 1.0, "in": 0.0254, "ft": 0.3048}
UNIT_LABEL = {"mm": "mm", "cm": "cm", "m": "m", "in": "in", "ft": "ft"}
PT_TO_M = 0.0254 / 72.0
PAPER_SIZES = {"A0": (841, 1189), "A1": (594, 841), "A2": (420, 594), "A3": (297, 420), "A4": (210, 297),
               "Letter": (215.9, 279.4), "Tabloid": (279.4, 431.8), "ANSI D": (558.8, 863.6)}


def paper_scale(unit="mm"):
    return {"m_per_pt": PT_TO_M, "unit": unit, "label": "1 : 1 (paper)", "method": "paper"}


def ratio_scale(ratio, unit="mm"):
    return {"m_per_pt": PT_TO_M * float(ratio), "unit": unit, "label": "1 : %g" % float(ratio), "method": "ratio"}


def fmt_len(v_m, unit, prec=None):
    prec = settings().get("measure_precision", 3) if prec is None else prec
    return "%.*f %s" % (prec, v_m / UNIT_TO_M[unit], UNIT_LABEL[unit])


def fmt_area(v_m2, unit, prec=None):
    prec = settings().get("measure_precision", 3) if prec is None else prec
    f = UNIT_TO_M[unit] ** 2
    return "%.*f %s²" % (prec, v_m2 / f, UNIT_LABEL[unit])


def get_scale(pdfdoc, i):
    s = pdfdoc.get_scale(i)
    if s and s.get("m_per_pt"):
        return s
    return paper_scale(settings().get("measure_unit", "mm") if settings().get("measure_unit") in UNIT_TO_M else "mm")


def polygon_area_centroid(pts):
    """Signed-area formula. pts: [(x, y)]. Returns (area, cx, cy) with area >= 0."""
    n = len(pts)
    if n < 3:
        return 0.0, None, None
    a = cx = cy = 0.0
    for k in range(n):
        x0, y0 = pts[k]
        x1, y1 = pts[(k + 1) % n]
        c = x0 * y1 - x1 * y0
        a += c
        cx += (x0 + x1) * c
        cy += (y0 + y1) * c
    a *= 0.5
    if abs(a) < 1e-12:
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return 0.0, sum(xs) / n, sum(ys) / n
    return abs(a), cx / (6 * a), cy / (6 * a)


def path_length(pts, closed=False):
    L = sum(math.hypot(pts[k + 1][0] - pts[k][0], pts[k + 1][1] - pts[k][1]) for k in range(len(pts) - 1))
    if closed and len(pts) > 2:
        L += math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1])
    return L


def page_paper_name(page):
    w = page.rect.width * 25.4 / 72
    h = page.rect.height * 25.4 / 72
    a, b = sorted((w, h))
    for name, (pw, ph) in PAPER_SIZES.items():
        if abs(a - pw) < 4 and abs(b - ph) < 4:
            return name
    return None


def detect_scale(pdfdoc, i):
    """Try to find the drawing scale automatically. Returns (scale|None, message)."""
    doc = pdfdoc.doc
    page = doc.load_page(i)
    # 1. standard PDF viewport measure dictionary (AutoCAD, PDF-XChange, Acrobat)
    try:
        t, v = doc.xref_get_key(page.xref, "VP")
        raw = v
        if t == "xref":
            raw = doc.xref_object(int(v.split()[0]))
        if raw and "/Measure" in raw:
            mx = re.search(r"/X\s*\[\s*<<(.*?)>>", raw, re.S)
            if mx:
                c = re.search(r"/C\s+([-\d.eE+]+)", mx.group(1))
                u = re.search(r"/U\s*\(([^)]*)\)", mx.group(1))
                if c:
                    unit = (u.group(1).strip().lower() if u else "mm")
                    unit = {"millimeters": "mm", "meter": "m", "meters": "m", "inch": "in", "inches": "in",
                            "\"": "in", "feet": "ft", "foot": "ft", "'": "ft", "centimeters": "cm"}.get(unit, unit)
                    if unit in UNIT_TO_M:
                        mpp = float(c.group(1)) * UNIT_TO_M[unit]
                        r = re.search(r"/R\s*\(([^)]*)\)", raw)
                        lab = r.group(1) if r else "PDF viewport scale"
                        return ({"m_per_pt": mpp, "unit": unit, "label": lab, "method": "auto-viewport"},
                                "Scale read from the PDF measurement dictionary: %s (%s)." % (lab, unit))
    except Exception:
        pass
    # 2. scale text on the sheet ('SCALE 1:100', 'SKALA 1 : 50', title block '1 : 115')
    try:
        text = page.get_text("text")
    except Exception:
        text = ""
    m = re.search(r"(?:SCALE|SKALA|SCALA)\s*[:=]?\s*1\s*[:/]\s*(\d+(?:[.,]\d+)?)", text, re.I)
    cand = None
    if m:
        cand = m.group(1)
    else:
        vals = re.findall(r"(?<![\d.])1\s*:\s*(\d{1,5}(?:[.,]\d+)?)(?![\d])", text)
        uniq = sorted(set(vals))
        if len(uniq) == 1:
            cand = uniq[0]
    paper = page_paper_name(page)
    if cand:
        ratio = float(cand.replace(",", "."))
        s = ratio_scale(ratio, settings().get("measure_unit", "m") if settings().get("measure_unit") in UNIT_TO_M else "m")
        s["method"] = "auto-text"
        msg = "Scale text found on the sheet: 1 : %g" % ratio
        if paper:
            msg += " (sheet size %s, printed at true size)." % paper
        else:
            msg += ". Sheet size is not a standard paper size - check with 'Calibrate' if the PDF was not printed at true size."
        return s, msg
    msg = "No scale information found in this page"
    if not text.strip():
        msg += " (the drawing text is vector lines, not searchable text)"
    msg += ". Enter the ratio from the title block or calibrate on a known dimension."
    if paper:
        msg += "\nDetected sheet size: %s." % paper
    return None, msg


def page_label_scale(pdfdoc, i):
    s = get_scale(pdfdoc, i)
    return "%s  [%s]" % (s.get("label", ""), s.get("unit", ""))


# ======================================================================== UI
class ScaleDialog(QDialog):
    calibrate_requested = False

    def __init__(self, main, pdfdoc, page_index):
        super().__init__(main)
        self.setWindowTitle("Measurement Scale")
        self.pdfdoc = pdfdoc
        self.page_index = page_index
        self.result_scale = None
        self.result_pages = []
        lay = QVBoxLayout(self)
        cur = pdfdoc.get_scale(page_index)
        info = QLabel("Current scale of page %d:  <b>%s</b>" % (page_index + 1, page_label_scale(pdfdoc, page_index)))
        lay.addWidget(info)
        box = QGroupBox("Scale")
        g = QGridLayout(box)
        self.r_ratio = QRadioButton("Drawing ratio")
        self.r_custom = QRadioButton("Paper length")
        self.r_ratio.setChecked(True)
        self.ratio = QDoubleSpinBox()
        self.ratio.setDecimals(3)
        self.ratio.setRange(0.0001, 1e7)
        self.ratio.setValue(100)
        g.addWidget(self.r_ratio, 0, 0)
        g.addWidget(QLabel("1 :"), 0, 1)
        g.addWidget(self.ratio, 0, 2)
        self.paper_len = QDoubleSpinBox()
        self.paper_len.setRange(0.0001, 1e7)
        self.paper_len.setDecimals(4)
        self.paper_len.setValue(1)
        self.paper_unit = QComboBox()
        self.paper_unit.addItems(["mm", "cm", "in"])
        self.real_len = QDoubleSpinBox()
        self.real_len.setRange(0.0001, 1e9)
        self.real_len.setDecimals(4)
        self.real_len.setValue(1)
        self.real_unit = QComboBox()
        self.real_unit.addItems(list(UNIT_TO_M.keys()))
        self.real_unit.setCurrentText("m")
        g.addWidget(self.r_custom, 1, 0)
        row = QHBoxLayout()
        row.addWidget(self.paper_len)
        row.addWidget(self.paper_unit)
        row.addWidget(QLabel(" on paper  ="))
        row.addWidget(self.real_len)
        row.addWidget(self.real_unit)
        row.addWidget(QLabel(" real"))
        g.addLayout(row, 1, 1, 1, 3)
        lay.addWidget(box)
        f = QFormLayout()
        self.unit = QComboBox()
        self.unit.addItems(list(UNIT_TO_M.keys()))
        self.unit.setCurrentText(cur.get("unit") if cur else settings().get("measure_unit", "m"))
        self.prec = QSpinBox()
        self.prec.setRange(0, 6)
        self.prec.setValue(settings().get("measure_precision", 3))
        f.addRow("Display unit", self.unit)
        f.addRow("Decimal places", self.prec)
        self.apply = QComboBox()
        self.apply.addItems(["This page", "All pages", "Page range…"])
        self.range = QLineEdit()
        self.range.setPlaceholderText("e.g. 1-3, 5")
        self.range.setEnabled(False)
        self.apply.currentIndexChanged.connect(lambda k: self.range.setEnabled(k == 2))
        f.addRow("Apply to", self.apply)
        f.addRow("Pages", self.range)
        lay.addLayout(f)
        if cur and cur.get("method") == "ratio":
            try:
                self.ratio.setValue(cur["m_per_pt"] / PT_TO_M)
            except Exception:
                pass
        brow = QHBoxLayout()
        b_auto = QPushButton(theme.icon("auto-fix"), "Auto detect")
        b_cal = QPushButton(theme.icon("tape-measure"), "Calibrate on drawing…")
        b_paper = QPushButton("Paper 1:1")
        b_auto.clicked.connect(self.auto)
        b_cal.clicked.connect(self.calibrate)
        b_paper.clicked.connect(lambda: (self.r_ratio.setChecked(True), self.ratio.setValue(1)))
        brow.addWidget(b_auto)
        brow.addWidget(b_cal)
        brow.addWidget(b_paper)
        lay.addLayout(brow)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        self.msg.setStyleSheet("color:#334;background:#F3F7FD;border:1px solid #D5E2F5;padding:6px;")
        lay.addWidget(self.msg)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.ok)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def auto(self):
        s, msg = detect_scale(self.pdfdoc, self.page_index)
        self.msg.setText(msg)
        if s:
            self.r_ratio.setChecked(True)
            self.ratio.setValue(s["m_per_pt"] / PT_TO_M)
            self._auto = s

    def calibrate(self):
        self.calibrate_requested = True
        settings().set("measure_unit", self.unit.currentText())
        self.reject()

    def ok(self):
        unit = self.unit.currentText()
        if self.r_ratio.isChecked():
            s = ratio_scale(self.ratio.value(), unit)
            if getattr(self, "_auto", None) and abs(self._auto["m_per_pt"] - s["m_per_pt"]) < 1e-12:
                s["method"] = self._auto.get("method", "ratio")
                s["label"] = self._auto.get("label", s["label"]) if self._auto.get("method") == "auto-viewport" else s["label"]
                s["method"] = "ratio"
        else:
            paper_m = self.paper_len.value() * UNIT_TO_M[self.paper_unit.currentText()]
            real_m = self.real_len.value() * UNIT_TO_M[self.real_unit.currentText()]
            ratio = real_m / paper_m
            s = {"m_per_pt": PT_TO_M * ratio, "unit": unit, "method": "ratio",
                 "label": "%g %s = %g %s" % (self.paper_len.value(), self.paper_unit.currentText(), self.real_len.value(), self.real_unit.currentText())}
        n = self.pdfdoc.page_count
        k = self.apply.currentIndex()
        if k == 0:
            pages = [self.page_index]
        elif k == 1:
            pages = list(range(n))
        else:
            pages = parse_page_range(self.range.text(), n)
        settings().set("measure_unit", unit)
        settings().set("measure_precision", self.prec.value())
        settings().save()
        self.result_scale = s
        self.result_pages = pages
        self.accept()


class CalibrateDialog(QDialog):
    def __init__(self, main, measured_pt, n_pages):
        super().__init__(main)
        self.setWindowTitle("Calibrate scale")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Picked distance on paper: <b>%.2f mm</b>" % (measured_pt * 25.4 / 72)))
        f = QFormLayout()
        self.val = QDoubleSpinBox()
        self.val.setRange(0.000001, 1e9)
        self.val.setDecimals(4)
        self.val.setValue(1.0)
        self.unit = QComboBox()
        self.unit.addItems(list(UNIT_TO_M.keys()))
        self.unit.setCurrentText(settings().get("measure_unit", "m"))
        row = QHBoxLayout()
        row.addWidget(self.val)
        row.addWidget(self.unit)
        f.addRow("Real length of this distance", row)
        self.apply = QComboBox()
        self.apply.addItems(["This page", "All pages"])
        f.addRow("Apply to", self.apply)
        lay.addLayout(f)
        self.preview = QLabel("")
        lay.addWidget(self.preview)
        self.measured_pt = measured_pt
        self.val.valueChanged.connect(self._upd)
        self.unit.currentTextChanged.connect(self._upd)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self._upd()

    def _upd(self):
        real_m = self.val.value() * UNIT_TO_M[self.unit.currentText()]
        ratio = real_m / max(1e-12, self.measured_pt * PT_TO_M)
        self.preview.setText("Resulting drawing ratio  ≈  1 : %.3f" % ratio)

    def scale(self):
        real_m = self.val.value() * UNIT_TO_M[self.unit.currentText()]
        mpp = real_m / max(1e-12, self.measured_pt)
        return {"m_per_pt": mpp, "unit": self.unit.currentText(), "method": "calibrated",
                "label": "Calibrated 1 : %.3f" % (mpp / PT_TO_M)}


# ===================================================================== tools
def _measure_style():
    c = settings().get("measure_color", [0.0, 0.45, 0.85])
    return {"stroke": c, "width": 1.0, "fontsize": 9.0, "font": "Helvetica"}


def _label_box(text, fs):
    w, h = A.freetext_size(text, fs, "Helvetica", min_w=20)
    return w, h


class _MeasureMixin:
    """Shared helpers for measurement tools."""

    def scale_for(self, i):
        return get_scale(self.doc, i)

    def real_len(self, i, pts_unrot, closed=False):
        s = self.scale_for(i)
        return path_length(pts_unrot, closed) * s["m_per_pt"], s

    def draw_label(self, p, pos, text):
        p.save()
        f = QFont("Segoe UI", 9, QFont.Bold)
        p.setFont(f)
        fm = p.fontMetrics()
        lines = text.split("\n")
        w = max(fm.horizontalAdvance(ln) for ln in lines) + 12
        h = fm.height() * len(lines) + 6
        r = QRectF(pos.x() + 14, pos.y() + 14, w, h)
        p.setPen(QPen(QColor(theme.NAVY), 1))
        p.setBrush(QColor(255, 255, 245, 240))
        p.drawRoundedRect(r, 3, 3)
        p.setPen(QColor(theme.NAVY))
        p.drawText(r.adjusted(6, 3, -6, -3), Qt.AlignLeft | Qt.AlignVCenter, text)
        p.restore()

    def add_label(self, page, anchor_unrot, text, st, group, rotate=0, offset_disp=(6, -6)):
        fs = float(st.get("fontsize", 9))
        w, h = _label_box(text, fs)
        derot = self.view.derot(self._page_index)
        ad = pymupdf.Point(*self.view.to_disp(self._page_index, *anchor_unrot))
        rd = pymupdf.Rect(ad.x + offset_disp[0], ad.y + offset_disp[1] - h, ad.x + offset_disp[0] + w, ad.y + offset_disp[1])
        r = rd * derot
        ur = pymupdf.Rect(min(r.x0, r.x1), min(r.y0, r.y1), max(r.x0, r.x1), max(r.y0, r.y1))
        lab = A.create_freetext(page, ur, text, {"stroke": st["stroke"], "fill": [1, 1, 1], "fontsize": fs, "width": 0,
                                                  "border": False, "opacity": 0.95, "subject": "Measurement label"},
                                self.author(), rotate=self.view.total_rot(self._page_index))
        self.doc.doc.xref_set_key(lab.xref, "AliefGroup", pymupdf.get_pdf_str(group))
        return lab

    def tag(self, annot, group, data):
        d = self.doc.doc
        d.xref_set_key(annot.xref, "AliefGroup", pymupdf.get_pdf_str(group))
        d.xref_set_key(annot.xref, "AliefMeasure", pymupdf.get_pdf_str(json.dumps(data)))


class DistanceTool(_MeasureMixin, TwoPointTool):
    name = "m_distance"

    def __init__(self, main=None, style=None):
        super().__init__(main, style or _measure_style())

    def paint_extra(self, p):
        a, b = self.a, self.b
        L, s = self.real_len(a.page, [a.unrot, b.unrot])
        # ΔX / ΔY / angle in the drawing frame (independent of the view rotation)
        ax_, ay_ = self.doc.to_disp(a.page, a.xu, a.yu)
        bx_, by_ = self.doc.to_disp(a.page, b.xu, b.yu)
        dx = (bx_ - ax_) * s["m_per_pt"]
        dy = (by_ - ay_) * s["m_per_pt"]
        ang = math.degrees(math.atan2(-(by_ - ay_), bx_ - ax_))
        self.draw_label(p, self.vpt(b), "L = %s\nΔX = %s   ΔY = %s\nAngle = %.2f°" % (
            fmt_len(L, s["unit"]), fmt_len(dx, s["unit"]), fmt_len(-dy, s["unit"]), ang))

    def finish(self, a, b):
        i = a.page
        self._page_index = i
        L, s = self.real_len(i, [a.unrot, b.unrot])
        st = dict(self.style)
        st.update({"line_start": "open", "line_end": "open"})
        txt = fmt_len(L, s["unit"])
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        g = "M" + uuid.uuid4().hex[:8]
        ln = A.create_shape(page, "line", st, self.author(), points=[a.unrot, b.unrot], content="Distance = " + txt)
        ln.set_info({"subject": "Measure: Distance", "content": "Distance = " + txt, "title": self.author()})
        ln.update()
        self.tag(ln, g, {"type": "Distance", "value_m": L, "unit": s["unit"], "text": txt, "scale": s.get("label", "")})
        mid = ((a.xu + b.xu) / 2, (a.yu + b.yu) / 2)
        self.add_label(page, mid, txt, st, g)
        doc.commit([i], content=False)
        self.done()


class PerimeterTool(_MeasureMixin, MultiPointTool):
    name = "m_perimeter"

    def __init__(self, main=None, style=None):
        super().__init__(main, style or _measure_style())

    def paint_extra(self, p, path):
        if not self.pts:
            return
        pts = [q.unrot for q in self.pts] + ([self.cur.unrot] if self.cur else [])
        L, s = self.real_len(self.pts[0].page, pts)
        self.draw_label(p, path[-1], "Length = %s\nSegments = %d   (double-click / Enter to finish)" % (fmt_len(L, s["unit"]), max(0, len(pts) - 1)))

    def finish(self, pts):
        i = pts[0].page
        self._page_index = i
        un = [q.unrot for q in pts]
        L, s = self.real_len(i, un)
        txt = fmt_len(L, s["unit"])
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        g = "M" + uuid.uuid4().hex[:8]
        pl = A.create_shape(page, "polyline", self.style, self.author(), points=un)
        pl.set_info({"subject": "Measure: Perimeter", "content": "Length = " + txt, "title": self.author()})
        pl.update()
        self.tag(pl, g, {"type": "Perimeter", "value_m": L, "unit": s["unit"], "text": txt, "scale": s.get("label", "")})
        self.add_label(page, un[-1], "L = " + txt, self.style, g)
        doc.commit([i], content=False)
        self.done()


class AreaTool(_MeasureMixin, MultiPointTool):
    name = "m_area"
    closed = True
    min_points = 3

    def __init__(self, main=None, style=None):
        st = style or _measure_style()
        st = dict(st)
        st["fill"] = st.get("fill") or [c * 0.35 + 0.65 for c in st["stroke"]]
        super().__init__(main, st)

    def _calc(self, i, un):
        s = self.scale_for(i)
        f = s["m_per_pt"]
        # use display orientation for centroid coordinates (X right, Y up)
        disp = [self.doc.to_disp(i, *q) for q in un]
        area_pt2, cxd, cyd = polygon_area_centroid(disp)
        perim = path_length(un, closed=True) * f
        org = self.doc.get_origin(i)
        if org:
            ox, oy = self.doc.to_disp(i, *org)
        else:
            ox, oy = 0.0, self.doc.page_sizes()[i][1]
        X = (cxd - ox) * f if cxd is not None else 0
        Y = (oy - cyd) * f if cyd is not None else 0
        cu = self.doc.to_unrot(i, cxd, cyd) if cxd is not None else un[0]
        return area_pt2 * f * f, perim, X, Y, cu, s

    def paint_extra(self, p, path):
        if not self.pts:
            return
        i = self.pts[0].page
        un = [q.unrot for q in self.pts] + ([self.cur.unrot] if self.cur else [])
        if len(un) < 3:
            L, s = self.real_len(i, un)
            self.draw_label(p, path[-1], "Length = %s\n(pick at least 3 points)" % fmt_len(L, s["unit"]))
            return
        area, per, X, Y, cu, s = self._calc(i, un)
        cv = self.view.unrot_to_view(i, *cu)
        p.setPen(QPen(QColor(220, 0, 0), 1.5))
        p.drawLine(cv + QPointF(-7, 0), cv + QPointF(7, 0))
        p.drawLine(cv + QPointF(0, -7), cv + QPointF(0, 7))
        self.draw_label(p, path[-1], "Area = %s\nPerimeter = %s\nCentroid X = %s  Y = %s" % (
            fmt_area(area, s["unit"]), fmt_len(per, s["unit"]), fmt_len(X, s["unit"]), fmt_len(Y, s["unit"])))

    def finish(self, pts):
        i = pts[0].page
        self._page_index = i
        un = [q.unrot for q in pts]
        area, per, X, Y, cu, s = self._calc(i, un)
        u = s["unit"]
        txt = "A = %s\nP = %s\nCG: X = %s, Y = %s" % (fmt_area(area, u), fmt_len(per, u), fmt_len(X, u), fmt_len(Y, u))
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        g = "M" + uuid.uuid4().hex[:8]
        st = dict(self.style, opacity=0.55)
        pg = A.create_shape(page, "polygon", st, self.author(), points=un)
        pg.set_info({"subject": "Measure: Area", "content": txt.replace("\n", "; "), "title": self.author()})
        pg.update()
        self.tag(pg, g, {"type": "Area", "value_m2": area, "perimeter_m": per, "cx_m": X, "cy_m": Y, "unit": u,
                         "text": txt.replace("\n", "; "), "scale": s.get("label", "")})
        # centroid cross
        sz = 5.0
        cx, cy = cu
        ink = page.add_ink_annot([[(cx - sz, cy), (cx + sz, cy)], [(cx, cy - sz), (cx, cy + sz)]])
        ink.set_colors(stroke=(0.85, 0, 0))
        ink.set_border(width=1.2)
        ink.set_info({"subject": "Measure: Centroid", "content": "Centroid X = %s, Y = %s" % (fmt_len(X, u), fmt_len(Y, u)),
                      "title": self.author()})
        ink.update()
        doc.doc.xref_set_key(ink.xref, "AliefGroup", pymupdf.get_pdf_str(g))
        self.add_label(page, cu, txt, self.style, g, offset_disp=(8, 30))
        doc.commit([i], content=False)
        self.done()


class AngleTool(_MeasureMixin, MultiPointTool):
    name = "m_angle"
    min_points = 3

    def __init__(self, main=None, style=None):
        super().__init__(main, style or _measure_style())

    def press(self, e):
        super().press(e)
        if len(self.pts) >= 3:
            self._finish()

    def _angle(self, a, v, b):
        a1 = math.atan2(a[1] - v[1], a[0] - v[0])
        a2 = math.atan2(b[1] - v[1], b[0] - v[0])
        d = abs(math.degrees(a2 - a1)) % 360
        return 360 - d if d > 180 else d

    def paint_extra(self, p, path):
        if len(self.pts) == 2 and self.cur:
            ang = self._angle(self.pts[0].unrot, self.pts[1].unrot, self.cur.unrot)
            self.draw_label(p, path[-1], "Angle = %.3f°" % ang)

    def finish(self, pts):
        i = pts[0].page
        self._page_index = i
        un = [q.unrot for q in pts[:3]]
        ang = self._angle(*un)
        txt = "%.2f°" % ang
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        g = "M" + uuid.uuid4().hex[:8]
        pl = A.create_shape(page, "polyline", self.style, self.author(), points=un)
        pl.set_info({"subject": "Measure: Angle", "content": "Angle = " + txt, "title": self.author()})
        pl.update()
        self.tag(pl, g, {"type": "Angle", "value_deg": ang, "unit": "deg", "text": txt})
        self.add_label(page, un[1], txt, self.style, g)
        doc.commit([i], content=False)
        self.done()


class CircleTool(_MeasureMixin, TwoPointTool):
    """Centre + point on circumference -> diameter, circumference and area."""
    name = "m_circle"

    def __init__(self, main=None, style=None):
        super().__init__(main, style or _measure_style())

    def paint(self, p):
        if self.a is not None and self.b is not None:
            c = self.vpt(self.a)
            r = (self.vpt(self.b) - c)
            rad = math.hypot(r.x(), r.y())
            p.setPen(self.style_pen(230, 1.5))
            p.setBrush(QColor(0, 110, 220, 30))
            p.drawEllipse(c, rad, rad)
            p.drawLine(c, self.vpt(self.b))
            R, s = self.real_len(self.a.page, [self.a.unrot, self.b.unrot])
            self.draw_label(p, self.vpt(self.b), "R = %s   Ø = %s\nArea = %s" % (fmt_len(R, s["unit"]), fmt_len(2 * R, s["unit"]),
                                                                              fmt_area(math.pi * R * R, s["unit"])))
        Tool.paint(self, p)

    def finish(self, a, b):
        i = a.page
        self._page_index = i
        R, s = self.real_len(i, [a.unrot, b.unrot])
        rpt = math.hypot(a.xu - b.xu, a.yu - b.yu)
        u = s["unit"]
        txt = "Ø = %s\nA = %s" % (fmt_len(2 * R, u), fmt_area(math.pi * R * R, u))
        doc = self.doc
        doc.checkpoint()
        page = doc.page(i)
        g = "M" + uuid.uuid4().hex[:8]
        st = dict(self.style)
        st["fill"] = [c * 0.35 + 0.65 for c in st["stroke"]]
        st["opacity"] = 0.55
        ci = A.create_shape(page, "ellipse", st, self.author(), rect=(a.xu - rpt, a.yu - rpt, a.xu + rpt, a.yu + rpt))
        ci.set_info({"subject": "Measure: Circle", "content": txt.replace("\n", "; "), "title": self.author()})
        ci.update()
        self.tag(ci, g, {"type": "Circle", "value_m2": math.pi * R * R, "diameter_m": 2 * R, "unit": u, "text": txt.replace("\n", "; ")})
        self.add_label(page, (a.xu + rpt * 0.7, a.yu - rpt * 0.7), txt, self.style, g)
        doc.commit([i], content=False)
        self.done()


class CalibrateTool(TwoPointTool):
    name = "m_calibrate"

    def __init__(self, main=None, style=None):
        super().__init__(main, {"stroke": [0.9, 0.1, 0.1], "width": 1.0})

    def paint_extra(self, p):
        d = math.hypot(self.b.xu - self.a.xu, self.b.yu - self.a.yu)
        p.save()
        p.setPen(QColor(theme.RED))
        p.setFont(QFont("Segoe UI", 9, QFont.Bold))
        p.drawText(self.vpt(self.b) + QPointF(12, -8), "%.2f mm on paper" % (d * 25.4 / 72))
        p.restore()

    def finish(self, a, b):
        d = math.hypot(b.xu - a.xu, b.yu - a.yu)
        dlg = CalibrateDialog(self.main, d, self.doc.page_count)
        if dlg.exec():
            s = dlg.scale()
            pages = [a.page] if dlg.apply.currentIndex() == 0 else list(range(self.doc.page_count))
            self.doc.checkpoint()
            self.doc.set_scale(pages, s)
            self.doc.commit(pages, annots=False, content=False)
            if self.main:
                self.main.on_scale_changed()
                self.main.status("Scale set: %s on %d page(s)." % (s["label"], len(pages)))
                self.main.set_tool("m_distance")


class OriginTool(Tool):
    name = "m_origin"
    snaps = True

    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        pk = self.pick(e.position())
        if not pk:
            return
        self.doc.checkpoint()
        self.doc.set_origin(pk.page, pk.unrot)
        self.doc.commit([pk.page], annots=False, content=False)
        if self.main:
            self.main.status("Origin (0,0) set on page %d. Coordinates and area centroids are measured from here (X right, Y up)." % (pk.page + 1))
            self.main.set_tool("m_area")
