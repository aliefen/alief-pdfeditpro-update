"""Edit page objects (text elements, images, shapes) directly in the PDF content stream.

The page content (and the content of Form XObjects used once) is tokenised; every painted
path, image and text run becomes an object with its byte range and graphics state.  Edits are
byte splices on the stream:

* move / resize   -> wrap the object in ``q A cm ... Q`` (A expressed in the object's own CTM),
                     text runs are cut out of their BT block and get a transformed text matrix
* delete          -> remove the operators (text: replaced by an equal blank advance so the rest
                     of the line keeps its place)
* duplicate       -> copy of the operators with an offset
* colour / width  -> ``q <colour> ... Q`` around a path, colour operators around a text run
"""
import json
import math
import re
import zlib

import numpy as np
import pymupdf

# ----------------------------------------------------------------------- matrices (PDF order)
ID = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def mmul(m, n):
    a, b, c, d, e, f = m
    A, B, C, D, E, F = n
    return (a * A + b * C, a * B + b * D, c * A + d * C, c * B + d * D, e * A + f * C + E, e * B + f * D + F)


def minv(m):
    a, b, c, d, e, f = m
    det = a * d - b * c
    if abs(det) < 1e-18:
        return ID
    ia, ib, ic, id_ = d / det, -b / det, -c / det, a / det
    return (ia, ib, ic, id_, -(e * ia + f * ic), -(e * ib + f * id_))


def mpt(m, x, y):
    return x * m[0] + y * m[2] + m[4], x * m[1] + y * m[3] + m[5]


def mtup(M):
    return (M.a, M.b, M.c, M.d, M.e, M.f)


def fmt_num(v):
    if abs(v) < 5e-7:
        return "0"
    s = ("%.6f" % v).rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"


def fmt_m(m):
    return " ".join(fmt_num(v) for v in m)


def bbox_of(m, x0, y0, x1, y1):
    pts = (mpt(m, x0, y0), mpt(m, x1, y0), mpt(m, x1, y1), mpt(m, x0, y1))
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys))


# ----------------------------------------------------------------------- tokens
WS = b"\x00\t\n\x0c\r "
_TOK = re.compile(rb"[\x00\t\n\x0c\r ]*(?:"
                  rb"(?P<n>[+-]?(?:\d+\.?\d*|\.\d+))(?=[\x00\t\n\x0c\r ()<>\[\]{}/%]|$)"
                  rb"|(?P<nm>/[^\x00\t\n\x0c\r ()<>\[\]{}/%]*)"
                  rb"|(?P<s>\()"
                  rb"|(?P<dl><<)|(?P<dr>>>)"
                  rb"|(?P<h><[^<>]*>)"
                  rb"|(?P<la>\[)|(?P<ra>\])"
                  rb"|(?P<c>%[^\r\n]*)"
                  rb"|(?P<k>[^\x00\t\n\x0c\r ()<>\[\]{}/%]+)"
                  rb"|(?P<o>[{}]))")
_STRSPECIAL = re.compile(rb"[()\\]")
_ESC = {ord("n"): 10, ord("r"): 13, ord("t"): 9, ord("b"): 8, ord("f"): 12}
_EI = re.compile(rb"[\x00\t\n\x0c\r ]EI(?=[\x00\t\n\x0c\r /\[<(%]|$)")


def lit_string(data, pos):
    """Literal string starting after '(' -> (bytes, end position)."""
    out = bytearray()
    depth = 1
    n = len(data)
    search = _STRSPECIAL.search
    while pos < n:
        m = search(data, pos)
        if not m:
            out += data[pos:]
            return bytes(out), n
        k = m.start()
        out += data[pos:k]
        ch = data[k]
        if ch == 0x5C:
            k += 1
            if k >= n:
                break
            c2 = data[k]
            if c2 in _ESC:
                out.append(_ESC[c2])
                pos = k + 1
            elif 0x30 <= c2 <= 0x37:
                j = k
                while j < n and j < k + 3 and 0x30 <= data[j] <= 0x37:
                    j += 1
                out.append(int(data[k:j], 8) & 255)
                pos = j
            elif c2 == 0x0D:
                pos = k + 1
                if pos < n and data[pos] == 0x0A:
                    pos += 1
            elif c2 == 0x0A:
                pos = k + 1
            else:
                out.append(c2)
                pos = k + 1
        elif ch == 0x28:
            depth += 1
            out.append(ch)
            pos = k + 1
        else:
            depth -= 1
            if depth == 0:
                return bytes(out), k + 1
            out.append(ch)
            pos = k + 1
    return bytes(out), n


def hex_string(tok):
    h = re.sub(rb"[^0-9A-Fa-f]", b"", tok[1:-1])
    if len(h) % 2:
        h += b"0"
    try:
        return bytes.fromhex(h.decode())
    except ValueError:
        return b""


class PStr(bytes):
    """String operand (distinguishes strings from names in operand lists)."""


def parse_pdf_array(s):
    """'[1 2 [3 4] 5]' -> nested python lists of floats (references and names are skipped)."""
    out = []
    stack = [out]
    for m in re.finditer(r"\[|\]|[+-]?(?:\d+\.?\d*|\.\d+)(?:\s+\d+\s+R)?|/[^\s/\[\]]*", s):
        t = m.group(0)
        if t == "[":
            new = []
            stack[-1].append(new)
            stack.append(new)
        elif t == "]":
            if len(stack) > 1:
                stack.pop()
        elif t.endswith("R"):
            continue
        elif t.startswith("/"):
            continue
        else:
            stack[-1].append(float(t))
    return out[0] if len(out) == 1 and isinstance(out[0], list) else out


# ----------------------------------------------------------------------- fonts
BASE14 = {"helvetica": "helv", "helvetica-bold": "hebo", "helvetica-oblique": "heit",
          "helvetica-boldoblique": "hebi", "times-roman": "tiro", "times-bold": "tibo", "times-italic": "tiit",
          "times-bolditalic": "tibi", "courier": "cour", "courier-bold": "cobo", "courier-oblique": "coit",
          "courier-boldoblique": "cobi", "symbol": "symb", "zapfdingbats": "zadb"}


class FontInfo:
    def __init__(self, doc, xref):
        self.two = False
        self.scale = 0.001
        self.first = 0
        self.widths = []
        self.wmap = {}
        self.dw = 1000.0
        self.missing = 0.0
        self.asc = 0.75
        self.desc = -0.25
        self.base = None
        self.name = ""
        self._cache = {}
        if not xref:
            self._base14("Helvetica")
            return
        g = doc.xref_get_key
        st = g(xref, "Subtype")[1].lstrip("/")
        self.name = g(xref, "BaseFont")[1].lstrip("/")
        if st == "Type0":
            enc = g(xref, "Encoding")
            self.two = True
            t, v = g(xref, "DescendantFonts")
            dx = None
            if t == "array":
                mm = re.search(r"(\d+)\s+0\s+R", v)
                dx = int(mm.group(1)) if mm else None
            elif t == "xref":
                arr = doc.xref_object(int(v.split()[0]))
                mm = re.search(r"(\d+)\s+0\s+R", arr)
                dx = int(mm.group(1)) if mm else None
            if dx:
                t, v = g(dx, "DW")
                if t == "int" or t == "float":
                    self.dw = float(v)
                t, v = g(dx, "W")
                if t == "xref":
                    v = doc.xref_object(int(v.split()[0]))
                if t in ("array", "xref"):
                    self._parse_w(parse_pdf_array(v))
                self._descriptor(doc, dx)
            _ = enc
            return
        t, v = g(xref, "FirstChar")
        if t in ("int", "float"):
            self.first = int(float(v))
        t, v = g(xref, "Widths")
        if t == "xref":
            v = doc.xref_object(int(v.split()[0]))
            t = "array"
        if t == "array":
            self.widths = [w for w in parse_pdf_array(v) if not isinstance(w, list)]
        if st == "Type3":
            t, v = g(xref, "FontMatrix")
            if t == "array":
                fm = parse_pdf_array(v)
                if len(fm) >= 4:
                    self.scale = float(fm[0]) or 0.001
            self.asc, self.desc = 0.8, -0.2
        self._descriptor(doc, xref)
        if not self.widths:
            self._base14(self.name)

    def _descriptor(self, doc, xref):
        t, v = doc.xref_get_key(xref, "FontDescriptor")
        if t != "xref":
            return
        fd = int(v.split()[0])
        for key, attr in (("Ascent", "asc"), ("Descent", "desc"), ("MissingWidth", "missing")):
            t, v = doc.xref_get_key(fd, key)
            if t in ("int", "float"):
                val = float(v)
                if attr == "missing":
                    self.missing = val
                else:
                    setattr(self, attr, val / 1000.0)
        self.asc = min(1.2, max(0.5, self.asc)) if self.asc else 0.75
        self.desc = max(-0.6, min(0.0, self.desc))

    def _parse_w(self, arr):
        k = 0
        while k < len(arr):
            c = arr[k]
            if k + 1 < len(arr) and isinstance(arr[k + 1], list):
                for j, w in enumerate(arr[k + 1]):
                    self.wmap[int(c) + j] = float(w)
                k += 2
            elif k + 2 < len(arr):
                c1, c2, w = int(arr[k]), int(arr[k + 1]), float(arr[k + 2])
                if c2 - c1 < 70000:
                    for cc in range(c1, c2 + 1):
                        self.wmap[cc] = w
                k += 3
            else:
                break

    def _base14(self, name):
        key = (name or "").split("+")[-1].lower().replace(",", "-")
        fn = BASE14.get(key)
        if fn is None:
            low = key
            bold = "bold" in low
            ital = "italic" in low or "oblique" in low
            if "times" in low or "roman" in low or "serif" in low:
                fn = "tibi" if bold and ital else "tibo" if bold else "tiit" if ital else "tiro"
            elif "cour" in low or "mono" in low:
                fn = "cobi" if bold and ital else "cobo" if bold else "coit" if ital else "cour"
            else:
                fn = "hebi" if bold and ital else "hebo" if bold else "heit" if ital else "helv"
        try:
            self.base = pymupdf.Font(fn)
        except Exception:
            self.base = None

    def width(self, code):
        w = self._cache.get(code)
        if w is not None:
            return w
        if self.two:
            w = self.wmap.get(code, self.dw)
        else:
            k = code - self.first
            if 0 <= k < len(self.widths):
                w = self.widths[k]
            elif self.base is not None:
                try:
                    w = self.base.glyph_advance(code) * 1000.0
                except Exception:
                    w = 500.0
            else:
                w = self.missing or 500.0
        self._cache[code] = w
        return w


# ----------------------------------------------------------------------- objects
class PObj:
    __slots__ = ("kind", "owner", "rng", "grp", "ctm", "gctm", "bbox", "pts", "subs", "stroke", "fill", "lw",
                 "blk", "si", "ei", "chain", "wrapped", "name", "clip", "gclip", "gs", "ggs", "res")

    def __init__(self, kind, owner, rng, ctm, bbox):
        self.kind = kind          # text | image | shape | form
        self.owner = owner        # 0 = page contents, otherwise form xref
        self.rng = rng            # (start, end) byte range of the object's own operators
        self.grp = None           # (start, end) of an enclosing q..Q that holds only this object
        self.ctm = ctm            # CTM at rng start (PDF default space)
        self.gctm = None          # CTM at grp start
        self.bbox = bbox          # unrotated page coordinates (MuPDF, y down)
        self.pts = None
        self.subs = None
        self.stroke = False
        self.fill = False
        self.lw = 1.0
        self.blk = None
        self.si = self.ei = 0
        self.chain = ()           # ((form xref, form->page matrix, bbox), ...) innermost last
        self.wrapped = None       # (matrix A, header end) when grp is one of our own "q A cm %aoe" wrappers
        self.name = ""
        self.clip = None          # clip bbox (unrot) active at rng start, None = unclipped
        self.gclip = None         # clip bbox at grp start
        self.gs = None            # raw graphics state at rng start (for re-creating the object elsewhere)
        self.ggs = None
        self.res = None           # resource lookup info

    @property
    def area(self):
        x0, y0, x1, y1 = self.bbox
        return max(0.01, (x1 - x0) * (y1 - y0))


PAINT = {b"S": (1, 0), b"s": (1, 0), b"f": (0, 1), b"F": (0, 1), b"f*": (0, 1), b"B": (1, 1), b"B*": (1, 1),
         b"b": (1, 1), b"b*": (1, 1)}
COLOR_FILL = {b"g", b"rg", b"k", b"sc", b"scn"}
COLOR_STROKE = {b"G", b"RG", b"K", b"SC", b"SCN"}
WRAP_RE = re.compile(rb"q ([-+\d.e ]+) cm %aoe\n")
_N = rb"[-+]?(?:\d++(?:\.\d*+)?|\.\d++)"
_WS = rb"[\x00\t\n\x0c\r ]"
# a whole simple polyline path "x y m (x y l)* paint" in one match (possessive: no backtracking)
_FASTPATH = re.compile(_WS + rb"*+(" + _N + rb")" + _WS + rb"++(" + _N + rb")" + _WS + rb"++m"
                       rb"((?:" + _WS + rb"++" + _N + _WS + rb"++" + _N + _WS + rb"++l)*+)"
                       + _WS + rb"++(S|s|f\*|f|F|B\*|B|b\*|b|n)(?=[\x00\t\n\x0c\r /\[<(%]|$)")


class PageObjects:
    """Parse result for one page."""

    def __init__(self, doc, page, recurse_forms=True):
        self.doc = doc
        self.pno = page.number
        self.page_xref = page.xref
        self.TM = mtup(page.transformation_matrix)
        self.data = {}
        self.objs = []
        self._fonts = {}
        self._res_cache = {}
        self.recurse = recurse_forms
        self.shared = self._shared_forms(page) if recurse_forms else set()
        data = page.read_contents() or b""
        self.data[0] = data
        self._parse(0, data, ID, ("page", page.xref), (), 0, set(), None)
        self._arrays()

    # -------------------------------------------------------------- resources
    def _shared_forms(self, page):
        """Form XObjects that are referenced by other pages too (edit them only as a whole)."""
        out = set()
        doc = self.doc
        if doc.page_count > 400:
            return out
        for k in range(doc.page_count):
            if k == page.number:
                continue
            try:
                px = doc.page_xref(k)
                t, v = doc.xref_get_key(px, "Resources/XObject")
                if t == "xref":
                    v = doc.xref_object(int(v.split()[0]))
                for m in re.finditer(r"(\d+)\s+0\s+R", v or ""):
                    out.add(int(m.group(1)))
            except Exception:
                pass
        return out

    def res_raw(self, resinfo, cat, name):
        """resinfo = ('page', xref) | ('form', xref) | ('inherit', parent_resinfo).
        Returns the raw (type, value) of the resource entry or None."""
        kind, x = resinfo[0], resinfo[1]
        doc = self.doc
        if kind == "inherit":
            return self.res_raw(x, cat, name)
        owner = x
        for _ in range(32):
            t, v = doc.xref_get_key(owner, "Resources/%s/%s" % (cat, name))
            if t != "null":
                return (t, v)
            if kind != "page":
                return None
            t, v = doc.xref_get_key(owner, "Resources")
            if t != "null":
                return None
            t, v = doc.xref_get_key(owner, "Parent")
            if t != "xref":
                return None
            owner = int(v.split()[0])
        return None

    def _res(self, resinfo, cat, name):
        """xref of a resource or 0."""
        key = (resinfo, cat, name)
        if key in self._res_cache:
            return self._res_cache[key]
        r = self.res_raw(resinfo, cat, name)
        val = int(r[1].split()[0]) if r and r[0] == "xref" else 0
        self._res_cache[key] = val
        return val

    def _font(self, resinfo, name):
        x = self._res(resinfo, "Font", name)
        fi = self._fonts.get(x)
        if fi is None:
            try:
                fi = FontInfo(self.doc, x)
            except Exception:
                fi = FontInfo(self.doc, 0)
            self._fonts[x] = fi
        return fi

    # -------------------------------------------------------------- parser
    def _parse(self, owner, data, ctm0, resinfo, chain, depth, seen, clip0):
        doc = self.doc
        TM = self.TM
        objs = self.objs
        match = _TOK.match
        n = len(data)
        pos = 0
        stack = []
        arr_stack = []
        dict_depth = 0
        op_start = -1
        # graphics state
        ctm = ctm0
        lw = 1.0
        font = None
        fname = b""
        fs = 0.0
        tc = tw = tl = ts = 0.0
        th = 1.0
        tr = 0
        fillc = b""
        strokec = b""
        fillcs = b""
        strokecs = b""
        clip = clip0
        xs_ = {}
        pend_clip = False
        gstack = []
        qstack = []               # (q start, ctm at q, len(objs) at q, text seen, clip, gs)
        # path
        pts = None
        subs = None
        path_start = -1
        # text
        in_text = False
        tlm = tm = ID
        acc = 0.0
        blk = None
        text_in_q = 0
        fast = _FASTPATH.match
        while pos < n:
            if pts is None and not stack and not arr_stack and not dict_depth:
                fm_ = fast(data, pos)
                if fm_ is not None:
                    try:
                        fp = [float(fm_.group(1)), float(fm_.group(2))]
                        g3 = fm_.group(3)
                        if g3:
                            fp.extend(float(v) for v in g3.split() if v != b"l")
                    except ValueError:
                        fp = None
                    if fp is not None:
                        ptok = fm_.group(4)
                        fstart = fm_.start(1)
                        pos = fm_.end()
                        if ptok == b"n":
                            if pend_clip:
                                M = mmul(ctm, TM)
                                bb = bbox_of(M, min(fp[0::2]), min(fp[1::2]), max(fp[0::2]), max(fp[1::2]))
                                clip = bb if clip is None else (max(clip[0], bb[0]), max(clip[1], bb[1]),
                                                                 min(clip[2], bb[2]), min(clip[3], bb[3]))
                            pend_clip = False
                            continue
                        pf = PAINT[ptok]
                        M = mmul(ctm, TM)
                        bb = bbox_of(M, min(fp[0::2]), min(fp[1::2]), max(fp[0::2]), max(fp[1::2]))
                        pclip = clip
                        if pend_clip:
                            clip = bb if clip is None else (max(clip[0], bb[0]), max(clip[1], bb[1]),
                                                             min(clip[2], bb[2]), min(clip[3], bb[3]))
                            pend_clip = False
                        if pf[0]:
                            sc = math.sqrt(abs(M[0] * M[3] - M[1] * M[2])) * lw / 2
                            bb = (bb[0] - sc, bb[1] - sc, bb[2] + sc, bb[3] + sc)
                        o = PObj("shape", owner, (fstart, pos), ctm, bb)
                        o.pts = fp
                        o.subs = [[0, ptok in (b"s", b"b", b"b*")]]
                        o.stroke, o.fill = bool(pf[0]), bool(pf[1])
                        o.lw = lw
                        o.chain = chain
                        o.clip = pclip
                        o.gs = (fillcs, fillc, strokecs, strokec, lw, xs_)
                        o.res = resinfo
                        objs.append(o)
                        continue
            m = match(data, pos)
            if m is None:
                pos += 1
                continue
            kind = m.lastgroup
            s = m.start(kind)
            pos = m.end()
            if kind == "n":
                if op_start < 0:
                    op_start = s
                stack.append(float(m.group("n")))
                continue
            if kind == "k":
                tok = m.group("k")
                if arr_stack or dict_depth:
                    if arr_stack:
                        arr_stack[-1].append(tok)
                    continue
                if tok in (b"true", b"false", b"null"):
                    if op_start < 0:
                        op_start = s
                    stack.append(tok)
                    continue
                if op_start < 0:
                    op_start = s
                os_ = op_start
                op_start = -1
                st = stack
                stack = []
                # ---------------------------------------------------- path construction
                if tok == b"l":
                    if pts is not None and len(st) >= 2:
                        pts.append(st[-2])
                        pts.append(st[-1])
                    continue
                if tok == b"m":
                    if len(st) < 2:
                        continue
                    if pts is None:
                        pts = []
                        subs = []
                        path_start = os_
                    subs.append([len(pts), False])
                    pts.append(st[-2])
                    pts.append(st[-1])
                    continue
                if tok == b"c":
                    if pts is not None and len(st) >= 6:
                        pts.extend(st[-6:])
                    continue
                if tok in (b"v", b"y"):
                    if pts is not None and len(st) >= 4:
                        pts.extend(st[-4:])
                    continue
                if tok == b"re":
                    if len(st) < 4:
                        continue
                    if pts is None:
                        pts = []
                        subs = []
                        path_start = os_
                    x, y, w, h = st[-4:]
                    subs.append([len(pts), True])
                    pts.extend((x, y, x + w, y, x + w, y + h, x, y + h))
                    continue
                if tok == b"h":
                    if subs:
                        subs[-1][1] = True
                    continue
                pf = PAINT.get(tok)
                if pf is not None:
                    if pts:
                        M = mmul(ctm, TM)
                        xs = pts[0::2]
                        ys = pts[1::2]
                        bb = bbox_of(M, min(xs), min(ys), max(xs), max(ys))
                        pclip = clip
                        if pend_clip:
                            clip = bb if clip is None else (max(clip[0], bb[0]), max(clip[1], bb[1]),
                                                             min(clip[2], bb[2]), min(clip[3], bb[3]))
                            pend_clip = False
                        if pf[0]:
                            sc = math.sqrt(abs(M[0] * M[3] - M[1] * M[2])) * lw / 2
                            bb = (bb[0] - sc, bb[1] - sc, bb[2] + sc, bb[3] + sc)
                        o = PObj("shape", owner, (path_start, pos), ctm, bb)
                        o.pts = pts
                        o.subs = subs
                        o.stroke, o.fill = bool(pf[0]), bool(pf[1])
                        o.lw = lw
                        o.chain = chain
                        o.clip = pclip
                        o.gs = (fillcs, fillc, strokecs, strokec, lw, xs_)
                        o.res = resinfo
                        if tok in (b"s", b"b", b"b*"):
                            subs[-1][1] = True
                        objs.append(o)
                    pts = None
                    subs = None
                    continue
                if tok == b"n":
                    if pend_clip and pts:
                        M = mmul(ctm, TM)
                        bb = bbox_of(M, min(pts[0::2]), min(pts[1::2]), max(pts[0::2]), max(pts[1::2]))
                        clip = bb if clip is None else (max(clip[0], bb[0]), max(clip[1], bb[1]),
                                                         min(clip[2], bb[2]), min(clip[3], bb[3]))
                    pend_clip = False
                    pts = None
                    subs = None
                    continue
                if tok in (b"W", b"W*"):
                    pend_clip = True
                    continue
                if tok in (b"J", b"j", b"M", b"d", b"gs", b"ri", b"i"):
                    xs_ = dict(xs_)
                    xs_[tok] = data[os_:pos]
                    continue
                # ---------------------------------------------------- graphics state
                if tok == b"q":
                    gstack.append((ctm, lw, font, fname, fs, tc, tw, th, tl, ts, tr, fillc, strokec, fillcs, strokecs,
                                   clip, xs_))
                    qstack.append((os_, ctm, len(objs), text_in_q, clip, (fillcs, fillc, strokecs, strokec, lw, xs_)))
                    text_in_q = 0
                    continue
                if tok == b"Q":
                    if gstack:
                        (ctm, lw, font, fname, fs, tc, tw, th, tl, ts, tr, fillc, strokec, fillcs,
                         strokecs, clip, xs_) = gstack.pop()
                    if qstack:
                        qs, qctm, nobj, prev_text, qclip, qgs = qstack.pop()
                        inner = objs[nobj:]
                        if len(inner) == 1 and not text_in_q and inner[0].owner == owner and inner[0].kind != "text":
                            o = inner[0]
                            o.grp = (qs, pos)
                            o.gctm = qctm
                            o.gclip = qclip
                            o.ggs = qgs
                            wm = WRAP_RE.match(data, qs)
                            if wm and data[pos - 1:pos] == b"Q":
                                try:
                                    A = tuple(float(v) for v in wm.group(1).split())
                                    o.wrapped = (A, wm.end()) if len(A) == 6 else None
                                except ValueError:
                                    o.wrapped = None
                            else:
                                o.wrapped = None
                        text_in_q = text_in_q or prev_text
                    continue
                if tok == b"cm":
                    if len(st) >= 6:
                        ctm = mmul(tuple(st[-6:]), ctm)
                    continue
                if tok == b"w":
                    if st:
                        lw = st[-1]
                    continue
                if tok in COLOR_FILL:
                    fillc = data[os_:pos]
                    if tok in (b"g", b"rg", b"k"):
                        fillcs = b""
                    continue
                if tok in COLOR_STROKE:
                    strokec = data[os_:pos]
                    if tok in (b"G", b"RG", b"K"):
                        strokecs = b""
                    continue
                if tok == b"cs":
                    fillcs = data[os_:pos]
                    fillc = b""
                    continue
                if tok == b"CS":
                    strokecs = data[os_:pos]
                    strokec = b""
                    continue
                # ---------------------------------------------------- text
                if tok == b"BT":
                    in_text = True
                    tlm = tm = ID
                    acc = 0.0
                    blk = {"bt": os_, "ctm": ctm, "shows": [], "tms": [], "res": resinfo}
                    text_in_q = 1
                    continue
                if tok == b"ET":
                    in_text = False
                    if blk is not None:
                        blk["et"] = pos
                        self._finish_block(owner, blk, chain)
                    blk = None
                    continue
                if tok == b"Tf":
                    if len(st) >= 2 and isinstance(st[-2], bytes):
                        fname = st[-2]
                        fs = st[-1]
                        font = self._font(resinfo, fname[1:].decode("latin-1"))
                    continue
                if tok == b"Tc":
                    tc = st[-1] if st else 0.0
                    continue
                if tok == b"Tw":
                    tw = st[-1] if st else 0.0
                    continue
                if tok == b"Tz":
                    th = (st[-1] if st else 100.0) / 100.0
                    continue
                if tok == b"TL":
                    tl = st[-1] if st else 0.0
                    continue
                if tok == b"Ts":
                    ts = st[-1] if st else 0.0
                    continue
                if tok == b"Tr":
                    tr = int(st[-1]) if st else 0
                    continue
                if tok in (b"Td", b"TD"):
                    if len(st) >= 2:
                        if tok == b"TD":
                            tl = -st[-1]
                        tlm = mmul((1, 0, 0, 1, st[-2], st[-1]), tlm)
                        tm = tlm
                        acc = 0.0
                    continue
                if tok == b"Tm":
                    if len(st) >= 6:
                        tlm = tm = tuple(st[-6:])
                        acc = 0.0
                        if blk is not None:
                            blk["tms"].append((os_, pos, tlm))
                    continue
                if tok == b"T*":
                    tlm = mmul((1, 0, 0, 1, 0, -tl), tlm)
                    tm = tlm
                    acc = 0.0
                    continue
                if tok in (b"Tj", b"TJ", b"'", b'"'):
                    if blk is None:
                        continue
                    pre_tlm, pre_acc = tlm, acc
                    aw = ac = 0.0
                    if tok == b'"' and len(st) >= 3:
                        aw, ac = st[-3], st[-2]
                        tw, tc = aw, ac
                    if tok in (b"'", b'"'):
                        tlm = mmul((1, 0, 0, 1, 0, -tl), tlm)
                        tm = tlm
                        acc = 0.0
                    start_acc = acc
                    items = st[-1] if st else b""
                    if not isinstance(items, list):
                        items = [items]
                    fi = font or self._font(resinfo, "")
                    two = fi.two
                    sc = fi.scale
                    adv = 0.0
                    for it in items:
                        if isinstance(it, float):
                            adv -= it / 1000.0 * fs * th
                            continue
                        if not isinstance(it, PStr):
                            continue
                        if two:
                            for k in range(0, len(it) - 1, 2):
                                code = (it[k] << 8) | it[k + 1]
                                adv += (fi.width(code) * sc * fs + tc) * th
                        else:
                            for code in it:
                                adv += (fi.width(code) * sc * fs + tc + (tw if code == 32 else 0.0)) * th
                    trm = mmul(mmul((1, 0, 0, 1, start_acc, 0), tlm), ctm)
                    M = mmul(trm, TM)
                    y0 = fi.desc * fs + ts
                    y1 = fi.asc * fs + ts
                    x0, x1 = (0.0, adv) if adv >= 0 else (adv, 0.0)
                    bb = bbox_of(M, x0, y0, x1, y1)
                    acc = start_acc + adv
                    tm = mmul((1, 0, 0, 1, acc, 0), tlm)
                    blk["shows"].append({
                        "s": os_, "e": pos, "op": tok, "pre_tlm": pre_tlm, "pre_acc": pre_acc, "ctm": ctm,
                        "clip": clip, "gs": (fillcs, fillc, strokecs, strokec, lw, xs_),
                        "post_tlm": tlm, "post_acc": acc, "adv": adv, "fs": fs, "th": th, "aw": aw, "ac": ac,
                        "state": (fname, fs, tc, tw, th, tl, ts, tr, fillcs, fillc, strokecs, strokec),
                        "bbox": bb, "M": M, "h": abs(fs) * math.hypot(M[2], M[3]) / max(abs(fs), 1e-9) * abs(fs)
                        if fs else 1.0})
                    continue
                # ---------------------------------------------------- xobjects / images
                if tok == b"Do":
                    if not st or not isinstance(st[-1], bytes) or isinstance(st[-1], PStr):
                        continue
                    nm = st[-1][1:].decode("latin-1")
                    x = self._res(resinfo, "XObject", nm)
                    if not x:
                        continue
                    sub = doc.xref_get_key(x, "Subtype")[1]
                    if sub == "/Image":
                        bb = bbox_of(mmul(ctm, TM), 0, 0, 1, 1)
                        o = PObj("image", owner, (os_, pos), ctm, bb)
                        o.chain = chain
                        o.name = nm
                        o.clip = clip
                        o.gs = (fillcs, fillc, strokecs, strokec, lw, xs_)
                        o.res = resinfo
                        objs.append(o)
                    elif sub == "/Form":
                        fm = doc.xref_get_key(x, "Matrix")
                        fmat = ID
                        if fm[0] == "array":
                            vals = parse_pdf_array(fm[1])
                            if len(vals) == 6:
                                fmat = tuple(float(v) for v in vals)
                        fctm = mmul(fmat, ctm)
                        fb = doc.xref_get_key(x, "BBox")
                        fbox = (0.0, 0.0, 1.0, 1.0)
                        if fb[0] == "array":
                            vals = parse_pdf_array(fb[1])
                            if len(vals) == 4:
                                fbox = tuple(float(v) for v in vals)
                        uses = data.count(b"/" + nm.encode("latin-1") + b" Do") + data.count(b"/" + nm.encode("latin-1") + b"\nDo")
                        if (self.recurse and depth < 6 and x not in seen and x not in self.shared and uses <= 1):
                            try:
                                fdata = doc.xref_stream(x) or b""
                            except Exception:
                                fdata = b""
                            t, v = doc.xref_get_key(x, "Resources")
                            rinfo = ("form", x) if t in ("dict", "xref") else ("inherit", resinfo)
                            self.data[x] = fdata
                            nb = len(objs)
                            fb_u = bbox_of(mmul(fctm, TM), *fbox)
                            fclip = fb_u if clip is None else (max(clip[0], fb_u[0]), max(clip[1], fb_u[1]),
                                                               min(clip[2], fb_u[2]), min(clip[3], fb_u[3]))
                            self._parse(x, fdata, fctm, rinfo, chain + ((x, mmul(fctm, TM), fbox),), depth + 1,
                                        seen | {x}, fclip)
                            if len(objs) == nb:
                                pass
                        else:
                            bb = bbox_of(mmul(fctm, TM), *fbox)
                            o = PObj("form", owner, (os_, pos), ctm, bb)
                            o.chain = chain
                            o.name = nm
                            o.clip = clip
                            o.gs = (fillcs, fillc, strokecs, strokec, lw, xs_)
                            o.res = resinfo
                            objs.append(o)
                    continue
                if tok == b"BI":
                    # inline image: dictionary up to ID, binary data, EI
                    info = {}
                    key = None
                    while pos < n:
                        mm = match(data, pos)
                        if mm is None:
                            pos += 1
                            continue
                        pos = mm.end()
                        g = mm.lastgroup
                        if g == "k" and mm.group("k") == b"ID":
                            break
                        val = mm.group(g)
                        if g == "nm" and key is None:
                            key = val
                        else:
                            if g == "la":
                                depth_a = 1
                                while depth_a and pos < n:
                                    m2 = match(data, pos)
                                    if m2 is None:
                                        pos += 1
                                        continue
                                    pos = m2.end()
                                    if m2.lastgroup == "la":
                                        depth_a += 1
                                    elif m2.lastgroup == "ra":
                                        depth_a -= 1
                                val = b"[]"
                            elif g == "dl":
                                depth_d = 1
                                while depth_d and pos < n:
                                    m2 = match(data, pos)
                                    if m2 is None:
                                        pos += 1
                                        continue
                                    pos = m2.end()
                                    if m2.lastgroup == "dl":
                                        depth_d += 1
                                    elif m2.lastgroup == "dr":
                                        depth_d -= 1
                                val = b"<<>>"
                            if key is not None:
                                info[key] = val
                            key = None
                    pos = self._skip_inline(data, pos, info)
                    bb = bbox_of(mmul(ctm, TM), 0, 0, 1, 1)
                    o = PObj("image", owner, (os_, pos), ctm, bb)
                    o.chain = chain
                    o.name = "inline"
                    o.clip = clip
                    o.gs = (fillcs, fillc, strokecs, strokec, lw, xs_)
                    o.res = resinfo
                    objs.append(o)
                    continue
                # anything else: ignored (sh, gs, d, BDC, EMC, ...)
                continue
            if kind == "nm":
                if op_start < 0:
                    op_start = s
                val = m.group("nm")
                if arr_stack:
                    arr_stack[-1].append(val)
                elif not dict_depth:
                    stack.append(val)
                continue
            if kind == "s":
                if op_start < 0:
                    op_start = s
                b, pos = lit_string(data, pos)
                val = PStr(b)
                if arr_stack:
                    arr_stack[-1].append(val)
                elif not dict_depth:
                    stack.append(val)
                continue
            if kind == "h":
                if op_start < 0:
                    op_start = s
                val = PStr(hex_string(m.group("h")))
                if arr_stack:
                    arr_stack[-1].append(val)
                elif not dict_depth:
                    stack.append(val)
                continue
            if kind == "la":
                if op_start < 0:
                    op_start = s
                arr_stack.append([])
                continue
            if kind == "ra":
                if arr_stack:
                    a = arr_stack.pop()
                    if arr_stack:
                        arr_stack[-1].append(a)
                    elif not dict_depth:
                        stack.append(a)
                continue
            if kind == "dl":
                if op_start < 0:
                    op_start = s
                dict_depth += 1
                continue
            if kind == "dr":
                if dict_depth:
                    dict_depth -= 1
                    if not dict_depth and not arr_stack:
                        stack.append(b"<<>>")
                continue
            # comments / braces ignored
        if blk is not None:
            blk["et"] = n
            self._finish_block(owner, blk, chain)
        if owner == 0:
            self.qdepth = len(gstack)
        return resinfo

    @staticmethod
    def _skip_inline(data, pos, info):
        n = len(data)
        p = pos
        if p < n and data[p] in WS:
            p += 1
        filt = info.get(b"/F") or info.get(b"/Filter")
        try:
            if not filt:
                w = int(float(info.get(b"/W") or info.get(b"/Width") or 0))
                h = int(float(info.get(b"/H") or info.get(b"/Height") or 0))
                im = (info.get(b"/IM") or info.get(b"/ImageMask") or b"false") == b"true"
                bpc = 1 if im else int(float(info.get(b"/BPC") or info.get(b"/BitsPerComponent") or 8))
                cs = info.get(b"/CS") or info.get(b"/ColorSpace") or b"/G"
                nc = 1 if im else {b"/G": 1, b"/DeviceGray": 1, b"/RGB": 3, b"/DeviceRGB": 3, b"/CMYK": 4,
                                   b"/DeviceCMYK": 4, b"/I": 1, b"/Indexed": 1, b"[]": 1}.get(cs)
                if nc and w > 0 and h > 0:
                    ln = ((w * nc * bpc + 7) // 8) * h
                    q = p + ln
                    k = q
                    while k < n and data[k] in WS:
                        k += 1
                    if data[k:k + 2] == b"EI":
                        return k + 2
        except Exception:
            pass
        m = _EI.search(data, p)
        if m:
            return m.end()
        return n

    def _finish_block(self, owner, blk, chain):
        shows = blk["shows"]
        if not shows:
            return
        groups = []
        cur = [0]
        for k in range(1, len(shows)):
            a, b = shows[k - 1], shows[k]
            if self._same_line(a, b):
                cur.append(k)
            else:
                groups.append(cur)
                cur = [k]
        groups.append(cur)
        for g in groups:
            si, ei = g[0], g[-1]
            if all(abs(shows[k]["adv"]) < 1e-9 for k in g):
                continue
            xs0 = [shows[k]["bbox"][0] for k in g]
            ys0 = [shows[k]["bbox"][1] for k in g]
            xs1 = [shows[k]["bbox"][2] for k in g]
            ys1 = [shows[k]["bbox"][3] for k in g]
            o = PObj("text", owner, (shows[si]["s"], shows[ei]["e"]), shows[si]["ctm"],
                     (min(xs0), min(ys0), max(xs1), max(ys1)))
            o.blk = blk
            o.si, o.ei = si, ei
            o.chain = chain
            o.clip = shows[si]["clip"]
            o.gs = shows[si]["gs"]
            o.res = blk.get("res")
            self.objs.append(o)

    @staticmethod
    def _same_line(a, b):
        Ma, Mb = a["M"], b["M"]
        la = math.hypot(Ma[0], Ma[1])
        lb = math.hypot(Mb[0], Mb[1])
        if la < 1e-9 or lb < 1e-9:
            return False
        da = (Ma[0] / la, Ma[1] / la)
        db = (Mb[0] / lb, Mb[1] / lb)
        if da[0] * db[0] + da[1] * db[1] < 0.995:
            return False
        h = max(1e-3, abs(a["fs"]) * math.hypot(Ma[2], Ma[3]))
        # end of a (baseline), start of b (baseline)
        ex, ey = mpt(Ma, a["adv"], 0)
        sx, sy = mpt(Mb, 0, 0)
        dx, dy = sx - ex, sy - ey
        along = dx * da[0] + dy * da[1]
        perp = -dx * da[1] + dy * da[0]
        return abs(perp) < 0.35 * h and -0.6 * h < along < 0.9 * h

    # -------------------------------------------------------------- queries
    def _arrays(self):
        if self.objs:
            b = np.array([o.bbox for o in self.objs], dtype=float)
        else:
            b = np.zeros((0, 4))
        self.bx = b
        self.kinds = np.array([o.kind for o in self.objs]) if self.objs else np.array([], dtype="<U5")

    def mask_for(self, mode):
        if mode == "all":
            return np.ones(len(self.objs), bool)
        if mode == "text":
            return self.kinds == "text"
        if mode == "image":
            return (self.kinds == "image") | (self.kinds == "form")
        if mode == "shape":
            return (self.kinds == "shape") | (self.kinds == "form")
        return np.ones(len(self.objs), bool)

    def hit(self, x, y, tol, mode="all"):
        """Index of the object under (x, y) (unrotated page coords) or -1."""
        if not len(self.objs):
            return -1
        b = self.bx
        mk = self.mask_for(mode) & (b[:, 0] - tol <= x) & (b[:, 2] + tol >= x) & (b[:, 1] - tol <= y) & (b[:, 3] + tol >= y)
        idx = np.nonzero(mk)[0]
        if not len(idx):
            return -1
        best = None
        for k in idx[::-1]:          # topmost first
            o = self.objs[k]
            if o.kind == "shape":
                d = self._path_dist(o, x, y)
                inside = o.fill and self._inside_bbox(o, x, y)
                if d <= tol:
                    score = (0, o.area)
                elif inside:
                    score = (2, o.area)
                else:
                    continue
            else:
                score = (1 if o.kind != "text" else 0, o.area)
            if best is None or score < best[0]:
                best = (score, k)
        return -1 if best is None else int(best[1])

    @staticmethod
    def _inside_bbox(o, x, y):
        x0, y0, x1, y1 = o.bbox
        return x0 <= x <= x1 and y0 <= y <= y1

    def _path_dist(self, o, x, y):
        M = mmul(o.ctm, self.TM)
        pts = o.pts
        n = len(pts) // 2
        if n == 0:
            return 1e9
        arr = np.array(pts, dtype=float).reshape(-1, 2)
        X = arr[:, 0] * M[0] + arr[:, 1] * M[2] + M[4]
        Y = arr[:, 0] * M[1] + arr[:, 1] * M[3] + M[5]
        best = 1e9
        starts = [s[0] // 2 for s in o.subs] + [n]
        for k, sub in enumerate(o.subs):
            a, b = starts[k], starts[k + 1]
            if b - a < 1:
                continue
            xs, ys = X[a:b], Y[a:b]
            if sub[1] or o.fill:
                xs = np.append(xs, xs[0])
                ys = np.append(ys, ys[0])
            if len(xs) == 1:
                best = min(best, math.hypot(xs[0] - x, ys[0] - y))
                continue
            x0, y0, x1, y1 = xs[:-1], ys[:-1], xs[1:], ys[1:]
            dx, dy = x1 - x0, y1 - y0
            L2 = dx * dx + dy * dy
            t = np.clip(((x - x0) * dx + (y - y0) * dy) / np.where(L2 > 0, L2, 1), 0, 1)
            px, py = x0 + t * dx, y0 + t * dy
            dmin = float(np.min(np.hypot(px - x, py - y)))
            best = min(best, dmin)
        return best

    def in_rect(self, r, mode="all", touch=False):
        if not len(self.objs):
            return []
        b = self.bx
        x0, y0, x1, y1 = r
        if touch:
            mk = (b[:, 2] >= x0) & (b[:, 0] <= x1) & (b[:, 3] >= y0) & (b[:, 1] <= y1)
        else:
            mk = (b[:, 0] >= x0) & (b[:, 2] <= x1) & (b[:, 1] >= y0) & (b[:, 3] <= y1)
        mk &= self.mask_for(mode)
        return [int(k) for k in np.nonzero(mk)[0]]

    def text_of(self, k):
        o = self.objs[k]
        try:
            page = self.doc.load_page(self.pno)
            r = pymupdf.Rect(o.bbox)
            return page.get_text("text", clip=r + (-0.5, -0.5, 0.5, 0.5)).strip()
        except Exception:
            return ""


# ----------------------------------------------------------------------- edits
def _tj_shift(dx, fs, th):
    if abs(dx) < 1e-9:
        return b""
    den = fs * th
    if abs(den) < 1e-9:
        return b""
    return ("[%s] TJ\n" % fmt_num(-dx * 1000.0 / den)).encode()


def _state_bytes(state):
    fname, fs, tc, tw, th, tl, ts, tr, fillcs, fillc, strokecs, strokec = state
    out = []
    if fname:
        out.append(fname + (" %s Tf" % fmt_num(fs)).encode())
    out.append(("%s Tc %s Tw %s Tz %s TL %s Ts %d Tr" % (fmt_num(tc), fmt_num(tw), fmt_num(th * 100),
                                                         fmt_num(tl), fmt_num(ts), tr)).encode())
    if fillcs:
        out.append(fillcs)
    out.append(fillc or b"0 g")
    if strokecs:
        out.append(strokecs)
    out.append(strokec or b"0 G")
    return b"\n".join(out) + b"\n"


class Editor:
    """Collects splices per owner stream and writes them back."""

    def __init__(self, po, page):
        self.po = po
        self.page = page
        self.doc = po.doc
        self.splices = {}
        self.bbox_grow = {}
        self.tail = []
        TM = po.TM
        self.TM = TM
        self.iTM = minv(TM)

    def _add(self, owner, s, e, rep):
        self.splices.setdefault(owner, []).append((s, e, rep))

    def _t_pdf(self, T):
        return mmul(mmul(self.TM, T), self.iTM)

    @staticmethod
    def _A(C, Tp):
        return mmul(mmul(C, Tp), minv(C))

    def _grow_forms(self, o, T):
        """Make sure Form BBoxes still contain the moved object."""
        if not o.chain:
            return
        nb = bbox_of(T, *o.bbox)
        for fx, f2p, fbox in o.chain:
            inv = minv(f2p)
            fb = bbox_of(inv, *nb)
            cur = self.bbox_grow.get(fx, fbox)
            self.bbox_grow[fx] = (min(cur[0], fb[0]), min(cur[1], fb[1]), max(cur[2], fb[2]), max(cur[3], fb[3]))

    # ---------------------------------------------------------- hoisting
    def _needs_hoist(self, o, T):
        clip = o.gclip if (o.grp and o.kind != "text") else o.clip
        if clip is None:
            return False
        nb = bbox_of(T, *o.bbox)
        tol = 1.0
        return nb[0] < clip[0] - tol or nb[1] < clip[1] - tol or nb[2] > clip[2] + tol or nb[3] > clip[3] + tol

    def _snippet(self, o, T):
        """Stand-alone copy of o (with its graphics state) for the end of the page content."""
        Tp = self._t_pdf(T)
        data = self.po.data[o.owner]
        if o.kind == "text":
            sh = o.blk["shows"]
            a, b = sh[o.si], sh[o.ei]
            C = mmul(a["ctm"], Tp)
            gs = a["gs"]
            core = (b"BT\n" + _state_bytes(a["state"]) + ("%s Tm\n" % fmt_m(a["pre_tlm"])).encode()
                    + _tj_shift(a["pre_acc"], a["state"][1], a["state"][4]) + data[a["s"]:b["e"]] + b"\nET")
        else:
            s, e = o.grp or o.rng
            C = mmul(o.gctm if o.grp else o.ctm, Tp)
            gs = (o.ggs if o.grp else o.gs) or (b"", b"", b"", b"", 1.0, {})
            core = data[s:e]
        fillcs, fillc, strokecs, strokec, lw, xs_ = gs
        head = [b"q", ("%s cm" % fmt_m(C)).encode(), ("%s w" % fmt_num(lw)).encode()]
        for k in (b"J", b"j", b"M", b"d", b"ri", b"i", b"gs"):
            if xs_.get(k):
                head.append(xs_[k])
        for raw in (fillcs, fillc, strokecs, strokec):
            if raw:
                head.append(raw)
        snip = b"\n".join(head) + b"\n" + core + b"\nQ\n"
        return self._remap_resources(o, snip)

    _RES_RE = re.compile(rb"/([^\x00\t\n\x0c\r ()<>\[\]{}/%]+)((?:[\x00\t\n\x0c\r ]+[-+.\d]+)*)[\x00\t\n\x0c\r ]*"
                         rb"(Tf|Do|gs|cs|CS|sh|scn|SCN)(?=[\x00\t\n\x0c\r ()<>\[\]/%]|$)")
    _CAT = {b"Tf": "Font", b"Do": "XObject", b"gs": "ExtGState", b"cs": "ColorSpace", b"CS": "ColorSpace",
            b"sh": "Shading", b"scn": "Pattern", b"SCN": "Pattern"}
    _DEVICE = {b"DeviceRGB", b"DeviceGray", b"DeviceCMYK", b"Pattern"}

    def _remap_resources(self, o, snip):
        po = self.po
        if not o.res or o.res[0] == "page":
            return snip
        page_ri = ("page", po.page_xref)
        renames = {}
        for m in self._RES_RE.finditer(snip):
            name, op = m.group(1), m.group(3)
            cat = self._CAT[op]
            if cat == "ColorSpace" and name in self._DEVICE:
                continue
            key = (cat, name)
            if key in renames:
                continue
            src = po.res_raw(o.res, cat, name.decode("latin-1"))
            if src is None:
                continue
            nm = name
            k = 1
            while True:
                cur = po.res_raw(page_ri, cat, nm.decode("latin-1"))
                if cur is None:
                    self._page_res_set(cat, nm.decode("latin-1"), src)
                    break
                if cur == src:
                    break
                nm = b"%s_ae%d" % (name, k)
                k += 1
            renames[key] = nm
        for (cat, name), nm in renames.items():
            if nm != name:
                snip = re.sub(rb"/" + re.escape(name) + rb"(?=[\x00\t\n\x0c\r ()<>\[\]{}/%])", b"/" + nm, snip)
        return snip

    def _page_res_set(self, cat, name, raw):
        doc = self.doc
        px = self.po.page_xref
        t, v = doc.xref_get_key(px, "Resources")
        if t == "null":
            # inherited resources: give the page its own copy first
            owner = px
            for _ in range(32):
                tt, vv = doc.xref_get_key(owner, "Parent")
                if tt != "xref":
                    break
                owner = int(vv.split()[0])
                rt, rv = doc.xref_get_key(owner, "Resources")
                if rt != "null":
                    doc.xref_set_key(px, "Resources", rv if rt == "dict" else doc.xref_object(int(rv.split()[0])))
                    break
            else:
                doc.xref_set_key(px, "Resources", "<<>>")
            t, v = doc.xref_get_key(px, "Resources")
            if t == "null":
                doc.xref_set_key(px, "Resources", "<<>>")
        tgt, prefix = px, "Resources/"
        t, v = doc.xref_get_key(px, "Resources")
        if t == "xref":
            tgt, prefix = int(v.split()[0]), ""
        ct, cv = doc.xref_get_key(tgt, prefix + cat)
        if ct == "xref":
            tgt, prefix = int(cv.split()[0]), ""
            doc.xref_set_key(tgt, name, raw[1])
        else:
            if ct == "null":
                doc.xref_set_key(tgt, prefix + cat, "<<>>")
            doc.xref_set_key(tgt, prefix + cat + "/" + name, raw[1])
        self.po._res_cache.clear()

    def hoist(self, o, T, keep=False):
        try:
            snip = self._snippet(o, T)
        except Exception:
            return False
        if not keep:
            self.delete(o)
        self.tail.append(snip)
        return True

    # ---------------------------------------------------------- operations
    def transform(self, o, T):
        """T: matrix in unrotated page coords (MuPDF)."""
        if self._needs_hoist(o, T) and self.hoist(o, T):
            return
        Tp = self._t_pdf(T)
        data = self.po.data[o.owner]
        if o.kind == "text":
            self._text_transform(o, Tp, data)
        else:
            if o.wrapped is not None:
                A_old, hdr_end = o.wrapped
                C = o.gctm
                A = mmul(mmul(mmul(A_old, C), Tp), minv(C))
                self._add(o.owner, o.grp[0], hdr_end, ("q %s cm %%aoe\n" % fmt_m(A)).encode())
            else:
                s, e = o.grp or o.rng
                C = o.gctm if o.grp else o.ctm
                A = self._A(C, Tp)
                self._add(o.owner, s, s, ("q %s cm %%aoe\n" % fmt_m(A)).encode())
                self._add(o.owner, e, e, b"\nQ")
        self._grow_forms(o, T)

    def _text_transform(self, o, Tp, data):
        blk = o.blk
        sh = blk["shows"]
        a, b = sh[o.si], sh[o.ei]
        A = self._A(a["ctm"], Tp)
        pre = (b"\nET\nBT\n" + ("%s Tm\n" % fmt_m(mmul(a["pre_tlm"], A))).encode()
               + _tj_shift(a["pre_acc"], a["state"][1], a["state"][4]))
        self._add(o.owner, a["s"], a["s"], pre)
        for (ts_, te_, M) in blk["tms"]:
            if a["s"] <= ts_ and te_ <= b["e"]:
                self._add(o.owner, ts_, te_, ("%s Tm" % fmt_m(mmul(M, A))).encode())
        post = (b"\nET\nBT\n" + ("%s Tm\n" % fmt_m(b["post_tlm"])).encode()
                + _tj_shift(b["post_acc"], b["fs"], b["th"]))
        self._add(o.owner, b["e"], b["e"], post)

    def delete(self, o):
        if o.kind == "text":
            for k in range(o.si, o.ei + 1):
                s = o.blk["shows"][k]
                rep = _tj_shift(s["adv"], s["fs"], s["th"]) or b" "
                if s["op"] == b"'":
                    rep = b"T*\n" + rep
                elif s["op"] == b'"':
                    rep = ("%s Tw %s Tc T*\n" % (fmt_num(s["aw"]), fmt_num(s["ac"]))).encode() + rep
                self._add(o.owner, s["s"], s["e"], rep)
            return
        s, e = o.grp or o.rng
        self._add(o.owner, s, e, b"\n")

    def duplicate(self, o, T):
        if self._needs_hoist(o, T) and self.hoist(o, T, keep=True):
            return
        Tp = self._t_pdf(T)
        data = self.po.data[o.owner]
        if o.kind == "text":
            blk = o.blk
            sh = blk["shows"]
            a, b = sh[o.si], sh[o.ei]
            A = self._A(a["ctm"], Tp)
            body = data[a["s"]:b["e"]]
            # transform inner Tm operators of the copy
            reps = [(ts_ - a["s"], te_ - a["s"], ("%s Tm" % fmt_m(mmul(M, A))).encode())
                    for (ts_, te_, M) in blk["tms"] if a["s"] <= ts_ and te_ <= b["e"]]
            for s0, e0, r in sorted(reps, reverse=True):
                body = body[:s0] + r + body[e0:]
            st = a["state"]
            ins = (b"\nET\nBT\n" + _state_bytes(st) + ("%s Tm\n" % fmt_m(mmul(a["pre_tlm"], A))).encode()
                   + _tj_shift(a["pre_acc"], st[1], st[4]) + body
                   + b"\nET\nBT\n" + ("%s Tm\n" % fmt_m(b["post_tlm"])).encode()
                   + _tj_shift(b["post_acc"], b["fs"], b["th"]))
            self._add(o.owner, b["e"], b["e"], ins)
        else:
            s, e = o.grp or o.rng
            C = o.gctm if o.grp else o.ctm
            A = self._A(C, Tp)
            self._add(o.owner, e, e, ("\nq %s cm %%aoe\n" % fmt_m(A)).encode() + data[s:e] + b"\nQ")
        self._grow_forms(o, T)

    def recolor(self, o, stroke=None, fill=None, width=None):
        def rgb(c, op):
            return ("%s %s %s %s" % (fmt_num(c[0]), fmt_num(c[1]), fmt_num(c[2]), op)).encode()
        if o.kind == "text":
            blk = o.blk
            a, b = blk["shows"][o.si], blk["shows"][o.ei]
            c = fill or stroke
            if c is None:
                return
            self._add(o.owner, a["s"], a["s"], b"\n" + rgb(c, "rg") + b" " + rgb(c, "RG") + b"\n")
            st = b["state"]
            restore = (st[8] + b" " if st[8] else b"") + (st[9] or b"0 g") + b" " + \
                      (st[10] + b" " if st[10] else b"") + (st[11] or b"0 G")
            self._add(o.owner, b["e"], b["e"], b"\n" + restore + b"\n")
            return
        if o.kind != "shape":
            return
        ops = []
        if stroke is not None:
            ops.append(rgb(stroke, "RG"))
        if fill is not None:
            ops.append(rgb(fill, "rg"))
        if width is not None:
            ops.append(("%s w" % fmt_num(width)).encode())
        if not ops:
            return
        s, e = o.rng
        self._add(o.owner, s, s, b"q " + b" ".join(ops) + b"\n")
        self._add(o.owner, e, e, b"\nQ")

    # ---------------------------------------------------------- write back
    def commit(self):
        doc = self.doc
        if self.tail:
            self.splices.setdefault(0, [])
        for owner, sp in self.splices.items():
            data = self.po.data[owner]
            # stable order: by start, inserts (s==e) before replacements at the same position
            sp.sort(key=lambda t: (t[0], t[1]))
            out = []
            last = 0
            for s, e, rep in sp:
                if s < last:
                    s = last
                    e = max(e, last)
                out.append(data[last:s])
                out.append(rep)
                last = e
            out.append(data[last:])
            new = b"".join(out)
            if owner == 0 and self.tail:
                if not new.startswith(b"q %aoe-wrap\n"):
                    new = (b"q %aoe-wrap\n" + new + b"\n" + b"Q\n" * getattr(self.po, "qdepth", 0)
                           + b"Q %aoe-wrap\n")
                new = new + b"\n" + b"".join(self.tail)
            z = zlib.compress(new, 1)
            if owner == 0:
                x = doc.get_new_xref()
                doc.update_object(x, "<<>>")
                doc.update_stream(x, z, compress=False)
                doc.xref_set_key(x, "Filter", "/FlateDecode")
                doc.xref_set_key(self.page.xref, "Contents", "%d 0 R" % x)
            else:
                doc.update_stream(owner, z, compress=False)
                doc.xref_set_key(owner, "DecodeParms", "null")
                doc.xref_set_key(owner, "Filter", "/FlateDecode")
        for fx, bb in self.bbox_grow.items():
            doc.xref_set_key(fx, "BBox", "[%s %s %s %s]" % tuple(fmt_num(v) for v in bb))
        return bool(self.splices) or bool(self.tail)


# ----------------------------------------------------------------------- cache
_CACHE = {}


def page_objects(pdfdoc, i):
    key = (id(pdfdoc), pdfdoc.epoch, i, pdfdoc.content_gen[i])
    po = _CACHE.get(key)
    if po is None:
        for k in [k for k in _CACHE if k[0] == id(pdfdoc) and k[2] == i]:
            _CACHE.pop(k, None)
        if len(_CACHE) > 12:
            _CACHE.pop(next(iter(_CACHE)))
        po = PageObjects(pdfdoc.doc, pdfdoc.doc.load_page(i))
        _CACHE[key] = po
    return po


def cached(pdfdoc, i):
    return _CACHE.get((id(pdfdoc), pdfdoc.epoch, i, pdfdoc.content_gen[i]))


def parse_rgb(raw):
    """Best-effort RGB of a colour operator like b'1 0 0 rg' / b'0.5 g' / b'0 0 0 1 k'."""
    try:
        parts = raw.split()
        op = parts[-1]
        vals = [float(v) for v in parts[:-1] if re.match(rb"^[-+.\d]+$", v)]
        if op in (b"rg", b"RG") and len(vals) >= 3:
            return tuple(vals[:3])
        if op in (b"g", b"G") and vals:
            return (vals[0],) * 3
        if op in (b"k", b"K") and len(vals) >= 4:
            c, m, y, k = vals[:4]
            return ((1 - c) * (1 - k), (1 - m) * (1 - k), (1 - y) * (1 - k))
        if len(vals) == 3:
            return tuple(vals)
        if len(vals) == 1:
            return (vals[0],) * 3
    except Exception:
        pass
    return (0.0, 0.0, 0.0)


def text_style(po, o):
    """(origin unrot, fontsize page units, angle deg (y-down), rgb, font resource name) of a text element."""
    a = o.blk["shows"][o.si]
    M = a["M"]
    ox, oy = mpt(M, 0, 0)
    fs_page = abs(a["fs"]) * math.hypot(M[2], M[3]) if a["fs"] else 10.0
    ang = math.degrees(math.atan2(M[1], M[0]))
    st = a["state"]
    rgb = parse_rgb(st[9]) if st[9] else (0.0, 0.0, 0.0)
    fname = (st[0] or b"").decode("latin-1").lstrip("/")
    real = ""
    try:
        x = po._res_cache.get(next((k for k in po._res_cache if k[1] == "Font" and k[2] == fname), None), 0)
        if x:
            real = po.doc.xref_get_key(x, "BaseFont")[1].lstrip("/")
    except Exception:
        real = ""
    return (ox, oy), fs_page, ang, rgb, real or fname


def base14_for(name):
    low = (name or "").lower()
    bold = "bold" in low or "black" in low or "heavy" in low
    ital = "italic" in low or "oblique" in low
    if any(k in low for k in ("times", "roman", "serif", "cambria", "georgia", "garamond")) and "sans" not in low:
        return "tibi" if bold and ital else "tibo" if bold else "tiit" if ital else "tiro"
    if "cour" in low or "mono" in low:
        return "cobi" if bold and ital else "cobo" if bold else "coit" if ital else "cour"
    return "hebi" if bold and ital else "hebo" if bold else "heit" if ital else "helv"


def dump_json(po):
    return json.dumps([(o.kind, o.owner, o.rng, [round(v, 2) for v in o.bbox]) for o in po.objs])


# ======================================================================= tool (UI)
from PySide6.QtCore import Qt, QPointF, QRectF  # noqa: E402
from PySide6.QtGui import QPen, QColor, QBrush  # noqa: E402
from PySide6.QtWidgets import QApplication, QMenu, QMessageBox, QInputDialog, QLineEdit, QColorDialog  # noqa: E402

from .tools import Tool  # noqa: E402

MODES = {"all": "All Objects", "text": "Text Elements", "image": "Images", "shape": "Shapes"}
_HANDLES = ("tl", "t", "tr", "r", "br", "b", "bl", "l")


def _union(boxes):
    return (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))


def _escape_pdf(s):
    return s.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)").replace(b"\r", b"\\r").replace(b"\n", b"\\n")


class EditObjectsTool(Tool):
    """Select, move, resize, duplicate, recolour and delete page content (text / images / shapes)."""
    name = "editobj"

    def __init__(self, main=None, mode="all", edit_text_on_click=False):
        super().__init__(main, {})
        self.mode = mode
        self.click_edit = edit_text_on_click
        self.sel_page = None
        self.sel = []
        self.hov = None
        self.drag = None
        self._pending = None

    # ------------------------------------------------------------ helpers
    def cursor(self):
        return Qt.IBeamCursor if self.click_edit else Qt.ArrowCursor

    def activate(self):
        if self.view and self.view.pdfdoc:
            self._po(self.view.current_page())
            if self.main:
                self.main.status(
                    ("Edit Text: click a text element to change it, drag to move it."
                     if self.click_edit else
                     "Edit Objects (%s): click to select, drag to move, handles to resize, Del = delete, "
                     "Ctrl+D = duplicate, right-click for colour / width." % MODES.get(self.mode, "")), 15000)

    def deactivate(self):
        self.sel = []
        self.hov = None

    def _po(self, i, parse=True):
        d = self.doc
        po = cached(d, i)
        if po is None and parse:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                if self.main:
                    self.main.status("Analysing page objects…", 0)
                    QApplication.processEvents()
                po = page_objects(d, i)
                if self.main:
                    self.main.status("%d objects on page %d (%d text, %d images, %d shapes)." % (
                        len(po.objs), i + 1, int(np.sum(po.kinds == "text")), int(np.sum(po.kinds == "image")),
                        int(np.sum(po.kinds == "shape"))), 6000)
            except Exception as ex:
                po = None
                if self.main:
                    self.main.status("Could not analyse this page: %s" % ex, 8000)
            finally:
                QApplication.restoreOverrideCursor()
        return po

    def _sel_objs(self):
        if self.sel_page is None:
            return None, []
        po = self._po(self.sel_page)
        if po is None:
            return None, []
        objs = [po.objs[k] for k in self.sel if k < len(po.objs)]
        return po, objs

    def _view_rect(self, i, bb):
        return self.view.unrot_rect_to_view(i, bb)

    def _handles(self):
        po, objs = self._sel_objs()
        if not objs:
            return []
        r = self._view_rect(self.sel_page, _union([o.bbox for o in objs]))
        c = r.center()
        pts = {"tl": r.topLeft(), "t": QPointF(c.x(), r.top()), "tr": r.topRight(), "r": QPointF(r.right(), c.y()),
               "br": r.bottomRight(), "b": QPointF(c.x(), r.bottom()), "bl": r.bottomLeft(), "l": QPointF(r.left(), c.y())}
        return [(k, pts[k]) for k in _HANDLES]

    @staticmethod
    def _opposite(h):
        return {"tl": "br", "t": "b", "tr": "bl", "r": "l", "br": "tl", "b": "t", "bl": "tr", "l": "r"}[h]

    def _unrot(self, i, qp):
        h = self.view.hit_unrot(qp, clamp_page=i)
        return (h[1], h[2]) if h else None

    # ------------------------------------------------------------ mouse
    def press(self, e):
        if e.button() != Qt.LeftButton:
            return
        v = self.view
        pos = e.position()
        h = v.hit_unrot(pos)
        if not h:
            self.sel = []
            v.viewport().update()
            return
        i, x, y = h
        if self.sel and self.sel_page == i:
            for hid, hp in self._handles():
                if (hp - pos).manhattanLength() <= 7:
                    anchor = dict(self._handles())[self._opposite(hid)]
                    self.drag = {"type": "resize", "page": i, "h": hid, "a": self._unrot(i, anchor),
                                 "o": self._unrot(i, hp), "cur": self._unrot(i, hp), "v0": pos}
                    return
        po = self._po(i)
        if po is None:
            return
        k = po.hit(x, y, v.view_tol_pt(i, 4), self.mode)
        mods = e.modifiers()
        if k >= 0:
            if mods & (Qt.ControlModifier | Qt.ShiftModifier):
                if self.sel_page != i:
                    self.sel = []
                self.sel_page = i
                if k in self.sel:
                    self.sel.remove(k)
                else:
                    self.sel.append(k)
            elif self.sel_page != i or k not in self.sel:
                self.sel = [k]
                self.sel_page = i
            self.drag = {"type": "move", "page": i, "start": (x, y), "cur": (x, y), "v0": pos, "hit": k}
        else:
            if not (mods & (Qt.ControlModifier | Qt.ShiftModifier)):
                self.sel = []
            self.sel_page = i
            self.drag = {"type": "band", "page": i, "start": (x, y), "cur": (x, y), "v0": pos, "v1": pos}
        v.viewport().update()

    def move(self, e):
        v = self.view
        pos = e.position()
        d = self.drag
        if d:
            p = self._unrot(d["page"], pos)
            if p:
                d["cur"] = p
            d["v1"] = pos
            v.viewport().update()
            return
        # hover feedback
        cur = self.cursor()
        for hid, hp in self._handles():
            if (hp - pos).manhattanLength() <= 7:
                cur = (Qt.SizeFDiagCursor if hid in ("tl", "br") else Qt.SizeBDiagCursor if hid in ("tr", "bl")
                       else Qt.SizeHorCursor if hid in ("l", "r") else Qt.SizeVerCursor)
                break
        h = v.hit_unrot(pos)
        hov = None
        if h and cur == self.cursor():
            i, x, y = h
            po = self._po(i, parse=(i == v.current_page()))
            if po is not None:
                k = po.hit(x, y, v.view_tol_pt(i, 4), self.mode)
                if k >= 0:
                    hov = (i, k)
                    if not (self.click_edit and po.objs[k].kind == "text"):
                        cur = Qt.SizeAllCursor
        if hov != self.hov:
            self.hov = hov
            v.viewport().update()
        v.viewport().setCursor(cur)

    def release(self, e):
        d = self.drag
        self.drag = None
        if not d:
            return
        v = self.view
        moved = (e.position() - d["v0"]).manhattanLength() > 3
        i = d["page"]
        if d["type"] == "move":
            if moved:
                (x0, y0), (x1, y1) = d["start"], d["cur"]
                dx, dy = x1 - x0, y1 - y0
                if e.modifiers() & Qt.ShiftModifier:
                    if abs(dx) > abs(dy):
                        dy = 0
                    else:
                        dx = 0
                self.apply("move", (1, 0, 0, 1, dx, dy))
            elif self.click_edit:
                po = self._po(i)
                if po and len(self.sel) == 1 and po.objs[self.sel[0]].kind == "text":
                    self.edit_text()
        elif d["type"] == "resize":
            T = self._resize_matrix(d, e.modifiers() & Qt.ShiftModifier)
            if T is not None and moved:
                self.apply("move", T)
        elif d["type"] == "band":
            po = self._po(i)
            if po is not None and moved:
                (x0, y0), (x1, y1) = d["start"], d["cur"]
                r = (min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))
                crossing = d["v1"].x() < d["v0"].x()
                ks = po.in_rect(r, self.mode, touch=crossing)
                for k in ks:
                    if k not in self.sel:
                        self.sel.append(k)
                self.sel_page = i
                if self.main:
                    self.main.status("%d object(s) selected." % len(self.sel), 4000)
        v.viewport().update()

    def _resize_matrix(self, d, keep_ratio):
        a, o, c = d["a"], d["o"], d["cur"]
        if not (a and o and c):
            return None
        ox, oy = o[0] - a[0], o[1] - a[1]
        sx = (c[0] - a[0]) / ox if abs(ox) > 1e-6 else 1.0
        sy = (c[1] - a[1]) / oy if abs(oy) > 1e-6 else 1.0
        if keep_ratio or d["h"] in ("tl", "tr", "bl", "br") and self._all_kind("image"):
            if abs(ox) > 1e-6 and abs(oy) > 1e-6:
                s = max(abs(sx), abs(sy))
                sx = math.copysign(s, sx)
                sy = math.copysign(s, sy)
        if abs(sx) < 0.02 or abs(sy) < 0.02:
            return None
        return mmul(mmul((1, 0, 0, 1, -a[0], -a[1]), (sx, 0, 0, sy, 0, 0)), (1, 0, 0, 1, a[0], a[1]))

    def _all_kind(self, kind):
        po, objs = self._sel_objs()
        return bool(objs) and all(o.kind == kind for o in objs)

    def double_click(self, e):
        po, objs = self._sel_objs()
        if len(objs) == 1 and objs[0].kind == "text":
            self.edit_text()

    # ------------------------------------------------------------ keys / menu
    def _view_delta(self, dxv, dyv):
        i = self.sel_page
        c = self.view.viewport().rect().center()
        p0 = self._unrot(i, QPointF(c))
        p1 = self._unrot(i, QPointF(c.x() + dxv, c.y() + dyv))
        if not (p0 and p1):
            return 0.0, 0.0
        return p1[0] - p0[0], p1[1] - p0[1]

    def _pt_delta(self, dxv, dyv, pts):
        """Direction of a view-space vector, length pts (page units)."""
        ux, uy = self._view_delta(dxv * 50, dyv * 50)
        L = math.hypot(ux, uy)
        if L < 1e-9:
            return 0.0, 0.0
        return ux / L * pts, uy / L * pts

    def wants_key(self, e):
        k = e.key()
        ctrl = bool(e.modifiers() & Qt.ControlModifier)
        if k in (Qt.Key_Delete, Qt.Key_Backspace, Qt.Key_Left, Qt.Key_Right, Qt.Key_Up, Qt.Key_Down):
            return bool(self.sel)
        if ctrl and k == Qt.Key_D:
            return bool(self.sel)
        if ctrl and k == Qt.Key_A:
            return True
        return False

    def key(self, e):
        k = e.key()
        mods = e.modifiers()
        if k == Qt.Key_Escape:
            if self.sel:
                self.sel = []
                self.view.viewport().update()
                return True
            return super().key(e)
        if not self.sel:
            if k == Qt.Key_A and mods & Qt.ControlModifier:
                self.select_all()
                return True
            return False
        if k in (Qt.Key_Delete, Qt.Key_Backspace):
            self.apply("delete")
            return True
        if k == Qt.Key_D and mods & Qt.ControlModifier:
            self.duplicate()
            return True
        if k == Qt.Key_A and mods & Qt.ControlModifier:
            self.select_all()
            return True
        arrows = {Qt.Key_Left: (-1, 0), Qt.Key_Right: (1, 0), Qt.Key_Up: (0, -1), Qt.Key_Down: (0, 1)}
        if k in arrows:
            step = 10.0 if mods & Qt.ShiftModifier else 1.0
            dx, dy = self._pt_delta(*arrows[k], step)
            self.apply("move", (1, 0, 0, 1, dx, dy))
            return True
        return False

    def select_all(self):
        v = self.view
        i = v.current_page()
        po = self._po(i)
        if po is None:
            return
        self.sel_page = i
        self.sel = [int(k) for k in np.nonzero(po.mask_for(self.mode))[0]]
        if self.main:
            self.main.status("%d object(s) selected." % len(self.sel), 4000)
        v.viewport().update()

    def duplicate(self):
        dx, dy = self._pt_delta(1, 1, 10.0)
        self.apply("dup", (1, 0, 0, 1, dx, dy))

    def context(self, e):
        v = self.view
        pos = QPointF(e.pos())
        h = v.hit_unrot(pos)
        if h:
            i, x, y = h
            po = self._po(i)
            if po is not None:
                k = po.hit(x, y, v.view_tol_pt(i, 4), self.mode)
                if k >= 0 and (self.sel_page != i or k not in self.sel):
                    self.sel, self.sel_page = [k], i
                    v.viewport().update()
        m = QMenu(v)
        po, objs = self._sel_objs()
        if objs:
            kinds = {o.kind for o in objs}
            if len(objs) == 1 and "text" in kinds:
                m.addAction("Edit text…", self.edit_text)
            m.addAction("Delete\tDel", lambda: self.apply("delete"))
            m.addAction("Duplicate\tCtrl+D", self.duplicate)
            m.addSeparator()
            if "shape" in kinds:
                m.addAction("Line colour…", lambda: self._pick_color("stroke"))
                m.addAction("Fill colour…", lambda: self._pick_color("fill"))
                m.addAction("Line width…", self._pick_width)
            if "text" in kinds:
                m.addAction("Text colour…", lambda: self._pick_color("fill", text=True))
            m.addSeparator()
        m.addAction("Select all (%s) on this page\tCtrl+A" % MODES.get(self.mode, ""), self.select_all)
        sub = m.addMenu("Edit objects of type")
        for key, label in MODES.items():
            a = sub.addAction(label, lambda k=key: self._set_mode(k))
            a.setCheckable(True)
            a.setChecked(key == self.mode)
        m.exec(e.globalPos())
        return True

    def _set_mode(self, mode):
        self.mode = mode
        self.sel = []
        if self.main and hasattr(self.main, "editobj_mode"):
            self.main.editobj_mode = mode
        self.view.viewport().update()

    def _pick_color(self, which, text=False):
        c = QColorDialog.getColor(QColor(220, 30, 30), self.view, "Colour")
        if not c.isValid():
            return
        rgb = (c.redF(), c.greenF(), c.blueF())
        if text:
            self.apply("color", fill=rgb)
        elif which == "stroke":
            self.apply("color", stroke=rgb)
        else:
            self.apply("color", fill=rgb)

    def _pick_width(self):
        po, objs = self._sel_objs()
        cur = next((o.lw for o in objs if o.kind == "shape"), 1.0)
        w, ok = QInputDialog.getDouble(self.view, "Line width", "Line width (pt):", float(cur), 0.0, 100.0, 2)
        if ok:
            self.apply("color", width=w)

    # ------------------------------------------------------------ editing
    def apply(self, op, T=None, **kw):
        po, objs = self._sel_objs()
        if not objs:
            return
        i = self.sel_page
        d = self.doc
        order = sorted(range(len(objs)), key=lambda k: (objs[k].owner, objs[k].rng[0]))
        d.checkpoint()
        page = d.page(i)
        ed = Editor(po, page)
        expected = []
        try:
            for k in order:
                o = objs[k]
                if op == "move":
                    ed.transform(o, T)
                    expected.append((o.kind, bbox_of(T, *o.bbox)))
                elif op == "dup":
                    ed.duplicate(o, T)
                    expected.append((o.kind, bbox_of(T, *o.bbox)))
                elif op == "delete":
                    ed.delete(o)
                elif op == "color":
                    ed.recolor(o, stroke=kw.get("stroke"), fill=kw.get("fill"), width=kw.get("width"))
                    expected.append((o.kind, o.bbox))
            ed.commit()
        except Exception as ex:
            QMessageBox.warning(self.main, "Edit objects", "The change could not be applied:\n%s" % ex)
            try:
                d.undo()
            except Exception:
                pass
            return
        d.commit([i])
        self.sel = []
        self.hov = None
        self._reselect(i, expected)
        if self.main and op == "delete":
            self.main.status("%d object(s) deleted (Ctrl+Z to undo)." % len(objs), 5000)

    def _reselect(self, i, expected):
        if not expected:
            self.view.viewport().update()
            return
        po = self._po(i)
        if po is None or not len(po.objs):
            return
        b = po.bx
        sel = []
        for kind, bb in expected:
            tol = 1.5 + 0.02 * max(bb[2] - bb[0], bb[3] - bb[1])
            dd = np.abs(b - np.array(bb)).max(axis=1)
            cand = np.nonzero((dd <= tol) & (po.kinds == kind))[0]
            if len(cand):
                k = int(cand[np.argmin(dd[cand])])
                if k not in sel:
                    sel.append(k)
        self.sel = sel
        self.sel_page = i
        self.view.viewport().update()

    def edit_text(self):
        po, objs = self._sel_objs()
        if len(objs) != 1 or objs[0].kind != "text":
            return
        o = objs[0]
        k = self.sel[0]
        old = po.text_of(k).replace("\n", " ")
        new, ok = QInputDialog.getText(self.main, "Edit text", "Text:", QLineEdit.Normal, old)
        if not ok or new == old:
            return
        i = self.sel_page
        d = self.doc
        d.checkpoint()
        page = d.page(i)
        try:
            if not self._edit_in_place(po, o, page, new):
                origin, fs, ang, rgb, fname = text_style(po, o)
                ed = Editor(po, page)
                ed.delete(o)
                ed.commit()
                try:
                    page = d.doc.reload_page(page)
                except Exception:
                    page = d.doc[page.number]
                if new.strip():
                    kw = {}
                    if abs(ang) > 0.05:
                        kw["morph"] = (pymupdf.Point(origin), pymupdf.Matrix(ang))
                    page.insert_text(pymupdf.Point(origin), new, fontsize=fs, fontname=base14_for(fname),
                                     color=rgb, **kw)
        except Exception as ex:
            QMessageBox.warning(self.main, "Edit text", str(ex))
            try:
                d.undo()
            except Exception:
                pass
            return
        d.commit([i])
        self.sel = []
        self._reselect(i, [("text", o.bbox)])

    def _edit_in_place(self, po, o, page, new):
        """Keep the original font when the new text only needs characters the font already has."""
        sh = o.blk["shows"]
        if o.si != o.ei:
            return False
        a = sh[o.si]
        fname = a["state"][0]
        if not fname:
            return False
        fx = po._res(o.blk.get("res") or ("page", po.page_xref), "Font", fname[1:].decode("latin-1"))
        fi = po._fonts.get(fx)
        if fi is None or fi.two:
            return False
        try:
            enc = new.encode("cp1252")
        except UnicodeEncodeError:
            return False
        subset = "+" in (fi.name or "")
        data = po.data[o.owner]
        old_codes = set()
        mm = _TOK.match(data, a["s"])
        if subset:
            # codes already shown by this element are certainly in the subset
            seg = data[a["s"]:a["e"]]
            for m2 in re.finditer(rb"\((?:\\.|[^\\)])*\)|<[0-9A-Fa-f\s]*>", seg):
                t = m2.group(0)
                b = hex_string(t) if t.startswith(b"<") else lit_string(t, 1)[0]
                old_codes.update(b)
            for c in enc:
                k = c - fi.first
                ok = c in old_codes or (0 <= k < len(fi.widths) and fi.widths[k] > 0)
                if not ok:
                    return False
        _ = mm
        body = b"(" + _escape_pdf(enc) + b") Tj"
        if a["op"] == b"'":
            body = b"T* " + body
        elif a["op"] == b'"':
            body = ("%s Tw %s Tc T* " % (fmt_num(a["aw"]), fmt_num(a["ac"]))).encode() + body
        ed = Editor(po, page)
        ed._add(o.owner, a["s"], a["e"], body)
        ed.commit()
        return True

    # ------------------------------------------------------------ painting
    def paint(self, p):
        if self.hov and (self.hov[0] != self.sel_page or self.hov[1] not in self.sel):
            po = cached(self.doc, self.hov[0])
            if po is not None and self.hov[1] < len(po.objs):
                p.setPen(QPen(QColor(255, 120, 0), 1, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRect(self._view_rect(self.hov[0], po.objs[self.hov[1]].bbox))
        d = self.drag
        po, objs = self._sel_objs() if self.sel else (None, [])
        if objs:
            i = self.sel_page
            T = None
            if d and d["type"] == "move":
                (x0, y0), (x1, y1) = d["start"], d["cur"]
                T = (1, 0, 0, 1, x1 - x0, y1 - y0)
            elif d and d["type"] == "resize":
                T = self._resize_matrix(d, False)
            pen = QPen(QColor(31, 91, 216), 1)
            p.setPen(pen)
            p.setBrush(QColor(31, 91, 216, 22))
            many = len(objs) > 1500
            boxes = [o.bbox for o in objs]
            if not many:
                for bb in boxes:
                    p.drawRect(self._view_rect(i, bb))
            u = _union(boxes)
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(QColor(31, 91, 216), 1, Qt.DashLine))
            p.drawRect(self._view_rect(i, u))
            if T is not None:
                p.setPen(QPen(QColor(220, 30, 30), 1, Qt.DashLine))
                p.setBrush(QColor(220, 30, 30, 25))
                for bb in (boxes if not many else [u]):
                    p.drawRect(self._view_rect(i, bbox_of(T, *bb)))
            else:
                p.setPen(QPen(QColor(31, 91, 216), 1))
                p.setBrush(QBrush(QColor(255, 255, 255)))
                for hid, hp in self._handles():
                    p.drawRect(QRectF(hp.x() - 3.5, hp.y() - 3.5, 7, 7))
        if d and d["type"] == "band":
            r = QRectF(d["v0"], d["v1"]).normalized()
            crossing = d["v1"].x() < d["v0"].x()
            col = QColor(0, 150, 60) if crossing else QColor(31, 91, 216)
            p.setPen(QPen(col, 1, Qt.DashLine if crossing else Qt.SolidLine))
            col.setAlpha(30)
            p.setBrush(col)
            p.drawRect(r)
