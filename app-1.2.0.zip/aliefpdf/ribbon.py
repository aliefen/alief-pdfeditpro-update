"""Small ribbon implementation (tabs -> groups -> large / small buttons)."""
from PySide6.QtCore import Qt, QSize
from PySide6.QtWidgets import (QTabWidget, QWidget, QHBoxLayout, QVBoxLayout, QGridLayout, QToolButton, QLabel,
                               QSizePolicy, QFrame, QScrollArea)


class RibbonGroup(QWidget):
    def __init__(self, title):
        super().__init__()
        self.setObjectName("RibbonGroup")
        v = QVBoxLayout(self)
        v.setContentsMargins(4, 2, 6, 1)
        v.setSpacing(0)
        self.grid = QGridLayout()
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setHorizontalSpacing(1)
        self.grid.setVerticalSpacing(0)
        v.addLayout(self.grid, 1)
        lab = QLabel(title)
        lab.setObjectName("RibbonGroupTitle")
        lab.setAlignment(Qt.AlignCenter)
        v.addWidget(lab)
        self.col = 0
        self.row = 0
        self.small_col_open = False

    def _btn(self, action, large, menu=None, popup=False):
        b = QToolButton()
        b.setDefaultAction(action)
        if large:
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setIconSize(QSize(28, 28))
            b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        else:
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setIconSize(QSize(16, 16))
            b.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        if menu is not None:
            b.setMenu(menu)
            b.setPopupMode(QToolButton.MenuButtonPopup if popup else QToolButton.InstantPopup)
        return b

    def add_large(self, action, menu=None, popup=False):
        if self.small_col_open:
            self.col += 1
            self.row = 0
            self.small_col_open = False
        b = self._btn(action, True, menu, popup)
        self.grid.addWidget(b, 0, self.col, 3, 1)
        self.col += 1
        return b

    def add_small(self, action, menu=None, popup=False):
        b = self._btn(action, False, menu, popup)
        self.grid.addWidget(b, self.row, self.col)
        self.small_col_open = True
        self.row += 1
        if self.row >= 3:
            self.row = 0
            self.col += 1
            self.small_col_open = False
        return b

    def add_widget(self, w, rows=1):
        self.grid.addWidget(w, self.row, self.col, rows, 1)
        self.small_col_open = True
        self.row += rows
        if self.row >= 3:
            self.row = 0
            self.col += 1
            self.small_col_open = False
        return w

    def new_column(self):
        if self.small_col_open:
            self.col += 1
            self.row = 0
            self.small_col_open = False


class RibbonPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("RibbonPage")
        self.h = QHBoxLayout(self)
        self.h.setContentsMargins(4, 3, 4, 2)
        self.h.setSpacing(2)
        self.h.addStretch(1)

    def group(self, title):
        g = RibbonGroup(title)
        self.h.insertWidget(self.h.count() - 1, g)
        return g


class Ribbon(QTabWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("Ribbon")
        self.setDocumentMode(True)
        self.setFixedHeight(134)

    def page(self, title):
        p = RibbonPage()
        sa = QScrollArea()
        sa.setWidget(p)
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setStyleSheet("QScrollArea{background:#FBFCFE;border:none;}"
                         "QScrollBar:horizontal{height:7px;background:#EEF2F7;border:none;}"
                         "QScrollBar::handle:horizontal{background:#B9C4D3;border-radius:3px;min-width:30px;}"
                         "QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{width:0;}")
        self.addTab(sa, title)
        return p
