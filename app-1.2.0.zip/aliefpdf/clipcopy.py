"""Copy selected text so that tables arrive as tables.

The clipboard gets three flavours:
* text/plain - tab separated values (Excel fills rows and columns, Notepad keeps the layout)
* text/html  - a real <table> (Word builds a table, Excel fills cells, merged cells kept)
* the plain selected text when the selection is not a table.
"""
import html
import re

import pymupdf
from PySide6.QtCore import QMimeData

from .convert import _cell_text


def _bbox(words):
    return (min(w[0] for w in words), min(w[1] for w in words), max(w[2] for w in words), max(w[3] for w in words))


def _inside(w, r, tol=1.0):
    cx, cy = (w[0] + w[2]) / 2, (w[1] + w[3]) / 2
    return r[0] - tol <= cx <= r[2] + tol and r[1] - tol <= cy <= r[3] + tol


# ------------------------------------------------------------------ ruled tables
def _ruled_grid(page, sel, all_words):
    """Grid from tables drawn with lines (find_tables), restricted to the selected cells."""
    R = _bbox(sel)
    clip = pymupdf.Rect(R) + (-40, -40, 40, 40)
    try:
        lines = [d for d in page.get_drawings() if pymupdf.Rect(d["rect"]).intersects(clip)]
    except Exception:
        lines = [1]
    if not lines:
        return None
    try:
        tables = page.find_tables(clip=clip, strategy="lines").tables
    except Exception:
        return None
    if not tables:
        return None
    sel_r = (R[0] - 1, R[1] - 1, R[2] + 1, R[3] + 1)
    rows_out = []
    header_rows = set()
    covered = 0
    for t in tables:
        grid_rows = []
        for ri, row in enumerate(t.rows):
            cells = row.cells
            picked = []
            for ci, c in enumerate(cells):
                if c is None:
                    picked.append((ci, None))
                    continue
                cx, cy = (c[0] + c[2]) / 2, (c[1] + c[3]) / 2
                has_sel = any(c[0] <= (w[0] + w[2]) / 2 <= c[2] and c[1] <= (w[1] + w[3]) / 2 <= c[3] for w in sel)
                empty = not any(c[0] <= (w[0] + w[2]) / 2 <= c[2] and c[1] <= (w[1] + w[3]) / 2 <= c[3]
                                for w in all_words)
                if has_sel or (empty and sel_r[0] <= cx <= sel_r[2] and sel_r[1] <= cy <= sel_r[3]):
                    picked.append((ci, c))
                else:
                    picked.append((ci, False))
            grid_rows.append(picked)
        # columns / rows that hold at least one selected cell
        cols = sorted({ci for r in grid_rows for ci, c in r if c})
        rows_idx = [k for k, r in enumerate(grid_rows) if any(c for _, c in r)]
        if not cols or not rows_idx:
            continue
        c0, c1 = cols[0], cols[-1]
        hdr = getattr(t, "header", None)
        for k in rows_idx:
            r = grid_rows[k]
            out = []
            ci = c0
            while ci <= c1:
                c = r[ci][1] if ci < len(r) else False
                if c is None:            # continuation of a merged cell
                    out.append((None, 0))
                    ci += 1
                    continue
                if c is False:
                    out.append(("", 1))
                    ci += 1
                    continue
                span = 1
                while ci + span <= c1 and ci + span < len(r) and r[ci + span][1] is None:
                    span += 1
                txt = _cell_text(all_words, c)
                covered += sum(1 for w in sel if _inside(w, c))
                out.append((txt, span))
                out.extend([(None, 0)] * (span - 1))
                ci += span
            if k == 0 and hdr is not None and not getattr(hdr, "external", True):
                header_rows.add(len(rows_out))
            rows_out.append(out)
        rows_out.append(None)            # blank line between tables
    while rows_out and rows_out[-1] is None:
        rows_out.pop()
    if not rows_out:
        return None
    # the table route only when (nearly) all selected words sit in table cells
    if covered < 0.8 * len(sel):
        return None
    ncols = max(len(r) for r in rows_out if r)
    if ncols < 2 and sum(1 for r in rows_out if r) < 2:
        return None
    return rows_out, header_rows


# ------------------------------------------------------------------ text tables
def _columns(spans, gap=2.0):
    """Merge horizontally overlapping x-intervals; the gaps between them are column gutters."""
    cols = []
    for a, b in sorted(spans):
        if cols and a <= cols[-1][1] + gap:
            cols[-1][1] = max(cols[-1][1], b)
        else:
            cols.append([a, b])
    return cols
def _rows_of(sel):
    words = sorted(sel, key=lambda w: (round((w[1] + w[3]) / 2 / 3), w[0]))
    rows, cur, cy = [], [], None
    for w in words:
        y = (w[1] + w[3]) / 2
        h = w[3] - w[1]
        if cy is None or abs(y - cy) <= max(2.0, h * 0.45):
            cur.append(w)
            cy = y if cy is None else (cy + y) / 2
        else:
            rows.append(sorted(cur, key=lambda q: q[0]))
            cur, cy = [w], y
    if cur:
        rows.append(sorted(cur, key=lambda q: q[0]))
    return rows


def _phrases(r, factor=0.6):
    phr = []
    for w in r:
        if phr and w[0] - phr[-1][2] < (w[3] - w[1]) * factor:
            p = phr[-1]
            phr[-1] = [p[0], min(p[1], w[1]), w[2], max(p[3], w[3]), p[4] + " " + w[4]]
        else:
            phr.append([w[0], w[1], w[2], w[3], w[4]])
    return phr


def _assign(rows_items, cols, structural=None):
    out = []
    for ri, r in enumerate(rows_items):
        line = [""] * len(cols)
        if structural is not None and not structural[ri]:
            line[0] = " ".join(p[4] for p in r)      # title / note line: one cell
            out.append(line)
            continue
        for p in r:
            cx = (p[0] + p[2]) / 2
            k = min(range(len(cols)), key=lambda j: 0 if cols[j][0] <= cx <= cols[j][1]
                    else min(abs(cx - cols[j][0]), abs(cx - cols[j][1])))
            line[k] = (line[k] + " " + p[4]).strip()
        out.append(line)
    return out


def _is_num(t):
    return bool(_NUM.match((t or "").strip()))


def _cleanup(grid, cols):
    """Merge header fragments: columns used by a single row, and wrapped header lines."""
    if len(grid) >= 3:
        changed = True
        while changed and len(cols) > 2:
            changed = False
            filled = [sum(1 for r in grid if r[j]) for j in range(len(cols))]
            for j in range(len(cols)):
                if filled[j] <= 1:
                    left = cols[j][0] - cols[j - 1][1] if j > 0 else 1e9
                    right = cols[j + 1][0] - cols[j][1] if j + 1 < len(cols) else 1e9
                    frag = next((r[j] for r in grid if r[j]), "")
                    if j > 0 and frag[:1] in "([/%-":
                        t = j - 1          # "(mm)", "(IDR)", "/ unit" continue the label on the left
                    else:
                        t = j - 1 if left <= right else j + 1
                    for r in grid:
                        if r[j]:
                            r[t] = (r[t] + " " + r[j]).strip() if t < j else (r[j] + " " + r[t]).strip()
                    cols[t] = [min(cols[t][0], cols[j][0]), max(cols[t][1], cols[j][1])]
                    del cols[j]
                    for r in grid:
                        del r[j]
                    changed = True
                    break
    # a wrapped header line: few, non-numeric cells right under a fuller row
    out = []
    merged_hdr = False
    for r in grid:
        n = sum(1 for c in r if c)
        if out:
            prev = out[-1]
            pn = sum(1 for c in prev if c)
            if (len(out) == 1 and not merged_hdr and n >= 1 and n <= max(1, len(r) // 4) and pn >= len(r) / 2
                    and pn >= 2 and all(not _is_num(c) for c in r if c) and all(not _is_num(c) for c in prev if c)
                    and not r[0]):
                merged_hdr = True
                for j, c in enumerate(r):
                    if c:
                        prev[j] = (prev[j] + " " + c).strip()
                continue
        out.append(r)
    return out


def _score(grid):
    if not grid:
        return -1
    ncol = len(grid[0])
    multi = [r for r in grid if sum(1 for c in r if c) >= 2]
    if len(multi) < 2 or ncol < 2:
        return -1
    fill = sum(sum(1 for c in r if c) for r in multi) / float(len(multi) * ncol)
    return ncol * min(1.0, fill / 0.6)


def _text_grid(sel):
    """Rows / columns from word positions (tables without lines). Several column guesses, best one wins."""
    rows = _rows_of(sel)
    if len(rows) < 2:
        return None
    cands = []
    phr_rows = [_phrases(r) for r in rows]
    # table body = from the first to the last row with 3+ phrases; lines above / below it
    # (titles, notes) stay one cell, body lines are placed by position
    many = [k for k, r in enumerate(phr_rows) if len(r) >= 3]
    if not many:
        many = [k for k, r in enumerate(phr_rows) if len(r) >= 2]
    if len(many) < 2:
        return None
    k0, k1 = many[0], many[-1]
    body = [k0 <= k <= k1 or len(phr_rows[k]) >= 3 for k in range(len(rows))]
    pcols = [r for k, r in enumerate(phr_rows) if body[k] and len(r) >= 2]
    if len(pcols) >= 2:
        cols = _columns([(p[0], p[2]) for r in pcols for p in r])
        if len(cols) >= 2:
            cands.append(_cleanup(_assign(phr_rows, cols, body), [c[:] for c in cols]))
    wrows = [[[w[0], w[1], w[2], w[3], w[4]] for w in r] for r in rows]
    wcols = [r for k, r in enumerate(wrows) if body[k] and len(r) >= 2]
    if len(wcols) >= 2:
        cols = _columns([(w[0], w[2]) for r in wcols for w in r], gap=0.4)
        if 2 <= len(cols) <= 40:
            cands.append(_cleanup(_assign(wrows, cols, body), [c[:] for c in cols]))
    best = None
    for g in cands:
        sc = _score(g)
        if sc > 0 and (best is None or sc > best[0] + 1e-9):
            best = (sc, g)
    if best is None:
        return None
    grid = best[1]
    if len(grid[0]) < 2:
        return None
    return [[(c, 1) for c in r] for r in grid], set()


# ------------------------------------------------------------------ public
def table_from_selection(page, sel, all_words, allow_text_tables=True):
    """(rows, header_rows) or None. rows: list of [(text, colspan) | (None, 0)] or None for a blank line."""
    if not sel or len(sel) < 2:
        return None
    g = _ruled_grid(page, sel, all_words)
    if g is not None:
        ncol = max(len(r) for r in g[0] if r)
        if ncol <= 2 and allow_text_tables:
            t = _text_grid(sel)
            if t is not None and len(t[0][0]) > ncol:
                return t
        return g
    if allow_text_tables:
        return _text_grid(sel)
    return None


def _tsv_cell(t):
    t = t or ""
    if any(ch in t for ch in "\t\n\""):
        return '"' + t.replace('"', '""') + '"'
    return t


def to_tsv(rows):
    lines = []
    for r in rows:
        if r is None:
            lines.append("")
            continue
        lines.append("\t".join(_tsv_cell(t) if t is not None else "" for t, _ in r))
    return "\r\n".join(lines) + "\r\n"


_NUM = re.compile(r"^[-+(]?[\d.,]+%?\)?$")


def to_html(rows, header_rows=()):
    out = ['<html><head><meta charset="utf-8"></head><body>',
           '<table border="1" cellspacing="0" cellpadding="4" '
           'style="border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:10pt;">']
    for k, r in enumerate(rows):
        if r is None:
            out.append("</table><br><table border=\"1\" cellspacing=\"0\" cellpadding=\"4\" "
                       "style=\"border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:10pt;\">")
            continue
        tag = "th" if k in header_rows else "td"
        cells = []
        for t, span in r:
            if t is None:
                continue
            style = "border:1px solid #808080;vertical-align:top;"
            if tag == "th":
                style += "background:#DCE6F2;font-weight:bold;"
            if t and _NUM.match(t.strip()):
                style += "text-align:right;"
            attrs = ' colspan="%d"' % span if span > 1 else ""
            cells.append('<%s%s style="%s">%s</%s>' % (tag, attrs, style, html.escape(t).replace("\n", "<br>"), tag))
        out.append("<tr>" + "".join(cells) + "</tr>")
    out.append("</table></body></html>")
    return "".join(out)


def make_mime(page, sel, all_words, plain_text, mode="auto"):
    """QMimeData for a text selection. mode: auto | table | text. Returns (mime, is_table)."""
    md = QMimeData()
    g = None
    if mode in ("auto", "table"):
        try:
            g = table_from_selection(page, sel, all_words, allow_text_tables=True)
        except Exception:
            g = None
    if g is not None:
        rows, hdr = g
        md.setText(to_tsv(rows))
        md.setHtml(to_html(rows, hdr))
        return md, len([r for r in rows if r])
    md.setText(plain_text)
    return md, 0
