"""PDF security: inspect, remove restrictions / known passwords, add protection.

The remover works like Mgsoft PDF Password Remover:
  * permission ("owner") passwords that only restrict printing / copying / editing are
    removed directly - the file can be opened, so it is simply rewritten without encryption;
  * files with an open ("user") password are decrypted when the password is supplied.
Unknown open passwords are NOT cracked.
"""
import os

import pymupdf

STATUS_PLAIN = "Not protected"
STATUS_RESTRICT = "Restrictions (owner password)"
STATUS_OPENPW = "Open password required"


def inspect(path):
    """Return dict(status, method, perms, pages, signed) without needing a password."""
    info = {"path": path, "status": "?", "method": "", "pages": 0, "signed": False, "error": ""}
    try:
        doc = pymupdf.open(path)
    except Exception as e:
        info["status"] = "Cannot open"
        info["error"] = str(e)
        return info
    try:
        meta = doc.metadata or {}
        info["method"] = meta.get("encryption") or ""
        if doc.needs_pass:
            info["status"] = STATUS_OPENPW
        elif doc.is_encrypted or info["method"]:
            info["status"] = STATUS_RESTRICT
        else:
            info["status"] = STATUS_PLAIN
        if not doc.needs_pass:
            info["pages"] = doc.page_count
            info["perms"] = doc.permissions
            info["signed"] = _has_signature(doc)
    finally:
        doc.close()
    return info


def _has_signature(doc):
    try:
        if not doc.is_form_pdf:
            return False
        for page in doc:
            for w in page.widgets():
                if w.field_type == pymupdf.PDF_WIDGET_TYPE_SIGNATURE:
                    return True
    except Exception:
        pass
    return False


def remove_security(path, out_path, password=None):
    """Write an unencrypted copy. Returns (ok: bool, message: str)."""
    try:
        doc = pymupdf.open(path)
    except Exception as e:
        return False, "Cannot open: %s" % e
    try:
        if doc.needs_pass:
            if not password:
                return False, "Open password required - enter the password in the Password box"
            if not doc.authenticate(password):
                return False, "Wrong password"
        was = bool(doc.is_encrypted or (doc.metadata or {}).get("encryption"))
        signed = _has_signature(doc)
        same = os.path.normcase(os.path.abspath(path)) == os.path.normcase(os.path.abspath(out_path))
        tmp = out_path + ".tmp_alief"
        doc.save(tmp, encryption=pymupdf.PDF_ENCRYPT_NONE, garbage=1, deflate=True)
        doc.close()
        if same:
            bak = path + ".bak"
            try:
                if os.path.exists(bak):
                    os.remove(bak)
                os.replace(path, bak)
            except Exception:
                pass
        os.replace(tmp, out_path)
        msg = "Unlocked" if was else "Saved (file had no security)"
        if signed:
            msg += " - note: digital signature(s) in this file are no longer valid"
        return True, msg
    except Exception as e:
        try:
            doc.close()
        except Exception:
            pass
        return False, str(e)


def protect(doc, out_path, user_pw="", owner_pw="", perms=None, method="AES-256"):
    enc = {"AES-256": pymupdf.PDF_ENCRYPT_AES_256, "AES-128": pymupdf.PDF_ENCRYPT_AES_128,
           "RC4-128": pymupdf.PDF_ENCRYPT_RC4_128}[method]
    if perms is None:
        perms = pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_PRINT_HQ | pymupdf.PDF_PERM_ACCESSIBILITY
    if not owner_pw:
        owner_pw = user_pw or os.urandom(9).hex()
    doc.save(out_path, encryption=enc, owner_pw=owner_pw, user_pw=user_pw or None, permissions=perms,
             garbage=1, deflate=True)
    return out_path
