"""Object snap (OSnap) engine built from the vector content of a PDF page.

All coordinates are unrotated PDF page coordinates (points, y downwards), the
same space used by PyMuPDF for drawings, words and annotations.

The index is built in a background *process* (heavy CAD pages have hundreds of
thousands of lines) and queried through a uniform grid, so a query costs the
same on a 10-line page and on a 250 000-line general arrangement.
"""
import math
import os
import sys
import threading

import numpy as np

KINDS = ("end", "intersection", "center", "quadrant", "mid", "perpendicular", "nearest")
PRIORITY = {k: i for i, k in enumerate(KINDS)}
CELL = 24.0          # grid cell size in points
BIG_CELLS = 64       # segments covering more cells than this are kept in a small "big" list


# ======================================================================= build
def _circle3(a, b, c):
    ax, ay = a
    bx, by = b
    cx, cy = c
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-9:
        return None
    ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d
    uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d
    return ux, uy, math.hypot(ax - ux, ay - uy)


_TS = np.linspace(0.0, 1.0, 9)
_B0 = (1 - _TS) ** 3
_B1 = 3 * (1 - _TS) ** 2 * _TS
_B2 = 3 * (1 - _TS) * _TS ** 2
_B3 = _TS ** 3


def build_arrays(page):
    """Return dict of numpy arrays (segs, ends, mids, centers, quads) for a pymupdf page."""
    try:
        paths = page.get_cdrawings()
        raw = True
    except Exception:
        paths = page.get_drawings()
        raw = False
    lines = []      # x1 y1 x2 y2
    curves = []     # 8 numbers (4 control points)
    centers = []
    quads = []
    for path in paths:
        items = path.get("items")
        if not items:
            continue
        # full circles (CAD circles = 2..4 bezier arcs forming a closed square-bbox path)
        if len(items) >= 2 and all(it[0] == "c" for it in items):
            bb = path.get("rect")
            if bb is not None:
                x0, y0, x1, y1 = (bb if raw else (bb.x0, bb.y0, bb.x1, bb.y1))
                f = items[0][1]
                l = items[-1][4]
                fx, fy = (f if raw else (f.x, f.y))
                lx, ly = (l if raw else (l.x, l.y))
                w, h = x1 - x0, y1 - y0
                if w > 0.5 and abs(fx - lx) < 0.5 and abs(fy - ly) < 0.5 and abs(w - h) <= 0.04 * max(w, h) + 0.3:
                    cx, cy, r = (x0 + x1) / 2, (y0 + y1) / 2, (w + h) / 4
                    centers.append((cx, cy))
                    quads.extend(((cx + r, cy), (cx - r, cy), (cx, cy + r), (cx, cy - r)))
        for it in items:
            k = it[0]
            if k == "l":
                a, b = it[1], it[2]
                if raw:
                    lines.append((a[0], a[1], b[0], b[1]))
                else:
                    lines.append((a.x, a.y, b.x, b.y))
            elif k == "re":
                r = it[1]
                x0, y0, x1, y1 = (r if raw else (r.x0, r.y0, r.x1, r.y1))
                lines.extend(((x0, y0, x1, y0), (x1, y0, x1, y1), (x1, y1, x0, y1), (x0, y1, x0, y0)))
                if x1 - x0 > 1 and y1 - y0 > 1:
                    centers.append(((x0 + x1) / 2, (y0 + y1) / 2))
            elif k == "qu":
                q = it[1]
                if raw:
                    pts = [q[0], q[1], q[3], q[2]]
                else:
                    pts = [(q.ul.x, q.ul.y), (q.ur.x, q.ur.y), (q.lr.x, q.lr.y), (q.ll.x, q.ll.y)]
                for j in range(4):
                    a, b = pts[j], pts[(j + 1) % 4]
                    lines.append((a[0], a[1], b[0], b[1]))
            elif k == "c":
                if raw:
                    curves.append((it[1][0], it[1][1], it[2][0], it[2][1], it[3][0], it[3][1], it[4][0], it[4][1]))
                else:
                    curves.append((it[1].x, it[1].y, it[2].x, it[2].y, it[3].x, it[3].y, it[4].x, it[4].y))
    L = np.asarray(lines, dtype=np.float64).reshape(-1, 4)
    C = np.asarray(curves, dtype=np.float64).reshape(-1, 8)
    seg_parts = [L]
    end_parts = [L[:, 0:2], L[:, 2:4]]
    mid_parts = [(L[:, 0:2] + L[:, 2:4]) / 2]
    if len(C):
        # sample every curve at 9 points (vectorised)
        X = (np.outer(C[:, 0], _B0) + np.outer(C[:, 2], _B1) + np.outer(C[:, 4], _B2) + np.outer(C[:, 6], _B3))
        Y = (np.outer(C[:, 1], _B0) + np.outer(C[:, 3], _B1) + np.outer(C[:, 5], _B2) + np.outer(C[:, 7], _B3))
        segs = np.stack([X[:, :-1], Y[:, :-1], X[:, 1:], Y[:, 1:]], axis=2).reshape(-1, 4)
        seg_parts.append(segs)
        end_parts += [C[:, 0:2], C[:, 6:8]]
        mid_parts.append(np.stack([X[:, 4], Y[:, 4]], 1))
        # arc centres: circle through samples 0, 4, 8 checked at 2 and 6
        ax, ay, bx, by, cx, cy = X[:, 0], Y[:, 0], X[:, 4], Y[:, 4], X[:, 8], Y[:, 8]
        d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
        ok = np.abs(d) > 1e-9
        with np.errstate(divide="ignore", invalid="ignore"):
            a2 = ax * ax + ay * ay
            b2 = bx * bx + by * by
            c2 = cx * cx + cy * cy
            ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
            uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
            r = np.hypot(ax - ux, ay - uy)
            e2 = np.abs(np.hypot(X[:, 2] - ux, Y[:, 2] - uy) - r)
            e6 = np.abs(np.hypot(X[:, 6] - ux, Y[:, 6] - uy) - r)
        ok &= (r > 0.5) & (r < 5000) & (e2 <= 0.03 * r + 0.05) & (e6 <= 0.03 * r + 0.05)
        if ok.any():
            centers.extend(np.stack([ux[ok], uy[ok]], 1).tolist())
    segs = np.concatenate(seg_parts) if seg_parts else np.zeros((0, 4))
    ends = np.concatenate(end_parts) if end_parts else np.zeros((0, 2))
    if len(ends):
        ends = np.unique(np.round(ends, 3), axis=0)
    mids = np.concatenate(mid_parts) if mid_parts else np.zeros((0, 2))
    cen = np.asarray(centers, dtype=np.float64).reshape(-1, 2)
    if len(cen):
        cen = np.unique(np.round(cen, 2), axis=0)
    qd = np.asarray(quads, dtype=np.float64).reshape(-1, 2)
    return {"segs": segs, "ends": ends, "mids": mids, "centers": cen, "quads": qd}


def build_from_source(source, page_no, password=None):
    """Worker entry point: source is a file path or PDF bytes."""
    import pymupdf
    doc = pymupdf.open(source) if isinstance(source, str) else pymupdf.open("pdf", source)
    if doc.needs_pass and password:
        doc.authenticate(password)
    try:
        return build_arrays(doc.load_page(page_no))
    finally:
        doc.close()


# ======================================================================= grid
class _PointGrid:
    def __init__(self, pts):
        self.pts = pts
        if len(pts):
            cx = np.floor(pts[:, 0] / CELL).astype(np.int64)
            cy = np.floor(pts[:, 1] / CELL).astype(np.int64)
            key = cx * 1000003 + cy
            order = np.argsort(key, kind="stable")
            self.keys = key[order]
            self.idx = order
        else:
            self.keys = np.zeros(0, np.int64)
            self.idx = np.zeros(0, np.int64)

    def candidates(self, x, y, tol):
        if not len(self.keys):
            return self.idx
        out = []
        for cx in range(int(math.floor((x - tol) / CELL)), int(math.floor((x + tol) / CELL)) + 1):
            for cy in range(int(math.floor((y - tol) / CELL)), int(math.floor((y + tol) / CELL)) + 1):
                k = cx * 1000003 + cy
                lo = np.searchsorted(self.keys, k, "left")
                hi = np.searchsorted(self.keys, k, "right")
                if hi > lo:
                    out.append(self.idx[lo:hi])
        return np.concatenate(out) if out else self.idx[:0]


class _SegGrid:
    def __init__(self, segs):
        self.segs = segs
        n = len(segs)
        if not n:
            self.keys = np.zeros(0, np.int64)
            self.vals = np.zeros(0, np.int64)
            self.big = np.zeros(0, np.int64)
            return
        x0 = np.floor(np.minimum(segs[:, 0], segs[:, 2]) / CELL).astype(np.int64)
        x1 = np.floor(np.maximum(segs[:, 0], segs[:, 2]) / CELL).astype(np.int64)
        y0 = np.floor(np.minimum(segs[:, 1], segs[:, 3]) / CELL).astype(np.int64)
        y1 = np.floor(np.maximum(segs[:, 1], segs[:, 3]) / CELL).astype(np.int64)
        nx = x1 - x0 + 1
        ny = y1 - y0 + 1
        cnt = nx * ny
        small = cnt <= BIG_CELLS
        sidx = np.nonzero(small)[0]
        c = cnt[sidx]
        rep = np.repeat(sidx, c)
        start = np.repeat(np.cumsum(c) - c, c)
        k = np.arange(rep.size, dtype=np.int64) - start
        nxr = nx[rep]
        cx = x0[rep] + k % nxr
        cy = y0[rep] + k // nxr
        key = cx * 1000003 + cy
        order = np.argsort(key, kind="stable")
        self.keys = key[order]
        self.vals = rep[order]
        self.big = np.nonzero(~small)[0]

    def candidates(self, x, y, tol):
        out = [self.big]
        if len(self.keys):
            for cx in range(int(math.floor((x - tol) / CELL)), int(math.floor((x + tol) / CELL)) + 1):
                for cy in range(int(math.floor((y - tol) / CELL)), int(math.floor((y + tol) / CELL)) + 1):
                    kk = cx * 1000003 + cy
                    lo = np.searchsorted(self.keys, kk, "left")
                    hi = np.searchsorted(self.keys, kk, "right")
                    if hi > lo:
                        out.append(self.vals[lo:hi])
        if len(out) == 1:
            return self.big
        return np.unique(np.concatenate(out))


class SnapIndex:
    def __init__(self, arrays):
        self.segs = arrays["segs"]
        self.ends = arrays["ends"]
        self.mids = arrays["mids"]
        self.centers = arrays["centers"]
        self.quads = arrays["quads"]
        self.g_segs = _SegGrid(self.segs)
        self.g_pts = {k: _PointGrid(getattr(self, k)) for k in ("ends", "mids", "centers", "quads")}

    @staticmethod
    def from_page(page):
        return SnapIndex(build_arrays(page))

    # ------------------------------------------------------------------ query
    def query(self, x, y, tol, modes, last=None, extra_points=None):
        """Return (kind, (sx, sy)) of the best snap within tol, or None."""
        best = []

        def near_pts(arr, idx, kind):
            if not modes.get(kind, False) or idx is None or not len(idx):
                return
            P = arr[idx]
            d = np.hypot(P[:, 0] - x, P[:, 1] - y)
            j = int(d.argmin())
            if d[j] <= tol:
                best.append((PRIORITY[kind], float(d[j]), kind, (float(P[j, 0]), float(P[j, 1]))))

        for name, kind in (("ends", "end"), ("centers", "center"), ("quads", "quadrant"), ("mids", "mid")):
            if modes.get(kind):
                near_pts(getattr(self, name), self.g_pts[name].candidates(x, y, tol), kind)
        if extra_points and modes.get("end"):
            ep = np.asarray(extra_points, dtype=float).reshape(-1, 2)
            near_pts(ep, np.arange(len(ep)), "end")

        need = modes.get("intersection") or modes.get("nearest") or (modes.get("perpendicular") and last)
        if need and len(self.segs):
            idx = self.g_segs.candidates(x, y, tol)
            if len(idx):
                S = self.segs[idx]
                ax, ay, bx, by = S[:, 0], S[:, 1], S[:, 2], S[:, 3]
                vx, vy = bx - ax, by - ay
                L2 = vx * vx + vy * vy
                L2s = np.where(L2 < 1e-12, 1e-12, L2)
                t = np.clip(((x - ax) * vx + (y - ay) * vy) / L2s, 0, 1)
                px, py = ax + t * vx, ay + t * vy
                d = np.hypot(px - x, py - y)
                close = d <= tol
                if close.any():
                    ci = np.nonzero(close)[0]
                    order = ci[np.argsort(d[ci])][:200]
                    if modes.get("nearest"):
                        j = order[0]
                        best.append((PRIORITY["nearest"], float(d[j]), "nearest", (float(px[j]), float(py[j]))))
                    if modes.get("perpendicular") and last is not None:
                        lx, ly = last
                        tt = ((lx - ax[order]) * vx[order] + (ly - ay[order]) * vy[order]) / L2s[order]
                        ok = (tt >= 0) & (tt <= 1) & (L2[order] > 1e-6)
                        fx = ax[order] + tt * vx[order]
                        fy = ay[order] + tt * vy[order]
                        fd = np.hypot(fx - x, fy - y)
                        ok &= fd <= tol
                        if ok.any():
                            k = int(np.argmin(np.where(ok, fd, np.inf)))
                            best.append((PRIORITY["perpendicular"], float(fd[k]), "perpendicular", (float(fx[k]), float(fy[k]))))
                    if modes.get("intersection") and len(order) > 1:
                        o = order[:100]
                        A = np.stack([ax[o], ay[o]], 1)
                        V = np.stack([vx[o], vy[o]], 1)
                        den = V[:, None, 0] * V[None, :, 1] - V[:, None, 1] * V[None, :, 0]
                        dA = A[None, :, :] - A[:, None, :]
                        with np.errstate(divide="ignore", invalid="ignore"):
                            tt = (dA[..., 0] * V[None, :, 1] - dA[..., 1] * V[None, :, 0]) / den
                            uu = (dA[..., 0] * V[:, None, 1] - dA[..., 1] * V[:, None, 0]) / den
                        eps = 1e-6
                        valid = (np.abs(den) > 1e-9) & (tt >= -eps) & (tt <= 1 + eps) & (uu >= -eps) & (uu <= 1 + eps)
                        valid &= np.triu(np.ones_like(valid, dtype=bool), 1)
                        if valid.any():
                            ii, jj = np.nonzero(valid)
                            IX = A[ii, 0] + tt[ii, jj] * V[ii, 0]
                            IY = A[ii, 1] + tt[ii, jj] * V[ii, 1]
                            dd = np.hypot(IX - x, IY - y)
                            k = int(np.argmin(dd))
                            if dd[k] <= tol:
                                best.append((PRIORITY["intersection"], float(dd[k]), "intersection", (float(IX[k]), float(IY[k]))))
        if not best:
            return None
        best.sort(key=lambda b: (b[0], b[1]))
        return best[0][2], best[0][3]


# ===================================================================== builder
class SnapBuilder:
    """Builds snap indexes off the UI thread (process pool, falls back to a thread)."""

    def __init__(self):
        self._pool = None
        self._pool_failed = False
        self._lock = threading.Lock()

    def _get_pool(self):
        if self._pool is None and not self._pool_failed:
            try:
                import multiprocessing as mp
                import concurrent.futures as cf
                if not getattr(sys, "frozen", False):
                    exe = os.path.basename(sys.executable).lower()
                    if not exe.startswith("python"):
                        # embedded launcher: run workers with the bundled interpreter
                        for cand in ("pythonw.exe", "python.exe", "python3"):
                            p = os.path.join(sys.exec_prefix, cand)
                            if os.path.exists(p):
                                mp.set_executable(p)
                                break
                ctx = mp.get_context("spawn")
                self._pool = cf.ProcessPoolExecutor(max_workers=1, mp_context=ctx)
            except Exception:
                self._pool_failed = True
                self._pool = None
        return self._pool

    def submit(self, source, page_no, password, done):
        """done(arrays or None) is called from a worker thread."""
        pool = self._get_pool()
        if pool is not None:
            try:
                fut = pool.submit(build_from_source, source, page_no, password)

                def cb(f):
                    try:
                        done(f.result())
                    except Exception:
                        # e.g. the pool died: retry in a thread
                        self._pool_failed = True
                        self._pool = None
                        threading.Thread(target=lambda: done(_safe_build(source, page_no, password)), daemon=True).start()
                fut.add_done_callback(cb)
                return
            except Exception:
                self._pool_failed = True
                self._pool = None
        threading.Thread(target=lambda: done(_safe_build(source, page_no, password)), daemon=True).start()

    def shutdown(self):
        if self._pool is not None:
            try:
                self._pool.shutdown(wait=False, cancel_futures=True)
            except Exception:
                pass


def _safe_build(source, page_no, password):
    try:
        return build_from_source(source, page_no, password)
    except Exception:
        return None


BUILDER = SnapBuilder()
